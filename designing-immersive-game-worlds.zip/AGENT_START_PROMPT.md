# Copy/paste this to the next coding agent

> You are taking over an existing, working project called **SOLVARA**. Do **not** rebuild it from scratch and do **not** replace the world with a demo.
>
> First read `HANDOFF.md` in the project root. It is the source of truth for the architecture, game mechanics, controls, known issues, test history, and the meaning of the user's earlier "Option A" / "Option B" references.
>
> Then inspect the repo and reproduce the current state before making changes:
>
> 1. Install dependencies if needed.
> 2. Run the TypeScript check and production build.
> 3. Load the app in a browser and confirm the Main Menu with login, profile creation, Explore & Evolve, the alien third-person world, the Stage 1 Proto-Goo HUD, and the Evolution Chamber all appear without errors.
>
> Current product:
>
> - React + Vite + TypeScript + Tailwind + Three.js r187, single-file build.
> - Third-person alien open world with 10 regions, two suns, a ringed gas giant, procedural terrain/flora/water/sky, day-night cycle, biome particles, and mobile touch controls.
> - Spore-like gameplay: start as a bioluminescent slime, hunt 10 fictional alien species, absorb DNA, grow, and choose diet-driven traits that physically mutate the 3D player body.
> - Main Menu with local sign-in, saved profiles, species naming/color, Quick Play, and New Proto-Goo reset. Login is local-only and not secure backend auth.
> - 4 DNA lineages, 11 traits, 6 cumulative stage anatomy layers, HP/armor/bite/spit/speed/jump/glide stats, world map fast travel, and biome discovery.
> - Aliens now fight back with a telegraph → charge → strike → recover loop. Player hits produce red damage vignette, camera shake, knockback, and hurt audio.
>
> Important constraints:
>
> - Preserve exact rendered-triangle terrain placement (`sampleRenderedTerrain` / `getRenderedTerrainHeight` / `ChunkField.sample`). Do not revert visible objects to analytical `getTerrainHeight`.
> - Keep `customProgramCacheKey` on shader-material factories and keep the `aGlow` terrain attribute on every mesh using the terrain material.
> - Keep mobile iOS/Android touch support and the loading/error screen.
> - Do not edit `package.json` or `vite.config.ts` directly; install new packages with npm.
> - TypeScript is strict about unused imports/variables.
> - Always run `npx tsc --noEmit` and `npm run build` before finishing.
> - Update `HANDOFF.md` after any significant feature or bug fix.
>
> Known issues to be aware of:
>
> - `E` is currently overloaded as both melee attack and camera orbit.
> - `onEvolutionReady` is not wired to auto-open the Evolution Modal.
> - HP is not persisted in the local profile.
> - World Map generation can stall briefly on slow/software GPUs.
> - Real iOS/Android devices have not been tested.
>
> The user builds step-by-step and expects complete, functional changes rather than questions asking for confirmation. Make targeted changes, keep the rest of the game intact, and give a short summary of what you changed.
>
> If you only have chat access and cannot read files, ask the user to paste `HANDOFF.md` and the relevant source files, or upload `solvara-handoff.zip`.

---

## If the agent has repository access

Send this shorter message instead:

> Start by reading `HANDOFF.md` and `AGENT_START_PROMPT.md` at the project root. Reproduce the current build, then tell me you are ready before changing anything. Do not rebuild from scratch.

---

## What to give the agent

Give them one of these:

1. **Best:** the whole project folder, excluding `node_modules`, with `HANDOFF.md` and `AGENT_START_PROMPT.md` included.
2. **Easiest:** `solvara-handoff.zip` from the project root.
3. **If only chat is available:** paste this prompt plus the full contents of `HANDOFF.md`, then provide files as the agent requests them.

The archive includes `dist/index.html` as the last known-good built output, but the agent should still run the build from source.


## New in the latest handoff

- **Drop Atlas & Landing Vista (`DropZoneMap.tsx`):** Battle Royale lobby now renders a 340×340 hill-shaded terrain atlas with the opening safe ring + a first-person ground-level landing preview, plus a 3rd-person sky-drop descent for the player and AI pilots.
- **Visible 3D Bio-Storm & Warnings (`rivals.ts`):** `zoneStartRadius` is 780 m (all 10 spread drop spots start inside), with a tall translucent 3D storm wall, top halo ring, 40 horizon beacons, and a 10-second pre-shrink warning banner.
- **Skill Matchmaking + Custom Lobby (`MainMenuModal.tsx`, `BattleRoyaleLobby.tsx`, `evolution.ts`):** Quick Matchmaking auto-queues by skill bracket (`MM-S0`..`S9`) for 12s then fills with AI; Custom Lobby lets friends join by code (`BroadcastChannel` for tabs, optional `node lobby-server.mjs` + `?ws=ws://host:8787` for devices).
- **Sleeker HUD & Higher Open World Cap:** Open World supports up to 24 pilots; in-game HUD is compacted with an eye details toggle and bottom icon dock.
- **Next Tasks Ready to Build (`HANDOFF.md` Section 18):**
  1. Start Battle Royale with a varied/randomized start+end storm center and as a **fresh Stage 1 normal blob** (keeping Open World persistent).
  2. Auto-evolve in Battle Royale with a quick non-blocking trait popup.
  3. Gate jumping behind leg traits and flying behind strong wings, scaling strength & flight time with size.
  4. Higher-detail evolution graphics, tentacles positioned **below** the player, stronger "turn into what you eat" morphology, and a **3-ability active loadout cap** based on diet/traits.
  5. Mobile-game style Main Menu + Blob Customization & Store + Dynamic World Events + ultra-clear in-game screen.

Read `HANDOFF.md` (especially Sections 16–18) before changing code. Keep exact terrain placement, shader `customProgramCacheKey`s, and the `aGlow` terrain attribute intact.
