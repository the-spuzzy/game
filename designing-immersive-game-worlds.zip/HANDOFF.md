# SOLVARA — Engineering Handoff

## 1. Project at a glance

**SOLVARA** is a browser-based, mobile-minded, third-person alien open-world game with a **Spore-like creature-evolution loop**.

The player begins as a small bioluminescent slime / goo organism, hunts imaginary alien wildlife, absorbs DNA, evolves through stages, and chooses diet-driven traits that visibly mutate the 3D body.

### Current product state

- **Stack:** React 19, Vite 7, TypeScript, Tailwind CSS 4, Three.js r187, Lucide icons.
- **Output:** `vite-plugin-singlefile` produces one self-contained `dist/index.html`.
- **Target:** desktop browsers plus iOS / Android-style touch controls.
- **Theme:** alien world, not Earth. Ten regions, two suns, a ringed gas giant, nebulae, aurorae, alien flora, ten made-up animal species.
- **Entry point:** `src/App.tsx`; 3D engine lives in `src/world/engine.ts`.
- **Last verified:** `npx tsc --noEmit` and `npm run build` pass. Latest build produced `dist/index.html` ≈ 1.14 MB, ≈ 312 KB gzip.
- **Browser smoke test:** headless Chrome verified login, profile creation, world load, HUD, and Evolution Modal with zero page/console errors on software WebGL. **No real iPhone/Android device test has been performed.**

---

## 2. How to run

```text
npm install
npm run dev       # local dev server
npm run build     # production single-file build
npm run preview   # serve build
```

Do not edit `package.json` or `vite.config.ts` directly unless explicitly instructed; use `npm install <package>` for new dependencies.

TypeScript is strict about unused imports/variables: small leftover declarations can break `npx tsc --noEmit`.

---

## 3. Important history / user intent

The user has been building this step-by-step:

1. **Original world:** realistic, immersive, third-person open world for iOS/Android.
2. **More trees/bushes, correct height, better graphics:** exact triangle-ground placement, denser flora, PBR foliage, HDR bloom, MSAA, IBL, cloud shadows.
3. **Immersion / more regions:** user asked for jungle, forest plains, snowy mountains, barren wastelands. There was no literal "Option B" file in the repo; the world was expanded into a **10-region alien map**.
4. **"B doesn't load":** reproduced a startup crash in headless Chrome. Root cause was a negative modulo in `createGasGiantTexture` in `src/world/sky.ts`. Fixed with positive modulo. Added loading screen, error screen, startup chunk optimization, blocked tall plants from the opening camera view, dark-pine color fix, ground-glow fix, and shader cache-key fixes.
5. **"Main menu with login / play like Spore":** added `MainMenuModal`, local sign-in, persistent profiles, slime/goo organism, hunting, DNA, diet-driven evolution, trait selection, 11 3D mutations, and trait stats.
6. **"Option A / evolve looks / aliens attack back":** interpreted Option A as **evolution visuals**. Added cumulative stage anatomy for stages 1–6 and a full telegraph/charge/strike/recover alien combat AI.

If a future user references "Option A" or "Option B" and no new option files exist, refer to this section and ask for clarification if needed.

---

## 4. File map

### Root / app shell

| File | Role |
|---|---|
| `index.html` | Page title `SOLVARA — Alien Open World`, mobile viewport/safe-area meta, Google fonts, inline SVG favicon. |
| `src/main.tsx` | React root mount. |
| `src/index.css` | Tailwind import, fullscreen/touch-safe styles, compass/banner/loading animations. |
| `src/App.tsx` | React state, engine lifecycle, Main Menu, HUD, modals, damage vignette, profile persistence callback, keyboard shortcuts. |
| `HANDOFF.md` | This document. |

### UI components (`src/components/`)

| File | Role |
|---|---|
| `MainMenuModal.tsx` | Create account / log in / Quick Play / saved profiles / profile dashboard / species name & color / New Proto-Goo reset / diet guide. |
| `EvolutionModal.tsx` | Genome/diet chamber, current stats, diet breakdown, 3 trait cards, 3D body mutation descriptions, Evolve button. |
| `WorldMapModal.tsx` | Hill-shaded topographic canvas map, 10 biome pins, player marker, fast travel, waypoint, discovery count. |
| `AtmospherePopover.tsx` | Time-of-day presets, day-cycle pause, camera presets, `High`/`Ultra HDR` graphics, mobile touch-control toggle. |
| `CompassBar.tsx` | Compass tape, cardinal directions, region/altitude, waypoint marker. |
| `MobileControls.tsx` | Left joystick; right Run, Spit, Bite, Jump/Glide buttons. |

### World systems (`src/world/`)

| File | Role |
|---|---|
| `engine.ts` | WebGL renderer, camera, input, physics, game loop, combat, evolution integration, HUD snapshot, post-processing, audio callbacks. |
| `evolution.ts` | All gameplay data: essences, traits, prey info, stage names, slime stats, diet-based trait choices, local user profiles. |
| `character.ts` | 3D third-person slime: translucent body, nucleus, eyes, all 11 trait rigs, 6 stage anatomy layers, squash/stretch, attack/spit/evolution FX. |
| `wildlife.ts` | Ten alien species, pooled instanced rendering, behavior, ranged/melee combat hooks, DNA orbs, target lock, **attack-back AI**, campfires. |
| `creatures.ts` | Procedural low-poly geometry for all ten species and instanced `PartBatch` helper. |
| `biomes.ts` | Ten-region layout, terrain height/color/glow, exact rendered-triangle height, water level, world radius, diet-independent world data. |
| `chunkManager.ts` | Streams 72 m terrain chunks, caches per-chunk height/biome field, places alien flora, rocks, colliders, water, LOD groups. |
| `foliage.ts` | Earth-shaped plant geometries turned alien via neutralized textures and instance-color tinting; wind, glow, backlit SSS. |
| `textures.ts` | Procedural canvas textures: leaves, pine boughs, fronds, bark, birch bark, bushes, grass, flowers, contact shadow. |
| `alienFlora.ts` | Alien plant geometries: capspires, mushroom clusters, coilwood, bulb lanterns, tube corals, crystals, shards, bone spires; glowing PBR materials. |
| `materials.ts` | Terrain PBR shader: micro-detail, cliff strata, cloud shadows, aerial haze, `aGlow` bioluminescence, fog replacement. |
| `sky.ts` | Sky shader, two suns, ringed gas giant, two moons, aurorae, nebulae, PMREM environment, sun/shadow/fog lighting. |
| `water.ts` | Alien water shader: teal shallows, violet abyss, caustics, sun sparkle, glowing plankton at night. |
| `particles.ts` | Biome particles, footstep puffs, water ripples. |
| `audio.ts` | Procedural Web Audio: alien drones, chirps, night pulses, creature calls, bite/spit/hurt/DNA/evolution sounds, footsteps. |
| `noise.ts` | Deterministic simplex/FBM/ridged noise, hash, clamp/lerp/smoothstep. |

---

## 5. World design

### Ten regions (`src/world/biomes.ts`)

`WORLD_MAP_RADIUS = 900`, `CHUNK_SIZE = 72`, `WATER_LEVEL = 0`.

| Id | Name | Theme |
|---|---|---|
| `meadow` | Lumen Vale | Teal bioluminescent moss meadows; starting region. |
| `plains` | Driftgrass Steppes | Coral prairie, grazer herds, longstriders, titans. |
| `forest` | Spirecap Woods | Giant glowing mushrooms and violet spire-pines. |
| `jungle` | Verdigris Tangle | Dense emerald alien jungle, rivers, karst towers. |
| `alpine` | Cryo Spires | Lilac snow, crystal mountains, prism crabs. |
| `autumn` | Crimson Highlands | Scarlet bloom ridges. |
| `wasteland` | Ashen Rift | Obsidian badlands, glowing rift canyons, bone spires. |
| `desert` | Rust Dunes | Iron-red sands, mesas, spinepods, teal oasis. |
| `coast` | Glass Shoals | Pearl-lavender beaches, tube corals, sea crystals. |
| `wetland` | Glowmire | Black-water channels, glowing moss, willow-like flora. |

### Terrain rules

- `getTerrainHeight(x, z)` is the analytical generator.
- `sampleRenderedTerrain(x, z, outNormal?, cellSize?)` returns the **exact barycentric height/normal of the rendered Three.js PlaneGeometry triangle**.
- `getRenderedTerrainHeight` and `getRenderedTerrainNormal` wrap that function.
- **Always use rendered height for visible objects, player, camera, wildlife, foliage, particles, and campfires.** Using analytical height can cause >1 m floating/sinking on steep terrain.
- `ChunkField` in `chunkManager.ts` caches one height/biome sample per terrain vertex; object placement reads that cached grid.
- Desktop grid: 48 segments per chunk / 1.5 m cells. Mobile: 36 segments / 2.0 m cells. Both divide `CHUNK_SIZE / 2 = 36`.
- `setActiveTerrainCellSize` must be called before the chunk field is used; `ChunkManager` does this in its constructor.
- `computeTerrainGlow` writes a `vec4 aGlow` attribute: RGB glow color + fissure mask. Both near chunks and the horizon mesh must provide this attribute or the terrain shader will fail.

### Sky / rendering

- ACES Filmic tone mapping, SRGB output, `PCFShadowMap` (not `PCFSoftShadowMap`, removed in Three r187).
- Ultra: `EffectComposer` with HalfFloat render target, 4× MSAA, `RenderPass`, subtle `UnrealBloomPass`, `OutputPass`.
- High: direct `renderer.render`.
- PMREM environment from a procedural sky sphere.
- Materials with `onBeforeCompile` use `customProgramCacheKey`; do not remove it. Foliage, alien flora, creature rim, and terrain variants otherwise share the wrong compiled shader constants.
- Plant textures are neutralized to luminance then tinted by instance color. Dark textures use `neutralGain` (e.g., pine 9.0, frond 3.6) to avoid black foliage.
- All textures are procedural canvas textures; no external image assets besides Google fonts.

---

## 6. Game flow and controls

### Flow

1. App mounts canvas and defers engine construction by one frame + 40 ms.
2. Loading bar / error panel appear in `MainMenuModal`.
3. `SolvaraWorldEngine` builds sky, water, foliage, chunks, slime, particles, wildlife, audio, post-processing.
4. Saved profile is loaded into the engine if present.
5. User clicks **Explore & Evolve** → `startExploration()`.
6. Intro cinematic camera blends down into third-person spring-arm camera.
7. Player hunts wildlife, gains DNA, evolves, explores/fast-travels, manages HP.

### Desktop controls

| Input | Action |
|---|---|
| `WASD` / arrows | Move |
| `Shift` | Sprint |
| `Space` | Jump; hold while falling to glide if `glide_wings` trait is owned |
| `F` | Bite / lunge |
| `R` | Spit bio-plasma |
| `V` | Evolution Chamber |
| `M` | World Map |
| `T` | Atmosphere / graphics / touch controls |
| `H` | Hide/show HUD |
| Drag mouse | Orbit camera |
| Wheel | Zoom |
| `Q` / `E` | Camera orbit (legacy) |

**Known conflict:** `E` is currently also mapped to melee attack in `onKeyDown`. See Known Issues.

### Touch controls

- Auto-enabled on coarse-pointer/touch devices; toggleable in `AtmospherePopover`.
- Left analog joystick, right Run / Spit / Bite / Jump buttons.
- Jump button reports hold state via `setTouchJumpHeld`, needed for glide-wing slow fall.
- Drag on canvas orbits camera; two-finger pinch zooms.
- `safe-top`, `safe-bottom`, `safe-left`, `safe-right` CSS classes handle iOS notches.

---

## 7. Login and persistence

Implemented in `src/world/evolution.ts`; **local-only, no backend**.

- Keys: `solvara_accounts_v1`, `solvara_active_user_v1`.
- `UserProfile` stores username, displayName, passwordHash, speciesName, baseColorHex, stage, dna, traits, stageDiet, totalDiet, kills, discoveredBiomes, lastLoginAt.
- `simpleHash` is a non-cryptographic FNV-style hash. **Not secure authentication.**
- `registerOrLoginAccount`, `getActiveAccount`, `saveProfileProgress`, `resetProfileOrganism`, `logoutActiveAccount`, `loadAllAccounts`.
- `App.tsx` passes `onProgressSaved` to the engine; devour/evolution/biome discovery triggers save.
- **Current HP is not persisted**; it resets to max HP on reload.
- Quick Play creates/logs into an `Explorer` guest profile.
- Main Menu supports multiple saved local profiles, switching accounts, and spawning a fresh Stage 1 Proto-Goo.

---

## 8. Evolution and player appearance

### Core data (`evolution.ts`)

- Four essences: `gelatinous` (Bio-Goo), `predator`, `chitin` (Carapace), `aerial` (Aero-Fin).
- `STAGE_NAMES`: Proto-Goo, Mutant Symbiote, Xeno-Stalker, Bio-Ravager, Apex Leviathan, Elder Behemoth.
- `getDnaRequiredForStage(stage) = 80 + (stage-1)*55`.
- `computeSlimeStats(stage, traits, speciesName, color, dna, stageDiet, totalDiet, kills, currentHp?)` returns `SlimeEvolutionState`.
- Base Stage 1: 100 HP, 20 bite, 15 spit, speed 1.0, scale ≈0.76.
- Traits add maxHp, biteDamage, spitDamage, speed, jump, armor, glide, and scale.
- `getDietTraitChoices(ownedTraits, stageDiet, totalDiet)` returns three trait cards biased toward the most-eaten essence of the current stage. The stage diet resets after each evolution.

### Eleven traits

| Essence | Traits |
|---|---|
| Predator | Razor Mandibles, Raptor Scythe-Arms, Bioluminescent Spine Crest |
| Chitin | Prism Crystal Carapace, Arachnid Stilt-Legs, Obsidian Crusher Claws |
| Gelatinous | Voltaic Whip-Tentacles, Bio-Plasma Spitter Sacs, Tri-Ocular Sensor Stalks |
| Aerial | Glidewing Membranes, Propulsion Tail-Fluke |

`TRAITS` also stores `visualMutation`, `gameplayEffect`, accent colors, tint colors, and stat bonuses. `EvolutionModal` displays three choices with diet tags and 3D body mutation descriptions.

### 3D slime (`character.ts`)

`setAppearance(baseColorHex, traits, targetScale, stage)` is called from `engine.ts` on init, profile load, devour, and evolve. **Always pass stage** so stage anatomy updates.

Trait rigs are separate groups; `syncTraitVisibility()` toggles them. All are animated: mandibles snap, stilt legs stride, tentacles undulate, wings flap, tail whips, eyes wobble.

Stage anatomy groups are cumulative and verified to show `1 → 2 → 3 → 4 → 5 → 6` visible groups:

1. Stage 1: base translucent dome, nucleus, organelles, two eyes.
2. Stage 2: glowing membrane nodules/ridges.
3. Stage 3: faceted carapace plates.
4. Stage 4: nutrient sacs and twin crest horns.
5. Stage 5: six orbiting biomass lobes and large crystal back-spines.
6. Stage 6: Elder crown ring and eight crystal spires.

`bodyPivot` squash/stretch handles slither, hop, swim, glide, lunge, spit recoil, and evolution burst. `attackWaveMesh`, `evoAuraMesh`, `contactShadow`, and `bioLight` are pooled on the character.

Stage visuals clamp to six groups, but `stage` itself can exceed six; `getStageTitle` clamps the name to Elder Behemoth while stats keep increasing.

---

## 9. Wildlife, hunting, and attack-back

### Species / DNA (`SPECIES_PREY_INFO`)

| Species | Tier | DNA | Primary / secondary essence | Aggressive |
|---|---:|---:|---|---|
| Blobling | 1 | 26 | Gelatinous / Predator | No |
| Prism Crab | 1 | 32 | Chitin / Gelatinous | No |
| Glowfin | 1 | 28 | Aerial / Gelatinous | No |
| Skyjelly | 2 | 40 | Gelatinous / Aerial | No |
| Vexari Grazer | 2 | 48 | Predator / Chitin | No |
| Glidewing Ray | 2 | 52 | Aerial / Gelatinous | No |
| Thornback Stalker | 3 | 70 | Predator / Chitin | Yes |
| Rift Wyrm | 3 | 95 | Predator / Chitin | Yes |
| Longstrider | 4 | 110 | Chitin / Aerial | No |
| Titan Colossus | 5 | 250 | Chitin / Predator | No |

Wildlife is pooled and drawn with `PartBatch` instanced meshes. Population respawns/despawns around the player; spawn direction avoids the camera view.

### Player attacks

- `triggerAttack()` in `engine.ts`: 0.42 s cooldown, `character.triggerAttackAnim()`, reach scales with body size and scythe trait, calls `wildlife.performMeleeStrike`, applies lunge impulse toward the nearest prey.
- `triggerSpit()`: 0.95 s cooldown, 0.55 s with `plasma_gland`, auto-aims with `getNearestTargetInfo`, calls `wildlife.fireBioProjectile`, rotates slime toward target.
- `performMeleeStrike` damages creatures, awards DNA on kill via `onPreyDevoured`, spawns DNA orbs, alerts herds.
- `fireBioProjectile` uses a pooled projectile; collisions call `damageCreature`.
- DNA orbs arc upward then magnetize into the player; `playDnaAbsorbSound` fires on absorption.
- `handlePreyDevoured` adds DNA and diet points, heals 24% max HP, grows the slime, updates the combat feed, saves progress, and calls `onEvolutionReady` when DNA first reaches the threshold.

### Alien attack-back AI (`wildlife.ts`)

New fields on `Creature`: `menaceTimer`, `attackMode`, `attackTimer`, `attackCooldown`, `attackDidHit`.

`ATTACK_DATA` gives each species detection radius, reach, charge speed, cooldown, and pulse/melee style.

`advanceAttackAI(c, sp, preyInfo, dt, px, pz, playerPos)`:

1. **Idle:** aggressive species attack within detect range; damaged creatures become provoked (`menaceTimer = 9`) and may attack regardless of natural aggression.
2. **Telegraph (`attackMode=1`):** ~0.55 s red pulsing glow, faces player, closes distance, plays species call.
3. **Strike (`attackMode=2`):** ~0.22 s lunge/pulse; if in reach and global `playerHitCooldown <= 0`, calls `onPlayerDamaged(damage, speciesName, c.x, c.z)`.
4. **Recover (`attackMode=3`):** backs off, then cooldown.
5. Render-only `aiDt = 0` is passed to normal species AI while attacking so grazing/flocking behavior does not fight the charge.

Global `playerHitCooldown = 0.85` prevents a herd from stacking damage in the same frame.

### Engine damage response

`handlePlayerDamaged(rawDamage, speciesName, sourceX?, sourceZ?)`:

- Applies armor: `actual = max(2, round(rawDamage * (1 - armor)))`.
- Sets `damageFlash`, `damageSource`, `combatFeed`, `camShake`.
- Plays `audio.playPlayerHurtSound()`.
- Knocks the slime away from the attacker and gives a small upward impulse.
- At 0 HP, reconstitutes to full HP without losing traits/stage and triggers the evolution burst visual.
- HUD shows a red radial vignette plus attacker name. Camera position receives small decaying random shake.

HP regenerates ~2.2/s while playing.

---

## 10. HUD and UI state

`WorldHudSnapshot` in `engine.ts` is emitted roughly every 0.085 s via `onHudUpdate`. It includes position, biome, time, movement flags, discovered biomes, camera/graphics settings, `evo`, nearest `target`, attack/spit cooldowns, combat feed, `damageFlash`, and `damageSource`.

`App.tsx` renders:

- Top-left: stage, species, HP bar, DNA bar, four diet counters, active trait chips, combat feed.
- Top-center: compass, altitude, target lock card with prey HP and DNA reward.
- Top-right: main-menu, map, atmosphere, mute, hide-HUD buttons; atmosphere popover.
- Bottom: desktop Bite/Spit/Evolution bar or mobile joystick/action cluster.
- Modals: Main Menu, Evolution Chamber, World Map.
- Discovery banner with 4.5 s timer.
- Damage vignette overlay.

`onEvolutionReady` exists in `WorldCallbacks` and is called by the engine, but **App does not currently pass it**; the Evolution Modal does not auto-open. The glowing `EVOLVE!` button / `V` key opens it.

---

## 11. Audio

`WorldAudio` is fully procedural Web Audio; no sound files.

- Must be unlocked by a user gesture (`startExploration`, attack, spit, join button).
- Ambient: wind, surf, planetary drone, singing moss, alien chirps, night pulses, glass frogs.
- Creature voices: ten synthesized call types panned by direction and attenuated by distance.
- Combat: bite, spit, DNA absorb, player hurt, evolution fanfare, biome discovery.
- Mute toggle exists in HUD.

---

## 12. Known issues / gotchas

1. **`E` key is overloaded:** `onKeyDown` maps `KeyF` or `KeyE` to attack, while the frame loop uses `KeyE` for camera orbit. Remove `KeyE` from one of them. Desktop hint only mentions `F`.
2. **`onEvolutionReady` is not wired in `App.tsx`:** add a callback to open `EvolutionModal` automatically or show a dedicated toast.
3. **Login is local and insecure:** no backend, no real password hashing, no account recovery. Do not present it as production auth.
4. **HP is runtime-only:** not saved in `UserProfile`.
5. **No automated test suite is committed.** Previous verification used ad-hoc `tsx` scripts and Puppeteer outside the repo.
6. **Real mobile devices are untested.** Touch layout may be crowded on narrow phones: top-left status card, compass, target card, and top-right buttons can overlap.
7. **World Map first open can stall** on slow/software GPUs because `WorldMapModal` samples a 280×280 terrain grid synchronously. It caches the resulting data URL in memory; consider a Web Worker or progressive tiles.
8. **Software WebGL is slow:** headless Chrome startup was ~13–30 s and full smoke tests took minutes; real GPUs are much faster, but profile on actual phones.
9. **Stage progression is uncapped:** stage visuals clamp to six layers and `getStageTitle` clamps the name; stats continue to scale past Stage 6.
10. **With zero diet points**, `getDietTraitChoices` returns a deterministic order (predator-first, then chitin). Consider randomizing or showing neutral starter choices.
11. **`setVegetationDensity` rebuilds all chunks**; avoid frequent graphics toggles.
12. **Shader cache keys matter:** materials built by shared factories must keep unique `customProgramCacheKey` values.
13. **`aGlow` terrain attribute is mandatory** on every mesh using `createTerrainMaterial`.
14. **Do not revert object placement to `getTerrainHeight`**; use `sampleRenderedTerrain` / `getRenderedTerrainHeight` / `ChunkField.sample`.
15. **Audio is silent until user interaction** due to browser autoplay policy.
16. **`sky.ts` positive-modulo fix is critical:** `createGasGiantTexture` previously crashed with a negative palette index and produced a blank page.
17. **`PCFSoftShadowMap` was removed in Three r187;** use `PCFShadowMap`.

---

## 13. Verification performed

### Build

- `npx tsc --noEmit` passes.
- `npm run build` passes; single-file `dist/index.html` generated.

### Headless browser

- Chrome + SwiftShader software WebGL.
- Created profile `ApexPilot` / `OptionAPilot` in different runs, loaded world, clicked Explore, confirmed HUD text including `STG 1 · PROTO-GOO`, `LUMIGOO`, `100 / 100 HP`, `0 / 80 DNA`, target `Blobling 5m`, opened Evolution Modal.
- Zero page errors / console errors.
- Screenshots confirmed slime HUD, alien world, and Genome/Diet Chamber.
- Note: Puppeteer and its system libraries were installed in `/tmp`, not in the repo.

### Headless logic checks

- `registerOrLoginAccount` works with a mocked `localStorage`.
- `getDietTraitChoices` returns matching traits for each of four dominant diets.
- All 11 trait mutations can be applied to `ExplorerCharacter` without NaN; final scale ≈3.39×, HP 665, Bite 219, Spit 149.
- Stage anatomy visibility verified: `1 → 2 → 3 → 4 → 5 → 6`; Stage 6 has six orbiting satellites and one crown ring.
- `WildlifeSystem` melee + homing spit killed a Prism Crab and triggered `onPreyDevoured`.
- Provoked Thornback telegraphed, charged, struck, and produced `Thornback Stalker -17HP` damage callback.

---

## 14. Suggested next work

### Immediate cleanup

- Fix the `E` key conflict.
- Wire `onEvolutionReady` to auto-open the Evolution Modal or show a clear evolution-ready banner.
- Add a small "Aliens fight back" tutorial hint on first attack.
- Add a dedicated 3D/illustrated trait preview in `EvolutionModal` so the user can see the body change before selecting.
- Save or intentionally reset HP on login; document the choice.
- Add a small committed smoke-test script (or document the exact Puppeteer setup) so future agents can reproduce browser tests.

### Gameplay

- Species-specific alien ranged attacks (acid spit, electric pulse, quill volley) with visible telegraphs.
- Dodge/roll or parry; armor trait currently only reduces damage.
- Group aggro: attacking one grazer should alert the whole herd, not just its group.
- Death penalty / respawn location / biomass loss instead of instant full reconstitution.
- More evolution stages with distinct silhouettes, not just additive parts.
- Balance DNA requirements and Titan HP for a satisfying ~10–15 minute first evolution.
- Make trait choices less deterministic when no diet data exists.

### Presentation / performance

- Evolution cinematic: brief camera orbit, slow-mo, particle burst, trait part grow-in animation.
- Mobile HUD layout mode for narrow screens.
- Web Worker for world-map generation.
- Reduce chunk generation cost on low-end devices; measure real frame time.
- Add quality preset that lowers shadow resolution and creature counts automatically.
- Add a proper favicon/image asset if desired; current favicon is inline SVG.

### Product / backend

- Replace local login with real authentication if this is intended for release.
- Cloud save / account sync.
- Analytics-free telemetry for performance crashes.
- App-store wrapper (Capacitor / PWA) if real iOS/Android packaging is required.

---

## 15. Contact points for a new agent

Start with these five files, in order:

1. `HANDOFF.md` — this file.
2. `src/App.tsx` — UI state and callbacks.
3. `src/world/engine.ts` — game loop, input, combat, evolution integration.
4. `src/world/evolution.ts` — all gameplay balance data and profile persistence.
5. `src/world/wildlife.ts` + `src/world/character.ts` — creature AI and player visuals.

When changing visuals, keep the exact terrain height rules, shader cache keys, and `aGlow` attribute intact. When changing gameplay, update both `evolution.ts` data and `EvolutionModal.tsx` copy so the UI stays truthful.


## 16. Previous milestone additions

- **Post-login Main Menu hub:** `MainMenuModal.tsx` has mode cards, max-player selector, persistent profile summary, ability codex, diet guide, and deploy flow.
- **Battle Royale lobby:** `BattleRoyaleLobby.tsx` + `lobby.ts` + `network.ts` add room codes, real-player presence, AI fill, spread-out drop-zone voting, a six-second pre-match drop countdown, and farthest-point drop assignment.
- **Real players:** `BroadcastChannel` joins tabs on the same browser with no server. Optional WebSocket relay `lobby-server.mjs` (uses `ws`) supports phones/other computers when the page is opened with `?ws=ws://your-host:8787`. Run `node lobby-server.mjs`. Note: no remote relay server is running by default in the sandbox; cross-device play requires running `node lobby-server.mjs` on a reachable host.
- **Engine lobby match:** `startBattleRoyaleMatch(roster, assignments, requestedPlayers, adapter)` spawns the local player at the chosen drop and rivals at spread-out spots. Remote real-player transforms are broadcast at ~10 Hz via `NetworkAdapter` and applied in `RivalSystem.applyRemoteState`.
- **Weather:** `weather.ts` adds eight biome/mode weather states with GPU precipitation particles, lightning flashes, fog tint/density, wind push on the airborne player, exposure/light changes, faster plant regrowth in wet weather, and weather-aware wind audio.
- **Edible plants:** `plants.ts` streams glowing flora around the player. Press `K` / Graze or bite near a bulb to consume it for DNA, diet essence, healing and growth. Plants respawn faster in rain/spore weather.
- **Post-blob evolution:** at Stage 6 (`Ascended Xeno-Beast`) `character.ts` hides the slime dome, skirt, nucleus and blob eyes, and shows a full skeletal xeno-beast with torso, head, eyes, horns, four legs, two clawed arms and an animated tail. `SlimeEvolutionState.ascended` drives HUD/menu banners.
- **More abilities:** Phase Dash, Gravity Slam, Spore Mines, Void Lance, Phase Veil, Symbiote Regeneration and Apex Sense are stage/traits unlocked and wired into desktop keys `G/X/C/B/Z`, mobile buttons, the Evolution Chamber, and HUD cooldowns.
- **Open World difficulty:** wildlife HP x1.85 and damage x1.3, with DNA x1.45. Battle Royale uses a shrinking Bio-Storm and AI/real rivals.

---

## 17. Latest completed updates (current verified state)

- **Last verified build:** `npx tsc --noEmit` and `npm run build` pass (`dist/index.html` ≈ 1.26 MB / 344 KB gzip).
- **Detailed Drop Atlas & First-Person Landing Vista (`src/components/DropZoneMap.tsx`, `BattleRoyaleLobby.tsx`):**
  - Replaced the empty coordinate grid with a 340×340 hill-shaded terrain atlas (`buildAtlasDataUrl`), biome coloring, safe-zone boundary circle (`zoneRadius=780`), and pilot count badges.
  - Added `LandingPreview` (ground-level sampled terrain panorama showing the selected drop's horizon, sky tint, alien silhouette, and landing beacon before deployment).
  - Battle Royale now spawns the player 62 m above their chosen drop (`dropIntroTimer = 4.1`) and AI rivals 54 m above their assigned drops (`dropTimer = 3.8`) so everyone visibly descends into the opening ring.
- **Visible In-World Bio-Storm & Warnings (`src/world/rivals.ts`, `src/world/modes.ts`, `src/App.tsx`):**
  - `zoneStartRadius` increased from `250` to `780` so all 10 spread-out drop spots start safely inside the initial ring.
  - Added 3D storm curtain (`zoneWall`), glowing top halo (`zoneTopRing`), and 40 vertical horizon beacons (`zoneBeaconBatch`) so the Bio-Storm boundary is clearly visible from anywhere on the map.
  - Added 10-second pre-collapse warning (`zoneWarning`, `zoneClosesIn`, pulsing top-center `Bio-Storm Closing` banner, 35s cycle with warning at 25s).
- **Skill-Based Auto Matchmaking & Custom Lobby (`src/world/evolution.ts`, `MainMenuModal.tsx`, `BattleRoyaleLobby.tsx`):**
  - Added `getMatchmakingRating`, `getMatchmakingBracket` (`S0`–`S9`), and `getMatchmakingRoom` (`MM-S{bracket}`).
  - Battle Royale Main Menu now has **Quick Matchmaking** (auto-joins skill-bracket queue, waits up to 12s for real pilots via BroadcastChannel/relay, then auto-fills remaining slots with AI) and **Custom Lobby · Join With Code**.
- **Sleeker In-Game HUD (`src/App.tsx`):**
  - Compacted top-left card (`max-w-[210px]`), collapsed diet/traits/feed behind `hudDetails` eye toggle, and switched bottom desktop action bar to compact icon buttons with keycap badges (`F`, `R`, `K`, `V`, plus unlocked ability keys).
- **Higher Open World Capacity (`src/world/modes.ts`, `src/world/rivals.ts`):**
  - Raised Open World `maxPlayers` from `8` to `24` and allocated `RivalSystem`'s pool dynamically from `Math.max(...GAME_MODE_LIST.map(m => m.maxPlayers))`.

---

## 18. Next requested features (for the next agent to build)

The user requested the following next iteration before asking for this handoff:

1. **Battle Royale Match Start & Ring Location:**
   - Start every Battle Royale match as a **fresh Stage 1 normal Proto-Goo blob** (do NOT carry over Open World's high stage/traits into Battle Royale; keep Open World persistent!).
   - Randomize/vary the Bio-Storm **starting and ending ring center** `(centerX, centerZ)` each match (not always `(0, 0)`), and ensure all drop spots & bots start inside the initial ring.
2. **Auto-Evolve + Quick Trait Popup in Battle Royale:**
   - In Battle Royale, when DNA reaches `dnaNext`, trigger evolution automatically and show a **compact quick trait-choice popup** (fast 3-card pick without blocking view behind a giant modal).
3. **Evolution-Gated Movement & Physics:**
   - **Cannot jump** until the player has evolved leg traits (e.g., `stilt_legs` or ascended legs).
   - **Cannot fly** until the player has evolved strong wings (upgrade `glide_wings` / wing progression into real flight).
   - **Scale power & flight with size:** as the player gets bigger, attacks/strength hit harder and flight duration/stamina lasts longer.
4. **Deeper Visual Evolution & Diet-Driven Morphology + 3-Ability Cap:**
   - Upgrade evolution graphics quality so creatures look **less low-poly** and visibly **turn more into what they eat** (stronger color, texture, and anatomical shifts matching the devoured species/diet).
   - Move tentacle mutations (`shock_tentacles`) **underneath / below the player** (like a jellyfish/octopus underside) rather than behind.
   - Grant abilities directly based on what the player eats and the traits they pick, and **cap active abilities to 3 equipped slots at a time** (with a clean swap prompt when gaining a 4th).
5. **Mobile-Game Style Main Menu, Store, Customization & World Events:**
   - Redesign the Main Menu to feel like a sleek **mobile game home screen** (clean hero view of your blob, Store button, Customize button, Mode selector, Play button) while keeping the **in-game screen as empty/clear as possible**.
   - Add **Blob Customization** and an in-game **Store** to buy cosmetic/visual items (skins, patterns, crowns/accessories, bio-auras, trails) using earned currency/DNA.
   - Add **Dynamic World Events** (e.g., Meteor DNA Drops, Alpha Boss Hunts, Spore Blooms, Storm Surges) across the world.

