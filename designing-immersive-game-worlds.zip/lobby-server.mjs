// Optional real-player relay for SOLVARA Battle Royale.
// Run: npm install ws   (already installed by the project setup)
// Then: node lobby-server.mjs
// Open the game with: ?ws=ws://localhost:8787  (or ws://YOUR_LAN_IP:8787)

import { WebSocketServer } from 'ws';

const PORT = Number(process.env.PORT || 8787);
const wss = new WebSocketServer({ port: PORT });
const rooms = new Map();

function roomClients(room) {
  if (!rooms.has(room)) rooms.set(room, new Map());
  return rooms.get(room);
}

function hostIdFor(room) {
  const ids = Array.from(roomClients(room).keys()).sort();
  return ids[0] || '';
}

function broadcastPresence(room) {
  const clients = roomClients(room);
  const peers = Array.from(clients.values()).map((c) => ({
    id: c.id,
    name: c.name,
    ready: Boolean(c.ready),
    dropId: c.dropId || null,
    isLocal: false,
  }));
  const payload = JSON.stringify({ type: 'presence', room, peers, hostId: hostIdFor(room) });
  for (const ws of wss.clients) {
    if (ws.solvaraRoom === room && ws.readyState === 1) ws.send(payload);
  }
}

function broadcastToRoom(room, payload, exceptWs = null) {
  const msg = typeof payload === 'string' ? payload : JSON.stringify(payload);
  for (const ws of wss.clients) {
    if (ws !== exceptWs && ws.solvaraRoom === room && ws.readyState === 1) ws.send(msg);
  }
}

wss.on('connection', (ws) => {
  ws.on('message', (raw) => {
    let msg;
    try {
      msg = JSON.parse(String(raw));
    } catch {
      return;
    }
    if (!msg || !msg.room || !msg.type) return;

    if (msg.type === 'join') {
      ws.solvaraRoom = msg.room;
      ws.solvaraId = msg.id;
      const clients = roomClients(msg.room);
      clients.set(msg.id, {
        id: msg.id,
        name: msg.name || 'Pilot',
        ready: false,
        dropId: null,
      });
      broadcastPresence(msg.room);
      return;
    }

    const room = ws.solvaraRoom || msg.room;
    const clients = roomClients(room);
    const client = clients.get(msg.id);

    if (msg.type === 'state' && client) {
      client.ready = Boolean(msg.ready);
      client.dropId = msg.dropId || null;
      broadcastPresence(room);
      return;
    }

    if (msg.type === 'begin') {
      broadcastToRoom(room, {
        type: 'begin',
        room,
        id: msg.id,
        countdown: Number(msg.countdown) || 6,
      });
      return;
    }

    if (msg.type === 'player-state') {
      broadcastToRoom(
        room,
        {
          type: 'player-state',
          room,
          id: msg.id,
          name: msg.name,
          x: msg.x,
          y: msg.y,
          z: msg.z,
          yaw: msg.yaw,
          hp: msg.hp,
          alive: msg.alive,
        },
        ws
      );
      return;
    }

    if (msg.type === 'leave' && client) {
      clients.delete(msg.id);
      if (!clients.size) rooms.delete(room);
      else broadcastPresence(room);
    }
  });

  ws.on('close', () => {
    const room = ws.solvaraRoom;
    const id = ws.solvaraId;
    if (!room || !id) return;
    const clients = roomClients(room);
    clients.delete(id);
    if (!clients.size) rooms.delete(room);
    else broadcastPresence(room);
  });
});

console.log(`SOLVARA lobby relay listening on ws://0.0.0.0:${PORT}`);
console.log('Open the game with ?ws=ws://localhost:8787 or ?ws=ws://YOUR_LAN_IP:8787');
