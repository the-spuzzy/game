import { useCallback, useEffect, useRef, useState } from 'react';
import {
  Dna,
  Eye,
  EyeOff,
  Flame,
  Home,
  Leaf,
  Map as MapIcon,
  Shield,
  Sparkles,
  Sun,
  Trophy,
  Users,
  Volume2,
  VolumeX,
  Zap,
} from 'lucide-react';
import { AtmospherePopover } from './components/AtmospherePopover';
import { BattleRoyaleLobby } from './components/BattleRoyaleLobby';
import { CompassBar } from './components/CompassBar';
import { EvolutionModal } from './components/EvolutionModal';
import { MainMenuModal } from './components/MainMenuModal';
import { MobileControls } from './components/MobileControls';
import { WorldMapModal } from './components/WorldMapModal';
import { BIOMES, BiomeId } from './world/biomes';
import {
  CameraPreset,
  GraphicsQuality,
  SolvaraWorldEngine,
  WorldHudSnapshot,
} from './world/engine';
import {
  ABILITIES,
  AbilityId,
  ESSENCES,
  EssenceType,
  TRAITS,
  TraitId,
  UserProfile,
  computeSlimeStats,
  getActiveAccount,
  getMatchmakingRating,
  getStageTitle,
  saveProfileProgress,
} from './world/evolution';
import { DropAssignment, RosterEntry } from './world/lobby';
import { GameMode, GAME_MODES, MatchState, clampMaxPlayers } from './world/modes';
import { LobbyNetwork } from './world/network';

interface BiomeBannerState {
  key: number;
  biome: BiomeId;
  isFirstDiscovery: boolean;
  altitude: number;
}

function detectTouchDevice(): boolean {
  if (typeof window === 'undefined') return false;
  return (
    window.matchMedia('(pointer: coarse)').matches ||
    'ontouchstart' in window ||
    navigator.maxTouchPoints > 0
  );
}

function emptyAbilityCooldowns(): Record<AbilityId, number> {
  const out = {} as Record<AbilityId, number>;
  for (const id of Object.keys(ABILITIES) as AbilityId[]) out[id] = 0;
  return out;
}

const INITIAL_MATCH: MatchState = {
  mode: 'open-world',
  totalPlayers: GAME_MODES['open-world'].maxPlayers,
  rivalsAlive: GAME_MODES['open-world'].maxPlayers - 1,
  playerAlive: true,
  matchOver: false,
  winner: null,
  playerWon: false,
  zoneRadius: GAME_MODES['open-world'].zoneStartRadius,
  zoneTargetRadius: GAME_MODES['open-world'].zoneStartRadius,
  zoneStage: 0,
  zoneTime: 0,
  zoneWarning: false,
  zoneClosesIn: 0,
  elapsed: 0,
  eliminations: 0,
  feed: null,
  realPlayers: 1,
  aiPlayers: GAME_MODES['open-world'].maxPlayers - 1,
  rosterNames: ['You'],
};

const INITIAL_HUD: WorldHudSnapshot = {
  x: 0,
  y: 11,
  z: 18,
  bearingDeg: 0,
  playerYaw: 0,
  biome: 'meadow',
  altitude: 11,
  timeOfDay: 0.35,
  timePaused: false,
  swimming: false,
  sprinting: false,
  gliding: false,
  discovered: ['meadow'],
  cameraPreset: 'balanced',
  graphicsQuality: 'ultra',
  muted: false,
  evo: computeSlimeStats(1, []),
  target: null,
  attackCooldown: 0,
  spitCooldown: 0,
  combatFeed: null,
  damageFlash: 0,
  damageSource: null,
  mode: 'open-world',
  maxPlayers: GAME_MODES['open-world'].maxPlayers,
  match: { ...INITIAL_MATCH },
  abilities: [],
  abilityCooldowns: emptyAbilityCooldowns(),
  cloaked: false,
  weather: {
    kind: 'clear',
    name: 'Radiant Xenosky',
    description: 'Warm twin-sun light and calm drifting spores.',
    intensity: 0.2,
    color: '#fcd34d',
    windLabel: 'Calm',
  },
  nearbyPlant: null,
};

export function App() {
  const mountRef = useRef<HTMLDivElement | null>(null);
  const engineRef = useRef<SolvaraWorldEngine | null>(null);
  const bannerTimerRef = useRef<number | null>(null);
  const activeProfileRef = useRef<UserProfile | null>(null);

  const [activeProfile, setActiveProfile] = useState<UserProfile | null>(() =>
    getActiveAccount()
  );
  const [started, setStarted] = useState(false);
  const [hud, setHud] = useState<WorldHudSnapshot>(INITIAL_HUD);
  const [banner, setBanner] = useState<BiomeBannerState | null>(null);

  const [mapOpen, setMapOpen] = useState(false);
  const [evoOpen, setEvoOpen] = useState(false);
  const [atmoOpen, setAtmoOpen] = useState(false);
  const [hudHidden, setHudHidden] = useState(false);
  const [hudDetails, setHudDetails] = useState(false);
  const [trackedBiome, setTrackedBiome] = useState<BiomeId | null>(null);
  const [showTouchControls, setShowTouchControls] = useState<boolean>(() => detectTouchDevice());
  const [loadState, setLoadState] = useState<'loading' | 'ready' | 'error'>('loading');
  const [loadError, setLoadError] = useState('');
  const [selectedMode, setSelectedMode] = useState<GameMode>('open-world');
  const [maxPlayers, setMaxPlayers] = useState<number>(
    GAME_MODES['open-world'].maxPlayers
  );
  const [lobbyOpen, setLobbyOpen] = useState(false);
  const [lobbyKind, setLobbyKind] = useState<'matchmaking' | 'custom'>('matchmaking');
  const networkRef = useRef<LobbyNetwork | null>(null);

  useEffect(() => {
    activeProfileRef.current = activeProfile;
  }, [activeProfile]);

  useEffect(() => {
    setMaxPlayers((n) => clampMaxPlayers(selectedMode, n));
  }, [selectedMode]);

  // Initialize 3D world engine once
  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    let engine: SolvaraWorldEngine | null = null;
    let cancelled = false;
    let timeoutId = 0;

    const fail = (err: unknown) => {
      console.error('Solvara failed to start:', err);
      const raw = err instanceof Error ? err.message : String(err);
      setLoadError(
        /webgl|context/i.test(raw)
          ? 'This browser or device could not start 3D graphics (WebGL). Try Chrome, Safari or Edge with hardware acceleration turned on.'
          : raw
      );
      setLoadState('error');
      setStarted(false);
    };

    const rafId = requestAnimationFrame(() => {
      timeoutId = window.setTimeout(() => {
        if (cancelled) return;
        try {
          engine = new SolvaraWorldEngine(container, {
            onHudUpdate: (snapshot) => {
              setHud(snapshot);
            },
            onBiomeEnter: (biome, isFirstDiscovery, altitude) => {
              if (bannerTimerRef.current) {
                window.clearTimeout(bannerTimerRef.current);
              }
              setBanner({ key: Date.now(), biome, isFirstDiscovery, altitude });
              bannerTimerRef.current = window.setTimeout(() => {
                setBanner(null);
              }, 4500);
            },
            onEvolutionReady: () => {
              setEvoOpen(true);
              setAtmoOpen(false);
              setMapOpen(false);
            },
            onProgressSaved: (evo, discovered) => {
              const prof = activeProfileRef.current;
              if (prof) {
                saveProfileProgress(prof.username, evo, discovered);
                setActiveProfile((prev) =>
                  prev
                    ? {
                        ...prev,
                        stage: evo.stage,
                        dna: evo.dna,
                        traits: [...evo.traits],
                        stageDiet: { ...evo.stageDiet },
                        totalDiet: { ...evo.totalDiet },
                        kills: evo.kills,
                        discoveredBiomes: [...discovered],
                      }
                    : null
                );
              }
            },
            onError: (message) => fail(new Error(message)),
          });

          const saved = getActiveAccount();
          if (saved) {
            engine.loadProfile(saved);
          }

          engineRef.current = engine;
          setLoadState('ready');
        } catch (err) {
          try {
            engine?.dispose();
          } catch {
            /* ignore cleanup errors */
          }
          engine = null;
          container.querySelectorAll('canvas').forEach((c) => c.remove());
          fail(err);
        }
      }, 40);
    });

    return () => {
      cancelled = true;
      cancelAnimationFrame(rafId);
      window.clearTimeout(timeoutId);
      if (bannerTimerRef.current) window.clearTimeout(bannerTimerRef.current);
      engine?.dispose();
      engineRef.current = null;
    };
  }, []);

  // Clear waypoint automatically once player arrives at pinned biome landmark
  useEffect(() => {
    if (!trackedBiome) return;
    const lm = BIOMES[trackedBiome].landmark;
    if (Math.hypot(hud.x - lm.x, hud.z - lm.z) < 16) {
      setTrackedBiome(null);
    }
  }, [hud.x, hud.z, trackedBiome]);

  // Keyboard shortcuts: M (Atlas), V (Evolution Chamber), T (Atmosphere), H (Immersion)
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) return;
      if (!started) return;
      if (e.code === 'Escape') {
        setMapOpen(false);
        setEvoOpen(false);
        setAtmoOpen(false);
      } else if (e.code === 'KeyM') {
        setAtmoOpen(false);
        setEvoOpen(false);
        setMapOpen((prev) => !prev);
      } else if (e.code === 'KeyV') {
        setAtmoOpen(false);
        setMapOpen(false);
        setEvoOpen((prev) => !prev);
      } else if (e.code === 'KeyT') {
        setMapOpen(false);
        setEvoOpen(false);
        setAtmoOpen((prev) => !prev);
      } else if (e.code === 'KeyH') {
        setAtmoOpen(false);
        setHudHidden((prev) => !prev);
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [started]);

  const handleProfileAuthenticated = useCallback((profile: UserProfile) => {
    setActiveProfile(profile);
    engineRef.current?.loadProfile(profile);
  }, []);

  const handleStartGame = useCallback(
    (mode: GameMode, requestedPlayers: number) => {
      const n = clampMaxPlayers(mode, requestedPlayers);
      setSelectedMode(mode);
      setMaxPlayers(n);
      setMapOpen(false);
      setEvoOpen(false);
      setAtmoOpen(false);
      setHudHidden(false);
      if (mode === 'battle-royale') {
        networkRef.current?.close();
        networkRef.current = null;
        setLobbyKind('matchmaking');
        setLobbyOpen(true);
        setStarted(false);
        return;
      }
      engineRef.current?.startExploration(mode, n);
      setStarted(true);
    },
    []
  );

  const handleLobbyStart = useCallback(
    (
      roster: RosterEntry[],
      assignments: DropAssignment[],
      network: LobbyNetwork
    ) => {
      networkRef.current = network;
      engineRef.current?.startBattleRoyaleMatch(
        roster,
        assignments,
        maxPlayers,
        network
      );
      setLobbyOpen(false);
      setStarted(true);
      setMapOpen(false);
      setEvoOpen(false);
      setAtmoOpen(false);
      setHudHidden(false);
    },
    [maxPlayers]
  );

  const handleLobbyCancel = useCallback(() => {
    networkRef.current?.close();
    networkRef.current = null;
    setLobbyOpen(false);
    setStarted(false);
  }, []);

  const handleOpenCustomLobby = useCallback(() => {
    networkRef.current?.close();
    networkRef.current = null;
    setSelectedMode('battle-royale');
    setLobbyKind('custom');
    setLobbyOpen(true);
    setStarted(false);
  }, []);

  const handleEat = useCallback(() => {
    engineRef.current?.triggerEat();
  }, []);

  const handleReturnToMenu = useCallback(() => {
    networkRef.current?.close();
    networkRef.current = null;
    engineRef.current?.returnToMenu();
    setStarted(false);
    setMapOpen(false);
    setEvoOpen(false);
    setAtmoOpen(false);
    setHudHidden(false);
  }, []);

  const handlePlayAgain = useCallback(() => {
    handleStartGame(hud.mode, hud.maxPlayers);
  }, [handleStartGame, hud.mode, hud.maxPlayers]);

  const handleAbility = useCallback((id: AbilityId) => {
    engineRef.current?.triggerAbility(id);
  }, []);

  const handleJoystick = useCallback((x: number, y: number) => {
    engineRef.current?.setJoystick(x, y);
  }, []);

  const handleSprint = useCallback((active: boolean) => {
    engineRef.current?.setTouchSprint(active);
  }, []);

  const handleJump = useCallback(() => {
    engineRef.current?.triggerJump();
  }, []);

  const handleJumpHold = useCallback((held: boolean) => {
    engineRef.current?.setTouchJumpHeld(held);
  }, []);

  const handleAttack = useCallback(() => {
    engineRef.current?.triggerAttack();
  }, []);

  const handleSpit = useCallback(() => {
    engineRef.current?.triggerSpit();
  }, []);

  const handleSelectTrait = useCallback((traitId: TraitId) => {
    engineRef.current?.evolveWithTrait(traitId);
  }, []);

  const handleFastTravel = useCallback((id: BiomeId) => {
    setTrackedBiome(null);
    engineRef.current?.teleportToBiome(id);
  }, []);

  const handleTimeChange = useCallback((t: number) => {
    engineRef.current?.setTimeOfDay(t);
  }, []);

  const handleTogglePause = useCallback(() => {
    engineRef.current?.setTimePaused(!hud.timePaused);
  }, [hud.timePaused]);

  const handleCameraPreset = useCallback((preset: CameraPreset) => {
    engineRef.current?.setCameraPreset(preset);
  }, []);

  const handleGraphicsQuality = useCallback((q: GraphicsQuality) => {
    engineRef.current?.setGraphicsQuality(q);
  }, []);

  const handleToggleMute = useCallback(() => {
    engineRef.current?.toggleMute();
  }, []);

  const bannerDef = banner ? BIOMES[banner.biome] : null;
  const dnaPct = Math.min(100, Math.round((hud.evo.dna / Math.max(1, hud.evo.dnaNext)) * 100));
  const hpPct = Math.min(100, Math.round((hud.evo.hp / Math.max(1, hud.evo.maxHp)) * 100));

  return (
    <div className="relative h-dvh w-screen overflow-hidden bg-[#0c1318]">
      {/* Full-Viewport Live 3D Alien Open World Canvas */}
      <div
        ref={mountRef}
        onPointerDown={() => {
          if (atmoOpen) setAtmoOpen(false);
        }}
        className="absolute inset-0 h-full w-full cursor-grab active:cursor-grabbing"
      />

      {/* Main Menu with Login, Symbiote Profile & Diet Guide */}
      {!started && !lobbyOpen && (
        <MainMenuModal
          loadState={loadState}
          loadError={loadError}
          activeProfile={activeProfile}
          onProfileAuthenticated={handleProfileAuthenticated}
          onLogout={() => setActiveProfile(null)}
          selectedMode={selectedMode}
          onSelectMode={setSelectedMode}
          maxPlayers={maxPlayers}
          onMaxPlayersChange={setMaxPlayers}
          onStartGame={handleStartGame}
          onCustomLobby={handleOpenCustomLobby}
        />
      )}

      {lobbyOpen && !started && (
        <BattleRoyaleLobby
          key={lobbyKind}
          open
          activeProfile={activeProfile}
          maxPlayers={maxPlayers}
          kind={lobbyKind}
          skillRating={activeProfile ? getMatchmakingRating(activeProfile) : 650}
          loadState={loadState}
          onClose={handleLobbyCancel}
          onStartMatch={handleLobbyStart}
        />
      )}

      {/* In-Game Spore Evolution & Open-World HUD */}
      {started && (
        <>
          {/* Red damage vignette + attacker name when alien wildlife strikes back */}
          {hud.damageFlash > 0.01 && (
            <div
              className="pointer-events-none fixed inset-0 z-[25]"
              style={{
                background: `radial-gradient(circle at 50% 50%, rgba(190,18,60,0) 38%, rgba(190,18,60,${(
                  hud.damageFlash * 0.55
                ).toFixed(3)}) 100%)`,
                boxShadow: `inset 0 0 140px rgba(244,63,94,${(hud.damageFlash * 0.65).toFixed(3)})`,
              }}
            >
              {hud.damageSource && (
                <div className="absolute inset-x-0 top-1/3 flex justify-center">
                  <span
                    className="rounded-full border border-rose-300/70 bg-rose-950/75 px-4 py-1.5 text-xs font-bold uppercase tracking-[0.2em] text-rose-100 backdrop-blur-md"
                    style={{ opacity: Math.min(1, hud.damageFlash * 1.4) }}
                  >
                    {hud.damageSource} struck you!
                  </span>
                </div>
              )}
            </div>
          )}

          {!hudHidden && (
            <div
              className="pointer-events-none fixed inset-x-0 top-0 z-10 h-24"
              style={{
                background:
                  'linear-gradient(to bottom, rgba(6,12,18,0.45) 0%, rgba(6,12,18,0.0) 100%)',
              }}
            />
          )}

          {/* Top Left: Symbiote Status, HP, DNA Evolution Progress & Diet Tracker */}
          {!hudHidden && (
            <div className="pointer-events-none fixed left-0 top-0 z-20 flex flex-col gap-1.5 safe-top safe-left pl-2.5 pt-2.5 max-w-[210px] sm:max-w-[230px]">
              <div className="pointer-events-auto rounded-xl border border-white/15 bg-slate-950/45 p-2.5 backdrop-blur-md shadow-[0_5px_20px_rgba(0,0,0,0.3)]">
                <div className="flex items-center justify-between gap-2">
                  <div className="min-w-0">
                    <div className="text-[10px] font-bold uppercase tracking-[0.16em] text-cyan-300 truncate">
                      Stg {hud.evo.stage} · {getStageTitle(hud.evo.stage)} ({hud.evo.bodyScale.toFixed(1)}x)
                    </div>
                    <div className="font-display text-sm font-semibold text-white truncate">
                      {hud.evo.speciesName}
                    </div>
                  </div>

                  {/* Evolve / Genome Button */}
                  <button
                    type="button"
                    onClick={() => {
                      setMapOpen(false);
                      setAtmoOpen(false);
                      setEvoOpen(true);
                    }}
                    className={`flex shrink-0 items-center gap-1 rounded-lg px-2 py-1 text-[10px] font-bold uppercase tracking-wider transition cursor-pointer ${
                      hud.evo.evolveReady
                        ? 'bg-gradient-to-r from-amber-300 via-teal-300 to-cyan-300 text-slate-950 shadow-[0_0_20px_rgba(45,212,191,0.75)] animate-pulse'
                        : 'border border-cyan-300/35 bg-cyan-950/55 text-cyan-200 hover:bg-cyan-900/60'
                    }`}
                  >
                    <Dna className="h-3.5 w-3.5" />
                    <span>{hud.evo.evolveReady ? 'EVOLVE!' : 'DNA'}</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setHudDetails((value) => !value)}
                    title={hudDetails ? 'Hide creature details' : 'Show creature details'}
                    aria-label={hudDetails ? 'Hide creature details' : 'Show creature details'}
                    className="flex h-7 w-7 shrink-0 items-center justify-center rounded-lg border border-white/15 bg-white/5 text-slate-300 hover:bg-white/12 cursor-pointer"
                  >
                    {hudDetails ? <EyeOff className="h-3.5 w-3.5" /> : <Eye className="h-3.5 w-3.5" />}
                  </button>
                </div>

                {/* Health Bar */}
                <div className="mt-2 flex items-center gap-2">
                  <span className="w-7 text-[9px] font-bold text-emerald-200">HP</span>
                  <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-white/12">
                    <div className="h-full rounded-full bg-gradient-to-r from-emerald-400 to-teal-300 transition-all duration-200" style={{ width: `${hpPct}%` }} />
                  </div>
                  <span className="w-12 text-right text-[9px] tabular-nums text-white/75">{hud.evo.hp}/{hud.evo.maxHp}</span>
                </div>

                {/* DNA / Evolution Bar */}
                <div className="mt-1 flex items-center gap-2">
                  <span className="w-7 text-[9px] font-bold text-cyan-200">DNA</span>
                  <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-white/12">
                    <div className="h-full rounded-full bg-gradient-to-r from-cyan-400 via-fuchsia-400 to-amber-300 transition-all duration-300" style={{ width: `${dnaPct}%` }} />
                  </div>
                  <span className="w-12 text-right text-[9px] tabular-nums text-white/75">{hud.evo.dna}/{hud.evo.dnaNext}</span>
                </div>

                {/* Diet Essence Pills (shows what you're eating this stage!) */}
                {hudDetails && <div className="mt-2 flex flex-wrap items-center gap-1 border-t border-white/10 pt-1.5">
                  {(Object.keys(ESSENCES) as EssenceType[]).map((k) => {
                    const ess = ESSENCES[k];
                    const pts = hud.evo.stageDiet[k];
                    return (
                      <div
                        key={k}
                        title={`${ess.name}: ${pts} pts eaten this stage`}
                        className="flex items-center gap-1 rounded bg-white/6 px-1.5 py-0.5 text-[9px] font-semibold"
                      >
                        <span
                          className="h-1.5 w-1.5 rounded-full"
                          style={{ backgroundColor: ess.color }}
                        />
                        <span className="text-slate-300">{ess.shortName}</span>
                        <span className="tabular-nums text-white">{pts}</span>
                      </div>
                    );
                  })}
                </div>}

                {/* Active Trait Chips */}
                {hudDetails && hud.evo.traits.length > 0 && (
                  <div className="mt-1.5 flex flex-wrap gap-1">
                    {hud.evo.traits.map((tid) => {
                      const t = TRAITS[tid];
                      if (!t) return null;
                      return (
                        <span
                          key={tid}
                          className="rounded bg-white/10 px-1.5 py-0.5 text-[9px] font-semibold"
                          style={{ color: t.accentColor }}
                        >
                          {t.name}
                        </span>
                      );
                    })}
                  </div>
                )}
              </div>

              {/* Combat / Devour Feed Toast */}
              {hudDetails && hud.combatFeed && (
                <div className="rounded-xl border border-cyan-300/35 bg-black/65 px-3 py-1.5 text-xs font-semibold text-cyan-200 backdrop-blur-md shadow animate-soft-in">
                  {hud.combatFeed}
                </div>
              )}

              {/* Compact mode/weather status; the map and evolution chamber hold the details. */}
              <div className="pointer-events-auto rounded-lg border border-white/12 bg-slate-950/40 px-2 py-1.5 backdrop-blur-md">
                <div className="flex items-center justify-between gap-3 text-[9px]">
                  <span className="font-bold uppercase tracking-[0.12em]" style={{ color: GAME_MODES[hud.mode].accent }}>
                    {hud.mode === 'battle-royale' ? 'Bio-Storm Arena' : 'Open World'}
                  </span>
                  {hud.evo.ascended && <span className="text-fuchsia-200">Ascended</span>}
                  {hud.cloaked && <span className="text-violet-200">Veiled</span>}
                </div>
                <div className="mt-0.5 flex items-center gap-1 text-[9px] text-white/65">
                  <span className="h-1.5 w-1.5 rounded-full" style={{ backgroundColor: hud.weather.color }} />
                  <span className="truncate">{hud.weather.name}</span>
                  {hud.nearbyPlant && <span className="ml-auto shrink-0 text-emerald-200">K · {hud.nearbyPlant.name}</span>}
                </div>
                {hudDetails && (
                  <div className="mt-1 border-t border-white/10 pt-1 text-[9px] text-slate-400">
                    {hud.mode === 'battle-royale'
                      ? `${hud.match.rosterNames.length} pilots · ${hud.match.eliminations} eliminations · ${hud.match.winner ?? 'last alive wins'}`
                      : `${hud.match.rivalsAlive + 1}/${hud.maxPlayers} local explorers · persistent evolution`}
                    <div>{hud.weather.description}</div>
                    {hud.match.feed && <div className="text-cyan-200">{hud.match.feed}</div>}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* Top Center: Horizon Compass Bar + Targeted Wildlife Lock-On */}
          {!hudHidden && (
            <div className="pointer-events-none fixed inset-x-0 top-0 z-20 flex flex-col items-center safe-top pt-3">
              <CompassBar
                bearingDeg={hud.bearingDeg}
                biome={hud.biome}
                altitude={hud.altitude}
                playerX={hud.x}
                playerZ={hud.z}
                trackedBiome={trackedBiome}
              />

              {hud.mode === 'battle-royale' && hud.match.zoneWarning && !hud.match.matchOver && (
                <div className="pointer-events-none mt-2 flex justify-center">
                  <div className="rounded-xl border border-rose-200/75 bg-rose-950/85 px-4 py-2 text-center shadow-[0_0_34px_rgba(244,63,94,0.55)] backdrop-blur-md animate-pulse">
                    <div className="text-[10px] font-black uppercase tracking-[0.24em] text-rose-100">
                      Bio-Storm Closing
                    </div>
                    <div className="mt-0.5 text-[11px] font-semibold text-white">
                      Get inside the {Math.round(hud.match.zoneTargetRadius)}m safe ring · {hud.match.zoneClosesIn}s
                    </div>
                  </div>
                </div>
              )}

              {/* Locked Prey Target HUD Card */}
              {hud.target && (
                <div className="mt-2 flex items-center gap-3 rounded-full border border-white/20 bg-black/55 px-4 py-1.5 backdrop-blur-md shadow-[0_6px_20px_rgba(0,0,0,0.45)]">
                  <div className="flex flex-col">
                    <div className="flex items-center gap-2 text-xs font-semibold text-white">
                      <span>{hud.target.name}</span>
                      <span className="text-[10px] text-slate-400 tabular-nums">
                        {hud.target.distance}m
                      </span>
                    </div>
                    <div className="mt-0.5 h-1.5 w-28 overflow-hidden rounded-full bg-white/15">
                      <div
                        className="h-full rounded-full bg-rose-400 transition-all duration-150"
                        style={{
                          width: `${Math.max(5, Math.round((hud.target.hp / Math.max(1, hud.target.maxHp)) * 100))}%`,
                        }}
                      />
                    </div>
                  </div>
                  <span
                    className="rounded-full px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider"
                    style={{
                      backgroundColor: `${hud.target.essenceColor}25`,
                      color: hud.target.essenceColor,
                      border: `1px solid ${hud.target.essenceColor}60`,
                    }}
                  >
                    +{hud.target.dnaReward} {hud.target.essenceName} DNA
                  </span>
                </div>
              )}
            </div>
          )}

          {/* Top Right: Compact Glass Utility Pills (Menu, Map, Atmosphere, Audio, Zen) */}
          <div className="pointer-events-none fixed right-0 top-0 z-30 flex flex-col items-end safe-top safe-right pr-3.5 pt-3">
            <div className="pointer-events-auto flex items-center gap-2">
              {!hudHidden && (
                <>
                  <button
                    type="button"
                    onClick={handleReturnToMenu}
                    title="Main Menu & Symbiote Account"
                    aria-label="Main Menu"
                    className="flex h-10 w-10 items-center justify-center rounded-full border border-white/22 bg-black/28 text-white/92 backdrop-blur-md hover:bg-black/45 active:scale-95 transition cursor-pointer"
                  >
                    <Home className="h-4 w-4" />
                  </button>

                  <button
                    type="button"
                    onClick={() => {
                      setAtmoOpen(false);
                      setEvoOpen(false);
                      setMapOpen(true);
                    }}
                    title="World Map & Biomes (M)"
                    aria-label="Open World Map"
                    className="flex h-10 items-center gap-1.5 rounded-full border border-white/22 bg-black/28 px-3.5 text-white/95 backdrop-blur-md hover:bg-black/45 active:scale-95 transition cursor-pointer"
                  >
                    <MapIcon className="h-4 w-4 text-amber-200" />
                    <span className="hidden sm:inline text-xs font-medium tracking-wide">Map</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setAtmoOpen((v) => !v)}
                    title="Time of Day, Camera & Touch Controls (T)"
                    aria-label="Atmosphere & Camera Settings"
                    className={`flex h-10 w-10 items-center justify-center rounded-full border backdrop-blur-md transition active:scale-95 cursor-pointer ${
                      atmoOpen
                        ? 'border-amber-300/70 bg-amber-300/25 text-amber-100'
                        : 'border-white/22 bg-black/28 text-white/92 hover:bg-black/45'
                    }`}
                  >
                    <Sun className="h-4.5 w-4.5" />
                  </button>

                  <button
                    type="button"
                    onClick={handleToggleMute}
                    title={hud.muted ? 'Unmute Ambient Audio' : 'Mute Ambient Audio'}
                    aria-label={hud.muted ? 'Unmute Audio' : 'Mute Audio'}
                    className="flex h-10 w-10 items-center justify-center rounded-full border border-white/22 bg-black/28 text-white/92 backdrop-blur-md hover:bg-black/45 active:scale-95 transition cursor-pointer"
                  >
                    {hud.muted ? (
                      <VolumeX className="h-4.5 w-4.5 text-white/60" />
                    ) : (
                      <Volume2 className="h-4.5 w-4.5" />
                    )}
                  </button>
                </>
              )}

              <button
                type="button"
                onClick={() => {
                  setAtmoOpen(false);
                  setHudHidden((v) => !v);
                }}
                title={hudHidden ? 'Show HUD (H)' : 'Pure Immersion View (H)'}
                aria-label={hudHidden ? 'Show HUD' : 'Hide HUD'}
                className={`flex h-10 w-10 items-center justify-center rounded-full border backdrop-blur-md transition active:scale-95 cursor-pointer ${
                  hudHidden
                    ? 'border-white/15 bg-black/18 text-white/60 hover:text-white hover:bg-black/40'
                    : 'border-white/22 bg-black/28 text-white/92 hover:bg-black/45'
                }`}
              >
                {hudHidden ? <Eye className="h-4 w-4" /> : <EyeOff className="h-4 w-4" />}
              </button>
            </div>

            {!hudHidden && (
              <AtmospherePopover
                open={atmoOpen}
                timeOfDay={hud.timeOfDay}
                timePaused={hud.timePaused}
                cameraPreset={hud.cameraPreset}
                graphicsQuality={hud.graphicsQuality}
                showTouchControls={showTouchControls}
                onTimeChange={handleTimeChange}
                onTogglePause={handleTogglePause}
                onCameraPreset={handleCameraPreset}
                onGraphicsQuality={handleGraphicsQuality}
                onToggleTouchControls={() => setShowTouchControls((v) => !v)}
              />
            )}
          </div>

          {/* Poetic Open-World Biome Discovery Banner */}
          {banner && bannerDef && !mapOpen && !evoOpen && !hudHidden && (
            <div
              key={banner.key}
              className="pointer-events-none fixed inset-x-0 top-24 sm:top-27 z-20 flex flex-col items-center text-center px-4 animate-banner"
            >
              {banner.isFirstDiscovery && (
                <span
                  className="text-[10px] font-semibold uppercase tracking-[0.32em] mb-1 drop-shadow-[0_1px_4px_rgba(0,0,0,0.85)]"
                  style={{ color: bannerDef.accentColor }}
                >
                  New Region Discovered
                </span>
              )}
              <h2 className="font-display text-2xl sm:text-4xl font-medium uppercase text-white drop-shadow-[0_3px_18px_rgba(0,0,0,0.75)]">
                {bannerDef.name}
              </h2>
              <div className="mt-1.5 h-px w-36 bg-gradient-to-r from-transparent via-white/65 to-transparent" />
              <p className="mt-1.5 text-[11px] sm:text-xs font-medium tracking-[0.2em] uppercase text-white/85 drop-shadow-[0_1px_6px_rgba(0,0,0,0.8)]">
                {bannerDef.subtitle}
              </p>
            </div>
          )}

          {/* Dual-Thumb Mobile Controls for iOS & Android */}
          {!hudHidden && showTouchControls && !mapOpen && !evoOpen && (
            <MobileControls
              onJoystickChange={handleJoystick}
              onSprintChange={handleSprint}
              onJump={handleJump}
              onJumpHoldChange={handleJumpHold}
              onAttack={handleAttack}
              onSpit={handleSpit}
              onAbility={handleAbility}
              onEat={handleEat}
              abilities={hud.match.matchOver ? [] : hud.abilities}
              abilityCooldowns={hud.abilityCooldowns}
              swimming={hud.swimming}
            />
          )}

          {/* Desktop Bottom Combat & Evolution Action Bar */}
          {!hudHidden && !showTouchControls && !mapOpen && !evoOpen && (
            <div className="pointer-events-none fixed inset-x-0 bottom-4 z-20 flex flex-col items-center gap-2 px-4">
              <div className="pointer-events-auto flex items-center gap-2.5 rounded-2xl border border-white/18 bg-black/45 px-3.5 py-2 backdrop-blur-md shadow-[0_10px_35px_rgba(0,0,0,0.5)]">
                <button
                  type="button"
                  onClick={handleAttack}
                  className="flex items-center gap-1.5 rounded-xl border border-rose-400/50 bg-rose-500/25 px-3.5 py-1.5 text-xs font-bold text-rose-100 hover:bg-rose-500/40 active:scale-95 transition cursor-pointer"
                >
                  <Flame className="h-4 w-4 text-rose-300" />
                  <span>Bite / Lunge</span>
                  <kbd className="ml-1 rounded bg-black/45 px-1.5 py-0.5 text-[10px] text-rose-200">
                    F
                  </kbd>
                </button>

                <button
                  type="button"
                  onClick={handleSpit}
                  className="flex items-center gap-1.5 rounded-xl border border-cyan-400/50 bg-cyan-500/25 px-3.5 py-1.5 text-xs font-bold text-cyan-100 hover:bg-cyan-500/40 active:scale-95 transition cursor-pointer"
                >
                  <Zap className="h-4 w-4 text-cyan-300" />
                  <span>Spit Plasma</span>
                  <kbd className="ml-1 rounded bg-black/45 px-1.5 py-0.5 text-[10px] text-cyan-200">
                    R
                  </kbd>
                </button>

                <button
                  type="button"
                  onClick={handleEat}
                  className="flex items-center gap-1.5 rounded-xl border border-emerald-400/50 bg-emerald-500/20 px-3 py-1.5 text-xs font-bold text-emerald-100 hover:bg-emerald-500/35 active:scale-95 transition cursor-pointer"
                >
                  <Leaf className="h-4 w-4 text-emerald-300" />
                  <span>Graze</span>
                  <kbd className="ml-1 rounded bg-black/35 px-1.5 py-0.5 text-[10px] text-emerald-200">
                    K
                  </kbd>
                </button>

                <button
                  type="button"
                  onClick={() => setEvoOpen(true)}
                  className={`flex items-center gap-1.5 rounded-xl border px-3.5 py-1.5 text-xs font-bold transition cursor-pointer ${
                    hud.evo.evolveReady
                      ? 'border-amber-200 bg-gradient-to-r from-amber-300 to-cyan-300 text-slate-950 shadow-[0_0_20px_rgba(45,212,191,0.7)] animate-pulse'
                      : 'border-white/20 bg-white/10 text-white hover:bg-white/20'
                  }`}
                >
                  <Sparkles className="h-4 w-4" />
                  <span>{hud.evo.evolveReady ? 'Evolve Now!' : 'Evolution'}</span>
                  <kbd className="ml-1 rounded bg-black/35 px-1.5 py-0.5 text-[10px]">
                    V
                  </kbd>
                </button>

                {hud.abilities
                  .filter((id) => ABILITIES[id].active)
                  .map((id) => {
                    const def = ABILITIES[id];
                    const cd = hud.abilityCooldowns[id] ?? 0;
                    const ready = cd <= 0.001 && !hud.match.matchOver;
                    return (
                      <button
                        key={id}
                        type="button"
                        disabled={!ready}
                        onClick={() => handleAbility(id)}
                        title={`${def.name}: ${def.description}`}
                        className={`flex items-center gap-1 rounded-xl border px-2.5 py-1.5 text-[11px] font-bold transition cursor-pointer ${
                          ready ? 'bg-white/10 text-white hover:bg-white/20 active:scale-95' : 'bg-black/35 text-white/40'
                        }`}
                        style={{
                          borderColor: ready ? `${def.color}aa` : 'rgba(255,255,255,0.15)',
                          boxShadow: ready ? `0 0 12px ${def.color}33` : undefined,
                        }}
                      >
                        <Sparkles className="h-3.5 w-3.5" style={{ color: def.color }} />
                        <span>{def.shortName}</span>
                        <kbd className="rounded bg-black/35 px-1 py-0.5 text-[9px] tabular-nums">
                          {ready ? def.key : `${cd.toFixed(1)}s`}
                        </kbd>
                      </button>
                    );
                  })}
              </div>

              <div className="text-[11px] font-medium text-white/75 drop-shadow">
                WASD Move · Shift Run · Space Jump{hud.evo.glide ? '/Glide' : ''} · F Bite · R Spit · G Dash · X Slam · C Mines · B Lance · Z Cloak · V Evolve · M Map
              </div>
            </div>
          )}

          {/* Spore Evolution & Diet Trait Selection Modal */}
          <EvolutionModal
            open={evoOpen}
            onClose={() => setEvoOpen(false)}
            evo={hud.evo}
            onSelectTrait={handleSelectTrait}
          />

          {/* Interactive Hill-Shaded World Atlas & Biome Fast Travel */}
          <WorldMapModal
            open={mapOpen}
            onClose={() => setMapOpen(false)}
            playerX={hud.x}
            playerZ={hud.z}
            bearingDeg={hud.bearingDeg}
            currentBiome={hud.biome}
            discovered={hud.discovered}
            trackedBiome={trackedBiome}
            onTrackBiome={setTrackedBiome}
            onFastTravel={handleFastTravel}
          />

          {/* Battle Royale Match Result */}
          {hud.match.matchOver && hud.mode === 'battle-royale' && (
            <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4 backdrop-blur-xl animate-soft-in">
              <div className="pointer-events-auto w-full max-w-lg rounded-2xl border border-white/20 bg-[#0c1420]/95 p-6 text-center shadow-[0_24px_90px_rgba(0,0,0,0.8)]">
                <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-full border border-white/25 bg-white/10">
                  <Trophy
                    className="h-7 w-7"
                    style={{ color: hud.match.playerWon ? '#facc15' : '#fb7185' }}
                  />
                </div>
                <div className="mt-3 text-[11px] font-bold uppercase tracking-[0.24em] text-cyan-300">
                  {GAME_MODES[hud.mode].name} · Match Complete
                </div>
                <h2 className="font-display mt-1 text-3xl font-semibold text-white">
                  {hud.match.playerWon ? 'Last Symbiote Standing!' : 'Eliminated'}
                </h2>
                <p className="mt-2 text-sm text-slate-300">
                  {hud.match.playerWon
                    ? `${hud.evo.speciesName} survived the collapsing Bio-Storm.`
                    : `${hud.match.winner ?? 'The Bio-Storm'} outlasted you.`}
                </p>

                <p className="mt-1.5 text-[11px] font-semibold text-cyan-200">
                  {hud.match.realPlayers} real player{hud.match.realPlayers === 1 ? '' : 's'} ·{' '}
                  {hud.match.aiPlayers} AI rival{hud.match.aiPlayers === 1 ? '' : 's'}
                </p>

                <div className="mt-4 grid grid-cols-3 gap-2 text-xs">
                  <div className="rounded-xl border border-white/12 bg-black/35 p-2.5">
                    <div className="text-[10px] uppercase tracking-wider text-slate-400">Pilots</div>
                    <div className="mt-0.5 inline-flex items-center gap-1 font-bold text-white tabular-nums">
                      <Users className="h-3.5 w-3.5 text-cyan-300" />
                      {hud.maxPlayers}
                    </div>
                  </div>
                  <div className="rounded-xl border border-white/12 bg-black/35 p-2.5">
                    <div className="text-[10px] uppercase tracking-wider text-slate-400">Elims</div>
                    <div className="mt-0.5 inline-flex items-center gap-1 font-bold text-rose-200 tabular-nums">
                      <Shield className="h-3.5 w-3.5" />
                      {hud.match.eliminations}
                    </div>
                  </div>
                  <div className="rounded-xl border border-white/12 bg-black/35 p-2.5">
                    <div className="text-[10px] uppercase tracking-wider text-slate-400">Time</div>
                    <div className="mt-0.5 font-bold text-emerald-200 tabular-nums">
                      {Math.round(hud.match.elapsed)}s
                    </div>
                  </div>
                </div>

                <div className="mt-5 flex gap-2.5">
                  <button
                    type="button"
                    onClick={handlePlayAgain}
                    className="flex-1 rounded-xl bg-gradient-to-r from-cyan-300 via-teal-300 to-emerald-300 py-2.5 text-xs font-bold uppercase tracking-[0.18em] text-slate-950 hover:brightness-105 cursor-pointer"
                  >
                    Play Again
                  </button>
                  <button
                    type="button"
                    onClick={handleReturnToMenu}
                    className="rounded-xl border border-white/20 bg-white/8 px-4 py-2.5 text-xs font-bold uppercase tracking-[0.18em] text-white hover:bg-white/16 cursor-pointer"
                  >
                    Main Menu
                  </button>
                </div>
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
}

export default App;
