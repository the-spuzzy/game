import React from 'react';
import { Camera, Pause, Play, Smartphone, Sparkles, Sun } from 'lucide-react';
import { CameraPreset, GraphicsQuality } from '../world/engine';

interface AtmospherePopoverProps {
  open: boolean;
  timeOfDay: number;
  timePaused: boolean;
  cameraPreset: CameraPreset;
  graphicsQuality: GraphicsQuality;
  showTouchControls: boolean;
  onTimeChange: (t: number) => void;
  onTogglePause: () => void;
  onCameraPreset: (preset: CameraPreset) => void;
  onGraphicsQuality: (q: GraphicsQuality) => void;
  onToggleTouchControls: () => void;
}

const TIME_PRESETS: ReadonlyArray<{ label: string; value: number }> = [
  { label: 'Dawn', value: 0.255 },
  { label: 'Morning', value: 0.35 },
  { label: 'Noon', value: 0.5 },
  { label: 'Golden', value: 0.715 },
  { label: 'Dusk', value: 0.76 },
  { label: 'Night', value: 0.92 },
];

export function formatClock(t: number): string {
  const totalMinutes = Math.floor((((t % 1) + 1) % 1) * 24 * 60);
  const hh = Math.floor(totalMinutes / 60);
  const mm = totalMinutes % 60;
  return `${String(hh).padStart(2, '0')}:${String(mm).padStart(2, '0')}`;
}

export const AtmospherePopover: React.FC<AtmospherePopoverProps> = ({
  open,
  timeOfDay,
  timePaused,
  cameraPreset,
  graphicsQuality,
  showTouchControls,
  onTimeChange,
  onTogglePause,
  onCameraPreset,
  onGraphicsQuality,
  onToggleTouchControls,
}) => {
  if (!open) return null;

  return (
    <div
      onPointerDown={(e) => e.stopPropagation()}
      className="pointer-events-auto mt-2.5 w-72 rounded-2xl border border-white/18 bg-[#0e161d]/88 p-4 text-white backdrop-blur-xl shadow-[0_18px_50px_rgba(0,0,0,0.55)] animate-soft-in"
    >
      {/* Time of Day Section */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-1.5 text-[11px] font-semibold uppercase tracking-[0.15em] text-slate-300">
          <Sun className="h-3.5 w-3.5 text-amber-300" />
          <span>Time of Day</span>
        </div>
        <div className="flex items-center gap-2">
          <span className="tabular-nums text-xs font-medium text-amber-100">
            {formatClock(timeOfDay)}
          </span>
          <button
            type="button"
            onClick={onTogglePause}
            aria-label={timePaused ? 'Resume day cycle' : 'Pause day cycle'}
            className="flex h-6 w-6 items-center justify-center rounded-full border border-white/18 bg-white/8 hover:bg-white/18 transition cursor-pointer"
          >
            {timePaused ? <Play className="h-3 w-3" /> : <Pause className="h-3 w-3" />}
          </button>
        </div>
      </div>

      <input
        type="range"
        min={0}
        max={1}
        step={0.002}
        value={timeOfDay}
        onChange={(e) => onTimeChange(parseFloat(e.target.value))}
        className="mt-2.5 h-1.5 w-full accent-amber-300 cursor-pointer"
      />

      <div className="mt-2.5 grid grid-cols-3 gap-1.5">
        {TIME_PRESETS.map((p) => {
          const dist = Math.min(
            Math.abs(timeOfDay - p.value),
            1 - Math.abs(timeOfDay - p.value)
          );
          const active = dist < 0.032;
          return (
            <button
              key={p.label}
              type="button"
              onClick={() => onTimeChange(p.value)}
              className={`rounded-lg border py-1.5 text-[11px] font-medium transition cursor-pointer ${
                active
                  ? 'border-amber-300/70 bg-amber-300/20 text-amber-100'
                  : 'border-white/12 bg-white/5 text-slate-300 hover:bg-white/12'
              }`}
            >
              {p.label}
            </button>
          );
        })}
      </div>

      {/* 3rd-Person Camera Framing */}
      <div className="mt-4 border-t border-white/10 pt-3.5">
        <div className="flex items-center gap-1.5 text-[11px] font-semibold uppercase tracking-[0.15em] text-slate-300">
          <Camera className="h-3.5 w-3.5 text-sky-300" />
          <span>3rd-Person View</span>
        </div>
        <div className="mt-2 grid grid-cols-3 gap-1.5">
          {(
            [
              { id: 'close', label: 'Shoulder' },
              { id: 'balanced', label: 'Balanced' },
              { id: 'vista', label: 'Wide Vista' },
            ] as const
          ).map((c) => (
            <button
              key={c.id}
              type="button"
              onClick={() => onCameraPreset(c.id)}
              className={`rounded-lg border py-1.5 text-[11px] font-medium transition cursor-pointer ${
                cameraPreset === c.id
                  ? 'border-white/50 bg-white/20 text-white'
                  : 'border-white/12 bg-white/5 text-slate-300 hover:bg-white/12'
              }`}
            >
              {c.label}
            </button>
          ))}
        </div>
      </div>

      {/* Graphics Quality & Vegetation Density */}
      <div className="mt-3.5 border-t border-white/10 pt-3">
        <div className="flex items-center gap-1.5 text-[11px] font-semibold uppercase tracking-[0.15em] text-slate-300">
          <Sparkles className="h-3.5 w-3.5 text-amber-200" />
          <span>Graphics &amp; Foliage</span>
        </div>
        <div className="mt-2 grid grid-cols-2 gap-1.5">
          {(
            [
              { id: 'high', label: 'High (Mobile)' },
              { id: 'ultra', label: 'Ultra HDR' },
            ] as const
          ).map((q) => (
            <button
              key={q.id}
              type="button"
              onClick={() => onGraphicsQuality(q.id)}
              className={`rounded-lg border py-1.5 text-[11px] font-medium transition cursor-pointer ${
                graphicsQuality === q.id
                  ? 'border-amber-300/70 bg-amber-300/20 text-amber-100'
                  : 'border-white/12 bg-white/5 text-slate-300 hover:bg-white/12'
              }`}
            >
              {q.label}
            </button>
          ))}
        </div>
      </div>

      {/* Mobile iOS / Android Touch Controls Toggle */}
      <div className="mt-3.5 border-t border-white/10 pt-3 flex items-center justify-between">
        <span className="flex items-center gap-2 text-xs text-slate-200">
          <Smartphone className="h-3.5 w-3.5 text-emerald-300" />
          Mobile Touch Controls
        </span>
        <button
          type="button"
          onClick={onToggleTouchControls}
          className={`relative h-6 w-11 rounded-full transition-colors cursor-pointer ${
            showTouchControls ? 'bg-emerald-400/85' : 'bg-white/20'
          }`}
          aria-label="Toggle on-screen touch controls"
        >
          <span
            className={`absolute top-0.5 left-0.5 h-5 w-5 rounded-full bg-white shadow transition-transform ${
              showTouchControls ? 'translate-x-5' : 'translate-x-0'
            }`}
          />
        </button>
      </div>
    </div>
  );
};
