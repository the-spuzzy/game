import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  Check,
  Copy,
  MapPin,
  Play,
  Radio,
  Trophy,
  Users,
  Wifi,
  WifiOff,
  X,
} from 'lucide-react';
import { DropZoneMap, LandingPreview } from './DropZoneMap';
import {
  UserProfile,
  getMatchmakingBracket,
  getMatchmakingRoom,
} from '../world/evolution';
import {
  AI_NAMES,
  DROP_SPOTS,
  DropAssignment,
  RosterEntry,
  assignDropSpots,
  getDropSpot,
} from '../world/lobby';
import {
  LobbyNetwork,
  LobbyPeer,
  LobbyPhase,
  RelayStatus,
} from '../world/network';

interface BattleRoyaleLobbyProps {
  open: boolean;
  activeProfile: UserProfile | null;
  maxPlayers: number;
  kind: 'matchmaking' | 'custom';
  skillRating: number;
  loadState: 'loading' | 'ready' | 'error';
  onClose: () => void;
  onStartMatch: (
    roster: RosterEntry[],
    assignments: DropAssignment[],
    network: LobbyNetwork
  ) => void;
}

function randomRoom(): string {
  return `SOL-${Math.random().toString(36).slice(2, 6).toUpperCase()}`;
}

export const BattleRoyaleLobby: React.FC<BattleRoyaleLobbyProps> = ({
  open,
  activeProfile,
  maxPlayers,
  kind,
  skillRating,
  loadState,
  onClose,
  onStartMatch,
}) => {
  const [roomCode, setRoomCode] = useState(() =>
    kind === 'matchmaking' && activeProfile
      ? getMatchmakingRoom(activeProfile)
      : randomRoom()
  );
  const [relayUrl, setRelayUrl] = useState(() => {
    try {
      return new URLSearchParams(window.location.search).get('ws') ?? '';
    } catch {
      return '';
    }
  });
  const [joined, setJoined] = useState(false);
  const [peers, setPeers] = useState<LobbyPeer[]>([]);
  const [hostId, setHostId] = useState('');
  const [phase, setPhase] = useState<LobbyPhase>('lobby');
  const [countdown, setCountdown] = useState(0);
  const [dropVotes, setDropVotes] = useState<Record<string, string>>({});
  const [relayStatus, setRelayStatus] = useState<RelayStatus>('local');
  const [ready, setReady] = useState(false);
  const [selectedDropId, setSelectedDropId] = useState(DROP_SPOTS[0].id);
  const [copied, setCopied] = useState(false);
  const [queueSeconds, setQueueSeconds] = useState(12);
  const networkRef = useRef<LobbyNetwork | null>(null);
  const launchedRef = useRef(false);

  const localId = networkRef.current?.getLocalId() ?? '';
  const isHost = !hostId || hostId === localId;
  const skillBracket = activeProfile
    ? getMatchmakingBracket(activeProfile)
    : Math.max(0, Math.min(9, Math.floor(skillRating / 350)));

  const realPlayers = useMemo<LobbyPeer[]>(
    () => peers.slice(0, Math.max(1, maxPlayers)),
    [peers, maxPlayers]
  );

  const roster = useMemo<RosterEntry[]>(() => {
    const real: RosterEntry[] = realPlayers.map((p) => ({
      id: p.id,
      name: p.name,
      isAI: false,
      isLocal: p.isLocal,
      ready: p.ready,
      dropId: p.dropId ?? dropVotes[p.id] ?? null,
    }));
    const aiCount = Math.max(0, maxPlayers - real.length);
    const ai: RosterEntry[] = Array.from({ length: aiCount }, (_, i) => ({
      id: `ai-${i}`,
      name: AI_NAMES[i % AI_NAMES.length],
      isAI: true,
      isLocal: false,
      ready: true,
      dropId: null,
    }));
    return [...real, ...ai];
  }, [realPlayers, maxPlayers, dropVotes]);

  const assignments = useMemo(
    () => assignDropSpots(roster, dropVotes),
    [roster, dropVotes]
  );

  const startMatch = useCallback(() => {
    if (launchedRef.current || loadState !== 'ready') return;
    const net = networkRef.current;
    if (!net) return;
    launchedRef.current = true;
    const finalAssignments = assignDropSpots(roster, dropVotes);
    onStartMatch(roster, finalAssignments, net);
  }, [dropVotes, loadState, onStartMatch, roster]);

  // Create / destroy the lobby network when the player joins.
  useEffect(() => {
    if (!open || !joined || !activeProfile) return;
    launchedRef.current = false;
    const net = new LobbyNetwork({
      room: roomCode,
      name: activeProfile.displayName,
      relayUrl: relayUrl || undefined,
      onState: (s) => {
        setPeers(s.peers);
        setHostId(s.hostId);
        setPhase(s.phase);
        setCountdown(s.countdown);
        setDropVotes(s.dropVotes);
        setRelayStatus(s.relayStatus);
      },
    });
    networkRef.current = net;
    return () => {
      // The match keeps using this adapter after the lobby UI unmounts.
      if (!launchedRef.current) net.close();
      networkRef.current = null;
    };
  }, [open, joined, activeProfile, roomCode, relayUrl]);

  // Automatic skill-queue joins a shared bracket room, with no code entry.
  useEffect(() => {
    if (!open || kind !== 'matchmaking' || !activeProfile || joined) return;
    setRoomCode(getMatchmakingRoom(activeProfile));
    setReady(true);
    setJoined(true);
  }, [open, kind, activeProfile, joined]);

  useEffect(() => {
    if (joined) networkRef.current?.setReady(ready);
  }, [joined, ready]);

  useEffect(() => {
    if (joined) networkRef.current?.setDrop(selectedDropId);
  }, [joined, selectedDropId]);

  useEffect(() => {
    if (phase === 'launch') startMatch();
  }, [phase, startMatch]);

  // Wait for similarly-rated real pilots, then fill open slots with AI and start automatically.
  useEffect(() => {
    if (!open || !joined || kind !== 'matchmaking' || phase !== 'lobby' || !isHost) return;
    const realCount = realPlayers.length;
    const delay = realCount >= maxPlayers ? 1 : 12;
    const startedAt = Date.now();
    setQueueSeconds(delay);
    const tick = window.setInterval(() => {
      setQueueSeconds(Math.max(0, delay - Math.floor((Date.now() - startedAt) / 1000)));
    }, 250);
    const timer = window.setTimeout(() => {
      if (!launchedRef.current) networkRef.current?.beginDrop();
    }, delay * 1000);
    return () => {
      window.clearInterval(tick);
      window.clearTimeout(timer);
    };
  }, [open, joined, kind, phase, isHost, realPlayers.length, maxPlayers]);

  if (!open) return null;

  const localAssignment = assignments.find((a) => a.isLocal) ?? assignments[0];
  const relayLabel =
    relayStatus === 'connected'
      ? 'Relay connected — other devices can join'
      : relayStatus === 'connecting'
      ? 'Connecting to relay…'
      : relayStatus === 'error'
      ? 'Relay unavailable — same-browser tabs only'
      : 'Local lobby — same-browser tabs can join';

  const joinLobby = () => {
    if (!activeProfile || loadState !== 'ready' || kind === 'matchmaking') return;
    launchedRef.current = false;
    setJoined(true);
  };

  const copyRoom = async () => {
    try {
      await navigator.clipboard.writeText(roomCode);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 1500);
    } catch {
      setCopied(false);
    }
  };

  return (
    <div className="fixed inset-0 z-40 flex items-center justify-center bg-black/70 p-3 sm:p-6 backdrop-blur-xl animate-soft-in">
      <div className="relative flex w-full max-w-5xl max-h-[92vh] flex-col overflow-hidden rounded-2xl border border-rose-300/25 bg-[#0c1420]/95 shadow-[0_24px_90px_rgba(0,0,0,0.8)]">
        <button
          type="button"
          onClick={onClose}
          aria-label="Close Battle Royale Lobby"
          className="absolute right-3.5 top-3.5 z-20 flex h-9 w-9 items-center justify-center rounded-full border border-white/20 bg-black/45 text-white/85 hover:bg-white/15 cursor-pointer"
        >
          <X className="h-4.5 w-4.5" />
        </button>

        {/* Header */}
        <div className="border-b border-white/12 px-5 py-4 pr-14">
          <div className="flex items-center gap-2 text-[11px] font-bold uppercase tracking-[0.22em] text-rose-300">
            <Trophy className="h-4 w-4" />
            Battle Royale Lobby · Last Symbiote Standing
          </div>
          <h2 className="font-display mt-1 text-2xl font-semibold text-white">
            {phase === 'drop'
              ? 'Choose Your Drop Point!'
              : kind === 'matchmaking'
              ? 'Searching for Skill-Matched Pilots'
              : 'Custom Lobby · Join With Code'}
          </h2>
          <p className="mt-1 text-xs text-slate-300">
            {kind === 'matchmaking'
              ? `Automatic queue · Skill rating ${skillRating} · Bracket S${skillBracket}. ${joined ? `Starting in ${queueSeconds}s; AI fills open slots.` : 'Real pilots are matched automatically.'}`
              : 'Share the room code with friends. Real pilots join first, AI fills open slots, then everyone chooses a separated drop.'}
          </p>
        </div>

        <div className="grid flex-1 grid-cols-1 overflow-y-auto md:grid-cols-[1fr_1.15fr]">
          {/* Left: Join / Roster / Controls */}
          <div className="border-b border-white/10 p-5 md:border-b-0 md:border-r">
            {!joined && kind === 'matchmaking' ? (
              <div className="rounded-2xl border border-cyan-300/25 bg-cyan-950/20 p-5 text-center">
                <div className="mx-auto h-9 w-9 animate-spin rounded-full border-2 border-cyan-200/30 border-t-cyan-200" />
                <div className="mt-3 font-display text-lg text-white">Queueing for pilots</div>
                <p className="mt-1 text-xs text-slate-300">
                  Matching Stage, mutations and hunt experience in bracket S{skillBracket}.
                  Unfilled slots become AI rivals.
                </p>
              </div>
            ) : !joined ? (
              <div className="space-y-3">
                <div>
                  <label className="block text-[10px] font-semibold uppercase tracking-wider text-slate-400">
                    Room Code
                  </label>
                  <input
                    type="text"
                    value={roomCode}
                    onChange={(e) => setRoomCode(e.target.value.toUpperCase())}
                    className="mt-1 w-full rounded-xl border border-white/18 bg-black/40 px-3 py-2 text-sm font-bold tracking-widest text-white focus:border-rose-300 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-[10px] font-semibold uppercase tracking-wider text-slate-400">
                    Optional Relay Server URL
                  </label>
                  <input
                    type="text"
                    value={relayUrl}
                    onChange={(e) => setRelayUrl(e.target.value)}
                    placeholder="ws://your-host:8787"
                    className="mt-1 w-full rounded-xl border border-white/18 bg-black/40 px-3 py-2 text-xs text-white placeholder-slate-500 focus:border-cyan-300 focus:outline-none"
                  />
                  <p className="mt-1 text-[10px] leading-relaxed text-slate-400">
                    No server? Other tabs on this browser can still join. For phones / other PCs,
                    run <strong>node lobby-server.mjs</strong> and open the game with{' '}
                    <strong>?ws=ws://your-host:8787</strong>.
                  </p>
                </div>

                <button
                  type="button"
                  onClick={joinLobby}
                  disabled={loadState !== 'ready'}
                  className="w-full rounded-xl bg-gradient-to-r from-rose-300 via-fuchsia-300 to-cyan-300 py-2.5 text-xs font-bold uppercase tracking-[0.18em] text-slate-950 disabled:opacity-50 cursor-pointer"
                >
                  {loadState === 'ready' ? 'Join Lobby' : 'Generating World…'}
                </button>
              </div>
            ) : (
              <div className="space-y-4">
                <div className="rounded-xl border border-white/12 bg-black/35 p-3">
                  <div className="flex items-center justify-between gap-2">
                    <div>
                      <div className="text-[10px] uppercase tracking-wider text-slate-400">Room</div>
                      <div className="font-display text-lg font-semibold text-white">{roomCode}</div>
                    </div>
                    <button
                      type="button"
                      onClick={copyRoom}
                      className="flex items-center gap-1 rounded-lg border border-white/18 bg-white/8 px-2.5 py-1.5 text-[11px] font-semibold text-white hover:bg-white/16 cursor-pointer"
                    >
                      {copied ? <Check className="h-3.5 w-3.5" /> : <Copy className="h-3.5 w-3.5" />}
                      {copied ? 'Copied' : 'Copy'}
                    </button>
                  </div>
                  <div className="mt-2 flex items-center gap-1.5 text-[11px]">
                    {relayStatus === 'connected' ? (
                      <Wifi className="h-3.5 w-3.5 text-emerald-300" />
                    ) : relayStatus === 'local' ? (
                      <Radio className="h-3.5 w-3.5 text-cyan-300" />
                    ) : (
                      <WifiOff className="h-3.5 w-3.5 text-amber-300" />
                    )}
                    <span className="text-slate-300">{relayLabel}</span>
                  </div>
                  {kind === 'matchmaking' && relayStatus !== 'connected' && (
                    <div className="mt-2 rounded-lg border border-amber-300/20 bg-amber-400/8 px-2.5 py-2 text-[10px] leading-relaxed text-amber-100/90">
                      <strong>No online relay is connected.</strong> Quick Match will still launch with AI
                      and same-browser players. For other devices, start <code>node lobby-server.mjs</code>
                      in the project and open this game with <code>?ws=ws://YOUR-LAN-IP:8787</code>.
                    </div>
                  )}
                </div>

                <div>
                  <div className="mb-2 flex items-center justify-between">
                    <span className="text-[10px] font-bold uppercase tracking-[0.16em] text-slate-300">
                      Pilots ({roster.length}/{maxPlayers})
                    </span>
                    <span className="inline-flex items-center gap-1 text-[10px] text-cyan-300">
                      <Users className="h-3 w-3" />
                      {realPlayers.length} real · {roster.length - realPlayers.length} AI
                    </span>
                  </div>
                  <div className="grid grid-cols-1 gap-1.5">
                    {roster.map((p) => {
                      const a = assignments.find((x) => x.playerId === p.id);
                      return (
                        <div
                          key={p.id}
                          className={`flex items-center justify-between rounded-lg border px-2.5 py-1.5 text-xs ${
                            p.isAI
                              ? 'border-white/10 bg-white/[0.03] text-slate-300'
                              : 'border-cyan-300/30 bg-cyan-950/25 text-white'
                          }`}
                        >
                          <span className="flex items-center gap-2 min-w-0">
                            <span
                              className={`h-2 w-2 shrink-0 rounded-full ${p.ready ? 'bg-emerald-400' : 'bg-amber-400'}`}
                            />
                            <span className="truncate font-medium">{p.name}</span>
                            {p.isLocal && (
                              <span className="rounded bg-white/15 px-1 py-0.5 text-[9px] font-bold uppercase">
                                You
                              </span>
                            )}
                            {p.isAI && (
                              <span className="rounded bg-white/10 px-1 py-0.5 text-[9px] font-bold uppercase">
                                AI
                              </span>
                            )}
                          </span>
                          <span className="shrink-0 text-[10px] text-slate-400">
                            {a ? a.dropName : p.ready ? 'Ready' : 'Waiting'}
                          </span>
                        </div>
                      );
                    })}
                  </div>
                </div>

                <div className="rounded-xl border border-white/12 bg-black/30 p-3">
                  <div className="text-[10px] font-bold uppercase tracking-wider text-slate-300">
                    Your Drop
                  </div>
                  <div className="mt-1 flex items-center gap-1.5 text-sm font-semibold text-white">
                    <MapPin className="h-4 w-4" style={{ color: getDropSpot(selectedDropId).color }} />
                    {getDropSpot(selectedDropId).name}
                  </div>
                  <p className="mt-1 text-[10px] text-slate-400">
                    Click a spread-out drop marker on the map to change your choice.
                  </p>
                </div>

                <div className="space-y-2">
                  <button
                    type="button"
                    onClick={() => setReady((v) => !v)}
                    className={`w-full rounded-xl border py-2 text-xs font-bold uppercase tracking-[0.16em] cursor-pointer ${
                      ready
                        ? 'border-emerald-300/60 bg-emerald-400/20 text-emerald-200'
                        : 'border-white/18 bg-white/8 text-white hover:bg-white/16'
                    }`}
                  >
                    {ready ? 'Ready ✓' : 'Mark Ready'}
                  </button>

                  {phase === 'lobby' && (
                    <button
                      type="button"
                      onClick={() => networkRef.current?.beginDrop()}
                      disabled={!isHost || loadState !== 'ready'}
                      className="flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-amber-300 via-rose-300 to-fuchsia-300 py-2.5 text-xs font-bold uppercase tracking-[0.18em] text-slate-950 disabled:opacity-45 cursor-pointer"
                    >
                      <Play className="h-4 w-4 fill-slate-950" />
                      {isHost ? 'Begin Drop Phase' : 'Waiting for Host'}
                    </button>
                  )}

                  {phase !== 'lobby' && (
                    <div className="rounded-xl border border-rose-300/50 bg-rose-950/40 p-3 text-center">
                      <div className="text-[10px] font-bold uppercase tracking-[0.2em] text-rose-200">
                        {phase === 'launch' ? 'Deploying…' : 'Match starts in'}
                      </div>
                      <div className="font-display text-4xl font-semibold text-white tabular-nums">
                        {Math.max(0, countdown)}
                      </div>
                      <div className="text-[10px] text-slate-300">
                        AI pilots are being assigned remaining spread-out drop zones.
                      </div>
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>

          {/* Right: terrain atlas and ground-level view of the selected landing */}
          <div className="p-5">
            <div className="mb-2 flex items-center justify-between">
              <span className="text-[10px] font-bold uppercase tracking-[0.16em] text-slate-300">
                Drop Zone Terrain Atlas
              </span>
              <span className="text-[10px] text-slate-400">
                {DROP_SPOTS.length} landing regions · select a marker
              </span>
            </div>

            <div className="h-[320px] sm:h-[390px] overflow-hidden rounded-xl border border-white/15">
              <DropZoneMap
                spots={DROP_SPOTS}
                assignments={assignments}
                selectedDropId={selectedDropId}
                zoneRadius={780}
                onSelect={setSelectedDropId}
              />
            </div>

            <div className="mt-2 flex items-center justify-between rounded-lg border border-white/10 bg-black/25 px-2.5 py-1.5">
              <span className="text-[9px] font-semibold uppercase tracking-wider text-slate-400">
                Selected Landing
              </span>
              <span className="text-[11px] font-semibold text-white">
                {getDropSpot(selectedDropId).name}
              </span>
            </div>

            <div className="mt-2 h-[168px] sm:h-[190px] overflow-hidden rounded-xl border border-white/15">
              <LandingPreview
                spot={getDropSpot(selectedDropId)}
                countdown={phase === 'drop' ? countdown : undefined}
              />
            </div>

            <div className="mt-3 grid grid-cols-2 gap-2 text-[10px] text-slate-300">
              <div className="rounded-lg border border-white/10 bg-black/30 p-2">
                <strong className="text-cyan-200">See Your Drop:</strong> hill-shaded terrain atlas
                plus a ground-level landing vista.
              </div>
              <div className="rounded-lg border border-white/10 bg-black/30 p-2">
                <strong className="text-rose-200">Spread Drops:</strong> players land far apart
                inside the opening Bio-Storm ring.
              </div>
              <div className="rounded-lg border border-white/10 bg-black/30 p-2">
                <strong className="text-emerald-200">Local Roster:</strong>{' '}
                {localAssignment?.dropName ?? 'Lumen Ridge'} is your current landing zone.
              </div>
              <div className="rounded-lg border border-white/10 bg-black/30 p-2">
                <strong className="text-amber-200">Bio-Storm:</strong> the safe ring collapses and
                the last player alive wins.
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

