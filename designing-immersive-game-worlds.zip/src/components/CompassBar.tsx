import React from 'react';
import { BIOMES, BiomeId } from '../world/biomes';

interface CompassBarProps {
  bearingDeg: number;
  biome: BiomeId;
  altitude: number;
  playerX: number;
  playerZ: number;
  trackedBiome: BiomeId | null;
}

const CARDINALS: ReadonlyArray<{ deg: number; label: string; major: boolean }> = [
  { deg: 0, label: 'N', major: true },
  { deg: 45, label: 'NE', major: false },
  { deg: 90, label: 'E', major: true },
  { deg: 135, label: 'SE', major: false },
  { deg: 180, label: 'S', major: true },
  { deg: 225, label: 'SW', major: false },
  { deg: 270, label: 'W', major: true },
  { deg: 315, label: 'NW', major: false },
];

function wrapDeltaDeg(from: number, to: number): number {
  let d = ((to - from + 540) % 360) - 180;
  if (d < -180) d += 360;
  return d;
}

export const CompassBar: React.FC<CompassBarProps> = ({
  bearingDeg,
  biome,
  altitude,
  playerX,
  playerZ,
  trackedBiome,
}) => {
  const halfSpan = 68; // Visible compass arc +-68 deg
  const currentDef = BIOMES[biome];

  // Calculate tracked landmark bearing & distance if pinned
  let markerOffsetPct: number | null = null;
  let markerDistM = 0;
  let markerColor = '#fcd34d';
  let markerName = '';

  if (trackedBiome) {
    const tDef = BIOMES[trackedBiome];
    const dx = tDef.landmark.x - playerX;
    const dz = tDef.landmark.z - playerZ;
    markerDistM = Math.round(Math.hypot(dx, dz));
    if (markerDistM > 8) {
      // North = (0, -1) -> 0 deg, East = (+1, 0) -> 90 deg
      const targetDeg = ((Math.atan2(dx, -dz) * 180) / Math.PI + 360) % 360;
      const delta = wrapDeltaDeg(bearingDeg, targetDeg);
      const clamped = Math.max(-halfSpan, Math.min(halfSpan, delta));
      markerOffsetPct = 50 + (clamped / halfSpan) * 46;
      markerColor = tDef.accentColor;
      markerName = tDef.landmark.name;
    }
  }

  return (
    <div className="pointer-events-none flex flex-col items-center select-none">
      {/* Horizon Compass Tape */}
      <div
        className="relative h-7 w-56 sm:w-72 overflow-hidden"
        style={{
          maskImage:
            'linear-gradient(to right, transparent 0%, black 18%, black 82%, transparent 100%)',
          WebkitMaskImage:
            'linear-gradient(to right, transparent 0%, black 18%, black 82%, transparent 100%)',
        }}
      >
        {/* Subtle horizon hairline */}
        <div className="absolute inset-x-0 bottom-1.5 h-px bg-white/25" />

        {/* Center notch */}
        <div className="absolute left-1/2 bottom-0.5 -translate-x-1/2 w-1 h-2 bg-white/90 rounded-full shadow" />

        {/* Minor 15-degree tick marks */}
        {Array.from({ length: 24 }).map((_, i) => {
          const deg = i * 15;
          if (deg % 45 === 0) return null;
          const delta = wrapDeltaDeg(bearingDeg, deg);
          if (Math.abs(delta) > halfSpan) return null;
          const leftPct = 50 + (delta / halfSpan) * 46;
          return (
            <div
              key={deg}
              className="absolute bottom-1.5 h-1 w-px bg-white/30 -translate-x-1/2"
              style={{ left: `${leftPct}%` }}
            />
          );
        })}

        {/* Cardinal & Intercardinal directions */}
        {CARDINALS.map((c) => {
          const delta = wrapDeltaDeg(bearingDeg, c.deg);
          if (Math.abs(delta) > halfSpan) return null;
          const leftPct = 50 + (delta / halfSpan) * 46;
          return (
            <div
              key={c.label}
              className="absolute bottom-1.5 -translate-x-1/2 flex flex-col items-center"
              style={{ left: `${leftPct}%` }}
            >
              <span
                className={
                  c.major
                    ? `text-[11px] font-semibold tracking-wider leading-none mb-1 drop-shadow-[0_1px_3px_rgba(0,0,0,0.85)] ${
                        c.label === 'N' ? 'text-amber-200' : 'text-white/95'
                      }`
                    : 'text-[9px] font-medium text-white/65 leading-none mb-1 drop-shadow-[0_1px_2px_rgba(0,0,0,0.8)]'
                }
              >
                {c.label}
              </span>
              <div className={c.major ? 'h-1.5 w-px bg-white/75' : 'h-1 w-px bg-white/45'} />
            </div>
          );
        })}

        {/* Pinned Biome Waypoint Diamond */}
        {markerOffsetPct !== null && (
          <div
            className="absolute bottom-1 -translate-x-1/2 flex flex-col items-center"
            style={{ left: `${markerOffsetPct}%` }}
          >
            <div
              className="w-2.5 h-2.5 rotate-45 border border-black/40 shadow-[0_0_8px_rgba(255,255,255,0.65)]"
              style={{ backgroundColor: markerColor }}
            />
          </div>
        )}
      </div>

      {/* Whisper-light Region & Elevation Caption */}
      <div className="mt-0.5 flex items-center gap-2 text-[11px] font-medium tracking-[0.14em] uppercase text-white/85 drop-shadow-[0_1px_4px_rgba(0,0,0,0.85)]">
        <span>{currentDef.name}</span>
        <span className="text-white/40">·</span>
        <span className="tabular-nums text-white/70">{altitude}m</span>
        {markerOffsetPct !== null && (
          <>
            <span className="text-white/40">·</span>
            <span className="tabular-nums normal-case tracking-normal text-xs" style={{ color: markerColor }}>
              {markerName} {markerDistM}m
            </span>
          </>
        )}
      </div>
    </div>
  );
};
