import React, { useEffect, useRef } from 'react';
import { BIOMES, WORLD_MAP_RADIUS, computeTerrainColor, getTerrainHeightWithWeights, sampleBiomeWeights } from '../world/biomes';
import { DropAssignment, DropSpot } from '../world/lobby';
import { lerp, smoothstep } from '../world/noise';

interface DropZoneMapProps {
  spots: DropSpot[];
  assignments: DropAssignment[];
  selectedDropId: string;
  zoneRadius?: number;
  onSelect: (id: string) => void;
}

const MAP_SIZE = 340;
let cachedAtlasUrl: string | null = null;

function buildAtlasDataUrl(): string {
  if (cachedAtlasUrl) return cachedAtlasUrl;
  const canvas = document.createElement('canvas');
  canvas.width = MAP_SIZE;
  canvas.height = MAP_SIZE;
  const ctx = canvas.getContext('2d');
  if (!ctx) return '';

  const heights = new Float32Array(MAP_SIZE * MAP_SIZE);
  const biomes: ReturnType<typeof sampleBiomeWeights>[] = new Array(MAP_SIZE * MAP_SIZE);
  const step = (2 * WORLD_MAP_RADIUS) / (MAP_SIZE - 1);

  for (let py = 0; py < MAP_SIZE; py++) {
    const z = ((py / (MAP_SIZE - 1)) * 2 - 1) * WORLD_MAP_RADIUS;
    for (let px = 0; px < MAP_SIZE; px++) {
      const x = ((px / (MAP_SIZE - 1)) * 2 - 1) * WORLD_MAP_RADIUS;
      const w = sampleBiomeWeights(x, z);
      biomes[py * MAP_SIZE + px] = w;
      heights[py * MAP_SIZE + px] = getTerrainHeightWithWeights(x, z, w);
    }
  }

  const image = ctx.createImageData(MAP_SIZE, MAP_SIZE);
  const data = image.data;
  const rgb: [number, number, number] = [0, 0, 0];
  const light = [-0.58, 0.64, -0.5];

  for (let py = 0; py < MAP_SIZE; py++) {
    for (let px = 0; px < MAP_SIZE; px++) {
      const i = py * MAP_SIZE + px;
      const h = heights[i];
      const left = heights[py * MAP_SIZE + Math.max(0, px - 1)];
      const right = heights[py * MAP_SIZE + Math.min(MAP_SIZE - 1, px + 1)];
      const up = heights[Math.max(0, py - 1) * MAP_SIZE + px];
      const down = heights[Math.min(MAP_SIZE - 1, py + 1) * MAP_SIZE + px];
      const nx = left - right;
      const ny = 2 * step;
      const nz = up - down;
      const inv = 1 / Math.hypot(nx, ny, nz);

      let r: number;
      let g: number;
      let b: number;
      if (h < 0) {
        const depth = -h;
        const w = biomes[i];
        const coast = w.coast;
        const abyss = smoothstep(12, 64, depth);
        const shore = 1 - smoothstep(0, 3, depth);
        r = lerp(0.08, 0.28, coast) * (1 - abyss) + 0.025 * abyss + shore * 0.12;
        g = lerp(0.13, 0.5, coast) * (1 - abyss) + 0.04 * abyss + shore * 0.11;
        b = lerp(0.36, 0.78, coast) * (1 - abyss) + 0.2 * abyss + shore * 0.09;
      } else {
        const w = biomes[i];
        const x = ((px / (MAP_SIZE - 1)) * 2 - 1) * WORLD_MAP_RADIUS;
        const z = ((py / (MAP_SIZE - 1)) * 2 - 1) * WORLD_MAP_RADIUS;
        computeTerrainColor(x, z, h, ny * inv, w, rgb);
        const lightSlope = (nx * light[0] + ny * light[1] + nz * light[2]) * inv;
        const shade = 0.56 + Math.max(0, Math.min(1, lightSlope + 0.34)) * 0.58;
        const contourPhase = Math.abs(((h % 28) + 28) % 28 - 14);
        const contour = contourPhase < 0.26 ? 0.78 : 1;
        r = rgb[0] * shade * contour;
        g = rgb[1] * shade * contour;
        b = rgb[2] * shade * contour;
        const biomeColor = w.dominant === 'alpine'
          ? [0.77, 0.84, 1]
          : w.dominant === 'wasteland'
          ? [0.78, 0.48, 0.62]
          : w.dominant === 'jungle'
          ? [0.38, 0.92, 0.69]
          : w.dominant === 'plains'
          ? [1, 0.7, 0.5]
          : null;
        if (biomeColor) {
          const tint = w[w.dominant] * 0.16;
          r = lerp(r, biomeColor[0], tint);
          g = lerp(g, biomeColor[1], tint);
          b = lerp(b, biomeColor[2], tint);
        }
      }

      const k = i * 4;
      data[k] = Math.round(Math.min(1, r) * 255);
      data[k + 1] = Math.round(Math.min(1, g) * 255);
      data[k + 2] = Math.round(Math.min(1, b) * 255);
      data[k + 3] = 255;
    }
  }
  ctx.putImageData(image, 0, 0);
  cachedAtlasUrl = canvas.toDataURL('image/png');
  return cachedAtlasUrl;
}

function toMapPercent(x: number, z: number): { left: string; top: string } {
  const px = Math.max(3, Math.min(97, (x / WORLD_MAP_RADIUS + 1) * 50));
  const py = Math.max(3, Math.min(97, (z / WORLD_MAP_RADIUS + 1) * 50));
  return { left: `${px}%`, top: `${py}%` };
}

/** Real terrain atlas; overlays landing zones and pilots, instead of an empty coordinate grid. */
export const DropZoneMap: React.FC<DropZoneMapProps> = ({
  spots,
  assignments,
  selectedDropId,
  zoneRadius = 780,
  onSelect,
}) => {
  const imgRef = useRef<HTMLImageElement | null>(null);
  useEffect(() => {
    const img = imgRef.current;
    if (!img || img.src) return;
    img.src = buildAtlasDataUrl();
  }, []);

  return (
    <div className="relative h-full w-full overflow-hidden rounded-xl bg-[#111a28]">
      <img
        ref={imgRef}
        alt="Hill-shaded Solvara terrain atlas"
        className="absolute inset-0 h-full w-full object-cover"
        draggable={false}
      />
      <div className="pointer-events-none absolute inset-0 bg-gradient-to-b from-slate-950/10 via-transparent to-slate-950/35" />

      {/* Opening safe-zone ring; every fixed drop site is inside this boundary. */}
      <svg className="pointer-events-none absolute inset-0 h-full w-full" viewBox="0 0 100 100" preserveAspectRatio="none" aria-hidden="true">
        <circle
          cx="50"
          cy="50"
          r={(zoneRadius / WORLD_MAP_RADIUS) * 50}
          fill="rgba(45,212,191,0.045)"
          stroke="rgba(153,246,228,0.72)"
          strokeWidth="0.42"
          strokeDasharray="1.4 0.8"
          vectorEffect="non-scaling-stroke"
        />
        <circle
          cx="50"
          cy="50"
          r={(zoneRadius / WORLD_MAP_RADIUS) * 50}
          fill="none"
          stroke="rgba(45,212,191,0.22)"
          strokeWidth="1.1"
          vectorEffect="non-scaling-stroke"
        />
      </svg>

      {/* Spread-out landing markers and pilot roster dots */}
      {spots.map((spot) => {
        const pos = toMapPercent(spot.x, spot.z);
        const selected = spot.id === selectedDropId;
        const owners = assignments.filter((a) => a.dropId === spot.id);
        return (
          <button
            key={spot.id}
            type="button"
            onClick={() => onSelect(spot.id)}
            title={`${spot.name} · ${owners.length} pilot${owners.length === 1 ? '' : 's'}`}
            className="group absolute z-10 -translate-x-1/2 -translate-y-1/2 cursor-pointer"
            style={pos}
          >
            {selected && (
              <span className="absolute -inset-2 animate-ping rounded-full border border-white/70" />
            )}
            <span
              className={`relative block rounded-full border-2 transition-all ${
                selected
                  ? 'h-5 w-5 border-white shadow-[0_0_18px_rgba(255,255,255,0.9)]'
                  : 'h-3.5 w-3.5 border-white/75 group-hover:scale-125'
              }`}
              style={{ backgroundColor: spot.color }}
            />
            <span
              className={`pointer-events-none absolute left-1/2 top-full mt-1 -translate-x-1/2 whitespace-nowrap rounded px-1.5 py-0.5 text-[8px] font-semibold shadow ${
                selected ? 'bg-white text-slate-950' : 'bg-slate-950/80 text-white/90'
              }`}
            >
              {spot.name}
            </span>
            {owners.length > 0 && (
              <span className="absolute -right-2 -top-2 flex h-4 min-w-4 items-center justify-center rounded-full border border-slate-950 bg-slate-950 px-1 text-[8px] font-bold text-cyan-100">
                {owners.some((owner) => owner.isLocal) ? 'YOU' : owners.length}
              </span>
            )}
          </button>
        );
      })}

      <div className="pointer-events-none absolute left-2 top-2 rounded-full border border-white/20 bg-slate-950/65 px-2.5 py-1 text-[9px] font-semibold uppercase tracking-[0.18em] text-white/90 backdrop-blur">
        Solvara Drop Atlas
      </div>
      <div className="pointer-events-none absolute bottom-2 right-2 rounded bg-slate-950/65 px-2 py-1 text-[9px] tabular-nums text-white/75 backdrop-blur">
        ~{Math.round(WORLD_MAP_RADIUS * 2 / 100) / 10} km across
      </div>
    </div>
  );
};

export { toMapPercent };
export { BIOMES as DROP_BIOMES };

interface LandingPreviewProps {
  spot: DropSpot;
  countdown?: number;
}

/**
 * Ground-level, terrain-sampled panorama for the currently selected drop.
 * It is a lightweight 2D preview (not an inset WebGL renderer) and gives each
 * landing point a recognizable horizon, biome palette, foliage silhouette and
 * relative hills/ridges before the match starts.
 */
export const LandingPreview: React.FC<LandingPreviewProps> = ({ spot, countdown }) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext('2d');
    if (!canvas || !ctx) return;

    const wPx = Math.max(1, Math.round(canvas.clientWidth * 1.5));
    const hPx = Math.max(1, Math.round(canvas.clientHeight * 1.5));
    canvas.width = wPx;
    canvas.height = hPx;
    const w = wPx;
    const h = hPx;
    const biome = BIOMES[spot.biome];
    const tint = biome.fogTint;
    const accent = biome.accentColor;
    const horizon = h * 0.47;
    const ground = getTerrainHeightWithWeights(
      spot.x,
      spot.z,
      sampleBiomeWeights(spot.x, spot.z)
    );
    const cameraY = ground + 1.75;
    const yaw = biome.landmark.yaw;
    const forwardX = -Math.sin(yaw);
    const forwardZ = -Math.cos(yaw);
    const rightX = Math.cos(yaw);
    const rightZ = -Math.sin(yaw);
    const slices = 84;
    const depths = [520, 370, 255, 170, 112, 72, 42, 24];
    const base: [number, number, number] = [0, 0, 0];

    const sky = ctx.createLinearGradient(0, 0, 0, horizon + 36);
    sky.addColorStop(0, '#11172b');
    sky.addColorStop(0.42, '#544d89');
    sky.addColorStop(0.82, `rgb(${Math.round(tint[0] * 255)},${Math.round(tint[1] * 255)},${Math.round(tint[2] * 255)})`);
    sky.addColorStop(1, '#d7a9aa');
    ctx.fillStyle = sky;
    ctx.fillRect(0, 0, w, h);

    // Distant companion planet and low atmospheric sun.
    ctx.globalAlpha = 0.7;
    ctx.fillStyle = '#f2c3ba';
    ctx.beginPath();
    ctx.arc(w * 0.78, horizon * 0.57, h * 0.075, 0, Math.PI * 2);
    ctx.fill();
    ctx.globalAlpha = 0.55;
    ctx.strokeStyle = '#e8cbd6';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.ellipse(w * 0.78, horizon * 0.57, h * 0.12, h * 0.027, -0.14, 0, Math.PI * 2);
    ctx.stroke();
    ctx.globalAlpha = 1;

    // Draw successively nearer terrain strips. Heights and albedo are sampled from the same world generator.
    for (let layer = 0; layer < depths.length; layer++) {
      const depth = depths[layer];
      const points: Array<{ x: number; y: number; c: [number, number, number] }> = [];
      let cr = 0;
      let cg = 0;
      let cb = 0;
      for (let i = 0; i <= slices; i++) {
        const u = i / slices;
        const lateral = (u - 0.5) * depth * 1.5;
        const wx = spot.x + forwardX * depth + rightX * lateral;
        const wz = spot.z + forwardZ * depth + rightZ * lateral;
        const weights = sampleBiomeWeights(wx, wz);
        const elevation = getTerrainHeightWithWeights(wx, wz, weights);
        computeTerrainColor(wx, wz, elevation, 0.94, weights, base);
        const light = 0.84 + 0.12 * Math.sin(u * 19 + layer * 0.8);
        const color: [number, number, number] = [base[0] * light, base[1] * light, base[2] * light];
        cr += color[0];
        cg += color[1];
        cb += color[2];
        const projectedY = horizon - ((elevation - cameraY) * h * 0.76) / Math.max(18, depth);
        points.push({ x: u * w, y: Math.max(horizon * 0.48, Math.min(h * 0.87, projectedY)), c: color });
      }
      cr /= points.length;
      cg /= points.length;
      cb /= points.length;
      ctx.beginPath();
      ctx.moveTo(0, h);
      ctx.lineTo(points[0].x, points[0].y);
      for (let i = 1; i < points.length; i++) ctx.lineTo(points[i].x, points[i].y);
      ctx.lineTo(w, h);
      ctx.closePath();
      ctx.fillStyle = `rgb(${Math.round(Math.min(1, cr) * 255)},${Math.round(Math.min(1, cg) * 255)},${Math.round(Math.min(1, cb) * 255)})`;
      ctx.globalAlpha = 0.5 + (layer / depths.length) * 0.5;
      ctx.fill();

      // Fine terrain crest catches alien twilight.
      ctx.beginPath();
      ctx.moveTo(points[0].x, points[0].y);
      for (let i = 1; i < points.length; i++) ctx.lineTo(points[i].x, points[i].y);
      ctx.strokeStyle = accent;
      ctx.lineWidth = layer > 4 ? 1.3 : 0.6;
      ctx.globalAlpha = layer > 4 ? 0.2 : 0.12;
      ctx.stroke();
      ctx.globalAlpha = 1;
    }

    // Region-specific silhouette: alien vegetation / crystals at a human viewing scale.
    const rng = (n: number) => {
      const v = Math.sin(n * 127.1 + spot.x * 0.13 + spot.z * 0.19) * 43758.5453;
      return v - Math.floor(v);
    };
    for (let i = 0; i < 15; i++) {
      const x = (i / 14) * w + (rng(i + 2) - 0.5) * 16;
      const size = 14 + rng(i + 9) * 32;
      const y = horizon + 17 + rng(i + 19) * 29;
      ctx.fillStyle = accent;
      ctx.globalAlpha = 0.23 + rng(i + 27) * 0.3;
      if (spot.biome === 'alpine' || spot.biome === 'wasteland') {
        ctx.beginPath();
        ctx.moveTo(x, y - size);
        ctx.lineTo(x - size * 0.24, y);
        ctx.lineTo(x + size * 0.24, y);
        ctx.closePath();
        ctx.fill();
      } else if (spot.biome === 'forest' || spot.biome === 'jungle' || spot.biome === 'wetland') {
        ctx.fillRect(x - 2, y - size * 0.32, 4, size * 0.38);
        ctx.beginPath();
        ctx.ellipse(x, y - size * 0.55, size * 0.32, size * 0.48, 0, 0, Math.PI * 2);
        ctx.fill();
        if (spot.biome === 'forest') {
          ctx.beginPath();
          ctx.ellipse(x, y - size * 0.89, size * 0.5, size * 0.18, 0, 0, Math.PI * 2);
          ctx.fill();
        }
      } else {
        for (let blade = 0; blade < 5; blade++) {
          ctx.beginPath();
          ctx.moveTo(x, y);
          ctx.quadraticCurveTo(x + (blade - 2) * 3, y - size * 0.5, x + (blade - 2) * 5, y - size * (0.45 + rng(blade + i) * 0.45));
          ctx.lineWidth = 1.4;
          ctx.strokeStyle = accent;
          ctx.stroke();
        }
      }
    }
    ctx.globalAlpha = 1;

    // Foreground landing beacon and safe landing apron.
    const beaconX = w * 0.53;
    const beaconY = h * 0.83;
    ctx.fillStyle = 'rgba(7,12,23,0.55)';
    ctx.beginPath();
    ctx.ellipse(beaconX, beaconY + 10, 55, 8, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = '#d9e5ef';
    ctx.fillRect(beaconX - 1, beaconY - 24, 2, 31);
    ctx.fillStyle = accent;
    ctx.shadowColor = accent;
    ctx.shadowBlur = 12;
    ctx.beginPath();
    ctx.arc(beaconX, beaconY - 25, 4, 0, Math.PI * 2);
    ctx.fill();
    ctx.shadowBlur = 0;

    // Lens vignette keeps location name legible without obscuring the vista.
    const vignette = ctx.createLinearGradient(0, 0, 0, h);
    vignette.addColorStop(0, 'rgba(5,8,17,0.18)');
    vignette.addColorStop(0.48, 'rgba(5,8,17,0)');
    vignette.addColorStop(1, 'rgba(5,8,17,0.34)');
    ctx.fillStyle = vignette;
    ctx.fillRect(0, 0, w, h);
  }, [spot]);

  const biome = BIOMES[spot.biome];
  return (
    <div className="overflow-hidden rounded-xl border border-white/15 bg-[#101722]">
      <div className="relative h-32 sm:h-40">
        <canvas ref={canvasRef} className="absolute inset-0 h-full w-full" />
        <div className="pointer-events-none absolute inset-x-0 top-0 flex items-start justify-between gap-2 bg-gradient-to-b from-black/60 to-transparent px-3 py-2">
          <div>
            <div className="text-[9px] font-bold uppercase tracking-[0.2em]" style={{ color: biome.accentColor }}>
              First-Person Landing Preview
            </div>
            <div className="font-display text-sm font-semibold text-white drop-shadow">{biome.landmark.name}</div>
          </div>
          {typeof countdown === 'number' && countdown > 0 && (
            <div className="rounded-lg border border-amber-200/40 bg-black/65 px-2.5 py-1 text-[10px] font-bold text-amber-100">
              LANDING IN {countdown}s
            </div>
          )}
        </div>
        <div className="pointer-events-none absolute inset-x-0 bottom-0 flex items-end justify-between gap-2 bg-gradient-to-t from-black/60 to-transparent px-3 pb-2 pt-4">
          <span className="text-[9px] font-semibold uppercase tracking-[0.14em] text-white/90">{biome.name}</span>
          <span className="text-[9px] text-white/75">{biome.subtitle}</span>
        </div>
      </div>
    </div>
  );
};