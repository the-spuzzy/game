import React from 'react';
import { Check, Dna, Flame, Shield, Sparkles, Wind, X, Zap } from 'lucide-react';
import {
  ABILITIES,
  AbilityId,
  ESSENCES,
  EssenceType,
  SlimeEvolutionState,
  TRAITS,
  TraitId,
  getDietTraitChoices,
  getStageTitle,
} from '../world/evolution';

interface EvolutionModalProps {
  open: boolean;
  onClose: () => void;
  evo: SlimeEvolutionState;
  onSelectTrait: (traitId: TraitId) => void;
}

export const EvolutionModal: React.FC<EvolutionModalProps> = ({
  open,
  onClose,
  evo,
  onSelectTrait,
}) => {
  if (!open) return null;

  const choices = getDietTraitChoices(evo.traits, evo.stageDiet, evo.totalDiet);
  const totalStagePoints =
    evo.stageDiet.predator +
    evo.stageDiet.chitin +
    evo.stageDiet.gelatinous +
    evo.stageDiet.aerial;

  // Find dominant eaten essence to highlight why these traits were offered
  let topEssence: EssenceType = 'gelatinous';
  let bestVal = -1;
  (Object.keys(ESSENCES) as EssenceType[]).forEach((k) => {
    const val = evo.stageDiet[k] * 3 + evo.totalDiet[k];
    if (val > bestVal) {
      bestVal = val;
      topEssence = k;
    }
  });

  return (
    <div
      className="fixed inset-0 z-40 flex items-center justify-center bg-black/65 backdrop-blur-md p-3 sm:p-6 animate-soft-in"
      onPointerDown={(e) => {
        e.stopPropagation();
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div
        className="relative flex w-full max-w-4xl max-h-[92vh] flex-col overflow-y-auto rounded-2xl border border-cyan-300/25 bg-[#0c1420]/94 p-5 sm:p-7 text-white shadow-[0_24px_80px_rgba(0,0,0,0.75)]"
        onPointerDown={(e) => e.stopPropagation()}
      >
        <button
          type="button"
          onClick={onClose}
          aria-label="Close Evolution Chamber"
          className="absolute right-4 top-4 flex h-9 w-9 items-center justify-center rounded-full border border-white/20 bg-white/8 text-white/85 hover:bg-white/18 transition cursor-pointer"
        >
          <X className="h-4.5 w-4.5" />
        </button>

        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-white/12 pb-4 pr-10">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-[0.22em] text-cyan-300">
              <Dna className="h-4 w-4" />
              <span>
                {evo.evolveReady
                  ? 'Metamorphosis Ready — Choose Your Mutation!'
                  : 'Symbiote Genome & Diet Chamber'}
              </span>
            </div>
            <h2 className="font-display mt-1 text-2xl sm:text-3xl font-semibold tracking-wide text-white">
              {evo.speciesName} · Stage {evo.stage} ({getStageTitle(evo.stage)})
            </h2>
          </div>

          <div className="flex items-center gap-3 text-xs">
            <div className="rounded-xl border border-white/14 bg-black/40 px-3 py-2 text-center">
              <div className="text-[10px] uppercase tracking-wider text-slate-400">Size</div>
              <div className="font-bold text-cyan-200 tabular-nums">
                {evo.bodyScale.toFixed(2)}x
              </div>
            </div>
            <div className="rounded-xl border border-white/14 bg-black/40 px-3 py-2 text-center">
              <div className="text-[10px] uppercase tracking-wider text-slate-400">Max HP</div>
              <div className="font-bold text-emerald-300 tabular-nums">{evo.maxHp}</div>
            </div>
            <div className="rounded-xl border border-white/14 bg-black/40 px-3 py-2 text-center">
              <div className="text-[10px] uppercase tracking-wider text-slate-400">Bite / Spit</div>
              <div className="font-bold text-rose-300 tabular-nums">
                {evo.biteDamage} / {evo.spitDamage}
              </div>
            </div>
          </div>
        </div>

        {evo.ascended && (
          <div className="mt-4 flex items-center gap-2 rounded-xl border border-fuchsia-300/40 bg-fuchsia-950/35 px-4 py-2.5 text-xs text-fuchsia-100">
            <Sparkles className="h-4 w-4 shrink-0 text-fuchsia-300" />
            <span>
              <strong>Blob Form Shed!</strong> Your organism is now an Ascended Xeno-Beast — a full
              skeletal alien creature with a head, legs, claws and tail instead of a goo membrane.
            </span>
          </div>
        )}

        {/* Diet DNA Breakdown Bar (What You Ate This Stage) */}
        <div className="mt-4 rounded-xl border border-white/12 bg-black/35 p-4">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <span className="text-xs font-semibold uppercase tracking-[0.16em] text-slate-200">
              Genetic Diet Profile (Determines Available Traits)
            </span>
            <span className="text-xs text-slate-300">
              Dominant Diet:{' '}
              <strong style={{ color: ESSENCES[topEssence].color }}>
                {ESSENCES[topEssence].name}
              </strong>
            </span>
          </div>

          <div className="mt-3 grid grid-cols-2 sm:grid-cols-4 gap-2.5">
            {(Object.keys(ESSENCES) as EssenceType[]).map((k) => {
              const ess = ESSENCES[k];
              const pts = evo.stageDiet[k];
              const pct =
                totalStagePoints > 0 ? Math.round((pts / totalStagePoints) * 100) : 25;
              return (
                <div
                  key={k}
                  className="rounded-lg border border-white/10 bg-white/[0.03] p-2.5"
                >
                  <div className="flex items-center justify-between text-xs font-semibold">
                    <span style={{ color: ess.color }}>{ess.shortName}</span>
                    <span className="tabular-nums text-white/80">{pct}%</span>
                  </div>
                  <div className="mt-1.5 h-1.5 w-full overflow-hidden rounded-full bg-white/10">
                    <div
                      className="h-full rounded-full transition-all duration-300"
                      style={{
                        width: `${Math.max(8, pct)}%`,
                        backgroundColor: ess.color,
                      }}
                    />
                  </div>
                  <div className="mt-1 text-[10px] text-slate-400 truncate" title={ess.sources}>
                    Eat: {ess.sources}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Evolution Ability Genome — abilities unlock automatically by stage or early via traits */}
        <div className="mt-4 rounded-xl border border-cyan-300/20 bg-black/35 p-3.5">
          <div className="flex items-center justify-between gap-2">
            <span className="text-[11px] font-semibold uppercase tracking-[0.16em] text-cyan-200">
              Evolution Ability Genome
            </span>
            <span className="text-[10px] text-slate-400">
              {evo.abilities.length} / {Object.keys(ABILITIES).length} unlocked
            </span>
          </div>
          <div className="mt-2.5 grid grid-cols-1 sm:grid-cols-2 gap-2">
            {(Object.keys(ABILITIES) as AbilityId[]).map((id) => {
              const a = ABILITIES[id];
              const unlocked = evo.abilities.includes(id);
              return (
                <div
                  key={id}
                  className={`rounded-lg border px-2.5 py-1.5 ${
                    unlocked ? 'border-white/25 bg-white/10' : 'border-white/10 bg-black/25'
                  }`}
                >
                  <div className="flex items-center justify-between gap-2">
                    <span
                      className="inline-flex items-center gap-1 text-xs font-bold"
                      style={{ color: unlocked ? a.color : '#94a3b8' }}
                    >
                      <Zap className="h-3 w-3" />
                      {a.name}
                    </span>
                    <span className="text-[9px] uppercase tracking-wider text-slate-400 shrink-0">
                      {unlocked
                        ? a.active
                          ? `Ready · ${a.key}`
                          : 'Passive'
                        : a.active
                        ? `Stage ${a.unlockStage}`
                        : 'Trait Unlock'}
                    </span>
                  </div>
                  <p className="mt-0.5 text-[10px] leading-snug text-slate-300">
                    {a.description}
                  </p>
                </div>
              );
            })}
          </div>
        </div>

        {/* 3 Diet-Driven Trait Selection Cards */}
        <div className="mt-5">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-semibold uppercase tracking-[0.18em] text-amber-200">
              {evo.evolveReady
                ? 'Select 1 Trait to Evolve & Mutate Your 3D Body:'
                : `Preview Next Evolution Choices (${evo.dna} / ${evo.dnaNext} DNA):`}
            </span>
            {!evo.evolveReady && (
              <span className="text-xs text-cyan-300">
                Eat {Math.max(0, evo.dnaNext - evo.dna)} more DNA from wildlife to unlock!
              </span>
            )}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-3.5">
            {choices.map((trait) => {
              const ess = ESSENCES[trait.essence];
              const isDietMatch = trait.essence === topEssence && totalStagePoints > 0;
              return (
                <div
                  key={trait.id}
                  className={`flex flex-col justify-between rounded-2xl border p-4 transition-all ${
                    evo.evolveReady
                      ? 'border-white/25 bg-white/[0.06] hover:border-cyan-300/70 hover:bg-white/[0.1]'
                      : 'border-white/12 bg-white/[0.03] opacity-90'
                  }`}
                >
                  <div>
                    <div className="flex items-center justify-between gap-1">
                      <span
                        className="inline-flex items-center gap-1 rounded-full px-2.5 py-0.5 text-[10px] font-bold uppercase tracking-wider"
                        style={{
                          backgroundColor: `${ess.color}22`,
                          color: ess.color,
                          border: `1px solid ${ess.color}55`,
                        }}
                      >
                        <Sparkles className="h-3 w-3" />
                        {ess.shortName} DNA
                      </span>
                      {isDietMatch && (
                        <span className="rounded bg-amber-300/20 px-1.5 py-0.5 text-[9px] font-semibold uppercase text-amber-200">
                          Top Diet Match
                        </span>
                      )}
                    </div>

                    <h3 className="font-display mt-2.5 text-lg font-semibold text-white">
                      {trait.name}
                    </h3>
                    <div className="text-[11px] font-medium text-slate-400">
                      {trait.unlockedByText}
                    </div>

                    {trait.ability && (
                      <div
                        className="mt-1.5 inline-flex items-center gap-1 rounded-md px-2 py-0.5 text-[10px] font-semibold"
                        style={{
                          color: ABILITIES[trait.ability].color,
                          backgroundColor: `${ABILITIES[trait.ability].color}1c`,
                          border: `1px solid ${ABILITIES[trait.ability].color}55`,
                        }}
                      >
                        <Zap className="h-3 w-3" />
                        Unlocks {ABILITIES[trait.ability].shortName} Ability
                      </div>
                    )}

                    {/* Visual 3D Body Change box */}
                    <div className="mt-3 rounded-xl border border-white/10 bg-black/35 p-2.5">
                      <div className="text-[10px] font-bold uppercase tracking-wider text-cyan-300">
                        3D Body Mutation
                      </div>
                      <p className="mt-0.5 text-xs leading-relaxed text-slate-200">
                        {trait.visualMutation}
                      </p>
                    </div>

                    {/* Stat Bonuses */}
                    <div className="mt-2.5 flex flex-wrap gap-1.5 text-[11px]">
                      {trait.bonuses.biteDamage > 0 && (
                        <span className="inline-flex items-center gap-1 rounded-md bg-rose-500/20 px-2 py-0.5 text-rose-200">
                          <Flame className="h-3 w-3" />+{trait.bonuses.biteDamage} Bite
                        </span>
                      )}
                      {trait.bonuses.spitDamage > 0 && (
                        <span className="inline-flex items-center gap-1 rounded-md bg-cyan-500/20 px-2 py-0.5 text-cyan-200">
                          <Zap className="h-3 w-3" />+{trait.bonuses.spitDamage} Spit
                        </span>
                      )}
                      {trait.bonuses.maxHp > 0 && (
                        <span className="inline-flex items-center gap-1 rounded-md bg-emerald-500/20 px-2 py-0.5 text-emerald-200">
                          <Shield className="h-3 w-3" />+{trait.bonuses.maxHp} HP
                        </span>
                      )}
                      {trait.bonuses.speedMult > 0 && (
                        <span className="inline-flex items-center gap-1 rounded-md bg-amber-500/20 px-2 py-0.5 text-amber-200">
                          <Wind className="h-3 w-3" />+
                          {Math.round(trait.bonuses.speedMult * 100)}% Speed
                        </span>
                      )}
                      {trait.bonuses.glide && (
                        <span className="inline-flex items-center gap-1 rounded-md bg-teal-500/25 px-2 py-0.5 font-semibold text-teal-200">
                          Unlocks Air Gliding!
                        </span>
                      )}
                    </div>
                  </div>

                  <button
                    type="button"
                    disabled={!evo.evolveReady}
                    onClick={() => {
                      onSelectTrait(trait.id);
                      onClose();
                    }}
                    className={`mt-4 w-full rounded-xl py-2.5 text-xs font-bold uppercase tracking-[0.18em] transition ${
                      evo.evolveReady
                        ? 'bg-gradient-to-r from-cyan-300 via-teal-300 to-emerald-300 text-slate-950 shadow-[0_8px_24px_rgba(45,212,191,0.35)] hover:brightness-105 cursor-pointer'
                        : 'bg-white/10 text-white/40 cursor-not-allowed'
                    }`}
                  >
                    {evo.evolveReady ? 'Evolve & Mutate' : 'Need More DNA'}
                  </button>
                </div>
              );
            })}
          </div>
        </div>

        {/* Owned Mutations Footer */}
        {evo.traits.length > 0 && (
          <div className="mt-5 border-t border-white/12 pt-3.5">
            <div className="text-[10px] font-semibold uppercase tracking-[0.16em] text-slate-400 mb-2">
              Active 3D Body Mutations ({evo.traits.length})
            </div>
            <div className="flex flex-wrap gap-2">
              {evo.traits.map((tid) => {
                const t = TRAITS[tid];
                if (!t) return null;
                return (
                  <span
                    key={tid}
                    className="inline-flex items-center gap-1.5 rounded-lg border border-white/15 bg-white/8 px-3 py-1 text-xs font-medium"
                    style={{ color: t.accentColor }}
                  >
                    <Check className="h-3.5 w-3.5" />
                    {t.name}
                  </span>
                );
              })}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
