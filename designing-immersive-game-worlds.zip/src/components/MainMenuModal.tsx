import React, { useState } from 'react';
import {
  Dna,
  LogIn,
  LogOut,
  Play,
  RotateCcw,
  Shield,
  Sparkles,
  Swords,
  Trophy,
  User,
  UserPlus,
  Users,
  Zap,
} from 'lucide-react';
import {
  ABILITIES,
  AbilityId,
  ESSENCES,
  EssenceType,
  TRAITS,
  UserProfile,
  getStageTitle,
  getUnlockedAbilities,
  loadAllAccounts,
  logoutActiveAccount,
  registerOrLoginAccount,
  resetProfileOrganism,
} from '../world/evolution';
import {
  GAME_MODES,
  GAME_MODE_LIST,
  GameMode,
  clampMaxPlayers,
} from '../world/modes';

interface MainMenuModalProps {
  loadState: 'loading' | 'ready' | 'error';
  loadError: string;
  activeProfile: UserProfile | null;
  onProfileAuthenticated: (profile: UserProfile) => void;
  onLogout: () => void;
  selectedMode: GameMode;
  onSelectMode: (mode: GameMode) => void;
  maxPlayers: number;
  onMaxPlayersChange: (n: number) => void;
  onStartGame: (mode: GameMode, maxPlayers: number) => void;
  onCustomLobby: () => void;
}

const SLIME_COLORS = [
  { name: 'Teal Bio-Goo', hex: '#2dd4bf' },
  { name: 'Nebula Violet', hex: '#a855f7' },
  { name: 'Crimson Apex', hex: '#f43f5e' },
  { name: 'Verdigris Acid', hex: '#4ade80' },
  { name: 'Cryo Azure', hex: '#38bdf8' },
  { name: 'Solar Amber', hex: '#f59e0b' },
];

export const MainMenuModal: React.FC<MainMenuModalProps> = ({
  loadState,
  loadError,
  activeProfile,
  onProfileAuthenticated,
  onLogout,
  selectedMode,
  onSelectMode,
  maxPlayers,
  onMaxPlayersChange,
  onStartGame,
  onCustomLobby,
}) => {
  const [authMode, setAuthMode] = useState<'login' | 'register'>('register');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [speciesName, setSpeciesName] = useState('Lumigoo');
  const [selectedColor, setSelectedColor] = useState('#2dd4bf');
  const [authError, setAuthError] = useState<string | null>(null);
  const [showNewSlimeForm, setShowNewSlimeForm] = useState(false);
  const [showGuide, setShowGuide] = useState(false);
  const [showAbilities, setShowAbilities] = useState(false);

  const savedAccounts = Object.values(loadAllAccounts()).sort(
    (a, b) => b.lastLoginAt - a.lastLoginAt
  );
  const selectedCfg = GAME_MODES[selectedMode];
  const unlockedAbilities = activeProfile
    ? getUnlockedAbilities(activeProfile.stage, activeProfile.traits)
    : [];

  const handleSubmitAuth = (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError(null);
    const res = registerOrLoginAccount(
      username,
      password,
      authMode,
      speciesName,
      selectedColor
    );
    if (!res.ok || !res.profile) {
      setAuthError(res.error ?? 'Authentication failed.');
      return;
    }
    onProfileAuthenticated(res.profile);
  };

  const handleQuickGuest = () => {
    setAuthError(null);
    const existingGuest = loadAllAccounts()['explorer'];
    if (existingGuest) {
      const res = registerOrLoginAccount('Explorer', '', 'login');
      if (res.ok && res.profile) {
        onProfileAuthenticated(res.profile);
        return;
      }
    }
    const res = registerOrLoginAccount(
      'Explorer',
      'solvara',
      'register',
      speciesName || 'Lumigoo',
      selectedColor
    );
    if (res.ok && res.profile) onProfileAuthenticated(res.profile);
  };

  const handleResetOrganism = () => {
    if (!activeProfile) return;
    const updated = resetProfileOrganism(
      activeProfile.username,
      speciesName || activeProfile.speciesName,
      selectedColor
    );
    if (updated) {
      onProfileAuthenticated(updated);
      setShowNewSlimeForm(false);
    }
  };

  const handleModeSelect = (mode: GameMode) => {
    onSelectMode(mode);
    onMaxPlayersChange(clampMaxPlayers(mode, maxPlayers));
  };

  const handlePlayerCount = (n: number) => {
    onMaxPlayersChange(clampMaxPlayers(selectedMode, n));
  };

  return (
    <div className="pointer-events-none absolute inset-0 z-30 flex flex-col items-center justify-between py-6 sm:py-10 px-4 overflow-y-auto">
      <div
        className="fixed inset-0 -z-10"
        style={{
          background:
            'radial-gradient(circle at 50% 35%, rgba(8,12,24,0.18) 0%, rgba(6,10,20,0.72) 100%)',
        }}
      />

      {/* Top Title Header */}
      <div className="flex flex-col items-center text-center mt-1 sm:mt-2 animate-soft-in">
        <div className="inline-flex items-center gap-2 rounded-full border border-cyan-300/30 bg-cyan-950/45 px-3.5 py-1 text-[10px] font-semibold uppercase tracking-[0.24em] text-cyan-200 backdrop-blur-md">
          <Dna className="h-3.5 w-3.5 text-cyan-300" />
          <span>Spore Evolution Open World</span>
        </div>
        <h1 className="font-display mt-2 text-4xl sm:text-6xl font-medium tracking-[0.26em] text-white drop-shadow-[0_4px_28px_rgba(0,0,0,0.65)] pl-[0.26em]">
          SOLVARA
        </h1>
        <p className="mt-1.5 text-[11px] sm:text-xs font-medium uppercase tracking-[0.28em] text-cyan-100/85 drop-shadow-[0_2px_10px_rgba(0,0,0,0.65)]">
          Log In · Choose a Mode · Evolve · Survive
        </p>
      </div>

      {/* Center Card: Auth screen OR proper post-login Main Menu */}
      <div className="pointer-events-auto my-auto w-full max-w-lg rounded-2xl border border-white/20 bg-[#0b131e]/90 p-5 sm:p-6 text-white backdrop-blur-xl shadow-[0_24px_80px_rgba(0,0,0,0.72)] animate-soft-in">
        {!activeProfile ? (
          <div>
            <div className="grid grid-cols-2 gap-1.5 rounded-xl bg-white/6 p-1">
              <button
                type="button"
                onClick={() => {
                  setAuthMode('register');
                  setAuthError(null);
                }}
                className={`flex items-center justify-center gap-1.5 rounded-lg py-2 text-xs font-semibold uppercase tracking-wider transition cursor-pointer ${
                  authMode === 'register'
                    ? 'bg-cyan-400 text-slate-950 shadow'
                    : 'text-slate-300 hover:text-white'
                }`}
              >
                <UserPlus className="h-3.5 w-3.5" />
                Create Symbiote
              </button>
              <button
                type="button"
                onClick={() => {
                  setAuthMode('login');
                  setAuthError(null);
                }}
                className={`flex items-center justify-center gap-1.5 rounded-lg py-2 text-xs font-semibold uppercase tracking-wider transition cursor-pointer ${
                  authMode === 'login'
                    ? 'bg-cyan-400 text-slate-950 shadow'
                    : 'text-slate-300 hover:text-white'
                }`}
              >
                <LogIn className="h-3.5 w-3.5" />
                Log In
              </button>
            </div>

            <form onSubmit={handleSubmitAuth} className="mt-4 space-y-3">
              <div>
                <label className="block text-[10px] font-semibold uppercase tracking-[0.16em] text-slate-300">
                  Pilot Callsign (Username)
                </label>
                <input
                  type="text"
                  required
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="e.g. NovaSlime"
                  className="mt-1 w-full rounded-xl border border-white/18 bg-black/40 px-3.5 py-2 text-sm text-white placeholder-slate-500 focus:border-cyan-300 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-[10px] font-semibold uppercase tracking-[0.16em] text-slate-300">
                  Bio-Link Passkey
                </label>
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="•••••••• (optional for local play)"
                  className="mt-1 w-full rounded-xl border border-white/18 bg-black/40 px-3.5 py-2 text-sm text-white placeholder-slate-500 focus:border-cyan-300 focus:outline-none"
                />
              </div>

              {authMode === 'register' && (
                <>
                  <div>
                    <label className="block text-[10px] font-semibold uppercase tracking-[0.16em] text-slate-300">
                      Slime Species Name
                    </label>
                    <input
                      type="text"
                      value={speciesName}
                      onChange={(e) => setSpeciesName(e.target.value)}
                      placeholder="Lumigoo"
                      className="mt-1 w-full rounded-xl border border-white/18 bg-black/40 px-3.5 py-2 text-sm text-white placeholder-slate-500 focus:border-cyan-300 focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-semibold uppercase tracking-[0.16em] text-slate-300">
                      Proto-Goo Bioluminescence
                    </label>
                    <div className="mt-1.5 flex items-center gap-2.5">
                      {SLIME_COLORS.map((c) => (
                        <button
                          key={c.hex}
                          type="button"
                          onClick={() => setSelectedColor(c.hex)}
                          title={c.name}
                          className={`h-7 w-7 rounded-full border-2 transition-transform cursor-pointer ${
                            selectedColor === c.hex
                              ? 'scale-120 border-white shadow-[0_0_12px_rgba(255,255,255,0.8)]'
                              : 'border-white/30 opacity-75 hover:opacity-100'
                          }`}
                          style={{ backgroundColor: c.hex }}
                        />
                      ))}
                    </div>
                  </div>
                </>
              )}

              {authError && (
                <p className="rounded-lg border border-rose-400/40 bg-rose-950/50 px-3 py-1.5 text-xs text-rose-200">
                  {authError}
                </p>
              )}

              <button
                type="submit"
                className="w-full rounded-xl bg-gradient-to-r from-cyan-300 via-teal-300 to-emerald-300 py-2.5 text-xs font-bold uppercase tracking-[0.2em] text-slate-950 shadow-[0_8px_25px_rgba(45,212,191,0.35)] hover:brightness-105 active:scale-99 transition cursor-pointer"
              >
                {authMode === 'register' ? 'Create & Link Symbiote' : 'Sign In to Solvara'}
              </button>
            </form>

            <div className="mt-3.5 border-t border-white/12 pt-3">
              <button
                type="button"
                onClick={handleQuickGuest}
                className="w-full rounded-xl border border-white/20 bg-white/8 py-2 text-xs font-semibold uppercase tracking-[0.16em] text-white/90 hover:bg-white/15 transition cursor-pointer"
              >
                Quick Play as Guest Symbiote
              </button>

              {savedAccounts.length > 0 && (
                <div className="mt-3">
                  <div className="text-[10px] font-semibold uppercase tracking-wider text-slate-400 mb-1.5">
                    Saved Symbiote Profiles
                  </div>
                  <div className="flex flex-wrap gap-1.5">
                    {savedAccounts.slice(0, 4).map((acc) => (
                      <button
                        key={acc.username}
                        type="button"
                        onClick={() => {
                          const res = registerOrLoginAccount(acc.displayName, '', 'login');
                          if (res.ok && res.profile) onProfileAuthenticated(res.profile);
                        }}
                        className="flex items-center gap-1.5 rounded-lg border border-white/15 bg-white/6 px-2.5 py-1 text-xs text-slate-200 hover:bg-white/15 transition cursor-pointer"
                      >
                        <span
                          className="h-2 w-2 rounded-full"
                          style={{ backgroundColor: acc.baseColorHex }}
                        />
                        <span>{acc.displayName}</span>
                        <span className="text-[10px] text-cyan-300">Stg {acc.stage}</span>
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        ) : (
          /* ───────── Proper post-login Main Menu hub ───────── */
          <div>
            {/* Profile Header */}
            <div className="flex items-center justify-between border-b border-white/12 pb-3">
              <div className="flex items-center gap-2.5">
                <div
                  className="flex h-9 w-9 items-center justify-center rounded-full border border-white/30 shadow-inner"
                  style={{ backgroundColor: activeProfile.baseColorHex }}
                >
                  <User className="h-4.5 w-4.5 text-slate-950" />
                </div>
                <div>
                  <div className="text-[10px] font-semibold uppercase tracking-[0.16em] text-cyan-300">
                    Bio-Link Active · Main Menu
                  </div>
                  <div className="text-sm font-semibold text-white">
                    {activeProfile.displayName}
                  </div>
                </div>
              </div>
              <button
                type="button"
                onClick={() => {
                  logoutActiveAccount();
                  onLogout();
                }}
                className="flex items-center gap-1 rounded-lg border border-white/15 bg-white/6 px-2.5 py-1.5 text-[11px] font-medium text-slate-300 hover:bg-white/14 hover:text-white transition cursor-pointer"
              >
                <LogOut className="h-3.5 w-3.5" />
                Switch Account
              </button>
            </div>

            {/* Persistent Evolved Organism Summary */}
            <div className="mt-3.5 rounded-xl border border-white/14 bg-black/35 p-3.5">
              <div className="flex items-center justify-between gap-2">
                <div className="min-w-0">
                  <span className="text-[10px] font-semibold uppercase tracking-[0.18em] text-emerald-300">
                    Stage {activeProfile.stage} · {getStageTitle(activeProfile.stage)}
                  </span>
                  <h3 className="font-display text-lg font-semibold text-white truncate">
                    {activeProfile.speciesName}
                  </h3>
                </div>
                <div className="text-right shrink-0">
                  <div className="text-xs font-semibold text-cyan-200 tabular-nums">
                    {activeProfile.kills} Prey Devoured
                  </div>
                  <div className="text-[11px] text-slate-400">
                    {activeProfile.traits.length} Mutations · {unlockedAbilities.length} Abilities
                  </div>
                </div>
              </div>

              <p className="mt-2 text-[11px] leading-relaxed text-slate-300">
                Your evolved Stage, Traits, Abilities, DNA and discovered regions are saved to this
                profile and carry into both modes.
              </p>

              {activeProfile.traits.length > 0 ? (
                <div className="mt-2 flex flex-wrap gap-1.5">
                  {activeProfile.traits.map((tid) => {
                    const t = TRAITS[tid];
                    if (!t) return null;
                    return (
                      <span
                        key={tid}
                        className="rounded-md border border-white/15 bg-white/8 px-2 py-0.5 text-[10px] font-medium"
                        style={{ color: t.accentColor }}
                      >
                        {t.name}
                      </span>
                    );
                  })}
                </div>
              ) : (
                <p className="mt-2 text-xs text-slate-300">
                  Fresh Stage 1 Proto-Goo — hunt alien wildlife to absorb DNA and mutate your first
                  3D traits!
                </p>
              )}

              {unlockedAbilities.length > 0 && (
                <div className="mt-2 flex flex-wrap gap-1.5 border-t border-white/10 pt-2">
                  {unlockedAbilities.map((id) => (
                    <span
                      key={id}
                      className="inline-flex items-center gap-1 rounded-md px-2 py-0.5 text-[10px] font-semibold"
                      style={{
                        color: ABILITIES[id].color,
                        backgroundColor: `${ABILITIES[id].color}18`,
                        border: `1px solid ${ABILITIES[id].color}55`,
                      }}
                    >
                      <Zap className="h-3 w-3" />
                      {ABILITIES[id].shortName}
                    </span>
                  ))}
                </div>
              )}
            </div>

            {/* Mode Selection Cards */}
            <div className="mt-3.5">
              <div className="text-[10px] font-semibold uppercase tracking-[0.16em] text-slate-300 mb-2">
                Select Game Mode
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {GAME_MODE_LIST.map((cfg) => {
                  const active = cfg.id === selectedMode;
                  const isBR = cfg.battleRoyale;
                  return (
                    <button
                      key={cfg.id}
                      type="button"
                      onClick={() => handleModeSelect(cfg.id)}
                      className={`rounded-xl border p-3 text-left transition-all cursor-pointer ${
                        active
                          ? 'bg-white/12 shadow-[0_8px_25px_rgba(0,0,0,0.35)]'
                          : 'bg-black/25 hover:bg-white/8'
                      }`}
                      style={{
                        borderColor: active ? cfg.accent : 'rgba(255,255,255,0.14)',
                        boxShadow: active ? `0 0 18px ${cfg.accent}44` : undefined,
                      }}
                    >
                      <div className="flex items-center justify-between gap-2">
                        <div className="flex items-center gap-1.5">
                          {isBR ? (
                            <Trophy className="h-4 w-4" style={{ color: cfg.accent }} />
                          ) : (
                            <Shield className="h-4 w-4" style={{ color: cfg.accent }} />
                          )}
                          <span className="text-sm font-bold text-white">{cfg.name}</span>
                        </div>
                        {active && (
                          <span className="rounded bg-white/15 px-1.5 py-0.5 text-[9px] font-bold uppercase tracking-wider text-white">
                            Selected
                          </span>
                        )}
                      </div>
                      <div
                        className="mt-1 text-[10px] font-semibold uppercase tracking-wider"
                        style={{ color: cfg.accent }}
                      >
                        {cfg.tagline}
                      </div>
                      <p className="mt-1.5 text-[11px] leading-relaxed text-slate-300">
                        {cfg.description}
                      </p>
                      <div className="mt-2 flex items-center justify-between text-[10px] text-slate-400">
                        <span className="inline-flex items-center gap-1">
                          <Users className="h-3 w-3" />
                          Max {cfg.maxPlayers} pilots
                        </span>
                        <span>
                          Wildlife HP x{cfg.creatureHpMult.toFixed(2)} · DMG x
                          {cfg.creatureDamageMult.toFixed(2)}
                        </span>
                      </div>
                      {isBR && (
                        <div className="mt-1.5 inline-flex items-center gap-1 rounded bg-rose-500/20 px-2 py-0.5 text-[10px] font-semibold text-rose-200">
                          <Swords className="h-3 w-3" />
                          Shrinking Bio-Storm · Last Player Alive Wins
                        </div>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Max Players Selector */}
            <div className="mt-3 rounded-xl border border-white/14 bg-black/35 p-3">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-white">
                  Max Players for {selectedCfg.name}
                </span>
                <span className="text-[11px] text-slate-400">
                  You + {Math.max(0, maxPlayers - 1)} offline AI rival
                  {maxPlayers - 1 === 1 ? '' : 's'}
                </span>
              </div>
              <div className="mt-2 flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => handlePlayerCount(maxPlayers - 1)}
                  className="h-8 w-8 rounded-lg border border-white/18 bg-white/8 text-lg font-bold text-white hover:bg-white/16 cursor-pointer"
                >
                  −
                </button>
                <input
                  type="range"
                  min={selectedCfg.minPlayers}
                  max={selectedCfg.maxPlayers}
                  step={1}
                  value={maxPlayers}
                  onChange={(e) => handlePlayerCount(parseInt(e.target.value, 10))}
                  className="h-1.5 flex-1 accent-cyan-300 cursor-pointer"
                />
                <button
                  type="button"
                  onClick={() => handlePlayerCount(maxPlayers + 1)}
                  className="h-8 w-8 rounded-lg border border-white/18 bg-white/8 text-lg font-bold text-white hover:bg-white/16 cursor-pointer"
                >
                  +
                </button>
                <span className="w-10 text-right text-sm font-bold tabular-nums text-cyan-200">
                  {maxPlayers}
                </span>
              </div>
              <p className="mt-1.5 text-[10px] leading-relaxed text-slate-400">
                Offline simulation: other pilot slots are filled by AI rival symbiotes. No network
                backend is required.
              </p>
            </div>

            {/* Optional New Slime Reset Drawer */}
            {showNewSlimeForm && (
              <div className="mt-3 rounded-xl border border-cyan-300/30 bg-cyan-950/30 p-3 space-y-2.5">
                <div className="text-xs font-semibold text-cyan-200">
                  Spawn New Stage 1 Proto-Goo
                </div>
                <input
                  type="text"
                  value={speciesName}
                  onChange={(e) => setSpeciesName(e.target.value)}
                  placeholder="New Species Name"
                  className="w-full rounded-lg border border-white/20 bg-black/45 px-3 py-1.5 text-xs text-white"
                />
                <div className="flex items-center gap-2">
                  {SLIME_COLORS.map((c) => (
                    <button
                      key={c.hex}
                      type="button"
                      onClick={() => setSelectedColor(c.hex)}
                      className={`h-6 w-6 rounded-full border-2 cursor-pointer ${
                        selectedColor === c.hex ? 'border-white scale-115' : 'border-white/30'
                      }`}
                      style={{ backgroundColor: c.hex }}
                    />
                  ))}
                </div>
                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={handleResetOrganism}
                    className="flex-1 rounded-lg bg-cyan-400 py-1.5 text-xs font-bold text-slate-950 cursor-pointer"
                  >
                    Confirm New Goo
                  </button>
                  <button
                    type="button"
                    onClick={() => setShowNewSlimeForm(false)}
                    className="rounded-lg border border-white/20 px-3 py-1.5 text-xs text-slate-300 cursor-pointer"
                  >
                    Cancel
                  </button>
                </div>
              </div>
            )}

            {/* Diet Guide */}
            {showGuide && (
              <div className="mt-3 rounded-xl border border-white/14 bg-black/40 p-3 text-xs space-y-1.5">
                <div className="font-semibold text-amber-200 uppercase tracking-wider text-[10px]">
                  You Are What You Eat — Diet Evolution Guide
                </div>
                {(Object.keys(ESSENCES) as EssenceType[]).map((k) => {
                  const e = ESSENCES[k];
                  return (
                    <div key={k} className="flex items-start gap-2 text-[11px]">
                      <span
                        className="mt-1 h-2 w-2 shrink-0 rounded-full"
                        style={{ backgroundColor: e.color }}
                      />
                      <div>
                        <strong style={{ color: e.color }}>{e.shortName}:</strong>{' '}
                        <span className="text-slate-300">
                          Eat {e.sources} → {e.description}
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}

            {/* Evolution Ability Codex */}
            {showAbilities && (
              <div className="mt-3 rounded-xl border border-cyan-300/25 bg-cyan-950/25 p-3">
                <div className="font-semibold text-cyan-200 uppercase tracking-wider text-[10px]">
                  Evolution Ability Codex — unlocks by Stage & Traits
                </div>
                <div className="mt-2 grid grid-cols-1 sm:grid-cols-2 gap-1.5">
                  {(Object.keys(ABILITIES) as AbilityId[]).map((id) => {
                    const a = ABILITIES[id];
                    const unlocked = unlockedAbilities.includes(id);
                    return (
                      <div
                        key={id}
                        className={`rounded-lg border px-2 py-1.5 ${
                          unlocked ? 'border-white/25 bg-white/10' : 'border-white/10 bg-black/25'
                        }`}
                      >
                        <div className="flex items-center justify-between gap-1">
                          <span
                            className="text-[11px] font-bold"
                            style={{ color: unlocked ? a.color : '#94a3b8' }}
                          >
                            {a.name}
                          </span>
                          <span className="text-[9px] uppercase tracking-wider text-slate-400">
                            {unlocked
                              ? 'Unlocked'
                              : a.active
                              ? `Stage ${a.unlockStage} · ${a.key}`
                              : 'Trait Unlock'}
                          </span>
                        </div>
                        <p className="mt-0.5 text-[10px] leading-snug text-slate-300">
                          {a.description}
                        </p>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Deploy Button */}
            <div className="mt-4 space-y-2">
              {loadState === 'loading' && (
                <div className="flex flex-col items-center gap-2 py-2" role="status">
                  <div className="h-1.5 w-full overflow-hidden rounded-full bg-white/15">
                    <div className="h-full w-1/3 rounded-full bg-gradient-to-r from-cyan-300 via-fuchsia-300 to-cyan-300 animate-loading-bar" />
                  </div>
                  <span className="text-[11px] uppercase tracking-[0.24em] text-cyan-200">
                    Generating Alien Biosphere…
                  </span>
                </div>
              )}

              {loadState === 'ready' && (
                <button
                  type="button"
                  onClick={() => onStartGame(selectedMode, maxPlayers)}
                  className="flex w-full items-center justify-center gap-2.5 rounded-xl bg-gradient-to-r from-cyan-300 via-teal-300 to-emerald-300 py-3.5 text-sm font-bold uppercase tracking-[0.22em] text-slate-950 shadow-[0_12px_35px_rgba(45,212,191,0.4)] hover:brightness-105 active:scale-98 transition cursor-pointer"
                >
                  <Play className="h-4.5 w-4.5 fill-slate-950" />
                  <span>{selectedMode === 'battle-royale' ? 'Quick Matchmaking' : `Deploy to ${selectedCfg.name}`}</span>
                </button>
              )}

              {selectedMode === 'battle-royale' && loadState === 'ready' && (
                <button
                  type="button"
                  onClick={onCustomLobby}
                  className="flex w-full items-center justify-center gap-2 rounded-xl border border-rose-200/30 bg-rose-950/30 py-2.5 text-xs font-bold uppercase tracking-[0.17em] text-rose-100 hover:bg-rose-900/40 transition cursor-pointer"
                >
                  <Users className="h-4 w-4" />
                  Custom Lobby · Join With Code
                </button>
              )}

              {loadState === 'error' && (
                <div className="rounded-xl border border-rose-400/40 bg-rose-950/60 p-3 text-center">
                  <p className="text-xs text-rose-200">{loadError}</p>
                </div>
              )}

              <div className="flex flex-wrap items-center justify-between gap-2 pt-1">
                <button
                  type="button"
                  onClick={() => setShowNewSlimeForm((v) => !v)}
                  className="flex items-center gap-1 text-[11px] text-slate-300 hover:text-white transition cursor-pointer"
                >
                  <RotateCcw className="h-3.5 w-3.5" />
                  New Proto-Goo
                </button>
                <button
                  type="button"
                  onClick={() => setShowGuide((v) => !v)}
                  className="flex items-center gap-1 text-[11px] text-amber-200 hover:text-amber-100 transition cursor-pointer"
                >
                  <Sparkles className="h-3.5 w-3.5" />
                  {showGuide ? 'Hide Diet Guide' : 'Diet Guide'}
                </button>
                <button
                  type="button"
                  onClick={() => setShowAbilities((v) => !v)}
                  className="flex items-center gap-1 text-[11px] text-cyan-300 hover:text-cyan-200 transition cursor-pointer"
                >
                  <Zap className="h-3.5 w-3.5" />
                  {showAbilities ? 'Hide Abilities' : 'Ability Codex'}
                </button>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Bottom Controls Hint */}
      <div className="text-center text-[11px] text-white/70 drop-shadow max-w-xl">
        WASD / Joystick to Slither · F Bite · R Spit · K Graze Plants · G Dash · X Slam · C Mines
        · B Lance · Z Cloak · V Evolve · M Map
      </div>
    </div>
  );
};
