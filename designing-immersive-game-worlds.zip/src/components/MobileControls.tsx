import React, { useCallback, useRef, useState } from 'react';
import { ArrowUp, Flame, Leaf, Sparkles, Wind, Zap } from 'lucide-react';
import { ABILITIES, AbilityId } from '../world/evolution';

interface MobileControlsProps {
  onJoystickChange: (x: number, y: number) => void;
  onSprintChange: (sprinting: boolean) => void;
  onJump: () => void;
  onJumpHoldChange?: (held: boolean) => void;
  onAttack: () => void;
  onSpit: () => void;
  onAbility: (id: AbilityId) => void;
  onEat: () => void;
  abilities: AbilityId[];
  abilityCooldowns: Record<AbilityId, number>;
  swimming: boolean;
}

export const MobileControls: React.FC<MobileControlsProps> = ({
  onJoystickChange,
  onSprintChange,
  onJump,
  onJumpHoldChange,
  onAttack,
  onSpit,
  onAbility,
  onEat,
  abilities,
  abilityCooldowns,
  swimming,
}) => {
  const baseRef = useRef<HTMLDivElement | null>(null);
  const activeIdRef = useRef<number | null>(null);
  const [knob, setKnob] = useState({ x: 0, y: 0, active: false });
  const [sprintLocked, setSprintLocked] = useState(false);
  const activeAbilities = abilities.filter((id) => ABILITIES[id].active);

  const maxRadius = 44;

  const updateFromPointer = useCallback(
    (clientX: number, clientY: number) => {
      const el = baseRef.current;
      if (!el) return;
      const rect = el.getBoundingClientRect();
      const cx = rect.left + rect.width * 0.5;
      const cy = rect.top + rect.height * 0.5;
      const dx = clientX - cx;
      const dy = clientY - cy;
      const dist = Math.hypot(dx, dy);
      const clampedDist = Math.min(dist, maxRadius);
      const angle = Math.atan2(dy, dx);
      const kx = Math.cos(angle) * clampedDist;
      const ky = Math.sin(angle) * clampedDist;

      setKnob({ x: kx, y: ky, active: true });
      const nx = kx / maxRadius;
      const ny = ky / maxRadius;
      const mag = Math.hypot(nx, ny);
      if (mag < 0.08) onJoystickChange(0, 0);
      else onJoystickChange(nx, ny);
    },
    [onJoystickChange]
  );

  const handlePointerDown = (e: React.PointerEvent<HTMLDivElement>) => {
    e.stopPropagation();
    if (activeIdRef.current !== null) return;
    activeIdRef.current = e.pointerId;
    e.currentTarget.setPointerCapture(e.pointerId);
    updateFromPointer(e.clientX, e.clientY);
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
    e.stopPropagation();
    if (activeIdRef.current !== e.pointerId) return;
    updateFromPointer(e.clientX, e.clientY);
  };

  const handlePointerEnd = (e: React.PointerEvent<HTMLDivElement>) => {
    e.stopPropagation();
    if (activeIdRef.current !== e.pointerId) return;
    activeIdRef.current = null;
    setKnob({ x: 0, y: 0, active: false });
    onJoystickChange(0, 0);
  };

  const toggleSprint = (e: React.PointerEvent<HTMLButtonElement>) => {
    e.stopPropagation();
    const next = !sprintLocked;
    setSprintLocked(next);
    onSprintChange(next);
  };

  return (
    <div className="pointer-events-none fixed inset-x-0 bottom-0 z-20 flex items-end justify-between safe-bottom safe-left safe-right px-5 pb-5">
      {/* Left-Thumb Virtual Analog Joystick */}
      <div
        ref={baseRef}
        onPointerDown={handlePointerDown}
        onPointerMove={handlePointerMove}
        onPointerUp={handlePointerEnd}
        onPointerCancel={handlePointerEnd}
        className={`pointer-events-auto relative h-31 w-31 rounded-full border backdrop-blur-md transition-opacity duration-200 flex items-center justify-center touch-none ${
          knob.active
            ? 'bg-black/30 border-white/40 opacity-100 shadow-[0_8px_30px_rgba(0,0,0,0.35)]'
            : 'bg-black/18 border-white/22 opacity-80'
        }`}
        aria-label="Movement joystick"
      >
        <span className="absolute top-2.5 h-1 w-1 rounded-full bg-white/35" />
        <span className="absolute bottom-2.5 h-1 w-1 rounded-full bg-white/25" />
        <span className="absolute left-2.5 h-1 w-1 rounded-full bg-white/25" />
        <span className="absolute right-2.5 h-1 w-1 rounded-full bg-white/25" />

        <div
          className={`h-13 w-13 rounded-full border transition-colors ${
            knob.active
              ? 'bg-white/85 border-white shadow-[0_4px_18px_rgba(255,255,255,0.35)]'
              : 'bg-white/45 border-white/65'
          }`}
          style={{ transform: `translate3d(${knob.x}px, ${knob.y}px, 0)` }}
        />
      </div>

      {/* Right-Thumb Combat, Ability & Movement Action Cluster */}
      <div className="pointer-events-auto flex flex-col items-end gap-2 pb-1">
        {activeAbilities.length > 0 && (
          <div className="flex flex-wrap justify-end gap-1.5 max-w-[240px]">
            {activeAbilities.map((id) => {
              const def = ABILITIES[id];
              const cd = abilityCooldowns[id] ?? 0;
              const ready = cd <= 0.001;
              return (
                <button
                  key={id}
                  type="button"
                  disabled={!ready}
                  onPointerDown={(e) => {
                    e.stopPropagation();
                    if (ready) onAbility(id);
                  }}
                  title={`${def.name}: ${def.description}`}
                  aria-label={def.name}
                  className={`flex h-10 min-w-11 flex-col items-center justify-center rounded-xl border px-2 backdrop-blur-md transition-all touch-none ${
                    ready
                      ? 'bg-black/45 text-white active:scale-92'
                      : 'bg-black/65 text-white/40 opacity-70'
                  }`}
                  style={{
                    borderColor: ready ? `${def.color}bb` : 'rgba(255,255,255,0.16)',
                    boxShadow: ready ? `0 0 12px ${def.color}44` : undefined,
                  }}
                >
                  <span className="flex items-center gap-0.5 text-[9px] font-bold uppercase leading-none">
                    <Sparkles className="h-2.5 w-2.5" style={{ color: def.color }} />
                    {def.shortName}
                  </span>
                  <span className="mt-0.5 text-[8px] font-semibold tabular-nums leading-none text-slate-300">
                    {ready ? def.key : `${cd.toFixed(1)}s`}
                  </span>
                </button>
              );
            })}
          </div>
        )}

        <div className="flex items-end gap-2.5 sm:gap-3.5">
          <button
            type="button"
            onPointerDown={toggleSprint}
            aria-label="Toggle Sprint"
            className={`flex h-12 w-12 flex-col items-center justify-center rounded-full border backdrop-blur-md transition-all active:scale-92 touch-none ${
              sprintLocked
                ? 'bg-amber-300/85 border-amber-100 text-slate-950 shadow-[0_0_20px_rgba(252,211,77,0.45)]'
                : 'bg-black/28 border-white/28 text-white/90 hover:bg-black/40'
            }`}
          >
            <Wind className="h-4.5 w-4.5" />
            <span className="text-[8px] font-semibold uppercase tracking-wider leading-none mt-0.5">
              Run
            </span>
          </button>

          <button
            type="button"
            onPointerDown={(e) => {
              e.stopPropagation();
              onSpit();
            }}
            aria-label="Spit Bio-Plasma"
            className="mb-2 flex h-13 w-13 flex-col items-center justify-center rounded-full border border-cyan-300/50 bg-cyan-950/55 text-cyan-200 backdrop-blur-md transition-all active:scale-92 active:bg-cyan-400/40 touch-none"
          >
            <Zap className="h-5 w-5" />
            <span className="text-[8px] font-semibold uppercase tracking-wider leading-none mt-0.5">
              Spit
            </span>
          </button>

          <button
            type="button"
            onPointerDown={(e) => {
              e.stopPropagation();
              onEat();
            }}
            aria-label="Graze Edible Plant"
            className="mb-3 flex h-12 w-12 flex-col items-center justify-center rounded-full border border-emerald-300/55 bg-emerald-950/55 text-emerald-200 backdrop-blur-md transition-all active:scale-92 active:bg-emerald-400/40 touch-none"
          >
            <Leaf className="h-4.5 w-4.5" />
            <span className="text-[8px] font-semibold uppercase tracking-wider leading-none mt-0.5">
              Graze
            </span>
          </button>

          <button
            type="button"
            onPointerDown={(e) => {
              e.stopPropagation();
              onAttack();
            }}
            aria-label="Bite Prey"
            className="mb-1 flex h-16 w-16 flex-col items-center justify-center rounded-full border-2 border-rose-300/65 bg-rose-950/60 text-rose-200 shadow-[0_0_24px_rgba(244,63,94,0.35)] backdrop-blur-md transition-all active:scale-92 active:bg-rose-500/50 touch-none"
          >
            <Flame className="h-6 w-6" />
            <span className="text-[9px] font-bold uppercase tracking-wider leading-none mt-0.5">
              Bite
            </span>
          </button>

          {!swimming && (
            <button
              type="button"
              onPointerDown={(e) => {
                e.stopPropagation();
                onJump();
                onJumpHoldChange?.(true);
              }}
              onPointerUp={(e) => {
                e.stopPropagation();
                onJumpHoldChange?.(false);
              }}
              onPointerCancel={() => onJumpHoldChange?.(false)}
              aria-label="Jump or Glide"
              className="mb-5 flex h-13 w-13 flex-col items-center justify-center rounded-full border border-white/32 bg-black/28 text-white/95 backdrop-blur-md transition-all active:scale-92 active:bg-white/30 touch-none"
            >
              <ArrowUp className="h-5 w-5" />
              <span className="text-[8px] font-semibold uppercase tracking-wider leading-none mt-0.5">
                Jump
              </span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
