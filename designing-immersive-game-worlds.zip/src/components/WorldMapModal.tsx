import React, { useEffect, useRef, useState } from 'react';
import { Compass, MapPin, Navigation, X } from 'lucide-react';
import {
  BIOMES,
  BIOME_LIST,
  BiomeId,
  WATER_LEVEL,
  WORLD_MAP_RADIUS,
  computeTerrainColor,
  getTerrainHeightWithWeights,
  sampleBiomeWeights,
} from '../world/biomes';
import { clamp, lerp, smoothstep } from '../world/noise';

interface WorldMapModalProps {
  open: boolean;
  onClose: () => void;
  playerX: number;
  playerZ: number;
  bearingDeg: number;
  currentBiome: BiomeId;
  discovered: BiomeId[];
  trackedBiome: BiomeId | null;
  onTrackBiome: (id: BiomeId | null) => void;
  onFastTravel: (id: BiomeId) => void;
}

// Cache the rendered topographic canvas data URL so reopening the atlas is instantaneous
let cachedMapDataUrl: string | null = null;

function getTopographicMapDataUrl(): string {
  if (cachedMapDataUrl) return cachedMapDataUrl;

  const size = 280;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d')!;
  const img = ctx.createImageData(size, size);
  const data = img.data;

  const col: [number, number, number] = [0, 0, 0];
  // North-west sun vector for crisp cartographic relief shading
  const lx = -0.58;
  const ly = 0.62;
  const lz = -0.53;

  // One terrain evaluation per pixel; hill-shade normals from neighbouring samples
  const step = (2 * WORLD_MAP_RADIUS) / (size - 1);
  const heights = new Float32Array(size * size);
  const weightGrid: Array<ReturnType<typeof sampleBiomeWeights>> = new Array(size * size);
  for (let py = 0; py < size; py++) {
    const wz = ((py / (size - 1)) * 2 - 1) * WORLD_MAP_RADIUS;
    for (let px = 0; px < size; px++) {
      const wx = ((px / (size - 1)) * 2 - 1) * WORLD_MAP_RADIUS;
      const w = sampleBiomeWeights(wx, wz);
      weightGrid[py * size + px] = w;
      heights[py * size + px] = getTerrainHeightWithWeights(wx, wz, w);
    }
  }

  for (let py = 0; py < size; py++) {
    const wz = ((py / (size - 1)) * 2 - 1) * WORLD_MAP_RADIUS;
    for (let px = 0; px < size; px++) {
      const wx = ((px / (size - 1)) * 2 - 1) * WORLD_MAP_RADIUS;
      const w = weightGrid[py * size + px];
      const h = heights[py * size + px];

      let r: number;
      let g: number;
      let b: number;

      if (h < WATER_LEVEL) {
        // Luminous alien seas: teal shallows fading to violet abyss
        const depth = WATER_LEVEL - h;
        const tMid = smoothstep(0.0, 3.8, depth);
        const tDeep = smoothstep(3.2, 13.0, depth);
        r = lerp(lerp(0.12, 0.14, tMid), 0.1, tDeep);
        g = lerp(lerp(0.66, 0.3, tMid), 0.08, tDeep);
        b = lerp(lerp(0.72, 0.62, tMid), 0.34, tDeep);
        if (depth < 0.55) {
          const foam = (1 - depth / 0.55) * 0.42;
          r = lerp(r, 0.86, foam);
          g = lerp(g, 0.92, foam);
          b = lerp(b, 0.98, foam);
        }
      } else {
        const hL = heights[py * size + Math.max(0, px - 1)];
        const hR = heights[py * size + Math.min(size - 1, px + 1)];
        const hD = heights[Math.max(0, py - 1) * size + px];
        const hU = heights[Math.min(size - 1, py + 1) * size + px];
        const nxr = hL - hR;
        const nyr = 2 * step;
        const nzr = hD - hU;
        const ninv = 1 / Math.hypot(nxr, nyr, nzr);
        const n: [number, number, number] = [nxr * ninv, nyr * ninv, nzr * ninv];
        computeTerrainColor(wx, wz, h, n[1], w, col);
        const shade = clamp(n[0] * lx + n[1] * ly + n[2] * lz, 0.15, 1.0);
        const hill = 0.62 + shade * 0.62;

        // Subtle cartographic 12m contour lines
        const contourMod = Math.abs(((h % 12) + 12) % 12 - 6);
        const contour = contourMod > 5.55 ? 0.88 : 1.0;

        r = clamp(col[0] * hill * contour * 1.12, 0, 1);
        g = clamp(col[1] * hill * contour * 1.12, 0, 1);
        b = clamp(col[2] * hill * contour * 1.12, 0, 1);
      }

      const idx = (py * size + px) * 4;
      data[idx] = Math.floor(r * 255);
      data[idx + 1] = Math.floor(g * 255);
      data[idx + 2] = Math.floor(b * 255);
      data[idx + 3] = 255;
    }
  }

  ctx.putImageData(img, 0, 0);
  cachedMapDataUrl = canvas.toDataURL();
  return cachedMapDataUrl;
}

function worldToMapPercent(wx: number, wz: number): { left: string; top: string } {
  const u = clamp((wx / WORLD_MAP_RADIUS + 1) * 50, 3, 97);
  const v = clamp((wz / WORLD_MAP_RADIUS + 1) * 50, 3, 97);
  return { left: `${u}%`, top: `${v}%` };
}

export const WorldMapModal: React.FC<WorldMapModalProps> = ({
  open,
  onClose,
  playerX,
  playerZ,
  bearingDeg,
  currentBiome,
  discovered,
  trackedBiome,
  onTrackBiome,
  onFastTravel,
}) => {
  const [selected, setSelected] = useState<BiomeId>(currentBiome);
  const [mapSrc, setMapSrc] = useState<string>('');
  const prevOpen = useRef(false);

  useEffect(() => {
    if (open && !prevOpen.current) {
      setSelected(currentBiome);
      setMapSrc(getTopographicMapDataUrl());
    }
    prevOpen.current = open;
  }, [open, currentBiome]);

  if (!open) return null;

  const selDef = BIOMES[selected];
  const distToSelected = Math.round(
    Math.hypot(selDef.landmark.x - playerX, selDef.landmark.z - playerZ)
  );
  const isTracked = trackedBiome === selected;
  const playerPosPct = worldToMapPercent(playerX, playerZ);

  return (
    <div
      className="fixed inset-0 z-40 flex items-center justify-center bg-black/60 backdrop-blur-md p-3 sm:p-6 animate-soft-in"
      onPointerDown={(e) => {
        e.stopPropagation();
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div
        className="relative flex w-full max-w-4xl max-h-[92vh] flex-col md:flex-row overflow-hidden rounded-2xl border border-white/18 bg-[#0f171e]/92 shadow-[0_24px_80px_rgba(0,0,0,0.65)]"
        onPointerDown={(e) => e.stopPropagation()}
      >
        {/* Close button */}
        <button
          type="button"
          onClick={onClose}
          aria-label="Close World Map"
          className="absolute right-3.5 top-3.5 z-20 flex h-9 w-9 items-center justify-center rounded-full border border-white/20 bg-black/45 text-white/85 hover:bg-white/15 transition cursor-pointer"
        >
          <X className="h-4.5 w-4.5" />
        </button>

        {/* Left: Interactive Hill-Shaded Topographic Map */}
        <div className="relative aspect-square w-full max-h-[54vh] md:max-h-none md:w-[58%] shrink-0 overflow-hidden bg-[#0b1824]">
          {mapSrc && (
            <img
              src={mapSrc}
              alt="Topographic map of Solvara"
              className="h-full w-full object-cover select-none"
              draggable={false}
            />
          )}

          {/* Subtle cartographic coordinate grid */}
          <div
            className="pointer-events-none absolute inset-0 opacity-15"
            style={{
              backgroundImage:
                'linear-gradient(to right, rgba(255,255,255,0.4) 1px, transparent 1px), linear-gradient(to bottom, rgba(255,255,255,0.4) 1px, transparent 1px)',
              backgroundSize: '20% 20%',
            }}
          />

          {/* Compass Rose label */}
          <div className="pointer-events-none absolute left-3.5 top-3 flex items-center gap-2 rounded-full bg-black/45 border border-white/15 px-3 py-1 backdrop-blur-sm">
            <Compass className="h-3.5 w-3.5 text-amber-200" />
            <span className="font-display text-[11px] tracking-[0.2em] text-white/90 uppercase">
              Solvara Atlas
            </span>
          </div>

          <div className="pointer-events-none absolute left-3.5 bottom-3 rounded-full bg-black/45 border border-white/15 px-2.5 py-0.5 text-[10px] tracking-wider text-white/75 uppercase">
            {discovered.length} / {BIOME_LIST.length} Biomes Discovered
          </div>

          {/* 7 Biome Landmark Pins */}
          {BIOME_LIST.map((b) => {
            const pos = worldToMapPercent(b.landmark.x, b.landmark.z);
            const active = selected === b.id;
            const visited = discovered.includes(b.id);
            return (
              <button
                key={b.id}
                type="button"
                onClick={() => setSelected(b.id)}
                style={pos}
                className="group absolute -translate-x-1/2 -translate-y-1/2 z-10 flex flex-col items-center cursor-pointer"
              >
                <span
                  className={`flex h-6 w-6 items-center justify-center rounded-full border transition-transform duration-200 ${
                    active
                      ? 'scale-125 border-white bg-slate-950/90 shadow-[0_0_16px_rgba(255,255,255,0.7)]'
                      : 'border-white/70 bg-slate-950/70 group-hover:scale-110'
                  }`}
                >
                  <span
                    className="h-2.5 w-2.5 rounded-full"
                    style={{
                      backgroundColor: b.accentColor,
                      opacity: visited ? 1 : 0.72,
                    }}
                  />
                </span>
                <span
                  className={`mt-1 whitespace-nowrap rounded px-1.5 py-0.5 text-[9px] font-semibold tracking-wide shadow transition-opacity ${
                    active
                      ? 'bg-black/80 text-white'
                      : 'bg-black/55 text-white/85 hidden sm:block'
                  }`}
                >
                  {b.name}
                </span>
              </button>
            );
          })}

          {/* Live Player Position & Camera Direction Cone */}
          <div
            className="pointer-events-none absolute -translate-x-1/2 -translate-y-1/2 z-20"
            style={playerPosPct}
          >
            <div
              className="relative flex items-center justify-center"
              style={{ transform: `rotate(${bearingDeg}deg)` }}
            >
              {/* Soft view cone pointing along camera heading */}
              <div
                className="absolute -top-5 h-6 w-6 opacity-55"
                style={{
                  background:
                    'conic-gradient(from -28deg at 50% 100%, rgba(255,255,255,0.85) 0deg, rgba(255,255,255,0.85) 56deg, transparent 56deg)',
                }}
              />
              <div className="h-3.5 w-3.5 rounded-full bg-white border-2 border-slate-950 shadow-[0_0_10px_rgba(255,255,255,0.95)]" />
            </div>
          </div>
        </div>

        {/* Right: Selected Biome Details, Region List & Fast Travel */}
        <div className="flex flex-1 flex-col justify-between p-4 sm:p-6 overflow-y-auto">
          <div>
            <div className="flex items-center gap-2 text-[11px] font-semibold uppercase tracking-[0.18em]">
              <span
                className="inline-block h-2 w-2 rounded-full"
                style={{ backgroundColor: selDef.accentColor }}
              />
              <span style={{ color: selDef.accentColor }}>{selDef.subtitle}</span>
            </div>

            <h2 className="font-display mt-1 text-xl sm:text-2xl font-semibold tracking-wide text-white">
              {selDef.name}
            </h2>

            <p className="mt-2 text-xs sm:text-sm leading-relaxed text-slate-300">
              {selDef.description}
            </p>

            <div className="mt-3 flex items-center gap-4 text-xs text-slate-400">
              <span>
                Landmark: <strong className="text-slate-200 font-medium">{selDef.landmark.name}</strong>
              </span>
              <span>·</span>
              <span className="tabular-nums">{distToSelected}m away</span>
              <span>·</span>
              <span className="tabular-nums">{selDef.temperatureC}°C</span>
            </div>

            {/* Action buttons: Fast Travel or Pin Compass Waypoint */}
            <div className="mt-4 flex gap-2.5">
              <button
                type="button"
                onClick={() => {
                  onFastTravel(selected);
                  onClose();
                }}
                className="flex flex-1 items-center justify-center gap-2 rounded-xl bg-white text-slate-950 px-4 py-2.5 text-xs sm:text-sm font-semibold hover:bg-amber-100 active:scale-98 transition cursor-pointer"
              >
                <Navigation className="h-4 w-4" />
                Fast Travel
              </button>

              <button
                type="button"
                onClick={() => onTrackBiome(isTracked ? null : selected)}
                className={`flex items-center justify-center gap-1.5 rounded-xl border px-3.5 py-2.5 text-xs sm:text-sm font-medium transition cursor-pointer ${
                  isTracked
                    ? 'border-amber-300/70 bg-amber-300/20 text-amber-200'
                    : 'border-white/20 bg-white/5 text-white/85 hover:bg-white/12'
                }`}
              >
                <MapPin className="h-4 w-4" />
                {isTracked ? 'Pinned' : 'Waypoint'}
              </button>
            </div>

            {/* Quick Biome Picker Chips */}
            <div className="mt-5">
              <div className="text-[10px] font-semibold uppercase tracking-[0.16em] text-slate-400 mb-2">
                Regions of Solvara
              </div>
              <div className="grid grid-cols-1 gap-1.5">
                {BIOME_LIST.map((b) => {
                  const isSel = b.id === selected;
                  const isHere = b.id === currentBiome;
                  return (
                    <button
                      key={b.id}
                      type="button"
                      onClick={() => setSelected(b.id)}
                      className={`flex items-center justify-between rounded-lg border px-3 py-2 text-left transition cursor-pointer ${
                        isSel
                          ? 'border-white/35 bg-white/12 text-white'
                          : 'border-white/8 bg-white/[0.03] text-slate-300 hover:bg-white/[0.07]'
                      }`}
                    >
                      <span className="flex items-center gap-2.5 min-w-0">
                        <span
                          className="h-2.5 w-2.5 shrink-0 rounded-full"
                          style={{ backgroundColor: b.accentColor }}
                        />
                        <span className="truncate text-xs font-medium">{b.name}</span>
                      </span>
                      <span className="text-[10px] text-slate-400 shrink-0 ml-2">
                        {isHere ? 'Here' : b.subtitle.split(' ').slice(-1)[0]}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
