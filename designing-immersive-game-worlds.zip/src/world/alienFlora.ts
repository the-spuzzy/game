import * as THREE from 'three';

export interface AlienFloraUniforms {
  uTime: { value: number };
  uNight: { value: number };
}

type Vec3Fn = (x: number, y: number, z: number) => [number, number, number];
type NumFn = (x: number, y: number, z: number) => number;

interface AlienPart {
  geo: THREE.BufferGeometry;
  color: [number, number, number] | Vec3Fn;
  glow: number | NumFn;
  matrix?: THREE.Matrix4;
}

function rng(seed: number): () => number {
  let s = seed >>> 0;
  return () => {
    s = (Math.imul(s, 1664525) + 1013904223) >>> 0;
    return s / 4294967296;
  };
}

function clamp01(v: number): number {
  return v < 0 ? 0 : v > 1 ? 1 : v;
}

const _mv = new THREE.Vector3();
const _mn = new THREE.Vector3();
const _nm = new THREE.Matrix3();

/** Merge parts into one geometry carrying vertex colors + a per-vertex bioluminescence mask (aGlow) */
function mergeAlienParts(parts: AlienPart[]): THREE.BufferGeometry {
  const positions: number[] = [];
  const normals: number[] = [];
  const colors: number[] = [];
  const glows: number[] = [];

  for (const part of parts) {
    const g = part.geo.index ? part.geo.toNonIndexed() : part.geo;
    if (!g.attributes.normal) g.computeVertexNormals();
    const pos = g.attributes.position as THREE.BufferAttribute;
    const nor = g.attributes.normal as THREE.BufferAttribute;
    if (part.matrix) _nm.getNormalMatrix(part.matrix);
    for (let i = 0; i < pos.count; i++) {
      const lx = pos.getX(i);
      const ly = pos.getY(i);
      const lz = pos.getZ(i);
      const c = typeof part.color === 'function' ? part.color(lx, ly, lz) : part.color;
      const gl = typeof part.glow === 'function' ? part.glow(lx, ly, lz) : part.glow;
      _mv.set(lx, ly, lz);
      _mn.set(nor.getX(i), nor.getY(i), nor.getZ(i));
      if (part.matrix) {
        _mv.applyMatrix4(part.matrix);
        _mn.applyMatrix3(_nm).normalize();
      }
      positions.push(_mv.x, _mv.y, _mv.z);
      normals.push(_mn.x, _mn.y, _mn.z);
      colors.push(c[0], c[1], c[2]);
      glows.push(gl);
    }
    if (g !== part.geo) g.dispose();
    part.geo.dispose();
  }

  const out = new THREE.BufferGeometry();
  out.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
  out.setAttribute('normal', new THREE.Float32BufferAttribute(normals, 3));
  out.setAttribute('color', new THREE.Float32BufferAttribute(colors, 3));
  out.setAttribute('aGlow', new THREE.Float32BufferAttribute(glows, 1));
  out.computeBoundingSphere();
  return out;
}

function placement(
  x: number,
  y: number,
  z: number,
  rx: number,
  ry: number,
  rz: number,
  s = 1
): THREE.Matrix4 {
  return new THREE.Matrix4().compose(
    new THREE.Vector3(x, y, z),
    new THREE.Quaternion().setFromEuler(new THREE.Euler(rx, ry, rz, 'YXZ')),
    new THREE.Vector3(s, s, s)
  );
}

/** Taper a TubeGeometry along its length */
function taperTube(
  tube: THREE.TubeGeometry,
  curve: THREE.Curve<THREE.Vector3>,
  tubular: number,
  radial: number,
  taper: (t: number) => number
): void {
  const pos = tube.attributes.position as THREE.BufferAttribute;
  const p = new THREE.Vector3();
  for (let s = 0; s <= tubular; s++) {
    const t = s / tubular;
    curve.getPointAt(t, p);
    const k = taper(t);
    for (let r = 0; r <= radial; r++) {
      const i = s * (radial + 1) + r;
      pos.setXYZ(
        i,
        p.x + (pos.getX(i) - p.x) * k,
        p.y + (pos.getY(i) - p.y) * k,
        p.z + (pos.getZ(i) - p.z) * k
      );
    }
  }
  tube.computeVertexNormals();
}

/** 1. Capspire — towering bioluminescent mushroom tree (~9.4m at scale 1) */
function buildCapspire(): THREE.BufferGeometry {
  const parts: AlienPart[] = [];
  const prof: Array<[number, number]> = [
    [0.82, -0.7],
    [0.64, 0.0],
    [0.5, 1.4],
    [0.42, 3.4],
    [0.38, 5.6],
    [0.44, 7.2],
    [0.62, 7.9],
  ];
  const stem = new THREE.LatheGeometry(
    prof.map(([r, y]) => new THREE.Vector2(r, y)),
    14
  );
  const sp = stem.attributes.position as THREE.BufferAttribute;
  for (let i = 0; i < sp.count; i++) {
    const y = sp.getY(i);
    sp.setX(i, sp.getX(i) + Math.sin(y * 0.22) * 0.42);
  }
  stem.computeVertexNormals();
  parts.push({
    geo: stem,
    color: (_x, y) => {
      const t = clamp01((y + 0.7) / 8.6);
      return [0.82 + t * 0.12, 0.8 + t * 0.12, 0.92];
    },
    glow: (x, y, z) => 0.05 + 0.3 * Math.pow(Math.max(0, Math.sin(Math.atan2(z, x) * 5 + y * 0.6)), 8),
  });

  const gills = new THREE.ConeGeometry(4.05, 1.1, 32, 1, true);
  gills.translate(0, 8.05, 0);
  parts.push({
    geo: gills,
    color: [0.96, 0.94, 1.0],
    glow: (x, _y, z) => 0.5 + 0.5 * Math.pow(Math.abs(Math.sin(Math.atan2(z, x) * 22)), 3),
  });

  const cap = new THREE.SphereGeometry(4.2, 28, 10, 0, Math.PI * 2, 0, Math.PI * 0.5);
  cap.scale(1, 0.44, 1);
  cap.translate(0, 7.5, 0);
  const spot = (x: number, y: number, z: number) =>
    Math.sin(x * 1.7) * Math.sin(z * 1.9 + 1.3) * Math.cos((y - 7.5) * 2.3) > 0.42;
  parts.push({
    geo: cap,
    color: (x, y, z) => (spot(x, y, z) ? [1.55, 1.55, 1.6] : [1.0, 1.0, 1.0]),
    glow: (x, y, z) => (spot(x, y, z) ? 0.95 : 0.12),
  });

  return mergeAlienParts(parts);
}

/** 2. Small glowing mushroom cluster (0.3m - 1.3m) */
function buildMushroomCluster(): THREE.BufferGeometry {
  const r = rng(771);
  const parts: AlienPart[] = [];
  for (let k = 0; k < 6; k++) {
    const h = 0.3 + r() * 1.0;
    const capR = 0.12 + h * 0.22;
    const a = r() * Math.PI * 2;
    const d = k === 0 ? 0 : 0.18 + r() * 0.38;
    const ox = Math.cos(a) * d;
    const oz = Math.sin(a) * d;
    const stem = new THREE.CylinderGeometry(0.035 + h * 0.03, 0.055 + h * 0.045, h + 0.15, 7);
    stem.translate(ox, (h + 0.15) * 0.5 - 0.15, oz);
    parts.push({ geo: stem, color: [0.9, 0.9, 0.96], glow: 0.06 });

    const cap = new THREE.SphereGeometry(capR, 12, 6, 0, Math.PI * 2, 0, Math.PI * 0.5);
    cap.scale(1, 0.58, 1);
    cap.translate(ox, h - 0.02, oz);
    parts.push({ geo: cap, color: [1.0, 1.0, 1.0], glow: 0.5 });

    const gill = new THREE.CircleGeometry(capR * 0.95, 12);
    gill.rotateX(Math.PI / 2);
    gill.translate(ox, h - 0.025, oz);
    parts.push({ geo: gill, color: [1.2, 1.2, 1.25], glow: 1.0 });
  }
  return mergeAlienParts(parts);
}

/** 3. Coilwood — spiral helix tree with hanging luminous seed orbs (~9m) */
function buildCoilwood(): THREE.BufferGeometry {
  const parts: AlienPart[] = [];
  const pts: THREE.Vector3[] = [];
  for (let i = 0; i <= 20; i++) {
    const t = i / 20;
    const ang = t * Math.PI * 3.0;
    const rad = 0.15 + t * 1.1;
    pts.push(new THREE.Vector3(Math.cos(ang) * rad, -0.8 + t * 9.6, Math.sin(ang) * rad));
  }
  const curve = new THREE.CatmullRomCurve3(pts);
  const tube = new THREE.TubeGeometry(curve, 72, 0.5, 8, false);
  taperTube(tube, curve, 72, 8, (t) => 1.0 - t * 0.78);
  parts.push({
    geo: tube,
    color: (_x, y) => {
      const t = clamp01((y + 0.8) / 9.6);
      return [0.55 + t * 0.4, 0.5 + t * 0.4, 0.62 + t * 0.38];
    },
    glow: (x, y, z) => 0.04 + 0.32 * Math.pow(Math.max(0, Math.sin(Math.atan2(z, x) * 3 + y * 2.2)), 10),
  });

  const p = new THREE.Vector3();
  for (let k = 0; k < 7; k++) {
    const t = 0.58 + k * 0.058;
    curve.getPointAt(Math.min(1, t), p);
    const drop = 0.9 + (k % 3) * 0.35;
    const tendril = new THREE.CylinderGeometry(0.028, 0.028, drop, 4);
    tendril.translate(p.x, p.y - drop * 0.5, p.z);
    parts.push({ geo: tendril, color: [0.85, 0.85, 0.95], glow: 0.2 });
    const orb = new THREE.SphereGeometry(0.24, 12, 9);
    orb.translate(p.x, p.y - drop - 0.18, p.z);
    parts.push({ geo: orb, color: [1.35, 1.35, 1.35], glow: 1.0 });
  }

  curve.getPointAt(1, p);
  for (let k = 0; k < 6; k++) {
    const blade = new THREE.ConeGeometry(0.34, 2.6, 4);
    blade.scale(1, 1, 0.22);
    blade.translate(0, 1.3, 0);
    parts.push({
      geo: blade,
      color: [1.0, 1.0, 1.0],
      glow: (_x, y) => 0.1 + clamp01(y / 2.6) * 0.55,
      matrix: placement(p.x, p.y - 0.1, p.z, 1.1 + (k % 2) * 0.35, (k / 6) * Math.PI * 2, 0),
    });
  }
  return mergeAlienParts(parts);
}

/** 4. Bulb lantern — arching stalks ending in glowing lure bulbs (~2.2m) */
function buildBulbLantern(): THREE.BufferGeometry {
  const parts: AlienPart[] = [];
  for (let k = 0; k < 3; k++) {
    const a = k * 2.1 + 0.3;
    const h = 1.6 + k * 0.32;
    const reach = 0.5 + k * 0.16;
    const curve = new THREE.QuadraticBezierCurve3(
      new THREE.Vector3(0, -0.2, 0),
      new THREE.Vector3(Math.cos(a) * reach * 0.35, h * 1.2, Math.sin(a) * reach * 0.35),
      new THREE.Vector3(Math.cos(a) * reach, h, Math.sin(a) * reach)
    );
    const tube = new THREE.TubeGeometry(curve, 14, 0.05, 5, false);
    taperTube(tube, curve, 14, 5, (t) => 1.0 - t * 0.45);
    parts.push({ geo: tube, color: [0.8, 0.85, 0.9], glow: (_x, y) => 0.05 + clamp01(y / h) * 0.2 });
    const bulb = new THREE.SphereGeometry(0.21, 12, 9);
    bulb.scale(1, 1.25, 1);
    bulb.translate(Math.cos(a) * reach, h - 0.24, Math.sin(a) * reach);
    parts.push({ geo: bulb, color: [1.3, 1.3, 1.3], glow: 1.0 });
  }
  for (let l = 0; l < 5; l++) {
    const leaf = new THREE.ConeGeometry(0.11, 0.75, 4);
    leaf.scale(1, 1, 0.3);
    leaf.translate(0, 0.37, 0);
    parts.push({
      geo: leaf,
      color: [0.9, 0.95, 0.95],
      glow: 0.06,
      matrix: placement(0, -0.1, 0, 0.75, (l / 5) * Math.PI * 2 + 0.4, 0),
    });
  }
  return mergeAlienParts(parts);
}

/** 5. Tube coral — clustered open tubes with glowing rims (~1.6m) */
function buildTubeCoral(): THREE.BufferGeometry {
  const r = rng(4031);
  const parts: AlienPart[] = [];
  for (let k = 0; k < 8; k++) {
    const h = 0.55 + r() * 1.15;
    const rb = 0.07 + r() * 0.07;
    const rt = rb * (1.45 + r() * 0.35);
    const tube = new THREE.CylinderGeometry(rt, rb, h, 10, 1, true);
    tube.translate(0, h * 0.5 - 0.12, 0);
    const a = r() * Math.PI * 2;
    const d = k === 0 ? 0 : 0.12 + r() * 0.36;
    const top = h - 0.12;
    parts.push({
      geo: tube,
      color: (_x, y) => {
        const t = clamp01((y + 0.12) / h);
        return [0.75 + t * 0.3, 0.75 + t * 0.3, 0.8 + t * 0.25];
      },
      glow: (_x, y) => (y > top - h * 0.14 ? 1.0 : 0.08),
      matrix: placement(Math.cos(a) * d, 0, Math.sin(a) * d, (r() - 0.5) * 0.45, r() * 6.28, (r() - 0.5) * 0.45),
    });
  }
  return mergeAlienParts(parts);
}

function addCrystal(parts: AlienPart[], radius: number, height: number, m: THREE.Matrix4): void {
  const prism = new THREE.CylinderGeometry(radius, radius * 1.06, height, 6, 1);
  prism.translate(0, height * 0.5, 0);
  const total = height + radius * 1.8;
  const col: Vec3Fn = (_x, y) => {
    const t = clamp01(y / total);
    return [0.55 + t * 0.6, 0.55 + t * 0.6, 0.6 + t * 0.55];
  };
  const glow: NumFn = (_x, y) => 0.22 + clamp01(y / total) * 0.78;
  parts.push({ geo: prism, color: col, glow, matrix: m });
  const tip = new THREE.ConeGeometry(radius, radius * 1.8, 6);
  tip.translate(0, height + radius * 0.9, 0);
  parts.push({ geo: tip, color: col, glow, matrix: m.clone() });
}

/** 6. Crystal cluster (~1.4m) */
function buildCrystalCluster(): THREE.BufferGeometry {
  const r = rng(9101);
  const parts: AlienPart[] = [];
  addCrystal(parts, 0.2, 1.2, placement(0, -0.15, 0, 0.05, 0, 0.05));
  for (let k = 0; k < 7; k++) {
    const a = (k / 7) * Math.PI * 2 + r() * 0.5;
    const tilt = 0.35 + r() * 0.45;
    addCrystal(
      parts,
      0.08 + r() * 0.1,
      0.35 + r() * 0.75,
      placement(Math.cos(a) * 0.18, -0.12, Math.sin(a) * 0.18, tilt, -a + Math.PI / 2, 0)
    );
  }
  return mergeAlienParts(parts);
}

/** 7. Crystal spire formation (~8m) */
function buildCrystalSpire(): THREE.BufferGeometry {
  const r = rng(5513);
  const parts: AlienPart[] = [];
  addCrystal(parts, 0.95, 6.4, placement(0, -0.8, 0, 0.06, 0.3, -0.04));
  addCrystal(parts, 0.7, 4.2, placement(1.1, -0.6, 0.4, 0.1, 1.2, -0.32));
  addCrystal(parts, 0.62, 3.6, placement(-0.9, -0.6, -0.5, -0.22, 2.1, 0.26));
  for (let k = 0; k < 7; k++) {
    const a = r() * Math.PI * 2;
    const d = 1.3 + r() * 1.2;
    addCrystal(
      parts,
      0.18 + r() * 0.24,
      0.8 + r() * 1.6,
      placement(Math.cos(a) * d, -0.3, Math.sin(a) * d, 0.3 + r() * 0.4, -a + Math.PI / 2, 0)
    );
  }
  return mergeAlienParts(parts);
}

/** 8. Obsidian shards (~2m) */
function buildShards(): THREE.BufferGeometry {
  const r = rng(6607);
  const parts: AlienPart[] = [];
  for (let k = 0; k < 6; k++) {
    const g = new THREE.OctahedronGeometry(1, 0);
    const h = 0.7 + r() * 1.3;
    g.scale(0.22 + r() * 0.18, h, 0.16 + r() * 0.14);
    const a = r() * Math.PI * 2;
    const d = k === 0 ? 0 : 0.25 + r() * 0.6;
    parts.push({
      geo: g,
      color: [0.7, 0.66, 0.78],
      glow: (_x, y) => (Math.abs(y) < h * 0.08 ? 0.6 : 0.03),
      matrix: placement(Math.cos(a) * d, h * 0.45 - 0.25, Math.sin(a) * d, (r() - 0.5) * 0.7, r() * 6.28, (r() - 0.5) * 0.7),
    });
  }
  return mergeAlienParts(parts);
}

/** 9. Bone spires — bleached giant rib-like arcs (~6.5m) */
function buildBoneSpire(): THREE.BufferGeometry {
  const parts: AlienPart[] = [];
  for (let k = 0; k < 3; k++) {
    const curve = new THREE.CatmullRomCurve3([
      new THREE.Vector3(0, -0.8, 0),
      new THREE.Vector3(0.5, 2.6, 0.15),
      new THREE.Vector3(1.6, 5.2, 0.35),
      new THREE.Vector3(3.0 - k * 0.4, 6.4 - k * 0.6, 0.3),
    ]);
    const tube = new THREE.TubeGeometry(curve, 24, 0.42 - k * 0.06, 7, false);
    taperTube(tube, curve, 24, 7, (t) => 1.0 - t * 0.9);
    parts.push({
      geo: tube,
      color: (_x, y) => {
        const t = clamp01((y + 0.8) / 7.0);
        return [0.86 + t * 0.12, 0.83 + t * 0.12, 0.76 + t * 0.12];
      },
      glow: 0.0,
      matrix: placement(Math.cos(k * 2.2) * 0.4, 0, Math.sin(k * 2.2) * 0.4, 0, k * 2.1 + 0.5, 0),
    });
  }
  return mergeAlienParts(parts);
}

function createAlienMaterial(
  u: AlienFloraUniforms,
  o: {
    roughness: number;
    metalness: number;
    flat?: boolean;
    doubleSide?: boolean;
    sway: number;
    heightRef: number;
    glowDay: number;
    glowNight: number;
    rim: number;
  }
): THREE.MeshStandardMaterial {
  const mat = new THREE.MeshStandardMaterial({
    vertexColors: true,
    roughness: o.roughness,
    metalness: o.metalness,
    flatShading: Boolean(o.flat),
    side: o.doubleSide ? THREE.DoubleSide : THREE.FrontSide,
    envMapIntensity: 0.85,
  });

  const programKey = ['alien', o.sway, o.heightRef, o.glowDay, o.glowNight, o.rim, Boolean(o.flat)].join('|');
  mat.customProgramCacheKey = () => programKey;

  mat.onBeforeCompile = (shader) => {
    shader.uniforms.uAlienTime = u.uTime;
    shader.uniforms.uAlienNight = u.uNight;

    shader.vertexShader = shader.vertexShader
      .replace(
        '#include <common>',
        `#include <common>
        attribute float aGlow;
        uniform float uAlienTime;
        varying float vAlienGlow;`
      )
      .replace(
        '#include <begin_vertex>',
        `#include <begin_vertex>
        vAlienGlow = aGlow;
        float aH = clamp(position.y / ${o.heightRef.toFixed(2)}, 0.0, 1.3);
        #ifdef USE_INSTANCING
          vec3 aOrigin = vec3(instanceMatrix[3][0], instanceMatrix[3][1], instanceMatrix[3][2]);
        #else
          vec3 aOrigin = vec3(0.0);
        #endif
        float aPhase = uAlienTime * 1.15 + aOrigin.x * 0.06 + aOrigin.z * 0.05;
        float aBend = aH * aH * ${o.sway.toFixed(3)};
        transformed.x += sin(aPhase) * aBend;
        transformed.z += cos(aPhase * 0.83 + 1.1) * aBend * 0.7;`
      );

    shader.fragmentShader = shader.fragmentShader
      .replace(
        '#include <common>',
        `#include <common>
        uniform float uAlienNight;
        varying float vAlienGlow;`
      )
      .replace(
        '#include <emissivemap_fragment>',
        `#include <emissivemap_fragment>
        float aGlowAmt = mix(${o.glowDay.toFixed(3)}, ${o.glowNight.toFixed(3)}, uAlienNight);
        totalEmissiveRadiance += diffuseColor.rgb * vAlienGlow * aGlowAmt;
        float aRim = pow(1.0 - clamp(abs(dot(normal, normalize(vViewPosition))), 0.0, 1.0), 3.0);
        totalEmissiveRadiance += diffuseColor.rgb * aRim * ${o.rim.toFixed(3)} * (0.35 + 0.65 * uAlienNight);`
      );
  };

  return mat;
}

export class AlienFloraLibrary {
  public readonly capspireGeo: THREE.BufferGeometry;
  public readonly mushClusterGeo: THREE.BufferGeometry;
  public readonly coilwoodGeo: THREE.BufferGeometry;
  public readonly bulbGeo: THREE.BufferGeometry;
  public readonly tubeCoralGeo: THREE.BufferGeometry;
  public readonly crystalClusterGeo: THREE.BufferGeometry;
  public readonly crystalSpireGeo: THREE.BufferGeometry;
  public readonly shardGeo: THREE.BufferGeometry;
  public readonly boneSpireGeo: THREE.BufferGeometry;

  public readonly organicMat: THREE.MeshStandardMaterial;
  public readonly smallMat: THREE.MeshStandardMaterial;
  public readonly crystalMat: THREE.MeshStandardMaterial;

  private readonly uniforms: AlienFloraUniforms = {
    uTime: { value: 0 },
    uNight: { value: 0 },
  };

  constructor() {
    this.capspireGeo = buildCapspire();
    this.mushClusterGeo = buildMushroomCluster();
    this.coilwoodGeo = buildCoilwood();
    this.bulbGeo = buildBulbLantern();
    this.tubeCoralGeo = buildTubeCoral();
    this.crystalClusterGeo = buildCrystalCluster();
    this.crystalSpireGeo = buildCrystalSpire();
    this.shardGeo = buildShards();
    this.boneSpireGeo = buildBoneSpire();

    this.organicMat = createAlienMaterial(this.uniforms, {
      roughness: 0.55,
      metalness: 0.02,
      doubleSide: true,
      sway: 0.16,
      heightRef: 9.0,
      glowDay: 0.16,
      glowNight: 1.65,
      rim: 0.12,
    });
    this.smallMat = createAlienMaterial(this.uniforms, {
      roughness: 0.5,
      metalness: 0.02,
      doubleSide: true,
      sway: 0.08,
      heightRef: 1.8,
      glowDay: 0.24,
      glowNight: 1.9,
      rim: 0.15,
    });
    this.crystalMat = createAlienMaterial(this.uniforms, {
      roughness: 0.14,
      metalness: 0.22,
      flat: true,
      sway: 0.0,
      heightRef: 4.0,
      glowDay: 0.4,
      glowNight: 1.7,
      rim: 0.55,
    });
  }

  public update(elapsed: number, nightFactor: number): void {
    this.uniforms.uTime.value = elapsed;
    this.uniforms.uNight.value = nightFactor;
  }
}
