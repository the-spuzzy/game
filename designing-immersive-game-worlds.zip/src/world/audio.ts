import { BiomeId, SurfaceMaterial } from './biomes';
import { clamp } from './noise';

export type CreatureCallKind =
  | 'grazer'
  | 'strider'
  | 'jelly'
  | 'manta'
  | 'blob'
  | 'wyrm'
  | 'titan'
  | 'crab'
  | 'fish'
  | 'thorn';

interface ToneOpts {
  attack?: number;
  vibRate?: number;
  vibDepth?: number;
  filter?: number;
  fmRate?: number;
  fmDepth?: number;
}

/** Procedural alien soundscape + synthesized creature voices (Web Audio, no assets) */
export class WorldAudio {
  private ctx: AudioContext | null = null;
  private noiseBuffer: AudioBuffer | null = null;
  private masterGain: GainNode | null = null;

  private windFilter: BiquadFilterNode | null = null;
  private windGain: GainNode | null = null;
  private surfFilter: BiquadFilterNode | null = null;
  private surfGain: GainNode | null = null;

  private droneGain: GainNode | null = null;
  private droneFilter: BiquadFilterNode | null = null;
  private droneOscA: OscillatorNode | null = null;
  private droneOscB: OscillatorNode | null = null;
  private shimmerGain: GainNode | null = null;

  private muted = false;
  private initialized = false;
  private chirpTimer = 2.0;
  private pulseTimer = 1.5;
  private frogTimer = 3.0;
  private weatherIntensity = 0;

  public unlock(): void {
    if (this.initialized) {
      if (this.ctx && this.ctx.state === 'suspended') this.ctx.resume().catch(() => {});
      return;
    }
    try {
      const AudioCtx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (!AudioCtx) return;
      const ctx = new AudioCtx();
      this.ctx = ctx;

      this.masterGain = ctx.createGain();
      this.masterGain.gain.value = this.muted ? 0 : 0.72;
      this.masterGain.connect(ctx.destination);

      const sampleRate = ctx.sampleRate;
      const length = sampleRate * 3;
      const buf = ctx.createBuffer(1, length, sampleRate);
      const data = buf.getChannelData(0);
      let b0 = 0,
        b1 = 0,
        b2 = 0,
        b3 = 0,
        b4 = 0,
        b5 = 0,
        b6 = 0;
      for (let i = 0; i < length; i++) {
        const white = Math.random() * 2 - 1;
        b0 = 0.99886 * b0 + white * 0.0555179;
        b1 = 0.99332 * b1 + white * 0.0750759;
        b2 = 0.969 * b2 + white * 0.153852;
        b3 = 0.8665 * b3 + white * 0.3104856;
        b4 = 0.55 * b4 + white * 0.5329522;
        b5 = -0.7616 * b5 - white * 0.016898;
        data[i] = (b0 + b1 + b2 + b3 + b4 + b5 + b6 + white * 0.5362) * 0.06;
        b6 = white * 0.115926;
      }
      this.noiseBuffer = buf;

      const windSrc = ctx.createBufferSource();
      windSrc.buffer = buf;
      windSrc.loop = true;
      this.windFilter = ctx.createBiquadFilter();
      this.windFilter.type = 'bandpass';
      this.windFilter.frequency.value = 380;
      this.windFilter.Q.value = 1.1;
      this.windGain = ctx.createGain();
      this.windGain.gain.value = 0.05;
      windSrc.connect(this.windFilter);
      this.windFilter.connect(this.windGain);
      this.windGain.connect(this.masterGain);
      windSrc.start();

      const surfSrc = ctx.createBufferSource();
      surfSrc.buffer = buf;
      surfSrc.loop = true;
      surfSrc.playbackRate.value = 0.72;
      this.surfFilter = ctx.createBiquadFilter();
      this.surfFilter.type = 'lowpass';
      this.surfFilter.frequency.value = 340;
      this.surfGain = ctx.createGain();
      this.surfGain.gain.value = 0;
      surfSrc.connect(this.surfFilter);
      this.surfFilter.connect(this.surfGain);
      this.surfGain.connect(this.masterGain);
      surfSrc.start();

      // Deep alien planetary drone
      this.droneOscA = ctx.createOscillator();
      this.droneOscA.type = 'sine';
      this.droneOscA.frequency.value = 55;
      this.droneOscB = ctx.createOscillator();
      this.droneOscB.type = 'triangle';
      this.droneOscB.frequency.value = 82.6;
      this.droneFilter = ctx.createBiquadFilter();
      this.droneFilter.type = 'lowpass';
      this.droneFilter.frequency.value = 260;
      const droneLfo = ctx.createOscillator();
      droneLfo.frequency.value = 0.07;
      const droneLfoGain = ctx.createGain();
      droneLfoGain.gain.value = 120;
      droneLfo.connect(droneLfoGain);
      droneLfoGain.connect(this.droneFilter.frequency);
      this.droneGain = ctx.createGain();
      this.droneGain.gain.value = 0.0;
      this.droneOscA.connect(this.droneFilter);
      this.droneOscB.connect(this.droneFilter);
      this.droneFilter.connect(this.droneGain);
      this.droneGain.connect(this.masterGain);
      this.droneOscA.start();
      this.droneOscB.start();
      droneLfo.start();

      // Glassy "singing moss" shimmer at night
      const shA = ctx.createOscillator();
      shA.type = 'sine';
      shA.frequency.value = 1318.5;
      const shB = ctx.createOscillator();
      shB.type = 'sine';
      shB.frequency.value = 1975.5;
      const trem = ctx.createGain();
      trem.gain.value = 0.5;
      const tremLfo = ctx.createOscillator();
      tremLfo.frequency.value = 0.31;
      const tremDepth = ctx.createGain();
      tremDepth.gain.value = 0.5;
      tremLfo.connect(tremDepth);
      tremDepth.connect(trem.gain);
      this.shimmerGain = ctx.createGain();
      this.shimmerGain.gain.value = 0;
      shA.connect(trem);
      shB.connect(trem);
      trem.connect(this.shimmerGain);
      this.shimmerGain.connect(this.masterGain);
      shA.start();
      shB.start();
      tremLfo.start();

      this.initialized = true;
    } catch {
      // Web Audio unavailable
    }
  }

  public setMuted(muted: boolean): void {
    this.muted = muted;
    if (this.masterGain && this.ctx) {
      this.masterGain.gain.setTargetAtTime(muted ? 0 : 0.72, this.ctx.currentTime, 0.08);
    }
  }

  public isMuted(): boolean {
    return this.muted;
  }

  public setWeatherIntensity(v: number): void {
    this.weatherIntensity = clamp(v, 0, 1);
  }

  private ready(): boolean {
    return Boolean(this.initialized && this.ctx && this.masterGain && !this.muted && this.ctx.state === 'running');
  }

  private out(pan: number): AudioNode | null {
    if (!this.ctx || !this.masterGain) return null;
    if (typeof this.ctx.createStereoPanner === 'function') {
      const p = this.ctx.createStereoPanner();
      p.pan.value = clamp(pan, -1, 1);
      p.connect(this.masterGain);
      return p;
    }
    return this.masterGain;
  }

  private tone(
    dest: AudioNode,
    type: OscillatorType,
    f0: number,
    f1: number,
    t0: number,
    dur: number,
    vol: number,
    o: ToneOpts = {}
  ): void {
    const ctx = this.ctx;
    if (!ctx) return;
    const osc = ctx.createOscillator();
    osc.type = type;
    osc.frequency.setValueAtTime(Math.max(20, f0), t0);
    osc.frequency.exponentialRampToValueAtTime(Math.max(20, f1), t0 + dur);
    const gain = ctx.createGain();
    const attack = Math.min(o.attack ?? 0.02, dur * 0.6);
    gain.gain.setValueAtTime(0.0001, t0);
    gain.gain.linearRampToValueAtTime(Math.max(0.0002, vol), t0 + attack);
    gain.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    let node: AudioNode = osc;
    if (o.filter) {
      const f = ctx.createBiquadFilter();
      f.type = 'lowpass';
      f.frequency.value = o.filter;
      node.connect(f);
      node = f;
    }
    node.connect(gain);
    gain.connect(dest);
    const mods: OscillatorNode[] = [];
    if (o.vibRate && o.vibDepth) {
      const lfo = ctx.createOscillator();
      lfo.frequency.value = o.vibRate;
      const lg = ctx.createGain();
      lg.gain.value = o.vibDepth;
      lfo.connect(lg);
      lg.connect(osc.frequency);
      mods.push(lfo);
    }
    if (o.fmRate && o.fmDepth) {
      const mod = ctx.createOscillator();
      mod.frequency.value = o.fmRate;
      const mg = ctx.createGain();
      mg.gain.value = o.fmDepth;
      mod.connect(mg);
      mg.connect(osc.frequency);
      mods.push(mod);
    }
    osc.start(t0);
    osc.stop(t0 + dur + 0.05);
    for (const m of mods) {
      m.start(t0);
      m.stop(t0 + dur + 0.05);
    }
  }

  private noiseBurst(
    dest: AudioNode,
    t0: number,
    dur: number,
    vol: number,
    type: BiquadFilterType,
    freq: number,
    q = 1,
    freqEnd?: number
  ): void {
    const ctx = this.ctx;
    if (!ctx || !this.noiseBuffer) return;
    const src = ctx.createBufferSource();
    src.buffer = this.noiseBuffer;
    src.loop = dur > 0.9;
    const f = ctx.createBiquadFilter();
    f.type = type;
    f.frequency.setValueAtTime(freq, t0);
    f.Q.value = q;
    if (freqEnd) f.frequency.exponentialRampToValueAtTime(freqEnd, t0 + dur);
    const g = ctx.createGain();
    g.gain.setValueAtTime(0.0001, t0);
    g.gain.linearRampToValueAtTime(Math.max(0.0002, vol), t0 + Math.min(0.05, dur * 0.3));
    g.gain.exponentialRampToValueAtTime(0.0001, t0 + dur);
    src.connect(f);
    f.connect(g);
    g.connect(dest);
    src.start(t0, Math.random() * 1.8, dur + 0.05);
  }

  /** Living alien soundscape: wind, surf, planetary drone, singing moss, chirps, night pulses */
  public update(
    dt: number,
    elapsed: number,
    biome: BiomeId,
    altitude: number,
    waterProximity: number,
    dayFactor: number,
    nightFactor: number,
    playerSpeed: number
  ): void {
    if (!this.ready() || !this.ctx) return;
    const now = this.ctx.currentTime;
    const gust = 0.72 + 0.28 * Math.sin(elapsed * 0.42) * Math.cos(elapsed * 0.19);
    const speedRush = clamp(playerSpeed / 12, 0, 0.65);

    const altFactor = clamp((altitude - 15) / 65, 0, 1);
    let windVol = (0.05 + altFactor * 0.11 + speedRush * 0.05 + this.weatherIntensity * 0.05) * gust;
    let windFreq = 340 + altFactor * 380 + gust * 110 + speedRush * 180;
    let windQ = 1.0 + altFactor * 2.2;
    if (biome === 'forest' || biome === 'jungle') {
      windFreq = 460 + gust * 90;
      windVol = 0.07 * gust;
      windQ = 0.85;
    } else if (biome === 'desert' || biome === 'wasteland' || biome === 'plains') {
      windFreq = 520 + gust * 160;
      windVol = (biome === 'plains' ? 0.085 : 0.075) * gust;
      windQ = 1.5;
    } else if (biome === 'wetland') {
      windVol = 0.035 * gust;
      windFreq = 290;
    }
    this.windGain?.gain.setTargetAtTime(windVol, now, 0.25);
    this.windFilter?.frequency.setTargetAtTime(windFreq, now, 0.25);
    this.windFilter?.Q.setTargetAtTime(windQ, now, 0.25);

    const waveCycle = biome === 'coast' ? 0.55 + 0.45 * Math.sin(elapsed * 0.78) : 0.72;
    const surfVol = waterProximity * (biome === 'coast' ? 0.17 : 0.08) * waveCycle;
    this.surfGain?.gain.setTargetAtTime(surfVol, now, 0.2);
    this.surfFilter?.frequency.setTargetAtTime(biome === 'coast' ? 240 + waveCycle * 360 : 320, now, 0.2);

    // Planetary drone pitch & presence per region (ominous in the Ashen Rift)
    let droneVol = 0.022 + nightFactor * 0.018;
    let droneHz = 55;
    if (biome === 'wasteland') {
      droneVol = 0.05;
      droneHz = 41.2;
    } else if (biome === 'alpine') {
      droneVol = 0.03;
      droneHz = 65.4;
    } else if (biome === 'jungle' || biome === 'wetland') {
      droneVol = 0.03 + nightFactor * 0.02;
      droneHz = 49;
    }
    this.droneGain?.gain.setTargetAtTime(droneVol, now, 1.2);
    this.droneOscA?.frequency.setTargetAtTime(droneHz, now, 2.0);
    this.droneOscB?.frequency.setTargetAtTime(droneHz * 1.502, now, 2.0);

    const lush = biome === 'meadow' || biome === 'forest' || biome === 'jungle' || biome === 'wetland' || biome === 'coast';
    this.shimmerGain?.gain.setTargetAtTime(lush ? nightFactor * 0.009 : nightFactor * 0.003, now, 1.5);

    // Daytime alien chirp-song from unseen canopy dwellers
    if (dayFactor > 0.3 && biome !== 'wasteland' && biome !== 'alpine') {
      this.chirpTimer -= dt;
      if (this.chirpTimer <= 0) {
        this.chirpTimer = 2.4 + Math.random() * 5.0;
        this.playAlienChirp();
      }
    }

    // Night pulse-insects & glass frogs
    if (nightFactor > 0.35 && biome !== 'alpine') {
      this.pulseTimer -= dt;
      if (this.pulseTimer <= 0) {
        this.pulseTimer = 1.4 + Math.random() * 2.6;
        this.playNightPulse();
      }
    }
    if ((biome === 'wetland' || biome === 'jungle') && nightFactor > 0.2) {
      this.frogTimer -= dt;
      if (this.frogTimer <= 0) {
        this.frogTimer = 2.2 + Math.random() * 3.5;
        this.playGlassFrog();
      }
    }
  }

  private playAlienChirp(): void {
    const dest = this.out((Math.random() - 0.5) * 1.6);
    if (!dest || !this.ctx) return;
    const now = this.ctx.currentTime;
    const f = 1800 + Math.random() * 1800;
    const fm = 28 + Math.random() * 50;
    this.tone(dest, 'sine', f, f * (1.25 + Math.random() * 0.4), now, 0.16, 0.016, { fmRate: fm, fmDepth: 320 });
    this.tone(dest, 'sine', f * 1.3, f * 0.9, now + 0.2, 0.22, 0.012, { fmRate: fm * 1.5, fmDepth: 260 });
  }

  private playNightPulse(): void {
    const dest = this.out((Math.random() - 0.5) * 1.6);
    if (!dest || !this.ctx) return;
    const now = this.ctx.currentTime;
    const f = 2900 + Math.random() * 700;
    const n = 4 + Math.floor(Math.random() * 4);
    for (let i = 0; i < n; i++) {
      this.tone(dest, 'square', f, f * 0.98, now + i * 0.06, 0.035, 0.0045, { filter: 5200 });
    }
  }

  private playGlassFrog(): void {
    const dest = this.out((Math.random() - 0.5) * 1.4);
    if (!dest || !this.ctx) return;
    const now = this.ctx.currentTime;
    const f = 280 + Math.random() * 120;
    this.tone(dest, 'sine', f, f * 1.8, now, 0.22, 0.024, { vibRate: 18, vibDepth: 14 });
    this.tone(dest, 'sine', f * 2.01, f * 3.4, now + 0.03, 0.18, 0.006);
  }

  /** Synthesized alien creature voices with distance volume & stereo pan */
  public playCreatureCall(kind: CreatureCallKind, volume: number, pan: number): void {
    if (!this.ready() || volume < 0.02 || !this.ctx) return;
    const dest = this.out(pan);
    if (!dest) return;
    const now = this.ctx.currentTime;
    const v = clamp(volume, 0, 1);
    const r = Math.random();

    switch (kind) {
      case 'grazer': {
        const f = 150 + r * 40;
        this.tone(dest, 'triangle', f, f * 0.74, now, 0.95, v * 0.5, { vibRate: 7, vibDepth: 6, filter: 900, attack: 0.12 });
        this.tone(dest, 'sine', f * 2, f * 1.5, now + 0.05, 0.85, v * 0.14, { attack: 0.1 });
        break;
      }
      case 'strider': {
        const f = 66 + r * 10;
        this.tone(dest, 'sawtooth', f, f * 1.08, now, 2.6, v * 0.3, { attack: 0.7, filter: 520, vibRate: 0.8, vibDepth: 2 });
        this.tone(dest, 'sine', f * 1.5, f * 1.6, now, 2.6, v * 0.24, { attack: 0.8 });
        break;
      }
      case 'jelly': {
        const base = 1046 * (0.85 + r * 0.3);
        const notes = [1, 1.26, 1.5];
        notes.forEach((m, i) => {
          const f = base * m;
          this.tone(dest, 'sine', f, f * 1.003, now + i * 0.16, 1.4, v * 0.11, { attack: 0.01, fmRate: f * 2.01, fmDepth: f * 0.12 });
        });
        break;
      }
      case 'manta': {
        const f = 1700 + r * 400;
        this.tone(dest, 'sine', f, f * 1.45, now, 0.36, v * 0.15, { vibRate: 22, vibDepth: 60 });
        this.tone(dest, 'sine', f * 1.45, f * 1.15, now + 0.36, 0.42, v * 0.11, { vibRate: 18, vibDepth: 40 });
        break;
      }
      case 'blob': {
        const f = 520 + r * 240;
        this.tone(dest, 'sine', f, f * 2.5, now, 0.13, v * 0.22);
        this.tone(dest, 'sine', f * 1.7, f * 3.4, now + 0.15, 0.09, v * 0.12);
        break;
      }
      case 'wyrm': {
        this.noiseBurst(dest, now, 1.3, v * 0.5, 'lowpass', 230);
        this.noiseBurst(dest, now, 1.1, v * 0.18, 'bandpass', 700, 2, 1400);
        this.tone(dest, 'sawtooth', 48, 36, now, 1.2, v * 0.14, { filter: 200, attack: 0.15 });
        break;
      }
      case 'titan': {
        this.tone(dest, 'sine', 44, 37, now, 4.6, v * 0.6, { attack: 1.2, vibRate: 0.5, vibDepth: 1.5 });
        this.tone(dest, 'sine', 66, 56, now + 0.2, 4.2, v * 0.34, { attack: 1.4 });
        this.tone(dest, 'triangle', 88, 79, now + 0.4, 3.8, v * 0.12, { attack: 1.5, filter: 300 });
        this.noiseBurst(dest, now, 4.0, v * 0.12, 'lowpass', 120);
        break;
      }
      case 'crab': {
        const n = 7 + Math.floor(r * 6);
        for (let i = 0; i < n; i++) {
          this.noiseBurst(dest, now + i * 0.045 + Math.random() * 0.012, 0.014, v * 0.32, 'highpass', 3200);
        }
        break;
      }
      case 'thorn': {
        this.tone(dest, 'sawtooth', 92, 76, now, 0.9, v * 0.28, { filter: 620, fmRate: 28, fmDepth: 40, attack: 0.08 });
        for (let i = 0; i < 5; i++) {
          this.noiseBurst(dest, now + 0.15 + i * 0.07, 0.02, v * 0.2, 'bandpass', 1800, 3);
        }
        break;
      }
      case 'fish': {
        this.tone(dest, 'sine', 900, 380, now, 0.12, v * 0.15);
        this.noiseBurst(dest, now, 0.25, v * 0.18, 'bandpass', 900, 0.8);
        break;
      }
    }
  }

  public playFootstep(surface: SurfaceMaterial, isRunning: boolean): void {
    if (!this.ready() || !this.ctx || !this.noiseBuffer || !this.masterGain) return;
    const now = this.ctx.currentTime;
    const src = this.ctx.createBufferSource();
    src.buffer = this.noiseBuffer;
    const filter = this.ctx.createBiquadFilter();
    const gain = this.ctx.createGain();
    const jitter = 0.88 + Math.random() * 0.24;
    const baseVol = isRunning ? 0.14 : 0.085;
    let dur = 0.11;
    switch (surface) {
      case 'snow':
        filter.type = 'bandpass';
        filter.frequency.value = 1450 * jitter;
        filter.Q.value = 1.2;
        dur = 0.15;
        break;
      case 'sand':
        filter.type = 'bandpass';
        filter.frequency.value = 980 * jitter;
        filter.Q.value = 0.9;
        dur = 0.14;
        break;
      case 'water':
        filter.type = 'bandpass';
        filter.frequency.value = 680 * jitter;
        filter.Q.value = 0.7;
        dur = 0.22;
        break;
      case 'rock':
        filter.type = 'highpass';
        filter.frequency.value = 720 * jitter;
        dur = 0.075;
        break;
      case 'dirt':
        filter.type = 'bandpass';
        filter.frequency.value = 620 * jitter;
        filter.Q.value = 1.1;
        dur = 0.1;
        break;
      case 'grass':
      default:
        filter.type = 'bandpass';
        filter.frequency.value = 820 * jitter;
        filter.Q.value = 0.8;
        dur = 0.11;
        break;
    }
    gain.gain.setValueAtTime(0.0001, now);
    gain.gain.linearRampToValueAtTime(baseVol, now + 0.012);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + dur);
    src.connect(filter);
    filter.connect(gain);
    gain.connect(this.masterGain);
    src.start(now, Math.random() * 2.2, dur + 0.02);
  }

  /** Shimmering alien discovery chord when entering a new region */
  public playBiomeDiscovery(): void {
    if (!this.ready() || !this.ctx || !this.masterGain) return;
    const now = this.ctx.currentTime;
    const notes = [233.08, 349.23, 466.16, 698.46];
    notes.forEach((freq, i) => {
      const t0 = now + i * 0.14;
      this.tone(this.masterGain as AudioNode, 'sine', freq, freq * 1.002, t0, 2.2, 0.04, {
        attack: 0.08,
        fmRate: freq * 1.5,
        fmDepth: freq * 0.04,
      });
    });
  }

  /** Player slime taking damage from an alien attacker */
  public playPlayerHurtSound(): void {
    if (!this.ready() || !this.ctx || !this.masterGain) return;
    const now = this.ctx.currentTime;
    const dest = this.masterGain as AudioNode;
    this.noiseBurst(dest, now, 0.24, 0.2, 'bandpass', 420, 1.3, 150);
    this.tone(dest, 'sawtooth', 210, 72, now, 0.26, 0.1, { attack: 0.008, filter: 1100 });
  }

  /** Juicy xeno-slime bite / lunge crunch */
  public playBiteSound(hitPrey: boolean): void {
    if (!this.ready() || !this.ctx || !this.masterGain) return;
    const now = this.ctx.currentTime;
    const dest = this.masterGain as AudioNode;
    this.tone(dest, 'sawtooth', 260, 88, now, 0.18, 0.12, {
      attack: 0.008,
      filter: 1400,
    });
    if (hitPrey) {
      this.noiseBurst(dest, now, 0.14, 0.22, 'bandpass', 1100, 1.5, 420);
      this.tone(dest, 'triangle', 520, 180, now + 0.02, 0.15, 0.14, {
        attack: 0.005,
      });
    }
  }

  /** Bio-plasma spit launch sound */
  public playSpitSound(): void {
    if (!this.ready() || !this.ctx || !this.masterGain) return;
    const now = this.ctx.currentTime;
    const dest = this.masterGain as AudioNode;
    this.tone(dest, 'sine', 680, 240, now, 0.22, 0.12, {
      attack: 0.01,
      fmRate: 35,
      fmDepth: 120,
    });
    this.noiseBurst(dest, now, 0.12, 0.1, 'bandpass', 1800, 2.2, 650);
  }

  /** Absorbing DNA / Biomass orb chime */
  public playDnaAbsorbSound(): void {
    if (!this.ready() || !this.ctx || !this.masterGain) return;
    const now = this.ctx.currentTime;
    const dest = this.masterGain as AudioNode;
    const base = 523.25 * (0.95 + Math.random() * 0.15);
    this.tone(dest, 'sine', base, base * 1.5, now, 0.22, 0.08, { attack: 0.01 });
    this.tone(dest, 'triangle', base * 1.5, base * 2.0, now + 0.07, 0.26, 0.06, {
      attack: 0.01,
    });
  }

  /** Triumphant Spore-style Evolution Mutation Fanfare */
  public playEvolutionFanfare(): void {
    if (!this.ready() || !this.ctx || !this.masterGain) return;
    const now = this.ctx.currentTime;
    const dest = this.masterGain as AudioNode;
    const chord = [261.63, 329.63, 392.0, 523.25, 659.25, 783.99];
    chord.forEach((f, idx) => {
      const t0 = now + idx * 0.085;
      this.tone(dest, 'triangle', f, f * 1.01, t0, 1.8, 0.065, {
        attack: 0.04,
        vibRate: 5,
        vibDepth: 3,
      });
    });
  }
}
