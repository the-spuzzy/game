import { clamp, fbm2, lerp, ridged2, simplex2, smoothstep, warpedFbm2 } from './noise';

export type BiomeId =
  | 'meadow'
  | 'forest'
  | 'alpine'
  | 'desert'
  | 'coast'
  | 'autumn'
  | 'wetland'
  | 'jungle'
  | 'plains'
  | 'wasteland';

export interface BiomeDefinition {
  id: BiomeId;
  name: string;
  subtitle: string;
  description: string;
  accentColor: string;
  mapColor: [number, number, number];
  landmark: {
    name: string;
    x: number;
    z: number;
    yaw: number;
  };
  fogTint: [number, number, number];
  temperatureC: number;
}

export const WATER_LEVEL = 0.0;
export const WORLD_MAP_RADIUS = 900; // ~1.8 km x 1.8 km alien continent
export const CHUNK_SIZE = 72;

let activeTerrainCellSize = 1.5;
const vertexHeightCache = new Map<number, number>();

export function setActiveTerrainCellSize(cellSize: number): void {
  if (cellSize !== activeTerrainCellSize) vertexHeightCache.clear();
  activeTerrainCellSize = cellSize;
}

export function getActiveTerrainCellSize(): number {
  return activeTerrainCellSize;
}

export const OASIS_X = 548;
export const OASIS_Z = 214;

function yawToward(fx: number, fz: number, tx: number, tz: number): number {
  return Math.atan2(-(tx - fx), -(tz - fz));
}

const JUNGLE_VIEW_X = -440;
const JUNGLE_VIEW_Z = 426;
const PLAINS_VIEW_X = 322;
const PLAINS_VIEW_Z = 28;
const WASTE_VIEW_X = 540;
const WASTE_VIEW_Z = -276;
const OASIS_VIEW_X = OASIS_X - 24;
const OASIS_VIEW_Z = OASIS_Z + 12;

export const BIOMES: Record<BiomeId, BiomeDefinition> = {
  meadow: {
    id: 'meadow',
    name: 'Lumen Vale',
    subtitle: 'Bioluminescent Moss Meadows',
    description:
      'Rolling teal moss hills, glowing lantern bulbs and drifting skyjellies beneath a giant ringed world.',
    accentColor: '#5eead4',
    mapColor: [40, 150, 150],
    landmark: { name: 'Landing Ridge', x: 0, z: 18, yaw: 0.08 },
    fogTint: [0.72, 0.78, 0.95],
    temperatureC: 19,
  },
  plains: {
    id: 'plains',
    name: 'Driftgrass Steppes',
    subtitle: 'Endless Coral Prairie',
    description:
      'A rolling sea of coral driftgrass where six-legged Vexari herds stampede and Longstriders tower overhead.',
    accentColor: '#fdba74',
    mapColor: [210, 130, 90],
    landmark: {
      name: 'Grazer Crossing',
      x: PLAINS_VIEW_X,
      z: PLAINS_VIEW_Z,
      yaw: yawToward(PLAINS_VIEW_X, PLAINS_VIEW_Z, 520, -120),
    },
    fogTint: [0.94, 0.8, 0.74],
    temperatureC: 26,
  },
  forest: {
    id: 'forest',
    name: 'Spirecap Woods',
    subtitle: 'Giant Fungal Forest',
    description:
      'Towering capspire mushrooms and violet spire-pines whose glowing gills light the forest floor at night.',
    accentColor: '#c4b5fd',
    mapColor: [80, 60, 140],
    landmark: { name: 'Elder Cap Hollow', x: -265, z: -115, yaw: -0.65 },
    fogTint: [0.64, 0.6, 0.86],
    temperatureC: 14,
  },
  jungle: {
    id: 'jungle',
    name: 'Verdigris Tangle',
    subtitle: 'Bioluminescent Jungle',
    description:
      'Dense emerald tangles of coilwood and fanfronds, lantern bulbs, hopping bloblings and prowling thornbacks.',
    accentColor: '#34d399',
    mapColor: [30, 120, 90],
    landmark: { name: 'Lantern Grove', x: JUNGLE_VIEW_X, z: JUNGLE_VIEW_Z, yaw: 0.6 },
    fogTint: [0.58, 0.8, 0.72],
    temperatureC: 33,
  },
  alpine: {
    id: 'alpine',
    name: 'Cryo Spires',
    subtitle: 'Frozen Crystal Mountains',
    description:
      'Lilac snowfields, blue-black frost ridges, singing crystal spires and scuttling prism crabs.',
    accentColor: '#bae6fd',
    mapColor: [210, 220, 245],
    landmark: { name: 'Highwatch Pass', x: -35, z: -395, yaw: 0.15 },
    fogTint: [0.82, 0.86, 0.99],
    temperatureC: -18,
  },
  autumn: {
    id: 'autumn',
    name: 'Crimson Highlands',
    subtitle: 'Scarlet Bloom Ridges',
    description: 'Windswept ridges of scarlet blushwood, ember-red bloom moss and stalking thornbacks.',
    accentColor: '#fb7185',
    mapColor: [170, 50, 60],
    landmark: { name: 'Ember Crest', x: 275, z: -215, yaw: -0.9 },
    fogTint: [0.92, 0.72, 0.75],
    temperatureC: 11,
  },
  wasteland: {
    id: 'wasteland',
    name: 'Ashen Rift',
    subtitle: 'Barren Obsidian Wastes',
    description:
      'Obsidian badlands split by glowing rift canyons, bleached bone spires and burrowing rift wyrms.',
    accentColor: '#f472b6',
    mapColor: [60, 50, 62],
    landmark: {
      name: 'Bone Spire Basin',
      x: WASTE_VIEW_X,
      z: WASTE_VIEW_Z,
      yaw: yawToward(WASTE_VIEW_X, WASTE_VIEW_Z, 650, -440),
    },
    fogTint: [0.56, 0.46, 0.54],
    temperatureC: 47,
  },
  desert: {
    id: 'desert',
    name: 'Rust Dunes',
    subtitle: 'Iron-Red Sand Seas',
    description: 'Wind-carved rust dunes, crimson mesas, spinepod cacti and a hidden teal oasis.',
    accentColor: '#fb923c',
    mapColor: [200, 100, 55],
    landmark: {
      name: 'Mirage Oasis',
      x: OASIS_VIEW_X,
      z: OASIS_VIEW_Z,
      yaw: yawToward(OASIS_VIEW_X, OASIS_VIEW_Z, OASIS_X, OASIS_Z),
    },
    fogTint: [0.95, 0.7, 0.55],
    temperatureC: 41,
  },
  coast: {
    id: 'coast',
    name: 'Glass Shoals',
    subtitle: 'Luminous Violet Coast',
    description:
      'Pearl-lavender beaches, glowing tube corals, sea crystals, leaping glowfins and gliding wingrays.',
    accentColor: '#67e8f9',
    mapColor: [200, 190, 225],
    landmark: { name: 'Sunbreak Cove', x: 28, z: 285, yaw: 2.95 },
    fogTint: [0.74, 0.82, 0.98],
    temperatureC: 24,
  },
  wetland: {
    id: 'wetland',
    name: 'Glowmire',
    subtitle: 'Radiant Fungal Marsh',
    description: 'Black-water channels lit by glowing moss, weepglow willows, lantern reeds and skyjelly swarms.',
    accentColor: '#86efac',
    mapColor: [40, 90, 70],
    landmark: { name: 'Lantern Reed Crossing', x: -275, z: 195, yaw: 2.2 },
    fogTint: [0.58, 0.78, 0.68],
    temperatureC: 22,
  },
};

export const BIOME_ORDER: ReadonlyArray<BiomeId> = [
  'meadow',
  'forest',
  'alpine',
  'desert',
  'coast',
  'autumn',
  'wetland',
  'jungle',
  'plains',
  'wasteland',
];

export const BIOME_LIST: BiomeDefinition[] = [
  BIOMES.meadow,
  BIOMES.plains,
  BIOMES.forest,
  BIOMES.jungle,
  BIOMES.alpine,
  BIOMES.autumn,
  BIOMES.wasteland,
  BIOMES.desert,
  BIOMES.coast,
  BIOMES.wetland,
];

export interface BiomeWeights {
  meadow: number;
  forest: number;
  alpine: number;
  desert: number;
  coast: number;
  autumn: number;
  wetland: number;
  jungle: number;
  plains: number;
  wasteland: number;
  dominant: BiomeId;
}

const BIOME_INDEX: Record<BiomeId, number> = {
  meadow: 0,
  forest: 1,
  alpine: 2,
  desert: 3,
  coast: 4,
  autumn: 5,
  wetland: 6,
  jungle: 7,
  plains: 8,
  wasteland: 9,
};

const ANCHOR_SPECS: ReadonlyArray<[BiomeId, number, number, number, number]> = [
  ['meadow', 0, -10, 220, 1.25],
  ['meadow', 40, 95, 150, 0.88],
  ['forest', -275, -115, 255, 1.35],
  ['forest', -175, -265, 205, 1.1],
  ['forest', -480, -250, 220, 1.15],
  ['alpine', -30, -475, 295, 1.55],
  ['alpine', -260, -480, 230, 1.35],
  ['alpine', 210, -510, 225, 1.3],
  ['alpine', -520, -560, 250, 1.3],
  ['alpine', 0, -720, 300, 1.5],
  ['alpine', 380, -680, 210, 1.2],
  ['autumn', 280, -235, 235, 1.35],
  ['autumn', 145, -205, 160, 0.9],
  ['plains', 330, 10, 265, 1.45],
  ['plains', 470, -70, 200, 1.1],
  ['plains', 205, 125, 170, 0.95],
  ['wasteland', 630, -390, 300, 1.55],
  ['wasteland', 770, -210, 230, 1.2],
  ['wasteland', 570, -570, 200, 1.15],
  ['desert', 560, 230, 290, 1.5],
  ['desert', 690, 60, 230, 1.2],
  ['desert', 450, 400, 220, 1.15],
  ['coast', 25, 345, 285, 1.45],
  ['coast', -120, 425, 230, 1.2],
  ['coast', 195, 455, 225, 1.2],
  ['wetland', -295, 195, 245, 1.4],
  ['wetland', -445, 85, 195, 1.1],
  ['jungle', -470, 400, 290, 1.55],
  ['jungle', -650, 230, 240, 1.25],
  ['jungle', -330, 570, 220, 1.15],
];

const REGION_ANCHORS = ANCHOR_SPECS.map(([id, x, z, radius, strength]) => ({
  idx: BIOME_INDEX[id],
  x,
  z,
  radius,
  strength,
}));

const _acc = new Float64Array(10);

/** Sample smooth biome blend weights at world coordinates (x, z) */
export function sampleBiomeWeights(x: number, z: number): BiomeWeights {
  const wx = x + fbm2(x * 0.0032, z * 0.0032, 3) * 68;
  const wz = z + fbm2(x * 0.0032 + 19.4, z * 0.0032 - 11.8, 3) * 68;

  _acc.fill(0.001);
  for (let i = 0; i < REGION_ANCHORS.length; i++) {
    const a = REGION_ANCHORS[i];
    const dx = (wx - a.x) / a.radius;
    const dz = (wz - a.z) / a.radius;
    const d2 = dx * dx + dz * dz;
    if (d2 < 3.8) {
      _acc[a.idx] += Math.exp(-d2 * 1.55) * a.strength;
    }
  }

  // Far-lands climate continuation so the planet keeps going beyond the charted continent
  const dist = Math.hypot(wx, wz);
  const farBlend = smoothstep(820, 1150, dist);
  if (farBlend > 0.001) {
    const temp = fbm2(wx * 0.0014 + 3.1, wz * 0.0014 - 7.4, 3);
    const moist = fbm2(wx * 0.0015 - 12.6, wz * 0.0015 + 5.9, 3);
    const k = farBlend * 0.85;
    _acc[2] += k * smoothstep(-0.1, -0.55, temp);
    _acc[3] += k * smoothstep(0.15, 0.55, temp) * smoothstep(0.1, -0.4, moist) * 0.6;
    _acc[9] += k * smoothstep(0.25, 0.6, temp) * smoothstep(-0.15, -0.55, moist) * 0.6;
    _acc[7] += k * smoothstep(0.15, 0.55, temp) * smoothstep(0.1, 0.5, moist);
    _acc[4] += k * smoothstep(0.0, 0.4, temp) * smoothstep(-0.1, 0.3, moist) * 0.5;
    _acc[1] += k * Math.max(0, 1 - Math.abs(temp + 0.15)) * smoothstep(0.0, 0.45, moist);
    _acc[5] += k * Math.max(0, 1 - Math.abs(temp - 0.05)) * smoothstep(0.15, -0.35, moist) * 0.7;
    _acc[8] += k * Math.max(0, 0.7 - Math.abs(temp - 0.1)) * smoothstep(0.1, -0.3, moist);
    _acc[6] += k * smoothstep(0.25, 0.65, moist) * smoothstep(-0.1, 0.35, temp) * 0.6;
    _acc[0] += k * Math.max(0, 0.5 - Math.abs(temp) - Math.abs(moist) * 0.5);
  }

  let sum = 0;
  for (let i = 0; i < 10; i++) {
    const v = Math.pow(_acc[i], 1.45);
    _acc[i] = v;
    sum += v;
  }
  const inv = 1 / sum;
  let maxI = 0;
  let maxV = -1;
  for (let i = 0; i < 10; i++) {
    _acc[i] *= inv;
    if (_acc[i] > maxV) {
      maxV = _acc[i];
      maxI = i;
    }
  }

  return {
    meadow: _acc[0],
    forest: _acc[1],
    alpine: _acc[2],
    desert: _acc[3],
    coast: _acc[4],
    autumn: _acc[5],
    wetland: _acc[6],
    jungle: _acc[7],
    plains: _acc[8],
    wasteland: _acc[9],
    dominant: BIOME_ORDER[maxI],
  };
}

/** Winding river from the Cryo Spires through Lumen Vale into the Glass Shoals */
export function sampleRiverFactor(x: number, z: number): number {
  const zMask = smoothstep(-370, -240, z) * smoothstep(320, 210, z);
  if (zMask <= 0.001) return 0;
  const riverCenterX =
    -28 +
    Math.sin(z * 0.0135 + 0.6) * 52 +
    Math.cos(z * 0.0065) * 28 +
    simplex2(z * 0.008, 4.2) * 22;
  const halfWidth = lerp(9.5, 22.0, smoothstep(-260, 250, z));
  const dist = Math.abs(x - riverCenterX);
  const bank = 1.0 - smoothstep(halfWidth * 0.45, halfWidth * 1.9, dist);
  return bank * zMask;
}

/** Worn explorer path factor [0, 1] */
export function sampleTrailFactor(x: number, z: number): number {
  let best = 0;
  if (z > -320 && z < 260 && x > -140 && x < 260) {
    const trailX = 16 + Math.sin((z - 18) * 0.015) * 34 + (z < -40 ? (-40 - z) * 0.08 : 0);
    const d = Math.abs(x - trailX);
    if (d < 4.5) best = Math.max(best, 1.0 - smoothstep(1.2, 3.6, d));
  }
  if (x > -290 && x < 350 && z > -140 && z < 160) {
    const trailZ = 22 + Math.sin(x * 0.013) * 32 + (x > 100 ? (x - 100) * 0.24 : -x * 0.22);
    const d = Math.abs(z - trailZ);
    if (d < 4.5) best = Math.max(best, 1.0 - smoothstep(1.1, 3.4, d));
  }
  return best;
}

function sampleDesertOasis(x: number, z: number): number {
  const dx = x - OASIS_X;
  const dz = z - OASIS_Z;
  const d = Math.hypot(dx + simplex2(x * 0.04, z * 0.04) * 6, dz);
  return 1.0 - smoothstep(14, 42, d);
}

interface TerrainPad {
  x: number;
  z: number;
  r0: number;
  r1: number;
  target: number | null;
  k: number;
  raise: boolean;
  resolved: number | null;
}

const TERRAIN_PADS: TerrainPad[] = [
  { x: 0, z: 18, r0: 10, r1: 42, target: 11.2, k: 0.65, raise: false, resolved: null },
  { x: 28, z: 285, r0: 10, r1: 36, target: 2.8, k: 0.72, raise: false, resolved: null },
  { x: -275, z: 195, r0: 7, r1: 24, target: 1.85, k: 0.85, raise: true, resolved: null },
  { x: OASIS_VIEW_X, z: OASIS_VIEW_Z, r0: 6, r1: 22, target: 3.4, k: 0.75, raise: false, resolved: null },
  { x: JUNGLE_VIEW_X, z: JUNGLE_VIEW_Z, r0: 6, r1: 20, target: null, k: 0.7, raise: false, resolved: null },
  { x: PLAINS_VIEW_X, z: PLAINS_VIEW_Z, r0: 6, r1: 20, target: null, k: 0.7, raise: false, resolved: null },
  { x: WASTE_VIEW_X, z: WASTE_VIEW_Z, r0: 6, r1: 20, target: null, k: 0.7, raise: false, resolved: null },
  { x: 275, z: -215, r0: 6, r1: 20, target: null, k: 0.75, raise: false, resolved: null },
];

function applyTerrainPads(x: number, z: number, hIn: number): number {
  let h = hIn;
  for (let i = 0; i < TERRAIN_PADS.length; i++) {
    const p = TERRAIN_PADS[i];
    const dx = x - p.x;
    const dz = z - p.z;
    const d2 = dx * dx + dz * dz;
    if (d2 >= p.r1 * p.r1) continue;
    if (p.resolved === null) {
      p.resolved =
        p.target !== null ? p.target : terrainCore(p.x, p.z, sampleBiomeWeights(p.x, p.z), false);
    }
    const f = (1.0 - smoothstep(p.r0, p.r1, Math.sqrt(d2))) * p.k;
    h = p.raise ? lerp(h, Math.max(h, p.resolved), f) : lerp(h, p.resolved, f);
  }
  return h;
}

function terrainCore(x: number, z: number, w: BiomeWeights, applyPads: boolean): number {
  let h = 0;

  if (w.meadow > 0.002) {
    const roll = warpedFbm2(x * 0.0065, z * 0.0065, 0.45, 4) * 14.5;
    const micro = fbm2(x * 0.028, z * 0.028, 2) * 1.4;
    h += (9.5 + roll + micro) * w.meadow;
  }

  if (w.forest > 0.002) {
    const hills = warpedFbm2(x * 0.0058 + 7.1, z * 0.0058 - 3.2, 0.5, 4) * 24.0;
    const ridge = ridged2(x * 0.008, z * 0.008, 3) * 12.0;
    const detail = fbm2(x * 0.032, z * 0.032, 2) * 1.8;
    h += (14.0 + hills + ridge + detail) * w.forest;
  }

  if (w.alpine > 0.002) {
    const macroRidge = ridged2(x * 0.0048 + 2.3, z * 0.0048 - 1.7, 5);
    const secondary = ridged2(x * 0.012 - 5.1, z * 0.012 + 8.4, 3);
    const crag = fbm2(x * 0.035, z * 0.035, 2) * 3.2;
    const rangeLift = smoothstep(-290, -560, z) * 42.0;
    const peakPower = Math.pow(macroRidge, 1.18) * 128.0 + secondary * 32.0 + rangeLift;
    const passDist = Math.hypot((x + 35) * 0.95, (z + 395) * 0.9);
    const passCarve = (1.0 - smoothstep(16, 62, passDist)) * 0.55;
    h += (24.0 + peakPower * (1.0 - passCarve) + crag) * w.alpine;
  }

  if (w.autumn > 0.002) {
    const raw = warpedFbm2(x * 0.0056 - 4.2, z * 0.0056 + 6.7, 0.5, 4);
    const ridge = ridged2(x * 0.0075 + 9.1, z * 0.0075, 3);
    const combined = 18.0 + raw * 22.0 + ridge * 24.0;
    const terraced = combined + Math.sin(combined * 0.48) * 1.15;
    h += (terraced + fbm2(x * 0.03, z * 0.03, 2) * 1.5) * w.autumn;
  }

  if (w.desert > 0.002) {
    const du = x * 0.014 + z * 0.008 + simplex2(x * 0.006, z * 0.006) * 1.4;
    const dv = -x * 0.006 + z * 0.012;
    const duneWave = 1.0 - Math.abs(simplex2(du, dv));
    const dunes = Math.pow(duneWave, 1.5) * 13.5 + fbm2(x * 0.005, z * 0.005, 3) * 8.0;
    const mesaField = fbm2(x * 0.0072 + 14.3, z * 0.0072 - 9.2, 3);
    const mesaMask = smoothstep(0.08, 0.22, mesaField);
    const upperCap = smoothstep(0.28, 0.36, mesaField);
    const oasisClear = smoothstep(40, 95, Math.hypot(x - OASIS_X, z - OASIS_Z));
    const mesaHeight = (mesaMask * 32.0 + upperCap * 18.0) * oasisClear;
    const oasis = sampleDesertOasis(x, z);
    h += lerp(6.5 + dunes + mesaHeight, -2.4, oasis) * w.desert;
  }

  if (w.coast > 0.002) {
    const bayCurve = Math.sin(x * 0.014) * 18.0 + fbm2(x * 0.007, z * 0.007, 3) * 26.0;
    const shoreDist = z - (296.0 + bayCurve);
    const baseSlope = clamp(-shoreDist * 0.095, -15.0, 11.0);
    const islandNoise = fbm2(x * 0.0125 - 3.7, z * 0.0125 + 11.2, 4);
    const islandLift = smoothstep(0.14, 0.42, islandNoise) * 19.5 * smoothstep(25, 65, shoreDist);
    const stackNoise = ridged2(x * 0.018 + 4.4, z * 0.018 - 2.1, 3);
    const stackLift = smoothstep(0.58, 0.78, stackNoise) * smoothstep(35, 85, shoreDist) * 28.0;
    h += (baseSlope + islandLift + stackLift) * w.coast;
  }

  if (w.wetland > 0.002) {
    const channels = warpedFbm2(x * 0.016 + 8.8, z * 0.016 - 6.3, 0.85, 4);
    const micro = fbm2(x * 0.045, z * 0.045, 2) * 0.65;
    h += (0.12 + channels * 6.4 + micro) * w.wetland;
  }

  // Verdigris Tangle: steaming hills, sheer karst towers & winding jungle rivers
  if (w.jungle > 0.002) {
    const hills = warpedFbm2(x * 0.0062 - 9.4, z * 0.0062 + 4.6, 0.6, 4) * 12.5;
    const chanAbs = Math.abs(simplex2(x * 0.0031 + 7.7, z * 0.0031 - 3.1));
    const channel = 1.0 - smoothstep(0.018, 0.07, chanAbs);
    const keepClear = smoothstep(0.05, 0.16, chanAbs);
    const karstN = fbm2(x * 0.0105 + 41.3, z * 0.0105 - 27.7, 3);
    const karst =
      smoothstep(0.3, 0.41, karstN) * (22.0 + fbm2(x * 0.03, z * 0.03, 2) * 6.0) * keepClear;
    const detail = fbm2(x * 0.034, z * 0.034, 2) * 1.4;
    const base = 6.0 + hills + karst + detail;
    h += lerp(base, -2.5, channel) * w.jungle;
  }

  // Driftgrass Steppes: endless gentle swells, rocky kopjes & shallow pools
  if (w.plains > 0.002) {
    const swell = warpedFbm2(x * 0.0042 + 3.3, z * 0.0042 - 8.1, 0.4, 3) * 7.0;
    const micro = fbm2(x * 0.021, z * 0.021, 2) * 0.8;
    const kop = smoothstep(0.36, 0.6, fbm2(x * 0.0115 + 21.7, z * 0.0115 - 13.4, 3)) * 9.5;
    const hollow = smoothstep(0.4, 0.62, fbm2(x * 0.0092 - 31.2, z * 0.0092 + 17.9, 2)) * 12.0;
    h += (9.5 + swell + micro + kop - hollow) * w.plains;
  }

  // Ashen Rift: obsidian badlands, ash dunes & deep jagged rift canyons
  if (w.wasteland > 0.002) {
    const basin = warpedFbm2(x * 0.0052 + 13.1, z * 0.0052 - 21.4, 0.5, 3) * 6.0;
    const ashDune =
      Math.pow(1.0 - Math.abs(simplex2(x * 0.0125 + z * 0.0042, -x * 0.0041 + z * 0.0112)), 2.0) *
      3.0;
    const badN = fbm2(x * 0.0086 - 17.3, z * 0.0086 + 9.6, 3);
    const badlands = smoothstep(0.12, 0.3, badN) * 17.0 + smoothstep(0.34, 0.44, badN) * 9.0;
    let hw = 7.5 + basin + ashDune + badlands;
    hw += Math.sin(hw * 0.95) * 0.65 * smoothstep(9.0, 18.0, hw);
    const rift = smoothstep(0.86, 0.965, ridged2(x * 0.0042 + 6.6, z * 0.0042 - 2.9, 2));
    hw = lerp(hw, 1.2, rift);
    hw += fbm2(x * 0.038, z * 0.038, 2) * 0.9;
    h += hw * w.wasteland;
  }

  const river = sampleRiverFactor(x, z);
  if (river > 0.001) {
    const targetBed = lerp(-2.6, -2.9, smoothstep(-180, 220, z));
    h = lerp(h, Math.min(h, targetBed), smoothstep(0.0, 0.88, river));
  }

  if (applyPads) h = applyTerrainPads(x, z, h);
  return h;
}

export function getTerrainHeightWithWeights(x: number, z: number, w: BiomeWeights): number {
  return terrainCore(x, z, w, true);
}

export function getTerrainHeight(x: number, z: number): number {
  return terrainCore(x, z, sampleBiomeWeights(x, z), true);
}

function vertexHeight(ix: number, iz: number, cell: number): number {
  if (cell !== activeTerrainCellSize) return getTerrainHeight(ix * cell, iz * cell);
  const key = (ix + 8192) * 16384 + (iz + 8192);
  const cached = vertexHeightCache.get(key);
  if (cached !== undefined) return cached;
  const h = getTerrainHeight(ix * cell, iz * cell);
  if (vertexHeightCache.size > 60000) vertexHeightCache.clear();
  vertexHeightCache.set(key, h);
  return h;
}

/**
 * Exact height (and optional unit normal) of the rendered terrain triangle at (x, z).
 * Matches Three.js PlaneGeometry triangulation so nothing floats or sinks.
 */
export function sampleRenderedTerrain(
  x: number,
  z: number,
  outNormal: [number, number, number] | null,
  cellSize = activeTerrainCellSize
): number {
  const gx = x / cellSize;
  const gz = z / cellSize;
  const ix = Math.floor(gx);
  const iz = Math.floor(gz);
  const fx = gx - ix;
  const fz = gz - iz;
  const hB = vertexHeight(ix + 1, iz, cellSize);
  const hC = vertexHeight(ix, iz + 1, cellSize);
  let h: number;
  let dhdx: number;
  let dhdz: number;
  if (fx + fz <= 1.0) {
    const hA = vertexHeight(ix, iz, cellSize);
    h = hA + fx * (hB - hA) + fz * (hC - hA);
    dhdx = (hB - hA) / cellSize;
    dhdz = (hC - hA) / cellSize;
  } else {
    const hD = vertexHeight(ix + 1, iz + 1, cellSize);
    h = hD + (1.0 - fx) * (hC - hD) + (1.0 - fz) * (hB - hD);
    dhdx = (hD - hC) / cellSize;
    dhdz = (hD - hB) / cellSize;
  }
  if (outNormal) {
    const inv = 1.0 / Math.hypot(dhdx, 1.0, dhdz);
    outNormal[0] = -dhdx * inv;
    outNormal[1] = inv;
    outNormal[2] = -dhdz * inv;
  }
  return h;
}

export function getRenderedTerrainHeight(
  x: number,
  z: number,
  cellSize = activeTerrainCellSize
): number {
  return sampleRenderedTerrain(x, z, null, cellSize);
}

export function getRenderedTerrainNormal(
  x: number,
  z: number,
  cellSize = activeTerrainCellSize
): [number, number, number] {
  const out: [number, number, number] = [0, 1, 0];
  sampleRenderedTerrain(x, z, out, cellSize);
  return out;
}

/** Smooth analytical finite-difference surface normal */
export function getTerrainNormal(x: number, z: number, eps = 0.85): [number, number, number] {
  const hL = getTerrainHeight(x - eps, z);
  const hR = getTerrainHeight(x + eps, z);
  const hD = getTerrainHeight(x, z - eps);
  const hU = getTerrainHeight(x, z + eps);
  const nx = hL - hR;
  const ny = 2.0 * eps;
  const nz = hD - hU;
  const inv = 1.0 / Math.hypot(nx, ny, nz);
  return [nx * inv, ny * inv, nz * inv];
}

export type SurfaceMaterial = 'grass' | 'snow' | 'sand' | 'rock' | 'dirt' | 'water';

export function getSurfaceMaterial(
  x: number,
  z: number,
  height: number,
  slopeY: number
): SurfaceMaterial {
  if (height < WATER_LEVEL + 0.12) return 'water';
  if (slopeY < 0.68) return 'rock';
  const w = sampleBiomeWeights(x, z);
  if (w.alpine > 0.38 && height > 12) return 'snow';
  if (w.wasteland > 0.45) return 'dirt';
  if (w.desert > 0.4 || w.coast > 0.42 || height < WATER_LEVEL + 1.45) return 'sand';
  if (sampleTrailFactor(x, z) > 0.45) return 'dirt';
  return 'grass';
}

/** Alien ground albedo (sRGB) for terrain vertices & the world atlas */
export function computeTerrainColor(
  x: number,
  z: number,
  height: number,
  normalY: number,
  w: BiomeWeights,
  out: [number, number, number]
): void {
  const slope = 1.0 - clamp(normalY, 0, 1);
  const patch = fbm2(x * 0.045, z * 0.045, 3) * 0.5 + 0.5;
  const fine = simplex2(x * 0.16, z * 0.16) * 0.5 + 0.5;
  const hueN = fbm2(x * 0.011 + 5.3, z * 0.011 - 2.7, 2) * 0.5 + 0.5;

  let r = 0;
  let g = 0;
  let b = 0;

  // Lumen Vale: teal-cyan moss with drifting violet patches
  if (w.meadow > 0.001) {
    const vio = smoothstep(0.55, 0.8, hueN) * 0.6;
    r += lerp(lerp(0.1, 0.17, patch), 0.34, vio) * w.meadow;
    g += lerp(lerp(0.38, 0.5, patch), 0.22, vio) * w.meadow;
    b += lerp(lerp(0.4, 0.5, patch), 0.52, vio) * w.meadow;
  }

  // Spirecap Woods: indigo-violet fungal loam
  if (w.forest > 0.001) {
    r += lerp(0.18, 0.27, patch) * w.forest;
    g += lerp(0.13, 0.19, patch) * w.forest;
    b += lerp(0.3, 0.4, patch) * w.forest;
  }

  // Cryo Spires: lilac-blue snow & blue-black frost tundra
  if (w.alpine > 0.001) {
    const snowLine = 16.0 + patch * 7.0 - slope * 22.0;
    let snow = smoothstep(snowLine - 4.0, snowLine + 5.0, height) * smoothstep(0.5, 0.24, slope);
    snow = Math.max(snow, smoothstep(0.38, 0.72, w.alpine) * smoothstep(0.46, 0.22, slope) * 0.9);
    r += lerp(lerp(0.3, 0.38, patch), 0.84, snow) * w.alpine;
    g += lerp(lerp(0.34, 0.42, patch), 0.88, snow) * w.alpine;
    b += lerp(lerp(0.48, 0.56, patch), 0.99, snow) * w.alpine;
  }

  // Crimson Highlands: scarlet bloom moss
  if (w.autumn > 0.001) {
    r += lerp(0.5, 0.66, patch) * w.autumn;
    g += lerp(0.13, 0.21, patch) * w.autumn;
    b += lerp(0.16, 0.22, patch) * w.autumn;
  }

  // Rust Dunes: iron-red sand, crimson mesas, teal oasis moss
  if (w.desert > 0.001) {
    const oasisRim = smoothstep(38, 16, Math.hypot(x - OASIS_X, z - OASIS_Z)) * 0.85;
    const mesa = smoothstep(22, 34, height);
    let dR = lerp(lerp(0.78, 0.86, patch), 0.52, mesa);
    let dG = lerp(lerp(0.4, 0.48, patch), 0.16, mesa);
    let dB = lerp(lerp(0.2, 0.26, patch), 0.12, mesa);
    dR = lerp(dR, 0.12, oasisRim);
    dG = lerp(dG, 0.46, oasisRim);
    dB = lerp(dB, 0.44, oasisRim);
    r += dR * w.desert;
    g += dG * w.desert;
    b += dB * w.desert;
  }

  // Glass Shoals: pearl-lavender sand with teal turf inland
  if (w.coast > 0.001) {
    const inland = smoothstep(4.2, 8.8, height) * smoothstep(0.35, 0.12, slope);
    r += lerp(lerp(0.78, 0.86, patch), 0.14, inland) * w.coast;
    g += lerp(lerp(0.74, 0.8, patch), 0.42, inland) * w.coast;
    b += lerp(lerp(0.86, 0.94, patch), 0.44, inland) * w.coast;
  }

  // Glowmire: black-teal mud & luminous green moss
  if (w.wetland > 0.001) {
    const bank = smoothstep(1.8, 0.1, height);
    r += lerp(lerp(0.08, 0.14, patch), 0.1, bank) * w.wetland;
    g += lerp(lerp(0.26, 0.36, patch), 0.14, bank) * w.wetland;
    b += lerp(lerp(0.18, 0.24, patch), 0.14, bank) * w.wetland;
  }

  // Verdigris Tangle: emerald-turquoise undergrowth, magenta moss drifts, violet mud banks
  if (w.jungle > 0.001) {
    const mud = smoothstep(2.6, 0.4, height) * 0.85;
    const mag = smoothstep(0.6, 0.85, hueN) * 0.5;
    let jR = lerp(lerp(0.05, 0.11, patch), 0.34, mag);
    let jG = lerp(lerp(0.26, 0.36, patch), 0.12, mag);
    let jB = lerp(lerp(0.2, 0.27, patch), 0.3, mag);
    jR = lerp(jR, 0.22, mud);
    jG = lerp(jG, 0.14, mud);
    jB = lerp(jB, 0.24, mud);
    r += jR * w.jungle;
    g += jG * w.jungle;
    b += jB * w.jungle;
  }

  // Driftgrass Steppes: amber-coral prairie, teal around pools
  if (w.plains > 0.001) {
    const lush = smoothstep(5.0, 1.5, height) * 0.7;
    r += lerp(lerp(0.7, 0.8, patch), 0.2, lush) * w.plains;
    g += lerp(lerp(0.4, 0.49, patch), 0.42, lush) * w.plains;
    b += lerp(lerp(0.28, 0.33, patch), 0.36, lush) * w.plains;
  }

  // Ashen Rift: obsidian ash with bone-white salt crusts
  if (w.wasteland > 0.001) {
    const salt = smoothstep(9.5, 6.0, height) * smoothstep(0.3, 0.7, patch) * 0.8;
    r += lerp(lerp(0.14, 0.22, patch), 0.72, salt) * w.wasteland;
    g += lerp(lerp(0.13, 0.19, patch), 0.7, salt) * w.wasteland;
    b += lerp(lerp(0.15, 0.22, patch), 0.68, salt) * w.wasteland;
  }

  // Exposed alien bedrock on steep slopes
  const strata = Math.sin(height * 0.85 + patch * 3.0) * 0.05;
  const rockMask = smoothstep(0.16, 0.38, slope);
  if (rockMask > 0.001) {
    let rkR = 0.27 + strata;
    let rkG = 0.24 + strata;
    let rkB = 0.32 + strata * 0.8;
    if (w.desert > 0.05) {
      const rb = Math.sin(height * 1.15) * 0.07;
      rkR = lerp(rkR, 0.58 + rb, w.desert);
      rkG = lerp(rkG, 0.2 + rb * 0.5, w.desert);
      rkB = lerp(rkB, 0.16 + rb * 0.4, w.desert);
    }
    if (w.alpine > 0.05) {
      rkR = lerp(rkR, 0.18 + strata, w.alpine);
      rkG = lerp(rkG, 0.21 + strata, w.alpine);
      rkB = lerp(rkB, 0.32 + strata, w.alpine);
    }
    if (w.jungle > 0.05) {
      const moss = smoothstep(0.4, 0.75, patch);
      rkR = lerp(rkR, lerp(0.42, 0.1, moss), w.jungle);
      rkG = lerp(rkG, lerp(0.46, 0.34, moss), w.jungle);
      rkB = lerp(rkB, lerp(0.5, 0.28, moss), w.jungle);
    }
    if (w.wasteland > 0.05) {
      const band = Math.sin(height * 1.4 + patch * 2.0) * 0.5 + 0.5;
      rkR = lerp(rkR, lerp(0.08, 0.34, band), w.wasteland);
      rkG = lerp(rkG, lerp(0.07, 0.18, band), w.wasteland);
      rkB = lerp(rkB, lerp(0.1, 0.3, band), w.wasteland);
    }
    r = lerp(r, rkR, rockMask);
    g = lerp(g, rkG, rockMask);
    b = lerp(b, rkB, rockMask);
  }

  // Pale lilac dust trails
  if (height > WATER_LEVEL + 1.6 && slope < 0.24 && w.alpine < 0.45 && w.jungle < 0.4 && w.wasteland < 0.4) {
    const trail = sampleTrailFactor(x, z) * (1.0 - w.coast * 0.8) * (1.0 - w.wetland * 0.7);
    if (trail > 0.01) {
      r = lerp(r, lerp(0.56, 0.64, fine), trail * 0.8);
      g = lerp(g, lerp(0.5, 0.57, fine), trail * 0.8);
      b = lerp(b, lerp(0.6, 0.68, fine), trail * 0.8);
    }
  }

  // Pearl-lavender shorelines
  if (height < WATER_LEVEL + 2.2 && slope < 0.32 && w.wetland < 0.55 && w.alpine < 0.45 && w.wasteland < 0.4 && w.jungle < 0.55) {
    const beachBand = smoothstep(WATER_LEVEL + 2.1, WATER_LEVEL + 0.35, height) * 0.82;
    r = lerp(r, lerp(0.7, 0.82, w.coast), beachBand);
    g = lerp(g, lerp(0.64, 0.76, w.coast), beachBand);
    b = lerp(b, lerp(0.74, 0.9, w.coast), beachBand);
  }

  if (height < WATER_LEVEL + 0.55) {
    const wet = smoothstep(WATER_LEVEL + 0.55, WATER_LEVEL - 0.15, height);
    r *= lerp(1.0, 0.7, wet);
    g *= lerp(1.0, 0.72, wet);
    b *= lerp(1.0, 0.76, wet);
  }

  const grain = 0.94 + fine * 0.12;
  out[0] = clamp(r * grain, 0, 1);
  out[1] = clamp(g * grain, 0, 1);
  out[2] = clamp(b * grain, 0, 1);
}

/**
 * Bioluminescent ground glow (linear RGB * strength) + fissure-pattern weight in [3].
 * Lights up moss speckles, glowing veins and rift fissures at night.
 */
export function computeTerrainGlow(
  x: number,
  z: number,
  height: number,
  normalY: number,
  w: BiomeWeights,
  out: [number, number, number, number]
): void {
  const dry = smoothstep(-0.2, 0.6, height);
  const flat = smoothstep(0.55, 0.85, normalY);
  let r = 0;
  let g = 0;
  let b = 0;
  r += w.meadow * 0.11; g += w.meadow * 0.71; b += w.meadow * 0.75;
  r += w.forest * 0.39; g += w.forest * 0.2; b += w.forest * 0.7;
  r += w.jungle * 0.16; g += w.jungle * 0.8; b += w.jungle * 0.44;
  r += w.wetland * 0.35; g += w.wetland * 1.0; b += w.wetland * 0.35;
  r += w.plains * 0.3; g += w.plains * 0.17; b += w.plains * 0.06;
  r += w.autumn * 0.42; g += w.autumn * 0.09; b += w.autumn * 0.13;
  r += w.wasteland * 0.95; g += w.wasteland * 0.21; b += w.wasteland * 0.48;
  r += w.alpine * 0.11; g += w.alpine * 0.21; b += w.alpine * 0.28;
  r += w.desert * 0.18; g += w.desert * 0.08; b += w.desert * 0.02;
  r += w.coast * 0.18; g += w.coast * 0.24; b += w.coast * 0.4;
  // Gentle variation so glowing fields breathe across the landscape
  const vary = 0.65 + 0.35 * (fbm2(x * 0.02 + 9.1, z * 0.02 - 4.4, 2) * 0.5 + 0.5);
  const k = dry * (0.35 + 0.65 * flat) * vary;
  out[0] = r * k;
  out[1] = g * k;
  out[2] = b * k;
  out[3] = clamp(smoothstep(0.25, 0.65, w.wasteland) + smoothstep(0.4, 0.8, w.desert) * 0.3, 0, 1);
}
