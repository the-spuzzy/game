import * as THREE from 'three';
import { ABILITIES, AbilityId, TRAITS, TraitId } from './evolution';
import { clamp, lerp } from './noise';
import { createContactShadowTexture } from './textures';

export interface CharacterAnimInput {
  speed: number;
  maxSprintSpeed: number;
  grounded: boolean;
  verticalVel: number;
  swimming: boolean;
  wading: boolean;
  gliding?: boolean;
  landingImpact: number;
  nightFactor: number;
  slopePitch: number;
}

/**
 * 3rd-Person Spore-Style Xeno-Slime / Goo Organism.
 * Starts as a squishy, translucent bioluminescent Proto-Goo with a pulsing nucleus & eye-stalks,
 * and physically grows larger + sprouts 3D body parts for every evolved trait!
 */
export class ExplorerCharacter {
  public readonly root = new THREE.Group();
  private readonly bodyPivot = new THREE.Group();
  private readonly slimeDome: THREE.Mesh;
  private readonly slimeSkirt: THREE.Mesh;
  private readonly nucleusMesh: THREE.Mesh;
  private readonly organellesGroup = new THREE.Group();

  // Base eyes
  private readonly leftEyePivot = new THREE.Group();
  private readonly rightEyePivot = new THREE.Group();

  // Trait 3D attachment groups (visible when that trait is evolved!)
  private readonly mandiblesGroup = new THREE.Group();
  private readonly leftMandible = new THREE.Group();
  private readonly rightMandible = new THREE.Group();

  private readonly scythesGroup = new THREE.Group();
  private readonly leftScythe = new THREE.Group();
  private readonly rightScythe = new THREE.Group();

  private readonly dorsalSpinesGroup = new THREE.Group();
  private readonly crystalShellGroup = new THREE.Group();

  private readonly stiltLegsGroup = new THREE.Group();
  private readonly stiltLegs: THREE.Group[] = [];

  private readonly pincersGroup = new THREE.Group();
  private readonly leftPincer = new THREE.Group();
  private readonly rightPincer = new THREE.Group();

  private readonly tentaclesGroup = new THREE.Group();
  private readonly tentacles: THREE.Group[][] = [];

  private readonly plasmaGlandGroup = new THREE.Group();
  private readonly eyeStalksGroup = new THREE.Group();
  private readonly extraStalks: THREE.Group[] = [];

  private readonly wingsGroup = new THREE.Group();
  private readonly leftWing = new THREE.Group();
  private readonly rightWing = new THREE.Group();

  private readonly tailGroup = new THREE.Group();
  private readonly tailSegments: THREE.Group[] = [];

  // New ability-trait 3D mutation rigs
  private readonly dashPodsGroup = new THREE.Group();
  private readonly slamPlatesGroup = new THREE.Group();
  private readonly sporePodsGroup = new THREE.Group();
  private readonly lanceHornGroup = new THREE.Group();
  private readonly veilFrillsGroup = new THREE.Group();
  private readonly regenMossGroup = new THREE.Group();
  private readonly senseCrownGroup = new THREE.Group();
  private readonly lanternPods: THREE.Mesh[] = [];

  // Combat & Evolution visual rings
  private readonly attackWaveMesh: THREE.Mesh;
  private readonly attackWaveMat: THREE.MeshBasicMaterial;
  private readonly evoAuraMesh: THREE.Mesh;
  private readonly evoAuraMat: THREE.MeshBasicMaterial;
  private readonly lanceBeamMesh: THREE.Mesh;
  private readonly lanceBeamMat: THREE.MeshBasicMaterial;

  // Materials that shift hue as the slime evolves
  private readonly outerGooMat: THREE.MeshStandardMaterial;
  private readonly innerCoreMat: THREE.MeshStandardMaterial;
  private readonly chitinMat: THREE.MeshStandardMaterial;
  private readonly crystalMat: THREE.MeshStandardMaterial;
  private readonly wingMat: THREE.MeshStandardMaterial;
  private readonly bioLight: THREE.PointLight;
  private readonly contactShadow: THREE.Mesh;
  private readonly contactShadowMat: THREE.MeshBasicMaterial;

  // Stage-specific xeno-anatomy groups (added on top of per-trait mutations)
  private readonly stageGroups: THREE.Group[] = [];
  private readonly stageSatellites: THREE.Mesh[] = [];
  private readonly stageRings: THREE.Mesh[] = [];
  private visualStage = 1;
  private evolutionStage = 1;
  private ascended = false;
  private readonly ascendedFormGroup = new THREE.Group();
  private readonly ascendedLegs: THREE.Group[] = [];
  private readonly ascendedArms: THREE.Group[] = [];
  private readonly ascendedHead = new THREE.Group();
  private readonly ascendedTail: THREE.Group[] = [];

  private stridePhase = 0;
  private lastFootSide = 0;
  private currentScale = 0.78;
  private targetScale = 0.78;
  private attackAnimTimer = 0;
  private spitAnimTimer = 0;
  private evoBurstTimer = 0;
  private dashAnimTimer = 0;
  private slamAnimTimer = 0;
  private lanceAnimTimer = 0;
  private cloaked = false;
  private activeTraits = new Set<TraitId>();

  constructor() {
    // Grounded ambient-occlusion contact shadow
    this.contactShadowMat = new THREE.MeshBasicMaterial({
      map: createContactShadowTexture(),
      transparent: true,
      opacity: 0.65,
      depthWrite: false,
      polygonOffset: true,
      polygonOffsetFactor: -1,
    });
    this.contactShadow = new THREE.Mesh(
      new THREE.PlaneGeometry(1.75, 1.75),
      this.contactShadowMat
    );
    this.contactShadow.rotation.x = -Math.PI / 2;
    this.contactShadow.position.set(0, 0.025, 0);
    this.contactShadow.renderOrder = 1;
    this.root.add(this.contactShadow);

    // Translucent, glossy Xeno-Goo outer membrane with glowing rim
    this.outerGooMat = new THREE.MeshStandardMaterial({
      color: new THREE.Color('#2dd4bf'),
      emissive: new THREE.Color('#0d9488'),
      emissiveIntensity: 0.38,
      roughness: 0.18,
      metalness: 0.05,
      transparent: true,
      opacity: 0.82,
    });

    // Radiant inner nucleus & bioluminescent organs
    this.innerCoreMat = new THREE.MeshStandardMaterial({
      color: new THREE.Color('#99f6e4'),
      emissive: new THREE.Color('#2dd4bf'),
      emissiveIntensity: 1.65,
      roughness: 0.22,
    });

    // Chitinous claws, mandibles, legs & spines
    this.chitinMat = new THREE.MeshStandardMaterial({
      color: new THREE.Color('#312e81'),
      emissive: new THREE.Color('#4338ca'),
      emissiveIntensity: 0.25,
      roughness: 0.35,
      metalness: 0.22,
    });

    // Faceted crystal shell & glowing spikes
    this.crystalMat = new THREE.MeshStandardMaterial({
      color: new THREE.Color('#e879f9'),
      emissive: new THREE.Color('#c026d3'),
      emissiveIntensity: 1.15,
      roughness: 0.14,
      metalness: 0.3,
      flatShading: true,
    });

    // Bioluminescent wing & fin membrane
    this.wingMat = new THREE.MeshStandardMaterial({
      color: new THREE.Color('#34d399'),
      emissive: new THREE.Color('#10b981'),
      emissiveIntensity: 0.75,
      roughness: 0.28,
      transparent: true,
      opacity: 0.88,
      side: THREE.DoubleSide,
    });

    const eyeWhiteMat = new THREE.MeshStandardMaterial({
      color: 0xfef9c3,
      emissive: new THREE.Color(0xfef08a),
      emissiveIntensity: 0.35,
      roughness: 0.15,
    });
    const pupilMat = new THREE.MeshStandardMaterial({
      color: 0x090d16,
      roughness: 0.1,
    });

    this.bodyPivot.position.set(0, 0.56, 0);
    this.root.add(this.bodyPivot);

    // 1. Squishy Outer Goo Dome + rippled lower skirt
    const domeGeo = new THREE.SphereGeometry(0.68, 24, 18);
    domeGeo.scale(1.06, 0.88, 1.18);
    this.slimeDome = new THREE.Mesh(domeGeo, this.outerGooMat);
    this.slimeDome.castShadow = true;
    this.slimeDome.receiveShadow = true;
    this.bodyPivot.add(this.slimeDome);

    const skirtGeo = new THREE.CylinderGeometry(0.62, 0.78, 0.32, 20, 1);
    skirtGeo.scale(1.04, 1.0, 1.14);
    this.slimeSkirt = new THREE.Mesh(skirtGeo, this.outerGooMat);
    this.slimeSkirt.position.set(0, -0.34, 0.02);
    this.slimeSkirt.castShadow = true;
    this.bodyPivot.add(this.slimeSkirt);

    // 2. Glowing Inner Nucleus + Floating DNA Organelles
    this.nucleusMesh = new THREE.Mesh(
      new THREE.IcosahedronGeometry(0.28, 2),
      this.innerCoreMat
    );
    this.nucleusMesh.position.set(0, 0.02, 0);
    this.bodyPivot.add(this.nucleusMesh);

    this.bodyPivot.add(this.organellesGroup);
    for (let i = 0; i < 6; i++) {
      const a = (i / 6) * Math.PI * 2;
      const orb = new THREE.Mesh(new THREE.SphereGeometry(0.065, 8, 6), this.innerCoreMat);
      orb.position.set(Math.cos(a) * 0.36, (i % 2 === 0 ? 1 : -1) * 0.1, Math.sin(a) * 0.38);
      this.organellesGroup.add(orb);
    }

    // Bioluminescent point light so your alien slime illuminates the ground at dusk/night!
    this.bioLight = new THREE.PointLight(0x2dd4bf, 1.2, 14, 1.6);
    this.bioLight.position.set(0, 0.45, 0);
    this.bodyPivot.add(this.bioLight);

    // 3. Expressive Alien Eyes (facing -Z forward)
    const buildEye = (pivot: THREE.Group, side: -1 | 1) => {
      pivot.position.set(side * 0.25, 0.36, -0.46);
      const stalk = new THREE.Mesh(
        new THREE.CylinderGeometry(0.055, 0.08, 0.24, 8),
        this.outerGooMat
      );
      stalk.position.set(0, 0.1, -0.04);
      stalk.rotation.x = 0.35;
      pivot.add(stalk);

      const eyeball = new THREE.Mesh(new THREE.SphereGeometry(0.125, 12, 10), eyeWhiteMat);
      eyeball.position.set(0, 0.22, -0.1);
      pivot.add(eyeball);

      const pupil = new THREE.Mesh(new THREE.SphereGeometry(0.068, 10, 8), pupilMat);
      pupil.scale.set(0.85, 1.15, 0.6);
      pupil.position.set(0, 0.22, -0.2);
      pivot.add(pupil);
      this.bodyPivot.add(pivot);
    };
    buildEye(this.leftEyePivot, -1);
    buildEye(this.rightEyePivot, 1);

    // ─────────────── BUILD ALL 11 VISUAL TRAIT MUTATION RIGS ───────────────
    this.buildMandibles();
    this.buildScytheClaws();
    this.buildDorsalSpines();
    this.buildCrystalShell();
    this.buildStiltLegs();
    this.buildCrusherPincers();
    this.buildShockTentacles();
    this.buildPlasmaGland();
    this.buildEyeStalks(eyeWhiteMat, pupilMat);
    this.buildGlideWings();
    this.buildTailFluke();
    this.buildAbilityTraitVisuals();
    this.buildAscendedForm();

    // Attack shockwave ring
    const waveGeo = new THREE.RingGeometry(0.45, 0.85, 28);
    waveGeo.rotateX(-Math.PI / 2);
    this.attackWaveMat = new THREE.MeshBasicMaterial({
      color: 0x5eead4,
      transparent: true,
      opacity: 0,
      side: THREE.DoubleSide,
      depthWrite: false,
    });
    this.attackWaveMesh = new THREE.Mesh(waveGeo, this.attackWaveMat);
    this.attackWaveMesh.position.set(0, 0.18, -0.45);
    this.attackWaveMesh.visible = false;
    this.root.add(this.attackWaveMesh);

    // Evolution DNA Burst Sphere
    this.evoAuraMat = new THREE.MeshBasicMaterial({
      color: 0x38bdf8,
      transparent: true,
      opacity: 0,
      wireframe: true,
      depthWrite: false,
    });
    this.evoAuraMesh = new THREE.Mesh(new THREE.IcosahedronGeometry(1.15, 2), this.evoAuraMat);
    this.evoAuraMesh.position.set(0, 0.65, 0);
    this.evoAuraMesh.visible = false;
    this.root.add(this.evoAuraMesh);

    // Void Lance energy beam (shown briefly when the lance ability fires)
    const lanceGeo = new THREE.CylinderGeometry(0.055, 0.16, 9.5, 8, 1, true);
    lanceGeo.rotateX(Math.PI / 2);
    this.lanceBeamMat = new THREE.MeshBasicMaterial({
      color: 0xfb7185,
      transparent: true,
      opacity: 0,
      side: THREE.DoubleSide,
      depthWrite: false,
      blending: THREE.AdditiveBlending,
    });
    this.lanceBeamMesh = new THREE.Mesh(lanceGeo, this.lanceBeamMat);
    this.lanceBeamMesh.position.set(0, 0.62, -5.0);
    this.lanceBeamMesh.visible = false;
    this.root.add(this.lanceBeamMesh);

    this.buildStageVisuals();
    this.applyStageVisuals();
    this.syncTraitVisibility();
  }


  /** At Stage 6+ the slime membrane is shed entirely for a full xeno-beast body. */
  private buildAscendedForm(): void {
    this.bodyPivot.add(this.ascendedFormGroup);

    const torso = new THREE.Mesh(new THREE.SphereGeometry(0.58, 18, 14), this.chitinMat);
    torso.scale.set(1.0, 0.82, 1.28);
    torso.position.set(0, 0.14, 0);
    torso.castShadow = true;
    this.ascendedFormGroup.add(torso);

    const chestCore = new THREE.Mesh(new THREE.IcosahedronGeometry(0.24, 2), this.innerCoreMat);
    chestCore.position.set(0, 0.2, -0.58);
    this.ascendedFormGroup.add(chestCore);

    const neck = new THREE.Mesh(new THREE.CylinderGeometry(0.16, 0.24, 0.34, 8), this.chitinMat);
    neck.rotation.x = -0.65;
    neck.position.set(0, 0.42, -0.56);
    this.ascendedFormGroup.add(neck);

    const head = new THREE.Mesh(new THREE.SphereGeometry(0.34, 14, 10), this.chitinMat);
    head.scale.set(1.05, 0.86, 1.18);
    head.position.set(0, 0.04, -0.32);
    this.ascendedHead.add(head);
    const jaw = new THREE.Mesh(new THREE.BoxGeometry(0.34, 0.12, 0.32), this.crystalMat);
    jaw.position.set(0, -0.18, -0.5);
    this.ascendedHead.add(jaw);
    for (const side of [-1, 1]) {
      const eye = new THREE.Mesh(new THREE.SphereGeometry(0.075, 8, 6), this.innerCoreMat);
      eye.position.set(side * 0.16, 0.08, -0.6);
      this.ascendedHead.add(eye);
      const horn = new THREE.Mesh(new THREE.ConeGeometry(0.075, 0.42, 6), this.crystalMat);
      horn.position.set(side * 0.22, 0.3, -0.16);
      horn.rotation.z = -side * 0.38;
      horn.rotation.x = -0.3;
      this.ascendedHead.add(horn);
    }
    this.ascendedHead.position.set(0, 0.62, -0.64);
    this.ascendedFormGroup.add(this.ascendedHead);

    for (let i = 0; i < 4; i++) {
      const side = i % 2 === 0 ? -1 : 1;
      const front = i < 2 ? -1 : 1;
      const leg = new THREE.Group();
      leg.position.set(side * 0.36, -0.12, front * 0.42);
      const upper = new THREE.Mesh(new THREE.CylinderGeometry(0.09, 0.13, 0.48, 7), this.chitinMat);
      upper.position.set(side * 0.08, -0.2, 0);
      upper.rotation.z = -side * 0.24;
      leg.add(upper);
      const foot = new THREE.Mesh(new THREE.ConeGeometry(0.12, 0.32, 6), this.crystalMat);
      foot.rotation.x = Math.PI;
      foot.position.set(side * 0.12, -0.5, -0.08);
      leg.add(foot);
      this.ascendedLegs.push(leg);
      this.ascendedFormGroup.add(leg);
    }

    for (const side of [-1, 1]) {
      const arm = new THREE.Group();
      arm.position.set(side * 0.52, 0.28, -0.18);
      const upper = new THREE.Mesh(new THREE.CylinderGeometry(0.07, 0.1, 0.44, 7), this.chitinMat);
      upper.position.set(side * 0.1, -0.2, 0);
      upper.rotation.z = -side * 0.35;
      arm.add(upper);
      const claw = new THREE.Mesh(new THREE.ConeGeometry(0.1, 0.3, 6), this.crystalMat);
      claw.rotation.x = Math.PI;
      claw.position.set(side * 0.18, -0.46, -0.04);
      arm.add(claw);
      this.ascendedArms.push(arm);
      this.ascendedFormGroup.add(arm);
    }

    let parent: THREE.Object3D = this.ascendedFormGroup;
    for (let i = 0; i < 4; i++) {
      const seg = new THREE.Group();
      seg.position.set(0, 0.12, 0.55 + i * 0.26);
      const body = new THREE.Mesh(
        new THREE.CylinderGeometry(0.1 - i * 0.018, 0.13 - i * 0.018, 0.3, 7),
        this.chitinMat
      );
      body.rotation.x = Math.PI / 2;
      body.position.set(0, 0, 0.15);
      seg.add(body);
      if (i === 3) {
        const fin = new THREE.Mesh(new THREE.ConeGeometry(0.2, 0.42, 4), this.wingMat);
        fin.scale.set(1.3, 1, 0.25);
        fin.rotation.x = Math.PI / 2;
        fin.position.set(0, 0, 0.42);
        seg.add(fin);
      }
      parent.add(seg);
      this.ascendedTail.push(seg);
      parent = seg;
    }
  }

  /** Add cumulative body-armor & biomass structures that visibly mark each evolution stage */
  private buildStageVisuals(): void {
    for (let s = 0; s < 6; s++) {
      const g = new THREE.Group();
      this.bodyPivot.add(g);
      this.stageGroups.push(g);
    }

    // Stage 2: pulsing membrane nodules & luminous skin ridges
    for (let i = 0; i < 14; i++) {
      const a = (i / 14) * Math.PI * 2;
      const y = 0.16 + (i % 3) * 0.17;
      const rr = 0.66 - Math.abs(y - 0.32) * 0.22;
      const nodule = new THREE.Mesh(
        new THREE.SphereGeometry(0.06 + (i % 2) * 0.025, 8, 6),
        i % 3 === 0 ? this.innerCoreMat : this.outerGooMat
      );
      nodule.position.set(Math.cos(a) * rr, y, Math.sin(a) * rr * 1.12);
      this.stageGroups[1].add(nodule);
    }

    // Stage 3: faceted mineral-carapace plates locked over the slime dome
    for (let i = 0; i < 12; i++) {
      const a = (i / 12) * Math.PI * 2;
      const y = 0.36 + (i % 2) * 0.15;
      const plate = new THREE.Mesh(new THREE.DodecahedronGeometry(0.12, 0), this.crystalMat);
      plate.scale.set(1.15, 0.35, 1.4);
      plate.position.set(Math.cos(a) * 0.58, y, Math.sin(a) * 0.66);
      plate.rotation.y = -a + Math.PI / 2;
      this.stageGroups[2].add(plate);
    }

    // Stage 4: nutrient sacs, double dorsal crests & heavy brow ridges
    for (let i = 0; i < 6; i++) {
      const a = (i / 6) * Math.PI * 2;
      const sac = new THREE.Mesh(new THREE.SphereGeometry(0.13, 10, 8), this.innerCoreMat);
      sac.scale.set(1.0, 0.75, 1.4);
      sac.position.set(Math.cos(a) * 0.62, -0.16, Math.sin(a) * 0.72);
      this.stageGroups[3].add(sac);
    }
    for (const side of [-1, 1]) {
      const crest = new THREE.Mesh(new THREE.ConeGeometry(0.13, 0.55, 6), this.chitinMat);
      crest.rotation.z = side * 0.48;
      crest.rotation.x = -0.35;
      crest.position.set(side * 0.3, 0.72, -0.14);
      this.stageGroups[3].add(crest);
    }

    // Stage 5: six floating Leviathan biomass lobes + huge crystalline back-plates
    for (let i = 0; i < 6; i++) {
      const a = (i / 6) * Math.PI * 2;
      const lobe = new THREE.Mesh(new THREE.IcosahedronGeometry(0.18, 1), this.innerCoreMat);
      lobe.position.set(Math.cos(a) * 1.0, 0.45, Math.sin(a) * 1.05);
      this.stageSatellites.push(lobe);
      this.stageGroups[4].add(lobe);
    }
    for (let i = 0; i < 5; i++) {
      const spine = new THREE.Mesh(new THREE.ConeGeometry(0.13, 0.52, 5), this.crystalMat);
      spine.rotation.x = -0.5;
      spine.position.set(0, 0.66, -0.35 + i * 0.19);
      this.stageGroups[4].add(spine);
    }

    // Stage 6: Elder Behemoth throne-ring & towering crown of crystal spires
    const ringGeo = new THREE.TorusGeometry(0.92, 0.04, 6, 40);
    ringGeo.rotateX(Math.PI / 2);
    const crownRing = new THREE.Mesh(ringGeo, this.innerCoreMat);
    crownRing.position.set(0, 0.86, 0);
    this.stageRings.push(crownRing);
    this.stageGroups[5].add(crownRing);

    for (let i = 0; i < 8; i++) {
      const a = (i / 8) * Math.PI * 2;
      const spire = new THREE.Mesh(new THREE.ConeGeometry(0.08, 0.62, 5), this.crystalMat);
      spire.position.set(Math.cos(a) * 0.86, 1.04, Math.sin(a) * 0.94);
      spire.rotation.z = -Math.cos(a) * 0.35;
      spire.rotation.x = Math.sin(a) * 0.35;
      this.stageGroups[5].add(spire);
    }
  }

  private applyStageVisuals(): void {
    for (let i = 0; i < this.stageGroups.length; i++) {
      this.stageGroups[i].visible = i < this.visualStage && (!this.ascended || i >= 4);
    }
    // Stage 6+ sheds the blob membrane entirely.
    this.slimeDome.visible = !this.ascended;
    this.slimeSkirt.visible = !this.ascended;
    this.nucleusMesh.visible = !this.ascended;
    this.organellesGroup.visible = !this.ascended;
    this.ascendedFormGroup.visible = this.ascended;
    this.outerGooMat.opacity = Math.max(0.7, 0.86 - this.visualStage * 0.025);
    this.outerGooMat.roughness = Math.max(0.1, 0.24 - this.visualStage * 0.018);
  }

  private buildMandibles(): void {
    this.mandiblesGroup.position.set(0, -0.06, -0.68);
    this.bodyPivot.add(this.mandiblesGroup);

    for (const side of [-1, 1] as const) {
      const jaw = side === -1 ? this.leftMandible : this.rightMandible;
      jaw.position.set(side * 0.24, 0, 0);

      const base = new THREE.Mesh(new THREE.ConeGeometry(0.11, 0.48, 7), this.chitinMat);
      base.rotation.x = -Math.PI / 2 + 0.15;
      base.rotation.z = side * 0.42;
      base.position.set(side * 0.06, 0, -0.2);
      jaw.add(base);

      // Glowing inner fangs
      for (let t = 0; t < 3; t++) {
        const tooth = new THREE.Mesh(new THREE.ConeGeometry(0.038, 0.16, 5), this.crystalMat);
        tooth.rotation.z = -side * 1.35;
        tooth.position.set(side * 0.04, 0.02, -0.12 - t * 0.11);
        jaw.add(tooth);
      }
      this.mandiblesGroup.add(jaw);
    }
  }

  private buildScytheClaws(): void {
    this.scythesGroup.position.set(0, 0.08, -0.25);
    this.bodyPivot.add(this.scythesGroup);

    for (const side of [-1, 1] as const) {
      const arm = side === -1 ? this.leftScythe : this.rightScythe;
      arm.position.set(side * 0.62, 0, 0);

      const upper = new THREE.Mesh(
        new THREE.CylinderGeometry(0.065, 0.085, 0.48, 7),
        this.chitinMat
      );
      upper.rotation.z = -side * 0.75;
      upper.rotation.x = 0.55;
      upper.position.set(side * 0.16, 0.08, -0.15);
      arm.add(upper);

      const blade = new THREE.Mesh(new THREE.ConeGeometry(0.095, 0.68, 6), this.crystalMat);
      blade.scale.set(0.45, 1.0, 1.15);
      blade.rotation.x = -Math.PI * 0.62;
      blade.rotation.z = side * 0.35;
      blade.position.set(side * 0.26, 0.04, -0.52);
      arm.add(blade);

      this.scythesGroup.add(arm);
    }
  }

  private buildDorsalSpines(): void {
    this.bodyPivot.add(this.dorsalSpinesGroup);
    for (let i = 0; i < 5; i++) {
      const t = i / 4;
      const z = -0.28 + t * 0.85;
      const y = 0.52 - Math.abs(t - 0.35) * 0.26;
      const h = 0.46 - i * 0.05;
      const spine = new THREE.Mesh(new THREE.ConeGeometry(0.085, h, 6), this.crystalMat);
      spine.position.set(0, y + h * 0.35, z);
      spine.rotation.x = -0.38 - i * 0.08;
      this.dorsalSpinesGroup.add(spine);
    }
  }

  private buildCrystalShell(): void {
    this.bodyPivot.add(this.crystalShellGroup);
    const specs: ReadonlyArray<[number, number, number, number, number, number]> = [
      [0.24, 0.38, 0.48, -0.05, 0.42, -0.35],
      [-0.24, 0.38, 0.48, -0.05, -0.42, 0.35],
      [0.38, 0.24, 0.38, 0.28, 0.65, -0.55],
      [-0.38, 0.24, 0.38, 0.28, -0.65, 0.55],
      [0, 0.46, 0.42, 0.35, 0, 0],
      [0.22, 0.32, 0.34, 0.52, 0.3, -0.4],
      [-0.22, 0.32, 0.34, 0.52, -0.3, 0.4],
    ];
    for (const [x, y, h, z, ry, rz] of specs) {
      const shard = new THREE.Mesh(new THREE.CylinderGeometry(0.02, 0.13, h, 6), this.crystalMat);
      shard.position.set(x, y, z);
      shard.rotation.set(-0.25, ry, rz);
      this.crystalShellGroup.add(shard);
    }
  }

  private buildStiltLegs(): void {
    this.bodyPivot.add(this.stiltLegsGroup);
    const rows = [-0.34, 0.02, 0.38];
    for (let r = 0; r < rows.length; r++) {
      for (const side of [-1, 1] as const) {
        const legPivot = new THREE.Group();
        legPivot.position.set(side * 0.54, -0.18, rows[r]);

        const femur = new THREE.Mesh(
          new THREE.CylinderGeometry(0.055, 0.075, 0.46, 7),
          this.chitinMat
        );
        femur.rotation.z = -side * 0.88;
        femur.position.set(side * 0.18, 0.08, 0);
        legPivot.add(femur);

        const tibia = new THREE.Mesh(
          new THREE.ConeGeometry(0.065, 0.58, 7),
          this.chitinMat
        );
        tibia.rotation.z = Math.PI - side * 0.22;
        tibia.position.set(side * 0.38, -0.18, 0);
        legPivot.add(tibia);

        const tip = new THREE.Mesh(new THREE.SphereGeometry(0.048, 6, 5), this.innerCoreMat);
        tip.position.set(side * 0.44, -0.44, 0);
        legPivot.add(tip);

        this.stiltLegsGroup.add(legPivot);
        this.stiltLegs.push(legPivot);
      }
    }
  }

  private buildCrusherPincers(): void {
    this.pincersGroup.position.set(0, -0.02, -0.36);
    this.bodyPivot.add(this.pincersGroup);

    for (const side of [-1, 1] as const) {
      const p = side === -1 ? this.leftPincer : this.rightPincer;
      p.position.set(side * 0.58, 0, 0);

      const palm = new THREE.Mesh(new THREE.SphereGeometry(0.18, 10, 8), this.chitinMat);
      palm.scale.set(0.85, 0.65, 1.35);
      palm.position.set(side * 0.12, 0, -0.26);
      p.add(palm);

      const outerClaw = new THREE.Mesh(new THREE.ConeGeometry(0.085, 0.38, 6), this.crystalMat);
      outerClaw.rotation.x = -Math.PI / 2;
      outerClaw.rotation.z = side * 0.25;
      outerClaw.position.set(side * 0.18, 0.02, -0.52);
      p.add(outerClaw);

      const innerClaw = new THREE.Mesh(new THREE.ConeGeometry(0.068, 0.32, 6), this.chitinMat);
      innerClaw.rotation.x = -Math.PI / 2;
      innerClaw.rotation.z = -side * 0.28;
      innerClaw.position.set(side * 0.05, -0.02, -0.48);
      p.add(innerClaw);

      this.pincersGroup.add(p);
    }
  }

  private buildShockTentacles(): void {
    this.bodyPivot.add(this.tentaclesGroup);
    const angles = [-0.85, -0.48, -0.16, 0.16, 0.48, 0.85];
    for (let i = 0; i < angles.length; i++) {
      const a = angles[i];
      const chain: THREE.Group[] = [];
      let parent: THREE.Object3D = this.tentaclesGroup;
      for (let s = 0; s < 3; s++) {
        const seg = new THREE.Group();
        if (s === 0) {
          seg.position.set(Math.sin(a) * 0.56, -0.18, Math.cos(a) * 0.62);
          seg.rotation.y = a;
        } else {
          seg.position.set(0, 0, 0.32);
        }
        const r = 0.075 * (1 - s * 0.24);
        const cyl = new THREE.Mesh(
          new THREE.CylinderGeometry(r * 0.75, r, 0.34, 7),
          s === 2 ? this.innerCoreMat : this.outerGooMat
        );
        cyl.rotation.x = Math.PI / 2;
        cyl.position.set(0, 0, 0.16);
        seg.add(cyl);

        if (s === 2) {
          const bulb = new THREE.Mesh(new THREE.SphereGeometry(0.075, 8, 6), this.innerCoreMat);
          bulb.position.set(0, 0, 0.34);
          seg.add(bulb);
        }

        parent.add(seg);
        chain.push(seg);
        parent = seg;
      }
      this.tentacles.push(chain);
    }
  }

  private buildPlasmaGland(): void {
    this.bodyPivot.add(this.plasmaGlandGroup);
    for (const side of [-1, 1] as const) {
      const sac = new THREE.Mesh(new THREE.SphereGeometry(0.22, 12, 10), this.innerCoreMat);
      sac.scale.set(0.85, 0.9, 1.15);
      sac.position.set(side * 0.56, 0.14, 0.05);
      this.plasmaGlandGroup.add(sac);
    }
    // Dorsal bio-cannon nozzle
    const nozzle = new THREE.Mesh(
      new THREE.CylinderGeometry(0.11, 0.16, 0.28, 10),
      this.chitinMat
    );
    nozzle.rotation.x = -0.68;
    nozzle.position.set(0, 0.54, -0.22);
    this.plasmaGlandGroup.add(nozzle);

    const orifice = new THREE.Mesh(new THREE.SphereGeometry(0.095, 8, 6), this.innerCoreMat);
    orifice.position.set(0, 0.63, -0.31);
    this.plasmaGlandGroup.add(orifice);
  }

  private buildEyeStalks(eyeWhiteMat: THREE.Material, pupilMat: THREE.Material): void {
    this.bodyPivot.add(this.eyeStalksGroup);
    const configs = [
      { x: -0.34, y: 0.42, z: -0.35, h: 0.44, lean: -0.32 },
      { x: 0.0, y: 0.52, z: -0.32, h: 0.52, lean: 0.0 },
      { x: 0.34, y: 0.42, z: -0.35, h: 0.44, lean: 0.32 },
    ];
    for (const c of configs) {
      const pivot = new THREE.Group();
      pivot.position.set(c.x, c.y, c.z);

      const stalk = new THREE.Mesh(
        new THREE.CylinderGeometry(0.042, 0.072, c.h, 8),
        this.outerGooMat
      );
      stalk.position.set(0, c.h * 0.5, -0.05);
      stalk.rotation.z = c.lean;
      stalk.rotation.x = 0.25;
      pivot.add(stalk);

      const tipX = -Math.sin(c.lean) * c.h * 0.45;
      const tipY = c.h;
      const eye = new THREE.Mesh(new THREE.SphereGeometry(0.135, 12, 10), eyeWhiteMat);
      eye.position.set(tipX, tipY, -0.12);
      pivot.add(eye);

      const pupil = new THREE.Mesh(new THREE.SphereGeometry(0.074, 10, 8), pupilMat);
      pupil.position.set(tipX, tipY, -0.23);
      pivot.add(pupil);

      const crown = new THREE.Mesh(new THREE.ConeGeometry(0.045, 0.12, 5), this.innerCoreMat);
      crown.position.set(tipX, tipY + 0.15, -0.12);
      pivot.add(crown);

      this.eyeStalksGroup.add(pivot);
      this.extraStalks.push(pivot);
    }
  }

  private buildGlideWings(): void {
    this.bodyPivot.add(this.wingsGroup);
    for (const side of [-1, 1] as const) {
      const wingPivot = side === -1 ? this.leftWing : this.rightWing;
      wingPivot.position.set(side * 0.55, 0.22, 0.05);

      // Sweeping triangular manta wing fin
      const shape = new THREE.Shape();
      shape.moveTo(0, 0);
      shape.quadraticCurveTo(side * 0.65, 0.45, side * 1.42, 0.12);
      shape.quadraticCurveTo(side * 0.95, -0.35, 0, -0.58);
      shape.closePath();

      const geo = new THREE.ShapeGeometry(shape, 8);
      geo.rotateX(-Math.PI / 2);
      const mesh = new THREE.Mesh(geo, this.wingMat);
      mesh.castShadow = true;
      wingPivot.add(mesh);

      // Glowing leading-edge wing spar
      const spar = new THREE.Mesh(
        new THREE.CylinderGeometry(0.025, 0.055, 1.4, 6),
        this.innerCoreMat
      );
      spar.rotation.z = -side * (Math.PI / 2 - 0.12);
      spar.position.set(side * 0.68, 0.02, -0.12);
      wingPivot.add(spar);

      this.wingsGroup.add(wingPivot);
    }
  }

  private buildTailFluke(): void {
    this.tailGroup.position.set(0, -0.08, 0.68);
    this.bodyPivot.add(this.tailGroup);

    let parent: THREE.Object3D = this.tailGroup;
    for (let i = 0; i < 4; i++) {
      const seg = new THREE.Group();
      seg.position.set(0, 0, i === 0 ? 0 : 0.34);
      const r0 = 0.24 * (1 - i * 0.2);
      const r1 = 0.24 * (1 - (i + 1) * 0.2);
      const body = new THREE.Mesh(
        new THREE.CylinderGeometry(r1, r0, 0.38, 10),
        this.outerGooMat
      );
      body.rotation.x = Math.PI / 2;
      body.position.set(0, 0, 0.18);
      seg.add(body);

      if (i === 3) {
        // Wide bioluminescent tail fluke at tip
        const fluke = new THREE.Mesh(new THREE.ConeGeometry(0.38, 0.52, 4), this.wingMat);
        fluke.scale.set(1.6, 1.0, 0.22);
        fluke.rotation.x = Math.PI / 2;
        fluke.position.set(0, 0, 0.42);
        seg.add(fluke);
      }

      parent.add(seg);
      this.tailSegments.push(seg);
      parent = seg;
    }
  }

  /** Build 3D anatomy for the seven new ability-linked mutations. */
  private buildAbilityTraitVisuals(): void {
    for (const g of [
      this.dashPodsGroup,
      this.slamPlatesGroup,
      this.sporePodsGroup,
      this.lanceHornGroup,
      this.veilFrillsGroup,
      this.regenMossGroup,
      this.senseCrownGroup,
    ]) {
      this.bodyPivot.add(g);
    }

    // Phase-Jet Pods
    for (const side of [-1, 1] as const) {
      const pod = new THREE.Mesh(
        new THREE.CylinderGeometry(0.075, 0.13, 0.46, 8),
        this.chitinMat
      );
      pod.rotation.z = side * 0.22;
      pod.rotation.x = Math.PI / 2;
      pod.position.set(side * 0.62, 0.14, 0.16);
      this.dashPodsGroup.add(pod);
      const nozzle = new THREE.Mesh(new THREE.ConeGeometry(0.09, 0.22, 7), this.innerCoreMat);
      nozzle.rotation.x = -Math.PI / 2;
      nozzle.position.set(side * 0.62, 0.14, 0.48);
      this.dashPodsGroup.add(nozzle);
    }

    // Gravitic Crush-Plates
    for (let i = 0; i < 4; i++) {
      const a = (i / 4) * Math.PI * 2;
      const plate = new THREE.Mesh(new THREE.DodecahedronGeometry(0.22, 0), this.crystalMat);
      plate.scale.set(1.1, 0.45, 1.1);
      plate.position.set(Math.cos(a) * 0.52, -0.32, Math.sin(a) * 0.58);
      plate.rotation.y = a;
      this.slamPlatesGroup.add(plate);
    }

    // Lumispore Mine Sacs
    for (let i = 0; i < 5; i++) {
      const a = (i / 5) * Math.PI * 2;
      const sac = new THREE.Mesh(new THREE.SphereGeometry(0.15, 10, 8), this.innerCoreMat);
      sac.position.set(Math.cos(a) * 0.36, 0.7, Math.sin(a) * 0.4);
      this.sporePodsGroup.add(sac);
      this.lanternPods.push(sac);
    }

    // Void Lance Horn
    const horn = new THREE.Mesh(new THREE.ConeGeometry(0.14, 0.9, 8), this.crystalMat);
    horn.rotation.x = -Math.PI / 2;
    horn.position.set(0, 0.68, -0.72);
    this.lanceHornGroup.add(horn);
    const muzzle = new THREE.Mesh(new THREE.SphereGeometry(0.1, 10, 8), this.innerCoreMat);
    muzzle.position.set(0, 0.68, -1.2);
    this.lanceHornGroup.add(muzzle);

    // Phase-Veil ghost frills
    for (let i = 0; i < 6; i++) {
      const a = (i / 6) * Math.PI * 2;
      const frill = new THREE.Mesh(new THREE.ConeGeometry(0.2, 0.68, 4), this.wingMat);
      frill.scale.set(1, 1, 0.16);
      frill.position.set(Math.cos(a) * 0.7, 0.2, Math.sin(a) * 0.76);
      frill.rotation.z = -Math.cos(a) * 0.65;
      frill.rotation.y = -a;
      this.veilFrillsGroup.add(frill);
    }

    // Regenerative moss plates
    for (let i = 0; i < 8; i++) {
      const a = (i / 8) * Math.PI * 2;
      const moss = new THREE.Mesh(new THREE.IcosahedronGeometry(0.12, 1), this.innerCoreMat);
      moss.scale.set(1.2, 0.5, 1.2);
      moss.position.set(Math.cos(a) * 0.62, -0.12, Math.sin(a) * 0.68);
      this.regenMossGroup.add(moss);
    }

    // Apex sensor crown: antennae + extra eyes
    for (let i = 0; i < 5; i++) {
      const a = (i / 5) * Math.PI * 2;
      const ant = new THREE.Mesh(new THREE.ConeGeometry(0.035, 0.48, 5), this.crystalMat);
      ant.position.set(Math.cos(a) * 0.32, 0.82, Math.sin(a) * 0.34);
      ant.rotation.z = -Math.cos(a) * 0.3;
      ant.rotation.x = Math.sin(a) * 0.3;
      this.senseCrownGroup.add(ant);
      if (i < 3) {
        const eye = new THREE.Mesh(new THREE.SphereGeometry(0.06, 8, 6), this.innerCoreMat);
        eye.position.set(Math.cos(a) * 0.32, 1.05, Math.sin(a) * 0.34 - 0.05);
        this.senseCrownGroup.add(eye);
      }
    }
  }

  /** Play the character-side visual for an active evolved ability. */
  public triggerAbilityAnim(id: AbilityId): void {
    const color = new THREE.Color(ABILITIES[id].color);
    switch (id) {
      case 'dash':
        this.dashAnimTimer = 0.32;
        this.bioLight.color.copy(color);
        break;
      case 'slam':
        this.slamAnimTimer = 0.5;
        this.attackWaveMesh.visible = true;
        this.attackWaveMesh.scale.setScalar(0.7);
        this.attackWaveMat.color.copy(color);
        break;
      case 'mines':
        this.spitAnimTimer = 0.32;
        break;
      case 'lance':
        this.lanceAnimTimer = 0.28;
        this.lanceBeamMat.color.copy(color);
        this.lanceBeamMesh.visible = true;
        break;
      case 'cloak':
        this.evoBurstTimer = 0.9;
        this.evoAuraMesh.visible = true;
        this.evoAuraMat.color.copy(color);
        break;
      default:
        break;
    }
  }

  public setCloaked(active: boolean): void {
    this.cloaked = active;
  }

  /** Set base slime color, evolution stage anatomy & blend with evolved trait hues */
  public setAppearance(
    baseColorHex: string,
    traits: TraitId[],
    targetScale: number,
    stage = this.visualStage
  ): void {
    this.targetScale = clamp(targetScale, 0.65, 3.2);
    this.evolutionStage = Math.max(1, Math.round(stage));
    this.visualStage = clamp(this.evolutionStage, 1, 6);
    this.ascended = this.evolutionStage >= 6;
    this.activeTraits = new Set(traits);
    this.applyStageVisuals();
    this.syncTraitVisibility();

    const baseCol = new THREE.Color(baseColorHex || '#2dd4bf');
    baseCol.offsetHSL(0, -0.015 * (this.visualStage - 1), 0.018 * (this.visualStage - 1));
    const glowCol = baseCol.clone().multiplyScalar(1.3);

    // Blend in subtle genetic tint shifts from evolved traits
    if (traits.length > 0) {
      const latest = TRAITS[traits[traits.length - 1]];
      if (latest) {
        const traitCol = new THREE.Color().setRGB(
          latest.bodyTint[0],
          latest.bodyTint[1],
          latest.bodyTint[2],
          THREE.SRGBColorSpace
        );
        baseCol.lerp(traitCol, 0.42);
        glowCol.setRGB(latest.glowTint[0], latest.glowTint[1], latest.glowTint[2]);
        this.wingMat.color.copy(traitCol).lerp(baseCol, 0.4);
        this.wingMat.emissive.copy(traitCol).multiplyScalar(0.6);
        this.crystalMat.color.copy(traitCol).offsetHSL(0.06, 0.15, 0.1);
        this.crystalMat.emissive.copy(traitCol);
      }
    }

    this.outerGooMat.color.copy(baseCol);
    this.outerGooMat.emissive.copy(baseCol).multiplyScalar(0.45);
    this.innerCoreMat.color.copy(baseCol).offsetHSL(0, 0.1, 0.22);
    this.innerCoreMat.emissive.copy(glowCol);
    this.bioLight.color.copy(baseCol);
    this.attackWaveMat.color.copy(baseCol);
    this.evoAuraMat.color.copy(baseCol);
  }

  private syncTraitVisibility(): void {
    const has = (id: TraitId) => this.activeTraits.has(id);
    this.mandiblesGroup.visible = has('mandibles');
    this.scythesGroup.visible = has('scythe_claws');
    this.dorsalSpinesGroup.visible = has('dorsal_spines');
    this.crystalShellGroup.visible = has('crystal_shell');
    this.stiltLegsGroup.visible = has('stilt_legs');
    this.pincersGroup.visible = has('crusher_pincers');
    this.tentaclesGroup.visible = has('shock_tentacles');
    this.plasmaGlandGroup.visible = has('plasma_gland');

    const hasTriEyes = has('eye_stalks');
    this.eyeStalksGroup.visible = !this.ascended && hasTriEyes;
    this.leftEyePivot.visible = !this.ascended && !hasTriEyes;
    this.rightEyePivot.visible = !this.ascended && !hasTriEyes;

    this.wingsGroup.visible = has('glide_wings');
    this.tailGroup.visible = has('tail_fluke');

    this.dashPodsGroup.visible = has('phase_dash');
    this.slamPlatesGroup.visible = has('gravity_slam');
    this.sporePodsGroup.visible = has('spore_mines');
    this.lanceHornGroup.visible = has('void_lance');
    this.veilFrillsGroup.visible = has('phase_veil');
    this.regenMossGroup.visible = has('symbiote_regen');
    this.senseCrownGroup.visible = has('apex_sense');
  }

  public triggerAttackAnim(): void {
    this.attackAnimTimer = 0.36;
    this.attackWaveMesh.visible = true;
    this.attackWaveMesh.scale.setScalar(0.5);
  }

  public triggerSpitAnim(): void {
    this.spitAnimTimer = 0.32;
  }

  public triggerEvolutionBurst(): void {
    this.evoBurstTimer = 1.45;
    this.evoAuraMesh.visible = true;
  }

  public update(dt: number, elapsed: number, input: CharacterAnimInput): boolean {
    let footstepTriggered = false;

    // Smoothly grow organism scale as DNA / traits increase
    this.currentScale = lerp(this.currentScale, this.targetScale, Math.min(1, dt * 4.5));
    const evoPulse =
      this.evoBurstTimer > 0 ? 1.0 + Math.sin(this.evoBurstTimer * 16.0) * 0.14 : 1.0;
    this.root.scale.setScalar(this.currentScale * evoPulse);

    const speedRatio = clamp(input.speed / Math.max(1, input.maxSprintSpeed), 0, 1.3);
    const isMoving = input.speed > 0.22;

    // Bioluminescent glow intensity (brighter at night & during evolution!)
    const nightBoost = lerp(0.85, 2.2, input.nightFactor);
    this.innerCoreMat.emissiveIntensity = 1.4 * nightBoost;
    this.outerGooMat.emissiveIntensity = 0.34 * nightBoost;
    this.bioLight.intensity = lerp(0.8, 3.2, input.nightFactor) * this.currentScale;
    const normalOpacity = Math.max(0.7, 0.86 - this.visualStage * 0.025);
    this.outerGooMat.opacity = lerp(
      this.outerGooMat.opacity,
      this.cloaked ? 0.22 : normalOpacity,
      Math.min(1, dt * 7)
    );
    this.bioLight.intensity *= this.cloaked ? 0.32 : 1;

    // Timed ability visuals
    this.dashAnimTimer = Math.max(0, this.dashAnimTimer - dt);
    this.slamAnimTimer = Math.max(0, this.slamAnimTimer - dt);
    this.lanceAnimTimer = Math.max(0, this.lanceAnimTimer - dt);

    if (this.lanceAnimTimer > 0) {
      const k = this.lanceAnimTimer / 0.28;
      this.lanceBeamMesh.visible = true;
      this.lanceBeamMat.opacity = k * 0.85;
      this.lanceBeamMesh.scale.set(1 + (1 - k) * 0.35, 1, 1 + (1 - k) * 0.35);
    } else {
      this.lanceBeamMesh.visible = false;
    }

    if (this.slamAnimTimer > 0 && this.attackAnimTimer <= 0) {
      const k = this.slamAnimTimer / 0.5;
      this.attackWaveMesh.visible = true;
      this.attackWaveMesh.scale.setScalar(0.7 + (1 - k) * 4.2);
      this.attackWaveMat.opacity = k * 0.7;
    } else if (this.slamAnimTimer <= 0 && this.attackAnimTimer <= 0) {
      this.attackWaveMesh.visible = false;
    }

    // Contact shadow fade when airborne or swimming
    const shadowTarget =
      input.grounded && !input.swimming && !input.wading ? 0.65 : 0.12;
    this.contactShadowMat.opacity = lerp(
      this.contactShadowMat.opacity,
      shadowTarget,
      Math.min(1, dt * 10)
    );

    // Advance stride / slither / hop cycle
    const cadence = isMoving ? lerp(5.5, 11.5, clamp(speedRatio, 0, 1)) : 2.2;
    this.stridePhase += dt * cadence;
    const p = this.stridePhase;
    const sinP = Math.sin(p);
    const cosP = Math.cos(p);

    if (isMoving && (input.grounded || input.swimming)) {
      const side = sinP >= 0 ? 1 : -1;
      if (side !== this.lastFootSide) {
        this.lastFootSide = side;
        footstepTriggered = true;
      }
    }

    // Squishy Goo Squash & Stretch physics!
    const hasLegs = this.activeTraits.has('stilt_legs');
    const baseHeight = hasLegs || this.ascended ? 0.72 : 0.54;
    let hopY = 0;
    let sx = 1.0;
    let sy = 1.0;
    let sz = 1.0;

    if (input.swimming) {
      hopY = -0.12 + Math.sin(elapsed * 3.0) * 0.05;
      sx = 1.08 + Math.sin(p) * 0.06;
      sy = 0.82;
      sz = 1.14 - Math.sin(p) * 0.06;
    } else if (!input.grounded) {
      if (input.gliding) {
        // Flattened aerodynamic manta-glide posture
        sx = 1.18;
        sy = 0.78;
        sz = 1.12;
      } else {
        const stretch = clamp(input.verticalVel * 0.035, -0.22, 0.26);
        sy = 1.0 + stretch;
        sx = 1.0 - stretch * 0.45;
        sz = 1.0 - stretch * 0.45;
      }
    } else if (isMoving) {
      // Rhythmic slime bounce & peristaltic wave
      const bounce = Math.abs(sinP);
      hopY = bounce * (hasLegs ? 0.08 : 0.16) * clamp(speedRatio + 0.3, 0.4, 1.1);
      const squash = cosP * 0.13 * clamp(speedRatio + 0.3, 0.4, 1.1);
      sy = 1.0 - squash - input.landingImpact * 0.25;
      sx = 1.0 + squash * 0.6 + input.landingImpact * 0.18;
      sz = 1.0 + squash * 0.75 + input.landingImpact * 0.18;
    } else {
      // Gentle living gelatinous breathing
      const breath = Math.sin(elapsed * 2.6);
      sy = 1.0 + breath * 0.045 - input.landingImpact * 0.25;
      sx = 1.0 - breath * 0.025 + input.landingImpact * 0.18;
      sz = 1.0 - breath * 0.025 + input.landingImpact * 0.18;
    }

    // Ascended creatures keep a firmer skeletal silhouette instead of goo wobble.
    if (this.ascended) {
      sx = lerp(sx, 1, 0.65);
      sy = lerp(sy, 1, 0.65);
      sz = lerp(sz, 1, 0.65);
    }

    // Phase Dash forward compression / speed streak
    if (this.dashAnimTimer > 0) {
      const k = this.dashAnimTimer / 0.32;
      sz *= 1.0 + k * 0.52;
      sx *= 1.0 - k * 0.26;
      sy *= 1.0 - k * 0.12;
    }

    // Forward Bite Lunge stretch
    let lungeZ = 0;
    if (this.attackAnimTimer > 0) {
      this.attackAnimTimer = Math.max(0, this.attackAnimTimer - dt);
      const t = 1.0 - this.attackAnimTimer / 0.36;
      const lungeCurve = Math.sin(t * Math.PI);
      lungeZ = -lungeCurve * 0.55;
      sz *= 1.0 + lungeCurve * 0.32;
      sx *= 1.0 - lungeCurve * 0.12;

      // Expand shockwave ring
      this.attackWaveMesh.scale.setScalar(0.55 + t * 2.8);
      this.attackWaveMat.opacity = (1.0 - t) * 0.75;
      if (this.attackAnimTimer <= 0) {
        this.attackWaveMesh.visible = false;
      }
    }

    // Acid Spit recoil pulse
    if (this.spitAnimTimer > 0) {
      this.spitAnimTimer = Math.max(0, this.spitAnimTimer - dt);
      const sCurve = Math.sin((1.0 - this.spitAnimTimer / 0.32) * Math.PI);
      sy *= 1.0 + sCurve * 0.22;
      sx *= 1.0 + sCurve * 0.15;
    }

    // Evolution DNA Burst aura
    if (this.evoBurstTimer > 0) {
      this.evoBurstTimer = Math.max(0, this.evoBurstTimer - dt);
      const t = 1.0 - this.evoBurstTimer / 1.45;
      this.evoAuraMesh.scale.setScalar(0.8 + t * 2.4);
      this.evoAuraMesh.rotation.y += dt * 4.5;
      this.evoAuraMesh.rotation.x += dt * 2.5;
      this.evoAuraMat.opacity = (1.0 - t) * 0.85;
      if (this.evoBurstTimer <= 0) {
        this.evoAuraMesh.visible = false;
      }
    }

    this.bodyPivot.position.set(0, baseHeight + hopY, lungeZ);
    this.bodyPivot.scale.set(sx, sy, sz);

    // Lean into movement & terrain slope
    const targetPitch =
      -speedRatio * 0.16 - clamp(input.slopePitch * 0.25, -0.15, 0.15) + (lungeZ * 0.25);
    this.bodyPivot.rotation.x = lerp(this.bodyPivot.rotation.x, targetPitch, Math.min(1, dt * 10));
    this.bodyPivot.rotation.z = isMoving ? sinP * 0.05 : Math.sin(elapsed * 1.3) * 0.02;

    // Orbit internal nucleus & organelles
    this.nucleusMesh.rotation.y = elapsed * 1.4;
    this.nucleusMesh.rotation.x = elapsed * 0.9;
    this.organellesGroup.rotation.y = -elapsed * 1.1;
    this.organellesGroup.rotation.z = Math.sin(elapsed * 0.8) * 0.25;

    // Animate stage-specific Leviathan biomass lobes & Elder crown halo
    for (let i = 0; i < this.stageSatellites.length; i++) {
      const orb = this.stageSatellites[i];
      const a = (i / this.stageSatellites.length) * Math.PI * 2 + elapsed * (0.65 + i * 0.04);
      orb.position.set(Math.cos(a) * 1.0, 0.45 + Math.sin(elapsed * 2.3 + i) * 0.14, Math.sin(a) * 1.05);
      orb.rotation.y += dt * 2.5;
    }
    for (const ring of this.stageRings) {
      ring.rotation.y += dt * 0.9;
      ring.rotation.z = Math.sin(elapsed * 0.8) * 0.14;
    }

    // Eye stalk wobble
    const eyeWobble = Math.sin(elapsed * 3.2) * 0.06;
    this.leftEyePivot.rotation.z = 0.1 + eyeWobble;
    this.rightEyePivot.rotation.z = -0.1 - eyeWobble;
    for (let i = 0; i < this.extraStalks.length; i++) {
      this.extraStalks[i].rotation.x = Math.sin(elapsed * 3.6 + i) * 0.08;
      this.extraStalks[i].rotation.z = Math.cos(elapsed * 2.8 + i * 1.5) * 0.08;
    }

    // Animate Mandibles & Claws & Pincers (snap shut during bite!)
    const snap =
      this.attackAnimTimer > 0
        ? Math.sin((1 - this.attackAnimTimer / 0.36) * Math.PI) * 0.65
        : Math.sin(elapsed * 2.8) * 0.08;
    this.leftMandible.rotation.y = -0.25 + snap;
    this.rightMandible.rotation.y = 0.25 - snap;

    this.leftScythe.rotation.y = -0.2 + snap * 1.1;
    this.rightScythe.rotation.y = 0.2 - snap * 1.1;
    this.leftScythe.rotation.x = this.attackAnimTimer > 0 ? -0.45 : 0;
    this.rightScythe.rotation.x = this.attackAnimTimer > 0 ? -0.45 : 0;

    this.leftPincer.rotation.y = -0.18 + snap * 0.9;
    this.rightPincer.rotation.y = 0.18 - snap * 0.9;

    // Animate 6 Arachnid Stilt-Legs when evolved
    if (this.stiltLegsGroup.visible) {
      const legAmp = isMoving ? 0.45 : 0.04;
      for (let i = 0; i < this.stiltLegs.length; i++) {
        const leg = this.stiltLegs[i];
        const phaseOff = (i % 2 === 0 ? 0 : Math.PI) + Math.floor(i / 2) * 1.1;
        leg.rotation.y = Math.sin(p + phaseOff) * legAmp;
        leg.rotation.z = Math.max(0, Math.cos(p + phaseOff)) * legAmp * 0.45 * (i % 2 === 0 ? -1 : 1);
      }
    }

    // Animate 6 Voltaic Whip-Tentacles
    if (this.tentaclesGroup.visible) {
      for (let t = 0; t < this.tentacles.length; t++) {
        const chain = this.tentacles[t];
        for (let s = 0; s < chain.length; s++) {
          const wave = Math.sin(elapsed * 4.5 - s * 0.9 + t * 1.2);
          chain[s].rotation.y = (s === 0 ? (t - 2.5) * 0.28 : 0) + wave * (0.18 + speedRatio * 0.15);
          chain[s].rotation.x = Math.cos(elapsed * 3.4 - s * 0.7 + t) * 0.12;
        }
      }
    }

    // Animate Glidewing Membranes (flap wide in air/glide, gentle pulse on ground)
    if (this.wingsGroup.visible) {
      const flapRate = !input.grounded ? 9.5 : isMoving ? 4.5 : 2.0;
      const flapAmp = input.gliding ? 0.22 : !input.grounded ? 0.58 : 0.18;
      const flap = Math.sin(elapsed * flapRate) * flapAmp;
      this.leftWing.rotation.z = flap + (input.gliding ? 0.08 : -0.15);
      this.rightWing.rotation.z = -flap - (input.gliding ? 0.08 : -0.15);
    }

    // Animate Propulsion Tail-Fluke
    if (this.tailGroup.visible) {
      const tailRate = isMoving ? 8.5 : 2.8;
      const tailAmp = isMoving ? 0.28 : 0.1;
      for (let i = 0; i < this.tailSegments.length; i++) {
        this.tailSegments[i].rotation.y = Math.sin(elapsed * tailRate - i * 0.85) * tailAmp;
      }
    }

    // Animate new ability-trait anatomy
    if (this.dashPodsGroup.visible) {
      const jet = 1 + Math.sin(elapsed * 8.0) * 0.08 + (this.dashAnimTimer > 0 ? 0.35 : 0);
      this.dashPodsGroup.scale.set(1, 1, jet);
    }
    if (this.slamPlatesGroup.visible) {
      this.slamPlatesGroup.rotation.y = Math.sin(elapsed * 1.4) * 0.08;
      this.slamPlatesGroup.position.y = -Math.max(0, this.slamAnimTimer) * 0.25;
    }
    if (this.sporePodsGroup.visible) {
      this.sporePodsGroup.rotation.y += dt * 0.7;
      for (let i = 0; i < this.lanternPods.length; i++) {
        const pulse = 1 + Math.sin(elapsed * 3.6 + i * 1.2) * 0.14;
        this.lanternPods[i].scale.setScalar(pulse);
      }
    }
    if (this.lanceHornGroup.visible) {
      this.lanceHornGroup.scale.setScalar(1 + (this.lanceAnimTimer > 0 ? 0.18 : 0));
    }
    if (this.veilFrillsGroup.visible) {
      this.veilFrillsGroup.rotation.y += dt * (this.cloaked ? 1.8 : 0.5);
      this.veilFrillsGroup.scale.setScalar(this.cloaked ? 1.12 : 1.0);
    }
    if (this.regenMossGroup.visible) {
      this.regenMossGroup.rotation.y += dt * 0.25;
    }
    if (this.senseCrownGroup.visible) {
      this.senseCrownGroup.rotation.y = Math.sin(elapsed * 0.9) * 0.14;
    }

    // Animate the post-blob xeno-beast body.
    if (this.ascended) {
      const gait = Math.sin(p) * (isMoving ? 0.42 : 0.04);
      for (let i = 0; i < this.ascendedLegs.length; i++) {
        const leg = this.ascendedLegs[i];
        leg.rotation.x = (i === 0 || i === 3 ? gait : -gait);
      }
      for (let i = 0; i < this.ascendedArms.length; i++) {
        const arm = this.ascendedArms[i];
        arm.rotation.x = (i === 0 ? -gait : gait) * 0.7;
      }
      this.ascendedHead.rotation.y = Math.sin(elapsed * 0.9) * 0.09;
      this.ascendedHead.position.y = 0.62 + Math.sin(elapsed * 2.1) * 0.025;
      for (let i = 0; i < this.ascendedTail.length; i++) {
        this.ascendedTail[i].rotation.y = Math.sin(elapsed * 3.2 - i * 0.8) * (0.12 + speedRatio * 0.12);
      }
    }

    return footstepTriggered;
  }
}
