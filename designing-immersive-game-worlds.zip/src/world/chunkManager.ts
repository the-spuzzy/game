import * as THREE from 'three';
import { AlienFloraLibrary } from './alienFlora';
import {
  BIOME_LIST,
  BIOME_ORDER,
  BiomeId,
  BiomeWeights,
  CHUNK_SIZE,
  OASIS_X,
  OASIS_Z,
  WATER_LEVEL,
  computeTerrainColor,
  computeTerrainGlow,
  getRenderedTerrainHeight,
  getTerrainHeightWithWeights,
  sampleBiomeWeights,
  sampleRenderedTerrain,
  sampleTrailFactor,
  setActiveTerrainCellSize,
} from './biomes';
import { FoliageLibrary } from './foliage';
import { TerrainShaderUniforms, createTerrainMaterial } from './materials';
import { clamp, hashSeed, lerp } from './noise';
import { AtmosphereState } from './sky';
import { WaterSystem } from './water';

export interface CircleCollider {
  x: number;
  z: number;
  r: number;
}

interface InstanceSpec {
  x: number;
  y: number;
  z: number;
  rotY: number;
  tiltX: number;
  tiltZ: number;
  sx: number;
  sy: number;
  sz: number;
  color: THREE.Color;
  color2: THREE.Color | null;
}

interface TerrainChunk {
  cx: number;
  cz: number;
  key: string;
  group: THREE.Group;
  understoryGroup: THREE.Group;
  detailGroup: THREE.Group;
  terrainGeo: THREE.BufferGeometry;
  waterMesh: THREE.Mesh | null;
  instancedMeshes: THREE.InstancedMesh[];
  colliders: CircleCollider[];
}

type RGB = [number, number, number];

type KindId =
  | 'spirePine'
  | 'frostPine'
  | 'parasol'
  | 'blushwood'
  | 'fanfrond'
  | 'weepglow'
  | 'spinepod'
  | 'capspire'
  | 'coilwood'
  | 'crystalSpire'
  | 'boneSpire'
  | 'sapling'
  | 'puffbrush'
  | 'bloombrush'
  | 'curlfrond'
  | 'agave'
  | 'mushCluster'
  | 'bulbLantern'
  | 'tubeCoral'
  | 'crystalCluster'
  | 'shard'
  | 'log'
  | 'reed'
  | 'lily'
  | 'rock'
  | 'grass'
  | 'flower';

interface KindDef {
  geo: THREE.BufferGeometry;
  mat: THREE.Material;
  trunkGeo?: THREE.BufferGeometry;
  trunkMat?: THREE.Material;
  group: 'main' | 'under' | 'detail';
  cast: boolean;
  slopeAlign: boolean;
}

interface FloraEntry {
  kind: KindId;
  w: number;
  s: [number, number];
  pal: RGB[];
  bark?: RGB;
  col?: number;
  squash?: number;
  bank?: boolean;
}

interface BiomeFlora {
  treeDensity: number;
  groveAmp: number;
  trees: FloraEntry[];
  underDensity: number;
  under: FloraEntry[];
  grassDensity: number;
  grassPal: RGB[];
  grassHeight: number;
  flowerChance: number;
  flowerPal: RGB[];
  rockChance: number;
  rockPal: RGB[];
  reedPal: RGB[];
}

/** Alien flora composition per region (sRGB tints) */
const FLORA: Record<BiomeId, BiomeFlora> = {
  meadow: {
    treeDensity: 0.32,
    groveAmp: 0.55,
    trees: [
      { kind: 'parasol', w: 3, s: [0.85, 1.25], pal: [[0.3, 0.85, 0.85], [0.25, 0.72, 0.95], [0.45, 0.95, 0.8]], bark: [0.78, 0.74, 0.9], col: 0.48 },
      { kind: 'capspire', w: 2, s: [0.7, 1.2], pal: [[0.75, 0.4, 1.0], [1.0, 0.45, 0.85], [0.4, 0.55, 1.0]], col: 0.55 },
      { kind: 'coilwood', w: 1.2, s: [0.8, 1.2], pal: [[0.45, 0.95, 0.9], [0.7, 0.5, 1.0]], col: 0.4 },
      { kind: 'weepglow', w: 1.6, s: [0.85, 1.15], pal: [[0.35, 0.95, 0.85], [0.5, 0.8, 1.0]], bark: [0.55, 0.6, 0.7], col: 0.5, bank: true },
      { kind: 'blushwood', w: 1, s: [0.85, 1.2], pal: [[0.95, 0.55, 0.85], [0.8, 0.62, 1.0]], bark: [0.95, 0.92, 1.0], col: 0.3 },
    ],
    underDensity: 0.55,
    under: [
      { kind: 'puffbrush', w: 3, s: [0.62, 1.25], pal: [[0.25, 0.8, 0.8], [0.55, 0.45, 0.95], [0.3, 0.65, 0.9]] },
      { kind: 'bloombrush', w: 2, s: [0.62, 1.15], pal: [[0.35, 0.85, 0.9], [0.6, 0.5, 1.0]] },
      { kind: 'bulbLantern', w: 1.3, s: [0.8, 1.3], pal: [[0.3, 1.0, 0.95], [0.9, 0.5, 1.0]] },
      { kind: 'mushCluster', w: 1.5, s: [0.8, 1.5], pal: [[0.7, 0.45, 1.0], [0.35, 0.9, 1.0]] },
      { kind: 'curlfrond', w: 1.5, s: [0.75, 1.3], pal: [[0.3, 0.85, 0.75], [0.4, 0.7, 0.95]] },
      { kind: 'sapling', w: 0.6, s: [0.75, 1.2], pal: [[0.35, 0.85, 0.85], [0.7, 0.5, 1.0]], bark: [0.7, 0.68, 0.82] },
    ],
    grassDensity: 1.0,
    grassPal: [[0.2, 0.66, 0.66], [0.28, 0.72, 0.7], [0.4, 0.5, 0.8]],
    grassHeight: 1.0,
    flowerChance: 0.2,
    flowerPal: [[0.4, 0.95, 1.0], [0.95, 0.5, 1.0], [1.0, 0.85, 0.4], [0.7, 0.6, 1.0]],
    rockChance: 0.05,
    rockPal: [[0.55, 0.52, 0.68]],
    reedPal: [[0.45, 1.0, 0.9], [0.7, 0.6, 1.0]],
  },
  plains: {
    treeDensity: 0.045,
    groveAmp: 0.2,
    trees: [
      { kind: 'parasol', w: 2, s: [0.8, 1.15], pal: [[1.0, 0.62, 0.3], [0.95, 0.5, 0.35]], bark: [0.6, 0.45, 0.42], col: 0.45, squash: 0.72 },
      { kind: 'coilwood', w: 1.2, s: [0.8, 1.15], pal: [[1.0, 0.55, 0.3], [1.0, 0.75, 0.4]], col: 0.4 },
      { kind: 'capspire', w: 0.7, s: [0.6, 0.95], pal: [[1.0, 0.5, 0.25], [1.0, 0.7, 0.3]], col: 0.5 },
    ],
    underDensity: 0.16,
    under: [
      { kind: 'puffbrush', w: 2, s: [0.6, 1.1], pal: [[1.0, 0.62, 0.32], [0.95, 0.45, 0.35]] },
      { kind: 'tubeCoral', w: 1.4, s: [0.7, 1.2], pal: [[1.0, 0.5, 0.3], [1.0, 0.7, 0.35]] },
      { kind: 'bulbLantern', w: 0.4, s: [0.8, 1.1], pal: [[1.0, 0.75, 0.35]] },
    ],
    grassDensity: 1.0,
    grassPal: [[0.95, 0.58, 0.38], [0.9, 0.5, 0.4], [1.0, 0.66, 0.42]],
    grassHeight: 1.75,
    flowerChance: 0.1,
    flowerPal: [[1.0, 0.9, 0.4], [1.0, 0.45, 0.35], [0.9, 0.5, 1.0]],
    rockChance: 0.05,
    rockPal: [[0.62, 0.45, 0.42]],
    reedPal: [[1.0, 0.75, 0.4]],
  },
  forest: {
    treeDensity: 0.72,
    groveAmp: 0.25,
    trees: [
      { kind: 'capspire', w: 3, s: [0.95, 1.65], pal: [[0.6, 0.35, 1.0], [0.3, 0.5, 1.0], [0.95, 0.4, 0.8], [0.35, 0.9, 0.95]], col: 0.6 },
      { kind: 'spirePine', w: 2.5, s: [0.85, 1.35], pal: [[0.45, 0.35, 0.85], [0.35, 0.3, 0.75], [0.55, 0.4, 0.95]], bark: [0.45, 0.4, 0.55], col: 0.4 },
      { kind: 'coilwood', w: 1, s: [0.85, 1.3], pal: [[0.6, 0.4, 1.0], [0.4, 0.8, 1.0]], col: 0.4 },
    ],
    underDensity: 0.75,
    under: [
      { kind: 'mushCluster', w: 3, s: [0.8, 1.7], pal: [[0.6, 0.4, 1.0], [0.35, 0.85, 1.0], [1.0, 0.5, 0.85]] },
      { kind: 'puffbrush', w: 2, s: [0.6, 1.2], pal: [[0.45, 0.35, 0.9], [0.35, 0.45, 0.85]] },
      { kind: 'curlfrond', w: 2, s: [0.75, 1.3], pal: [[0.5, 0.4, 0.95], [0.3, 0.7, 0.9]] },
      { kind: 'bulbLantern', w: 1, s: [0.8, 1.3], pal: [[0.4, 0.9, 1.0], [0.9, 0.5, 1.0]] },
      { kind: 'sapling', w: 0.8, s: [0.75, 1.25], pal: [[0.5, 0.4, 0.95]], bark: [0.5, 0.45, 0.6] },
      { kind: 'log', w: 0.4, s: [0.8, 1.2], pal: [[0.6, 0.55, 0.72]] },
    ],
    grassDensity: 0.75,
    grassPal: [[0.4, 0.32, 0.75], [0.32, 0.4, 0.8]],
    grassHeight: 0.95,
    flowerChance: 0.1,
    flowerPal: [[0.4, 0.9, 1.0], [0.9, 0.4, 1.0]],
    rockChance: 0.09,
    rockPal: [[0.45, 0.42, 0.6]],
    reedPal: [[0.6, 0.5, 1.0]],
  },
  jungle: {
    treeDensity: 0.86,
    groveAmp: 0.12,
    trees: [
      { kind: 'parasol', w: 2.5, s: [1.0, 1.5], pal: [[0.15, 0.85, 0.55], [0.1, 0.7, 0.6], [0.3, 0.95, 0.5]], bark: [0.45, 0.55, 0.5], col: 0.55 },
      { kind: 'fanfrond', w: 2, s: [0.85, 1.3], pal: [[0.2, 0.9, 0.6], [0.4, 0.95, 0.35]], bark: [0.55, 0.6, 0.5], col: 0.34 },
      { kind: 'coilwood', w: 1.5, s: [0.9, 1.35], pal: [[0.25, 1.0, 0.7], [0.9, 0.35, 0.85]], col: 0.4 },
      { kind: 'weepglow', w: 1, s: [0.9, 1.2], pal: [[0.25, 0.95, 0.6]], bark: [0.4, 0.5, 0.45], col: 0.5 },
      { kind: 'capspire', w: 0.8, s: [0.8, 1.3], pal: [[0.95, 0.35, 0.8], [0.3, 0.9, 0.6]], col: 0.55 },
    ],
    underDensity: 0.95,
    under: [
      { kind: 'curlfrond', w: 3, s: [0.85, 1.5], pal: [[0.2, 0.9, 0.6], [0.35, 0.95, 0.45]] },
      { kind: 'puffbrush', w: 2, s: [0.7, 1.35], pal: [[0.15, 0.8, 0.55], [0.9, 0.35, 0.75]] },
      { kind: 'bloombrush', w: 1.5, s: [0.7, 1.25], pal: [[0.2, 0.85, 0.6], [0.95, 0.4, 0.7]] },
      { kind: 'bulbLantern', w: 2, s: [0.9, 1.4], pal: [[0.3, 1.0, 0.6], [1.0, 0.4, 0.8]] },
      { kind: 'tubeCoral', w: 1, s: [0.8, 1.3], pal: [[0.95, 0.4, 0.7]] },
      { kind: 'sapling', w: 1, s: [0.8, 1.3], pal: [[0.2, 0.85, 0.6]], bark: [0.45, 0.55, 0.5] },
    ],
    grassDensity: 0.6,
    grassPal: [[0.15, 0.62, 0.45], [0.22, 0.7, 0.4]],
    grassHeight: 1.1,
    flowerChance: 0.18,
    flowerPal: [[1.0, 0.35, 0.75], [0.4, 1.0, 0.6], [1.0, 0.75, 0.3]],
    rockChance: 0.06,
    rockPal: [[0.35, 0.5, 0.46]],
    reedPal: [[0.4, 1.0, 0.6]],
  },
  alpine: {
    treeDensity: 0.55,
    groveAmp: 0.2,
    trees: [
      { kind: 'frostPine', w: 3, s: [0.75, 1.15], pal: [[0.75, 0.85, 1.0], [0.65, 0.75, 1.0], [0.8, 0.75, 1.0]], bark: [0.5, 0.55, 0.7], col: 0.36 },
      { kind: 'crystalSpire', w: 1.2, s: [0.6, 1.3], pal: [[0.5, 0.85, 1.0], [0.7, 0.6, 1.0], [0.45, 1.0, 0.95]], col: 0.9 },
    ],
    underDensity: 0.42,
    under: [
      { kind: 'crystalCluster', w: 2, s: [0.8, 1.6], pal: [[0.5, 0.85, 1.0], [0.75, 0.6, 1.0], [0.4, 1.0, 0.95]] },
      { kind: 'puffbrush', w: 1.5, s: [0.55, 1.0], pal: [[0.7, 0.8, 1.0], [0.8, 0.85, 0.95]] },
      { kind: 'mushCluster', w: 0.5, s: [0.7, 1.1], pal: [[0.5, 0.7, 1.0]] },
    ],
    grassDensity: 0.35,
    grassPal: [[0.55, 0.62, 0.85]],
    grassHeight: 0.7,
    flowerChance: 0.05,
    flowerPal: [[0.6, 0.85, 1.0]],
    rockChance: 0.2,
    rockPal: [[0.45, 0.5, 0.62]],
    reedPal: [[0.6, 0.8, 1.0]],
  },
  autumn: {
    treeDensity: 0.62,
    groveAmp: 0.26,
    trees: [
      { kind: 'blushwood', w: 3, s: [0.85, 1.3], pal: [[1.0, 0.25, 0.3], [0.95, 0.35, 0.2], [1.0, 0.45, 0.55], [0.85, 0.2, 0.4]], bark: [0.95, 0.88, 0.92], col: 0.3 },
      { kind: 'spirePine', w: 1, s: [0.8, 1.2], pal: [[0.55, 0.15, 0.25], [0.45, 0.12, 0.3]], bark: [0.35, 0.25, 0.3], col: 0.36 },
      { kind: 'capspire', w: 0.8, s: [0.7, 1.15], pal: [[1.0, 0.4, 0.2], [1.0, 0.3, 0.45]], col: 0.5 },
    ],
    underDensity: 0.62,
    under: [
      { kind: 'puffbrush', w: 2, s: [0.6, 1.25], pal: [[0.95, 0.3, 0.3], [1.0, 0.5, 0.25]] },
      { kind: 'bloombrush', w: 1.5, s: [0.6, 1.15], pal: [[1.0, 0.35, 0.45]] },
      { kind: 'curlfrond', w: 1, s: [0.75, 1.25], pal: [[1.0, 0.45, 0.35]] },
      { kind: 'tubeCoral', w: 1, s: [0.7, 1.2], pal: [[1.0, 0.35, 0.3]] },
      { kind: 'sapling', w: 0.6, s: [0.75, 1.2], pal: [[1.0, 0.3, 0.3]], bark: [0.9, 0.85, 0.88] },
    ],
    grassDensity: 0.9,
    grassPal: [[0.85, 0.3, 0.3], [0.9, 0.4, 0.32]],
    grassHeight: 1.1,
    flowerChance: 0.14,
    flowerPal: [[1.0, 0.85, 0.3], [1.0, 0.4, 0.7]],
    rockChance: 0.1,
    rockPal: [[0.55, 0.4, 0.42]],
    reedPal: [[1.0, 0.5, 0.4]],
  },
  desert: {
    treeDensity: 0.2,
    groveAmp: 0.0,
    trees: [
      { kind: 'spinepod', w: 3, s: [0.8, 1.3], pal: [[0.4, 0.85, 0.75], [0.55, 0.9, 0.6], [0.85, 0.55, 0.9]], col: 0.35 },
      { kind: 'crystalSpire', w: 0.5, s: [0.5, 0.9], pal: [[1.0, 0.6, 0.3], [1.0, 0.45, 0.6]], col: 0.8 },
    ],
    underDensity: 0.3,
    under: [
      { kind: 'agave', w: 2, s: [0.7, 1.3], pal: [[0.5, 0.95, 0.8], [0.85, 0.6, 1.0]] },
      { kind: 'tubeCoral', w: 1.5, s: [0.7, 1.15], pal: [[1.0, 0.55, 0.3], [1.0, 0.4, 0.5]] },
      { kind: 'shard', w: 0.6, s: [0.6, 1.1], pal: [[0.45, 0.2, 0.18]] },
    ],
    grassDensity: 0.08,
    grassPal: [[0.85, 0.55, 0.35]],
    grassHeight: 0.8,
    flowerChance: 0.03,
    flowerPal: [[1.0, 0.6, 0.3]],
    rockChance: 0.16,
    rockPal: [[0.75, 0.36, 0.24]],
    reedPal: [[0.4, 1.0, 0.8]],
  },
  coast: {
    treeDensity: 0.55,
    groveAmp: 0.3,
    trees: [
      { kind: 'fanfrond', w: 3, s: [0.85, 1.3], pal: [[0.35, 0.9, 0.95], [0.5, 0.8, 1.0], [0.4, 1.0, 0.8]], bark: [0.85, 0.8, 0.95], col: 0.32 },
      { kind: 'crystalSpire', w: 0.7, s: [0.5, 1.0], pal: [[0.6, 0.75, 1.0], [0.9, 0.6, 1.0]], col: 0.8 },
      { kind: 'parasol', w: 0.6, s: [0.85, 1.15], pal: [[0.3, 0.85, 0.95]], bark: [0.8, 0.78, 0.92], col: 0.45 },
    ],
    underDensity: 0.5,
    under: [
      { kind: 'tubeCoral', w: 2.5, s: [0.7, 1.35], pal: [[1.0, 0.5, 0.75], [0.5, 0.9, 1.0], [1.0, 0.7, 0.4]] },
      { kind: 'crystalCluster', w: 1.2, s: [0.7, 1.3], pal: [[0.6, 0.8, 1.0], [0.9, 0.65, 1.0]] },
      { kind: 'puffbrush', w: 1, s: [0.6, 1.1], pal: [[0.35, 0.85, 0.95]] },
    ],
    grassDensity: 0.5,
    grassPal: [[0.35, 0.7, 0.8], [0.5, 0.65, 0.9]],
    grassHeight: 0.95,
    flowerChance: 0.12,
    flowerPal: [[1.0, 0.55, 0.8], [0.6, 0.9, 1.0]],
    rockChance: 0.07,
    rockPal: [[0.78, 0.74, 0.88]],
    reedPal: [[0.5, 0.9, 1.0]],
  },
  wetland: {
    treeDensity: 0.6,
    groveAmp: 0.2,
    trees: [
      { kind: 'weepglow', w: 3, s: [0.85, 1.2], pal: [[0.3, 1.0, 0.45], [0.25, 0.9, 0.6]], bark: [0.35, 0.4, 0.38], col: 0.5 },
      { kind: 'capspire', w: 2, s: [0.75, 1.3], pal: [[0.35, 1.0, 0.5], [0.8, 1.0, 0.35], [0.4, 0.9, 1.0]], col: 0.55 },
      { kind: 'coilwood', w: 0.8, s: [0.8, 1.2], pal: [[0.4, 1.0, 0.5]], col: 0.4 },
    ],
    underDensity: 0.75,
    under: [
      { kind: 'mushCluster', w: 3, s: [0.8, 1.6], pal: [[0.4, 1.0, 0.5], [0.85, 1.0, 0.4]] },
      { kind: 'bulbLantern', w: 2, s: [0.8, 1.3], pal: [[0.4, 1.0, 0.55], [0.6, 0.9, 1.0]] },
      { kind: 'curlfrond', w: 2, s: [0.75, 1.3], pal: [[0.3, 0.85, 0.5]] },
      { kind: 'puffbrush', w: 1, s: [0.6, 1.1], pal: [[0.25, 0.75, 0.45]] },
    ],
    grassDensity: 0.85,
    grassPal: [[0.22, 0.55, 0.38], [0.28, 0.62, 0.34]],
    grassHeight: 1.05,
    flowerChance: 0.15,
    flowerPal: [[0.6, 1.0, 0.6], [0.9, 1.0, 0.5]],
    rockChance: 0.04,
    rockPal: [[0.3, 0.4, 0.36]],
    reedPal: [[0.5, 1.0, 0.5], [0.8, 1.0, 0.4]],
  },
  wasteland: {
    treeDensity: 0.085,
    groveAmp: 0.0,
    trees: [
      { kind: 'boneSpire', w: 3, s: [0.7, 1.4], pal: [[0.95, 0.92, 0.86], [0.85, 0.82, 0.78]], col: 0.5 },
      { kind: 'crystalSpire', w: 1, s: [0.55, 1.15], pal: [[1.0, 0.3, 0.6], [0.9, 0.25, 1.0]], col: 0.85 },
      { kind: 'capspire', w: 0.3, s: [0.6, 0.9], pal: [[0.45, 0.4, 0.42]], col: 0.5 },
    ],
    underDensity: 0.26,
    under: [
      { kind: 'shard', w: 3, s: [0.6, 1.4], pal: [[0.16, 0.14, 0.18], [0.22, 0.15, 0.24]] },
      { kind: 'crystalCluster', w: 1.2, s: [0.7, 1.3], pal: [[1.0, 0.3, 0.55], [0.85, 0.3, 1.0]] },
      { kind: 'tubeCoral', w: 0.5, s: [0.6, 1.0], pal: [[0.6, 0.5, 0.55]] },
    ],
    grassDensity: 0.05,
    grassPal: [[0.45, 0.42, 0.45]],
    grassHeight: 0.7,
    flowerChance: 0.01,
    flowerPal: [[1.0, 0.35, 0.6]],
    rockChance: 0.18,
    rockPal: [[0.16, 0.15, 0.18], [0.22, 0.2, 0.24]],
    reedPal: [[1.0, 0.4, 0.7]],
  },
};

const OASIS_PALM: FloraEntry = {
  kind: 'fanfrond',
  w: 1,
  s: [0.85, 1.25],
  pal: [[0.25, 0.95, 0.75], [0.35, 0.85, 0.95]],
  bark: [0.7, 0.6, 0.55],
  col: 0.34,
};

const _dummy = new THREE.Object3D();
const _srgb = new THREE.Color();
const _white = new THREE.Color(1, 1, 1);
const _up = new THREE.Vector3(0, 1, 0);
const _slopeNorm = new THREE.Vector3();
const _slopeQuat = new THREE.Quaternion();
const _yawQuat = new THREE.Quaternion();
const _W: BiomeWeights = {
  meadow: 0,
  forest: 0,
  alpine: 0,
  desert: 0,
  coast: 0,
  autumn: 0,
  wetland: 0,
  jungle: 0,
  plains: 0,
  wasteland: 0,
  dominant: 'meadow',
};

function srgbColor(c: RGB, jitter = 1): THREE.Color {
  return new THREE.Color().setRGB(
    clamp(c[0] * jitter, 0, 1.4),
    clamp(c[1] * jitter, 0, 1.4),
    clamp(c[2] * jitter, 0, 1.4),
    THREE.SRGBColorSpace
  );
}

function palColor(pal: RGB[], r: number, jitterR: number): THREE.Color {
  const c = pal[Math.min(pal.length - 1, Math.floor(r * pal.length))];
  return srgbColor(c, 0.88 + jitterR * 0.24);
}

function pickBiome(w: BiomeWeights, r: number): BiomeId {
  let acc = 0;
  for (let i = 0; i < BIOME_ORDER.length; i++) {
    const id = BIOME_ORDER[i];
    acc += w[id];
    if (r <= acc) return id;
  }
  return w.dominant;
}

function pickEntry(entries: FloraEntry[], r: number, bankOk: boolean): FloraEntry | null {
  let total = 0;
  for (const e of entries) if (!e.bank || bankOk) total += e.w;
  if (total <= 0) return null;
  let t = r * total;
  for (const e of entries) {
    if (e.bank && !bankOk) continue;
    t -= e.w;
    if (t <= 0) return e;
  }
  return entries[entries.length - 1];
}

function neutralizeVertexColors(geo: THREE.BufferGeometry, boost: number): void {
  const col = geo.getAttribute('color') as THREE.BufferAttribute | undefined;
  if (!col) return;
  for (let i = 0; i < col.count; i++) {
    const l = (col.getX(i) * 0.3 + col.getY(i) * 0.59 + col.getZ(i) * 0.11) * boost;
    col.setXYZ(i, l, l, l);
  }
  col.needsUpdate = true;
}

function buildInstanced(
  geo: THREE.BufferGeometry,
  mat: THREE.Material,
  specs: InstanceSpec[],
  castShadow: boolean,
  useSecondary: boolean,
  slopeAlign: boolean
): THREE.InstancedMesh | null {
  if (specs.length === 0) return null;
  const mesh = new THREE.InstancedMesh(geo, mat, specs.length);
  mesh.castShadow = castShadow;
  mesh.receiveShadow = true;
  for (let i = 0; i < specs.length; i++) {
    const s = specs[i];
    _dummy.position.set(s.x, s.y, s.z);
    if (slopeAlign) {
      _slopeNorm.set(s.tiltX, 1.0, s.tiltZ).normalize();
      _slopeQuat.setFromUnitVectors(_up, _slopeNorm);
      _yawQuat.setFromAxisAngle(_up, s.rotY);
      _dummy.quaternion.copy(_slopeQuat).multiply(_yawQuat);
    } else {
      _dummy.rotation.set(s.tiltX, s.rotY, s.tiltZ);
    }
    _dummy.scale.set(s.sx, s.sy, s.sz);
    _dummy.updateMatrix();
    mesh.setMatrixAt(i, _dummy.matrix);
    mesh.setColorAt(i, useSecondary ? s.color2 ?? _white : s.color);
  }
  mesh.instanceMatrix.needsUpdate = true;
  if (mesh.instanceColor) mesh.instanceColor.needsUpdate = true;
  mesh.computeBoundingSphere();
  return mesh;
}

/** Cached per-chunk height & biome field (one terrain evaluation per grid vertex) */
class ChunkField {
  public readonly N: number;
  private readonly M: number;
  public readonly x0: number;
  public readonly z0: number;
  private readonly cell: number;
  private readonly heights: Float32Array;
  private readonly weights: Float32Array;
  private readonly dominant: Uint8Array;
  public minHeight = Infinity;

  constructor(originX: number, originZ: number, segs: number, cell: number) {
    this.N = segs + 1;
    this.M = segs + 3;
    this.cell = cell;
    this.x0 = originX - CHUNK_SIZE * 0.5;
    this.z0 = originZ - CHUNK_SIZE * 0.5;
    this.heights = new Float32Array(this.M * this.M);
    this.weights = new Float32Array(this.N * this.N * 10);
    this.dominant = new Uint8Array(this.N * this.N);

    for (let j = -1; j <= this.N; j++) {
      const wz = this.z0 + j * cell;
      for (let i = -1; i <= this.N; i++) {
        const wx = this.x0 + i * cell;
        const w = sampleBiomeWeights(wx, wz);
        const h = getTerrainHeightWithWeights(wx, wz, w);
        this.heights[i + 1 + (j + 1) * this.M] = h;
        if (i >= 0 && j >= 0 && i < this.N && j < this.N) {
          const o = (i + j * this.N) * 10;
          for (let b = 0; b < 10; b++) this.weights[o + b] = w[BIOME_ORDER[b]];
          this.dominant[i + j * this.N] = BIOME_ORDER.indexOf(w.dominant);
          if (h < this.minHeight) this.minHeight = h;
        }
      }
    }
  }

  public H(i: number, j: number): number {
    return this.heights[i + 1 + (j + 1) * this.M];
  }

  public vertexNormal(i: number, j: number, out: [number, number, number]): void {
    const nx = this.H(i - 1, j) - this.H(i + 1, j);
    const ny = 2.0 * this.cell;
    const nz = this.H(i, j - 1) - this.H(i, j + 1);
    const inv = 1.0 / Math.hypot(nx, ny, nz);
    out[0] = nx * inv;
    out[1] = ny * inv;
    out[2] = nz * inv;
  }

  public vertexWeights(i: number, j: number, out: BiomeWeights): BiomeWeights {
    const o = (i + j * this.N) * 10;
    for (let b = 0; b < 10; b++) out[BIOME_ORDER[b]] = this.weights[o + b];
    out.dominant = BIOME_ORDER[this.dominant[i + j * this.N]];
    return out;
  }

  public weightsAt(wx: number, wz: number, out: BiomeWeights): BiomeWeights {
    const i = clamp(Math.round((wx - this.x0) / this.cell), 0, this.N - 1);
    const j = clamp(Math.round((wz - this.z0) / this.cell), 0, this.N - 1);
    return this.vertexWeights(i, j, out);
  }

  /** Exact rendered-triangle height (and optional normal) from the cached grid */
  public sample(wx: number, wz: number, out: [number, number, number] | null): number {
    const lx = (wx - this.x0) / this.cell;
    const lz = (wz - this.z0) / this.cell;
    if (lx < -1 || lz < -1 || lx >= this.N || lz >= this.N) {
      return sampleRenderedTerrain(wx, wz, out, this.cell);
    }
    const i = Math.floor(lx);
    const j = Math.floor(lz);
    const fx = lx - i;
    const fz = lz - j;
    const hB = this.H(i + 1, j);
    const hC = this.H(i, j + 1);
    let h: number;
    let dhdx: number;
    let dhdz: number;
    if (fx + fz <= 1.0) {
      const hA = this.H(i, j);
      h = hA + fx * (hB - hA) + fz * (hC - hA);
      dhdx = (hB - hA) / this.cell;
      dhdz = (hC - hA) / this.cell;
    } else {
      const hD = this.H(i + 1, j + 1);
      h = hD + (1.0 - fx) * (hC - hD) + (1.0 - fz) * (hB - hD);
      dhdx = (hD - hC) / this.cell;
      dhdz = (hD - hB) / this.cell;
    }
    if (out) {
      const inv = 1.0 / Math.hypot(dhdx, 1.0, dhdz);
      out[0] = -dhdx * inv;
      out[1] = inv;
      out[2] = -dhdz * inv;
    }
    return h;
  }
}

export class ChunkManager {
  private readonly scene: THREE.Scene;
  private readonly foliage: FoliageLibrary;
  private readonly alien: AlienFloraLibrary;
  private readonly water: WaterSystem;
  private readonly terrainMat: THREE.MeshStandardMaterial;
  private readonly distantTerrainMat: THREE.MeshStandardMaterial;
  private readonly distantMesh: THREE.Mesh;
  private readonly terrainUniforms: TerrainShaderUniforms;
  private readonly kinds: Record<KindId, KindDef>;

  private readonly chunks = new Map<string, TerrainChunk>();
  private readonly pendingQueue: Array<{ cx: number; cz: number; dist2: number }> = [];
  private readonly shrines: THREE.Group[] = [];
  private readonly chunkRadius: number;
  private readonly segs: number;
  private readonly cellSize: number;
  private readonly isMobile: boolean;
  private densityScale = 1.0;

  private lastCenterCx = Number.NaN;
  private lastCenterCz = Number.NaN;

  constructor(
    scene: THREE.Scene,
    foliage: FoliageLibrary,
    water: WaterSystem,
    isMobile: boolean,
    anisotropy: number
  ) {
    this.scene = scene;
    this.foliage = foliage;
    this.water = water;
    this.isMobile = isMobile;
    this.chunkRadius = isMobile ? 3 : 5;
    this.segs = isMobile ? 36 : 48;
    this.cellSize = CHUNK_SIZE / this.segs;
    setActiveTerrainCellSize(this.cellSize);

    this.alien = new AlienFloraLibrary();

    // Alien bark & tintable props: neutral bases so every species takes its own alien hue
    foliage.barkMat.color.setRGB(0.92, 0.9, 0.98);
    foliage.birchBarkMat.color.setRGB(1, 1, 1);
    neutralizeVertexColors(foliage.cactusGeo, 1.7);
    neutralizeVertexColors(foliage.agaveGeo, 1.7);
    neutralizeVertexColors(foliage.reedGeo, 1.8);
    neutralizeVertexColors(foliage.lilyGeo, 1.8);

    const f = foliage;
    const a = this.alien;
    this.kinds = {
      spirePine: { geo: f.pineCanopyGeo, mat: f.pineCanopyMat, trunkGeo: f.pineTrunkGeo, trunkMat: f.barkMat, group: 'main', cast: true, slopeAlign: false },
      frostPine: { geo: f.snowPineCanopyGeo, mat: f.snowPineCanopyMat, trunkGeo: f.snowPineTrunkGeo, trunkMat: f.barkMat, group: 'main', cast: true, slopeAlign: false },
      parasol: { geo: f.oakCanopyGeo, mat: f.broadleafCanopyMat, trunkGeo: f.oakTrunkGeo, trunkMat: f.barkMat, group: 'main', cast: true, slopeAlign: false },
      blushwood: { geo: f.birchCanopyGeo, mat: f.deciduousCanopyMat, trunkGeo: f.birchTrunkGeo, trunkMat: f.birchBarkMat, group: 'main', cast: true, slopeAlign: false },
      fanfrond: { geo: f.palmCanopyGeo, mat: f.frondMat, trunkGeo: f.palmTrunkGeo, trunkMat: f.barkMat, group: 'main', cast: true, slopeAlign: false },
      weepglow: { geo: f.willowCanopyGeo, mat: f.deciduousCanopyMat, trunkGeo: f.willowTrunkGeo, trunkMat: f.barkMat, group: 'main', cast: true, slopeAlign: false },
      spinepod: { geo: f.cactusGeo, mat: f.rockMat, group: 'main', cast: true, slopeAlign: false },
      capspire: { geo: a.capspireGeo, mat: a.organicMat, group: 'main', cast: true, slopeAlign: false },
      coilwood: { geo: a.coilwoodGeo, mat: a.organicMat, group: 'main', cast: true, slopeAlign: false },
      crystalSpire: { geo: a.crystalSpireGeo, mat: a.crystalMat, group: 'main', cast: true, slopeAlign: false },
      boneSpire: { geo: a.boneSpireGeo, mat: a.organicMat, group: 'main', cast: true, slopeAlign: false },
      sapling: { geo: f.saplingCanopyGeo, mat: f.deciduousCanopyMat, trunkGeo: f.saplingTrunkGeo, trunkMat: f.barkMat, group: 'under', cast: true, slopeAlign: false },
      puffbrush: { geo: f.bushGeo, mat: f.bushMat, group: 'under', cast: true, slopeAlign: true },
      bloombrush: { geo: f.flowerBushGeo, mat: f.flowerBushMat, group: 'under', cast: true, slopeAlign: true },
      curlfrond: { geo: f.fernGeo, mat: f.fernMat, group: 'under', cast: false, slopeAlign: true },
      agave: { geo: f.agaveGeo, mat: f.rockMat, group: 'under', cast: true, slopeAlign: true },
      mushCluster: { geo: a.mushClusterGeo, mat: a.smallMat, group: 'under', cast: true, slopeAlign: true },
      bulbLantern: { geo: a.bulbGeo, mat: a.smallMat, group: 'under', cast: false, slopeAlign: false },
      tubeCoral: { geo: a.tubeCoralGeo, mat: a.smallMat, group: 'under', cast: true, slopeAlign: true },
      crystalCluster: { geo: a.crystalClusterGeo, mat: a.crystalMat, group: 'under', cast: true, slopeAlign: true },
      shard: { geo: a.shardGeo, mat: a.crystalMat, group: 'under', cast: true, slopeAlign: true },
      log: { geo: f.logGeo, mat: f.barkMat, group: 'under', cast: true, slopeAlign: true },
      reed: { geo: f.reedGeo, mat: f.reedMat, group: 'under', cast: false, slopeAlign: false },
      lily: { geo: f.lilyGeo, mat: f.reedMat, group: 'under', cast: false, slopeAlign: false },
      rock: { geo: f.rockGeo, mat: f.rockMat, group: 'main', cast: true, slopeAlign: true },
      grass: { geo: f.grassGeo, mat: f.grassMat, group: 'detail', cast: false, slopeAlign: true },
      flower: { geo: f.flowerGeo, mat: f.flowerMat, group: 'detail', cast: false, slopeAlign: true },
    };

    this.terrainUniforms = {
      uTime: { value: 0 },
      uSunDir: { value: new THREE.Vector3(0.4, 0.65, -0.65) },
      uSunColor: { value: new THREE.Color(0xfff4de) },
      uDayFactor: { value: 1 },
      uFocusPos: { value: new THREE.Vector3(0, 0, 18) },
      uInnerRadius: { value: (this.chunkRadius - 0.35) * CHUNK_SIZE },
      uNightGlow: { value: 0 },
    };

    this.terrainMat = createTerrainMaterial(this.terrainUniforms, anisotropy, false);
    this.distantTerrainMat = createTerrainMaterial(this.terrainUniforms, anisotropy, true);

    this.distantMesh = this.buildHorizonTerrain();
    this.scene.add(this.distantMesh);

    for (const biome of BIOME_LIST) {
      const lx = biome.landmark.x + 3.9;
      const lz = biome.landmark.z - 4.3;
      const ly = getRenderedTerrainHeight(lx, lz, this.cellSize);
      if (ly > WATER_LEVEL + 0.35) {
        const shrine = this.foliage.createLandmarkShrine(lx, lz);
        this.scene.add(shrine);
        this.shrines.push(shrine);
      }
    }
  }

  public updateAtmosphere(elapsed: number, atmo: AtmosphereState, playerPos: THREE.Vector3): void {
    this.terrainUniforms.uTime.value = elapsed;
    this.terrainUniforms.uSunDir.value.copy(atmo.sunDirection);
    this.terrainUniforms.uSunColor.value.copy(atmo.sunColor);
    this.terrainUniforms.uDayFactor.value = atmo.dayFactor;
    this.terrainUniforms.uFocusPos.value.copy(playerPos);
    this.terrainUniforms.uNightGlow.value = 0.03 + atmo.nightFactor * 1.05;
    this.alien.update(elapsed, atmo.nightFactor);
  }

  public setVegetationDensity(scale: number, playerX: number, playerZ: number): void {
    if (Math.abs(this.densityScale - scale) < 0.02) return;
    this.densityScale = scale;
    for (const chunk of this.chunks.values()) this.disposeChunk(chunk);
    this.chunks.clear();
    this.pendingQueue.length = 0;
    this.primeAround(playerX, playerZ);
  }

  private buildHorizonTerrain(): THREE.Mesh {
    const size = 2600;
    const segs = 180;
    const N = segs + 1;
    const step = size / segs;
    const geo = new THREE.PlaneGeometry(size, size, segs, segs);
    geo.rotateX(-Math.PI / 2);

    const pos = geo.attributes.position as THREE.BufferAttribute;
    const norm = geo.attributes.normal as THREE.BufferAttribute;
    const heights = new Float32Array(pos.count);
    const weightList: BiomeWeights[] = new Array(pos.count);

    for (let i = 0; i < pos.count; i++) {
      const wx = pos.getX(i);
      const wz = pos.getZ(i);
      const w = sampleBiomeWeights(wx, wz);
      weightList[i] = w;
      heights[i] = getTerrainHeightWithWeights(wx, wz, w);
      pos.setY(i, heights[i]);
    }

    const colors = new Float32Array(pos.count * 3);
    const glows = new Float32Array(pos.count * 4);
    const colOut: [number, number, number] = [0, 0, 0];
    const glowOut: [number, number, number, number] = [0, 0, 0, 0];

    for (let i = 0; i < pos.count; i++) {
      const ix = i % N;
      const iz = (i / N) | 0;
      const hL = heights[Math.max(0, ix - 1) + iz * N];
      const hR = heights[Math.min(N - 1, ix + 1) + iz * N];
      const hD = heights[ix + Math.max(0, iz - 1) * N];
      const hU = heights[ix + Math.min(N - 1, iz + 1) * N];
      const nx = hL - hR;
      const ny = 2.0 * step;
      const nz = hD - hU;
      const inv = 1.0 / Math.hypot(nx, ny, nz);
      norm.setXYZ(i, nx * inv, ny * inv, nz * inv);

      const wx = pos.getX(i);
      const wz = pos.getZ(i);
      computeTerrainColor(wx, wz, heights[i], ny * inv, weightList[i], colOut);
      _srgb.setRGB(colOut[0], colOut[1], colOut[2], THREE.SRGBColorSpace);
      colors[i * 3] = _srgb.r;
      colors[i * 3 + 1] = _srgb.g;
      colors[i * 3 + 2] = _srgb.b;
      computeTerrainGlow(wx, wz, heights[i], ny * inv, weightList[i], glowOut);
      glows[i * 4] = glowOut[0];
      glows[i * 4 + 1] = glowOut[1];
      glows[i * 4 + 2] = glowOut[2];
      glows[i * 4 + 3] = glowOut[3];
    }

    geo.setAttribute('color', new THREE.BufferAttribute(colors, 3));
    geo.setAttribute('aGlow', new THREE.BufferAttribute(glows, 4));
    geo.computeBoundingSphere();

    const mesh = new THREE.Mesh(geo, this.distantTerrainMat);
    mesh.receiveShadow = false;
    return mesh;
  }

  public primeAround(x: number, z: number): void {
    const ccx = Math.round(x / CHUNK_SIZE);
    const ccz = Math.round(z / CHUNK_SIZE);
    this.lastCenterCx = Number.NaN;
    // Burst-build the ~12 nearest chunks (guaranteeing the 3x3 under the explorer); the rest
    // stream in one per frame — roughly halves the up-front build vs. a full 5x5 block
    this.update(x, z, true);
    for (let dz = -1; dz <= 1; dz++) {
      for (let dx = -1; dx <= 1; dx++) {
        const cx = ccx + dx;
        const cz = ccz + dz;
        const key = `${cx},${cz}`;
        if (!this.chunks.has(key)) {
          const chunk = this.generateChunk(cx, cz);
          this.chunks.set(key, chunk);
          this.scene.add(chunk.group);
        }
      }
    }
    this.updateLodVisibility(ccx, ccz);
  }

  public update(playerX: number, playerZ: number, burst = false): void {
    const ccx = Math.round(playerX / CHUNK_SIZE);
    const ccz = Math.round(playerZ / CHUNK_SIZE);

    if (ccx !== this.lastCenterCx || ccz !== this.lastCenterCz) {
      this.lastCenterCx = ccx;
      this.lastCenterCz = ccz;
      const r = this.chunkRadius;
      const needed = new Set<string>();
      this.pendingQueue.length = 0;
      for (let dz = -r; dz <= r; dz++) {
        for (let dx = -r; dx <= r; dx++) {
          const d2 = dx * dx + dz * dz;
          if (d2 > r * r + 2) continue;
          const cx = ccx + dx;
          const cz = ccz + dz;
          const key = `${cx},${cz}`;
          needed.add(key);
          if (!this.chunks.has(key)) this.pendingQueue.push({ cx, cz, dist2: d2 });
        }
      }
      this.pendingQueue.sort((a, b) => a.dist2 - b.dist2);
      for (const [key, chunk] of this.chunks.entries()) {
        if (!needed.has(key)) {
          this.disposeChunk(chunk);
          this.chunks.delete(key);
        }
      }
      this.updateLodVisibility(ccx, ccz);
    }

    const budget = burst ? 12 : 1;
    let built = 0;
    while (this.pendingQueue.length > 0 && built < budget) {
      const next = this.pendingQueue.shift()!;
      const key = `${next.cx},${next.cz}`;
      if (this.chunks.has(key)) continue;
      const chunk = this.generateChunk(next.cx, next.cz);
      this.chunks.set(key, chunk);
      this.scene.add(chunk.group);
      const dist = Math.hypot(next.cx - this.lastCenterCx, next.cz - this.lastCenterCz);
      chunk.detailGroup.visible = dist <= 2.65;
      chunk.understoryGroup.visible = dist <= 4.15;
      built++;
    }
  }

  private updateLodVisibility(ccx: number, ccz: number): void {
    for (const chunk of this.chunks.values()) {
      const dist = Math.hypot(chunk.cx - ccx, chunk.cz - ccz);
      chunk.detailGroup.visible = dist <= 2.65;
      chunk.understoryGroup.visible = dist <= 4.15;
    }
  }

  public resolveCollisions(x: number, z: number, playerRadius = 0.4): [number, number] {
    const ccx = Math.round(x / CHUNK_SIZE);
    const ccz = Math.round(z / CHUNK_SIZE);
    let rx = x;
    let rz = z;
    for (let dz = -1; dz <= 1; dz++) {
      for (let dx = -1; dx <= 1; dx++) {
        const chunk = this.chunks.get(`${ccx + dx},${ccz + dz}`);
        if (!chunk) continue;
        const cols = chunk.colliders;
        for (let i = 0; i < cols.length; i++) {
          const c = cols[i];
          const ox = rx - c.x;
          const oz = rz - c.z;
          const minDist = c.r + playerRadius;
          const d2 = ox * ox + oz * oz;
          if (d2 < minDist * minDist && d2 > 0.00001) {
            const d = Math.sqrt(d2);
            const push = minDist - d;
            rx += (ox / d) * push;
            rz += (oz / d) * push;
          }
        }
      }
    }
    return [rx, rz];
  }

  /**
   * Keep tall canopy out of each landmark's camera view: a capsule running from the
   * landmark back toward where the 3rd-person camera (and the opening fly-in) sits.
   */
  private blocksLandmarkView(wx: number, wz: number): boolean {
    for (let i = 0; i < BIOME_LIST.length; i++) {
      const b = BIOME_LIST[i];
      const lm = b.landmark;
      const bx = Math.sin(lm.yaw);
      const bz = Math.cos(lm.yaw);
      const dx = wx - lm.x;
      const dz = wz - lm.z;
      const along = clamp(dx * bx + dz * bz, 0, 22);
      const px = dx - bx * along;
      const pz = dz - bz * along;
      const radius = b.id === 'meadow' ? 14.5 : 10.5;
      if (px * px + pz * pz < radius * radius) return true;
    }
    return false;
  }

  private isNearLandmark(wx: number, wz: number, clearance: number): boolean {
    const c2 = clearance * clearance;
    for (let i = 0; i < BIOME_LIST.length; i++) {
      const lm = BIOME_LIST[i].landmark;
      const dx = wx - (lm.x + 1.2);
      const dz = wz - (lm.z - 1.5);
      if (dx * dx + dz * dz < c2) return true;
    }
    return false;
  }

  private generateChunk(cx: number, cz: number): TerrainChunk {
    const key = `${cx},${cz}`;
    const originX = cx * CHUNK_SIZE;
    const originZ = cz * CHUNK_SIZE;
    const segs = this.segs;
    const cell = this.cellSize;
    const dens = this.densityScale;
    const half = CHUNK_SIZE * 0.5;

    const group = new THREE.Group();
    const understoryGroup = new THREE.Group();
    const detailGroup = new THREE.Group();
    group.add(understoryGroup);
    group.add(detailGroup);

    // 1. Terrain mesh from the cached field (exact seamless grid)
    const field = new ChunkField(originX, originZ, segs, cell);
    const N = field.N;
    const terrainGeo = new THREE.PlaneGeometry(CHUNK_SIZE, CHUNK_SIZE, segs, segs);
    terrainGeo.rotateX(-Math.PI / 2);
    const pos = terrainGeo.attributes.position as THREE.BufferAttribute;
    const norm = terrainGeo.attributes.normal as THREE.BufferAttribute;
    const uvs = terrainGeo.attributes.uv as THREE.BufferAttribute;
    const colors = new Float32Array(pos.count * 3);
    const glows = new Float32Array(pos.count * 4);
    const colOut: [number, number, number] = [0, 0, 0];
    const glowOut: [number, number, number, number] = [0, 0, 0, 0];
    const nrm: [number, number, number] = [0, 1, 0];

    for (let i = 0; i < pos.count; i++) {
      const ix = i % N;
      const iz = (i / N) | 0;
      const wx = field.x0 + ix * cell;
      const wz = field.z0 + iz * cell;
      const h = field.H(ix, iz);
      field.vertexNormal(ix, iz, nrm);
      const w = field.vertexWeights(ix, iz, _W);
      pos.setY(i, h);
      norm.setXYZ(i, nrm[0], nrm[1], nrm[2]);
      uvs.setXY(i, wx * 0.16, wz * 0.16);
      computeTerrainColor(wx, wz, h, nrm[1], w, colOut);
      _srgb.setRGB(colOut[0], colOut[1], colOut[2], THREE.SRGBColorSpace);
      colors[i * 3] = _srgb.r;
      colors[i * 3 + 1] = _srgb.g;
      colors[i * 3 + 2] = _srgb.b;
      computeTerrainGlow(wx, wz, h, nrm[1], w, glowOut);
      glows[i * 4] = glowOut[0];
      glows[i * 4 + 1] = glowOut[1];
      glows[i * 4 + 2] = glowOut[2];
      glows[i * 4 + 3] = glowOut[3];
    }
    terrainGeo.setAttribute('color', new THREE.BufferAttribute(colors, 3));
    terrainGeo.setAttribute('aGlow', new THREE.BufferAttribute(glows, 4));
    terrainGeo.computeBoundingSphere();

    const terrainMesh = new THREE.Mesh(terrainGeo, this.terrainMat);
    terrainMesh.position.set(originX, 0, originZ);
    terrainMesh.receiveShadow = true;
    group.add(terrainMesh);

    // 2. Luminous alien water (only when the chunk actually dips below sea level)
    let waterMesh: THREE.Mesh | null = null;
    if (field.minHeight < WATER_LEVEL + 0.05) {
      waterMesh = this.water.createChunkWater(originX, originZ, CHUNK_SIZE, 28, (x, z) =>
        field.sample(x, z, null)
      );
      if (waterMesh) group.add(waterMesh);
    }

    // 3. Alien flora
    const lists = new Map<KindId, InstanceSpec[]>();
    const push = (kind: KindId, spec: InstanceSpec) => {
      let arr = lists.get(kind);
      if (!arr) {
        arr = [];
        lists.set(kind, arr);
      }
      arr.push(spec);
    };
    const colliders: CircleCollider[] = [];
    const n: [number, number, number] = [0, 1, 0];

    // PASS A — canopy trees, giant fungi, crystal & bone spires
    const treeSteps = this.isMobile ? 11 : 14;
    const treeCell = CHUNK_SIZE / treeSteps;
    for (let gz = 0; gz < treeSteps; gz++) {
      for (let gx = 0; gx < treeSteps; gx++) {
        const idX = cx * treeSteps + gx;
        const idZ = cz * treeSteps + gz;
        const r1 = hashSeed(idX, idZ, 1);
        const r2 = hashSeed(idX, idZ, 2);
        const r3 = hashSeed(idX, idZ, 3);
        const r4 = hashSeed(idX, idZ, 4);
        const r5 = hashSeed(idX, idZ, 5);
        const r6 = hashSeed(idX, idZ, 6);

        const wx = originX - half + (gx + 0.14 + r1 * 0.72) * treeCell;
        const wz = originZ - half + (gz + 0.14 + r2 * 0.72) * treeCell;
        if (this.isNearLandmark(wx, wz, 6.2) || this.blocksLandmarkView(wx, wz)) continue;
        if (sampleTrailFactor(wx, wz) > 0.28) continue;

        const h = field.sample(wx, wz, n);
        const slope = 1.0 - n[1];
        if (h < WATER_LEVEL + 0.38 || slope > 0.36) continue;

        const W = field.weightsAt(wx, wz, _W);
        const oasisD = Math.hypot(wx - OASIS_X, wz - OASIS_Z);
        let entry: FloraEntry | null = null;
        let biome: BiomeId;
        let shrink = 1.0;

        if (W.desert > 0.3 && oasisD > 10.5 && oasisD < 38 && h > WATER_LEVEL + 0.25) {
          biome = 'desert';
          if (r3 < 0.78 * dens) entry = OASIS_PALM;
        } else {
          biome = pickBiome(W, r5);
          const fl = FLORA[biome];
          const grove =
            (Math.sin(wx * 0.048 + 0.6) * Math.cos(wz * 0.044 - 0.4) + Math.sin((wx + wz) * 0.026) * 0.6) *
              0.31 +
            0.52;
          let density = fl.treeDensity * (1.0 - fl.groveAmp + fl.groveAmp * grove * 1.9);
          if (h < WATER_LEVEL + 3.0 && (biome === 'meadow' || biome === 'wetland')) density += 0.12;
          if (biome === 'alpine') {
            density *= h < 44 ? 1 : h < 66 ? 0.5 : h < 84 ? 0.15 : 0;
            shrink = lerp(1.1, 0.72, clamp((h - 24) / 56, 0, 1));
          }
          if (biome === 'coast' && (h < 0.6 || h > 14.5)) continue;
          if (biome === 'desert' && (h > 25 || slope > 0.24)) continue;
          if (r3 > density * dens) continue;
          entry = pickEntry(fl.trees, r6, h < WATER_LEVEL + 3.0);
        }
        if (!entry) continue;

        const sc = lerp(entry.s[0], entry.s[1], r4) * shrink;
        const isCrystal = entry.kind === 'crystalSpire' || entry.kind === 'boneSpire';
        push(entry.kind, {
          x: wx,
          y: h,
          z: wz,
          rotY: r4 * Math.PI * 2 + r2,
          tiltX: (r1 - 0.5) * (isCrystal ? 0.18 : 0.045),
          tiltZ: (r2 - 0.5) * (isCrystal ? 0.18 : 0.045),
          sx: sc,
          sy: sc * (entry.squash ?? 1),
          sz: sc,
          color: palColor(entry.pal, r1, r2),
          color2: entry.bark ? srgbColor(entry.bark, 0.9 + r3 * 0.2) : null,
        });
        colliders.push({ x: wx, z: wz, r: (entry.col ?? 0.4) * sc });
        void biome;
      }
    }

    // PASS B — alien understory: puffbrush, fungi clusters, lantern bulbs, corals, crystals, ferns
    const bushSteps = this.isMobile ? 14 : 20;
    const bushCell = CHUNK_SIZE / bushSteps;
    for (let gz = 0; gz < bushSteps; gz++) {
      for (let gx = 0; gx < bushSteps; gx++) {
        const idX = cx * bushSteps + gx;
        const idZ = cz * bushSteps + gz;
        const r1 = hashSeed(idX, idZ, 41);
        const r2 = hashSeed(idX, idZ, 42);
        const r3 = hashSeed(idX, idZ, 43);
        const r4 = hashSeed(idX, idZ, 44);
        const r5 = hashSeed(idX, idZ, 45);
        const r6 = hashSeed(idX, idZ, 46);

        const wx = originX - half + (gx + r1) * bushCell;
        const wz = originZ - half + (gz + r2) * bushCell;
        if (this.isNearLandmark(wx, wz, 3.6)) continue;
        const trail = sampleTrailFactor(wx, wz);
        if (trail > 0.34) continue;

        const h = field.sample(wx, wz, n);
        const slope = 1.0 - n[1];
        if (h < WATER_LEVEL + 0.35 || slope > 0.4) continue;

        const W = field.weightsAt(wx, wz, _W);
        const biome = pickBiome(W, r5);
        const fl = FLORA[biome];
        let density = fl.underDensity + (trail > 0.05 ? 0.2 : 0) + (h < WATER_LEVEL + 3.2 ? 0.12 : 0);
        if (biome === 'alpine' && h > 54) density *= 0.2;
        if (r3 > clamp(density, 0, 0.95) * dens) continue;

        const entry = pickEntry(fl.under, r6, h < WATER_LEVEL + 3.0);
        if (!entry) continue;
        const sc = lerp(entry.s[0], entry.s[1], r4);
        const align = this.kinds[entry.kind].slopeAlign ? 0.7 : 0.0;
        push(entry.kind, {
          x: wx,
          y: h,
          z: wz,
          rotY: r4 * Math.PI * 2 + r1 * 3.0,
          tiltX: n[0] * align,
          tiltZ: n[2] * align,
          sx: sc,
          sy: sc * (entry.kind === 'puffbrush' || entry.kind === 'bloombrush' ? 0.8 + r1 * 0.35 : 1),
          sz: sc,
          color: palColor(entry.pal, r2, r1),
          color2: entry.bark ? srgbColor(entry.bark) : null,
        });
        if (entry.kind === 'crystalCluster' && sc > 1.1) colliders.push({ x: wx, z: wz, r: 0.35 * sc });
      }
    }

    // PASS C — lantern reeds, glowing lily pads & rooted boulders
    const propSteps = 14;
    const propCell = CHUNK_SIZE / propSteps;
    for (let gz = 0; gz < propSteps; gz++) {
      for (let gx = 0; gx < propSteps; gx++) {
        const idX = cx * propSteps + gx;
        const idZ = cz * propSteps + gz;
        const r1 = hashSeed(idX, idZ, 11);
        const r2 = hashSeed(idX, idZ, 12);
        const r3 = hashSeed(idX, idZ, 13);
        const r4 = hashSeed(idX, idZ, 14);
        const r5 = hashSeed(idX, idZ, 15);

        const wx = originX - half + (gx + r1) * propCell;
        const wz = originZ - half + (gz + r2) * propCell;
        if (this.isNearLandmark(wx, wz, 4.8)) continue;
        if (sampleTrailFactor(wx, wz) > 0.3) continue;

        const h = field.sample(wx, wz, n);
        const slope = 1.0 - n[1];
        const W = field.weightsAt(wx, wz, _W);
        const biome = pickBiome(W, r5);
        const fl = FLORA[biome];
        const oasisD = Math.hypot(wx - OASIS_X, wz - OASIS_Z);

        if (
          h < WATER_LEVEL - 0.18 &&
          h > WATER_LEVEL - 1.45 &&
          (W.wetland > 0.3 || W.jungle > 0.35 || W.meadow > 0.45 || (W.desert > 0.3 && oasisD < 28))
        ) {
          if (r3 < 0.42 * dens) {
            const sc = 0.82 + r4 * 0.52;
            push('lily', {
              x: wx,
              y: WATER_LEVEL,
              z: wz,
              rotY: r4 * Math.PI * 2,
              tiltX: 0,
              tiltZ: 0,
              sx: sc,
              sy: 1,
              sz: sc,
              color: palColor(fl.reedPal, r1, r2),
              color2: null,
            });
          }
          continue;
        }

        if (
          h > WATER_LEVEL - 0.38 &&
          h < WATER_LEVEL + 0.48 &&
          slope < 0.28 &&
          (W.wetland > 0.18 || W.meadow > 0.22 || W.jungle > 0.25 || W.autumn > 0.25 || W.desert > 0.3 || W.plains > 0.3)
        ) {
          if (r3 < (W.wetland > 0.3 ? 0.72 : 0.42) * dens) {
            const sc = 0.82 + r4 * 0.38;
            push('reed', {
              x: wx,
              y: Math.max(h, WATER_LEVEL - 0.22),
              z: wz,
              rotY: r4 * Math.PI * 2,
              tiltX: 0,
              tiltZ: 0,
              sx: sc,
              sy: sc,
              sz: sc,
              color: palColor(fl.reedPal, r2, r1),
              color2: null,
            });
          }
          continue;
        }

        if (h < WATER_LEVEL - 0.15) continue;

        let rockProb = slope > 0.25 ? 0.11 : 0;
        for (let b = 0; b < BIOME_ORDER.length; b++) {
          const id = BIOME_ORDER[b];
          rockProb += W[id] * FLORA[id].rockChance;
        }
        if (r3 < rockProb) {
          const big = r4 > 0.84;
          const sx = (big ? 1.45 : 0.52) + r1 * (big ? 1.15 : 0.58);
          const sy = sx * (0.52 + r2 * 0.48);
          const sz = sx * (0.78 + r4 * 0.4);
          let rockCol = palColor(fl.rockPal, r2, r1);
          if (biome === 'alpine' && h > 27) rockCol = srgbColor([0.82, 0.86, 0.98]);
          push('rock', {
            x: wx,
            y: h - slope * sx * 0.55,
            z: wz,
            rotY: r4 * Math.PI * 2,
            tiltX: n[0] * 0.35,
            tiltZ: n[2] * 0.35,
            sx,
            sy,
            sz,
            color: rockCol,
            color2: null,
          });
          if (sx > 0.92) colliders.push({ x: wx, z: wz, r: sx * 0.72 });
        }
      }
    }

    // PASS D — luminous moss-grass carpets & glowing alien blossoms
    const grassCandidates = Math.round((this.isMobile ? 520 : 1200) * dens);
    for (let i = 0; i < grassCandidates; i++) {
      const r1 = hashSeed(cx * 997 + i, cz * 577, 21);
      const r2 = hashSeed(cx * 997 + i, cz * 577, 22);
      const r3 = hashSeed(cx * 997 + i, cz * 577, 23);
      const r4 = hashSeed(cx * 997 + i, cz * 577, 24);
      const r5 = hashSeed(cx * 997 + i, cz * 577, 25);

      const wx = originX - half + r1 * CHUNK_SIZE;
      const wz = originZ - half + r2 * CHUNK_SIZE;
      const h = field.sample(wx, wz, n);
      if (h < WATER_LEVEL + 0.45 || n[1] < 0.78) continue;
      if (sampleTrailFactor(wx, wz) > 0.32) continue;

      const W = field.weightsAt(wx, wz, _W);
      const biome = pickBiome(W, r5);
      const fl = FLORA[biome];
      let density = fl.grassDensity;
      if (biome === 'alpine' && h > 18) density = 0;
      if (biome === 'coast' && h < 2.8) density *= 0.25;
      const oasisNear = W.desert > 0.3 && Math.hypot(wx - OASIS_X, wz - OASIS_Z) < 38;
      if (oasisNear) density = 0.95;
      if (r3 > density) continue;

      const gPal = oasisNear ? FLORA.meadow.grassPal : fl.grassPal;
      const sx = 0.88 + r4 * 0.52;
      const sy = (0.72 + r3 * 0.56) * (oasisNear ? 1.0 : fl.grassHeight);
      push('grass', {
        x: wx,
        y: h,
        z: wz,
        rotY: r4 * Math.PI * 2,
        tiltX: n[0] * 0.78,
        tiltZ: n[2] * 0.78,
        sx,
        sy,
        sz: sx,
        color: palColor(gPal, r4, r1),
        color2: null,
      });

      if (r4 > 1.0 - fl.flowerChance) {
        const fPick = hashSeed(i, cx + cz * 31, 29);
        const fx = wx + 0.18;
        const fz = wz - 0.14;
        const fh = field.sample(fx, fz, null);
        const fScale = 0.8 + fPick * 0.38;
        push('flower', {
          x: fx,
          y: fh,
          z: fz,
          rotY: fPick * Math.PI * 2,
          tiltX: n[0] * 0.75,
          tiltZ: n[2] * 0.75,
          sx: fScale,
          sy: fScale,
          sz: fScale,
          color: palColor(fl.flowerPal, fPick, r3),
          color2: null,
        });
      }
    }

    // 4. Batch everything into GPU instanced meshes
    const instancedMeshes: THREE.InstancedMesh[] = [];
    for (const [kind, specs] of lists) {
      const def = this.kinds[kind];
      const target = def.group === 'main' ? group : def.group === 'under' ? understoryGroup : detailGroup;
      if (def.trunkGeo && def.trunkMat) {
        const trunk = buildInstanced(def.trunkGeo, def.trunkMat, specs, true, true, false);
        if (trunk) {
          target.add(trunk);
          instancedMeshes.push(trunk);
        }
      }
      const mesh = buildInstanced(def.geo, def.mat, specs, def.cast, false, def.slopeAlign);
      if (mesh) {
        target.add(mesh);
        instancedMeshes.push(mesh);
      }
    }

    return {
      cx,
      cz,
      key,
      group,
      understoryGroup,
      detailGroup,
      terrainGeo,
      waterMesh,
      instancedMeshes,
      colliders,
    };
  }

  private disposeChunk(chunk: TerrainChunk): void {
    this.scene.remove(chunk.group);
    chunk.terrainGeo.dispose();
    if (chunk.waterMesh) chunk.waterMesh.geometry.dispose();
    for (const im of chunk.instancedMeshes) im.dispose();
  }

  public dispose(): void {
    for (const chunk of this.chunks.values()) this.disposeChunk(chunk);
    this.chunks.clear();
    for (const s of this.shrines) this.scene.remove(s);
    this.distantMesh.geometry.dispose();
    this.terrainMat.dispose();
    this.distantTerrainMat.dispose();
  }
}
