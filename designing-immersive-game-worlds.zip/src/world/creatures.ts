import * as THREE from 'three';

/**
 * Procedural alien creature anatomy + instanced "part batches".
 * Every species is rigged from a handful of InstancedMeshes, so dozens of animated
 * animals render in just a few draw calls.
 */

export interface CreatureMaterials {
  skin: THREE.MeshStandardMaterial;
  wing: THREE.MeshStandardMaterial;
  glow: THREE.MeshBasicMaterial;
  jelly: THREE.MeshBasicMaterial;
  night: { value: number };
}

function addRim(mat: THREE.MeshStandardMaterial, night: { value: number }, base: number, nightAmt: number): void {
  const programKey = `creature-rim|${base}|${nightAmt}`;
  mat.customProgramCacheKey = () => programKey;
  mat.onBeforeCompile = (shader) => {
    shader.uniforms.uCreatureNight = night;
    shader.fragmentShader = shader.fragmentShader
      .replace(
        '#include <common>',
        `#include <common>
        uniform float uCreatureNight;`
      )
      .replace(
        '#include <emissivemap_fragment>',
        `#include <emissivemap_fragment>
        float cRim = pow(1.0 - clamp(abs(dot(normal, normalize(vViewPosition))), 0.0, 1.0), 2.5);
        totalEmissiveRadiance += diffuseColor.rgb * cRim * (${base.toFixed(3)} + ${nightAmt.toFixed(3)} * uCreatureNight);`
      );
  };
}

export function createCreatureMaterials(): CreatureMaterials {
  const night = { value: 0 };
  const skin = new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.56, metalness: 0.06 });
  addRim(skin, night, 0.08, 0.55);
  const wing = new THREE.MeshStandardMaterial({
    color: 0xffffff,
    roughness: 0.5,
    metalness: 0.04,
    side: THREE.DoubleSide,
  });
  addRim(wing, night, 0.1, 0.6);
  const glow = new THREE.MeshBasicMaterial({ color: 0xffffff });
  const jelly = new THREE.MeshBasicMaterial({
    color: 0xffffff,
    transparent: true,
    opacity: 0.5,
    depthWrite: false,
    side: THREE.DoubleSide,
  });
  return { skin, wing, glow, jelly, night };
}

const _white = new THREE.Color(1, 1, 1);

export class PartBatch {
  public readonly mesh: THREE.InstancedMesh;
  private readonly per: number;

  constructor(
    scene: THREE.Scene,
    geo: THREE.BufferGeometry,
    mat: THREE.Material,
    maxCreatures: number,
    per: number,
    castShadow: boolean
  ) {
    this.per = per;
    this.mesh = new THREE.InstancedMesh(geo, mat, Math.max(1, maxCreatures * per));
    this.mesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);
    this.mesh.frustumCulled = false;
    this.mesh.castShadow = castShadow;
    this.mesh.receiveShadow = false;
    this.mesh.setColorAt(0, _white);
    this.mesh.count = 0;
    scene.add(this.mesh);
  }

  public set(slot: number, sub: number, m: THREE.Matrix4, color: THREE.Color): void {
    const i = slot * this.per + sub;
    this.mesh.setMatrixAt(i, m);
    this.mesh.setColorAt(i, color);
  }

  public commit(slots: number): void {
    this.mesh.count = slots * this.per;
    this.mesh.instanceMatrix.needsUpdate = true;
    if (this.mesh.instanceColor) this.mesh.instanceColor.needsUpdate = true;
  }
}

type V3 = [number, number, number];

function sph(
  r: number,
  ws: number,
  hs: number,
  scale: V3,
  pos: V3,
  thetaLen = Math.PI
): THREE.BufferGeometry {
  const g = new THREE.SphereGeometry(r, ws, hs, 0, Math.PI * 2, 0, thetaLen);
  g.scale(scale[0], scale[1], scale[2]);
  g.translate(pos[0], pos[1], pos[2]);
  return g;
}

function xform(g: THREE.BufferGeometry, pos: V3, rot: V3, scale: V3 = [1, 1, 1]): THREE.BufferGeometry {
  g.applyMatrix4(
    new THREE.Matrix4().compose(
      new THREE.Vector3(pos[0], pos[1], pos[2]),
      new THREE.Quaternion().setFromEuler(new THREE.Euler(rot[0], rot[1], rot[2])),
      new THREE.Vector3(scale[0], scale[1], scale[2])
    )
  );
  return g;
}

function cone(r: number, h: number, seg: number): THREE.ConeGeometry {
  return new THREE.ConeGeometry(r, h, seg);
}

function mergeSimple(geos: THREE.BufferGeometry[]): THREE.BufferGeometry {
  const positions: number[] = [];
  const normals: number[] = [];
  for (const src of geos) {
    const g = src.index ? src.toNonIndexed() : src;
    if (!g.attributes.normal) g.computeVertexNormals();
    const p = g.attributes.position as THREE.BufferAttribute;
    const n = g.attributes.normal as THREE.BufferAttribute;
    for (let i = 0; i < p.count; i++) {
      positions.push(p.getX(i), p.getY(i), p.getZ(i));
      normals.push(n.getX(i), n.getY(i), n.getZ(i));
    }
    if (g !== src) g.dispose();
    src.dispose();
  }
  const out = new THREE.BufferGeometry();
  out.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
  out.setAttribute('normal', new THREE.Float32BufferAttribute(normals, 3));
  out.computeBoundingSphere();
  return out;
}

/** Unit limb segment: top at origin, extends 1 unit along -Y (scaled per use) */
export function unitSegment(radial = 7): THREE.BufferGeometry {
  const g = new THREE.CylinderGeometry(1, 0.72, 1, radial, 1);
  g.translate(0, -0.5, 0);
  return g;
}

function prismCrystal(r: number, h: number, pos: V3, rot: V3): THREE.BufferGeometry {
  const prism = new THREE.CylinderGeometry(r, r, h, 6, 1);
  prism.translate(0, h * 0.5, 0);
  const tip = new THREE.ConeGeometry(r, r * 2.0, 6);
  tip.translate(0, h + r, 0);
  return xform(mergeSimple([prism, tip]), pos, rot);
}

function wingStrip(
  lead: (t: number) => number,
  trail: (t: number) => number,
  span: number,
  steps: number,
  side: 1 | -1
): THREE.BufferGeometry {
  const positions: number[] = [];
  for (let k = 0; k < steps; k++) {
    const t0 = k / steps;
    const t1 = (k + 1) / steps;
    const x0 = t0 * span * side;
    const x1 = t1 * span * side;
    positions.push(x0, 0, lead(t0), x0, 0, trail(t0), x1, 0, lead(t1));
    positions.push(x0, 0, trail(t0), x1, 0, trail(t1), x1, 0, lead(t1));
  }
  const g = new THREE.BufferGeometry();
  g.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
  g.computeVertexNormals();
  return g;
}

/** Vexari Grazer — six-legged herd beast with glowing dorsal fins (~2.6m long) */
export function grazerGeos() {
  const body = mergeSimple([
    sph(1, 18, 12, [0.62, 0.55, 1.3], [0, 0, 0]),
    sph(1, 14, 10, [0.52, 0.44, 0.62], [0, 0.32, -0.3]),
    sph(1, 12, 8, [0.34, 0.3, 0.42], [0, 0.02, 1.15]),
    xform(cone(0.1, 0.8, 6), [0, 0.02, 1.62], [Math.PI / 2 + 0.3, 0, 0]),
  ]);
  const head = mergeSimple([
    sph(1, 14, 10, [0.24, 0.24, 0.5], [0, 0, -0.42]),
    xform(cone(0.15, 0.42, 8), [0, -0.06, -0.98], [-Math.PI / 2, 0, 0]),
    sph(1, 10, 6, [0.46, 0.32, 0.05], [0, 0.14, -0.12]),
    xform(cone(0.045, 0.5, 5), [0.13, 0.26, -0.28], [0.9, 0, -0.35]),
    xform(cone(0.045, 0.5, 5), [-0.13, 0.26, -0.28], [0.9, 0, 0.35]),
  ]);
  const eyes = mergeSimple([
    sph(0.045, 8, 6, [1, 1, 1], [0.17, 0.08, -0.6]),
    sph(0.045, 8, 6, [1, 1, 1], [-0.17, 0.08, -0.6]),
    sph(0.04, 8, 6, [1, 1, 1], [0.14, 0.14, -0.48]),
    sph(0.04, 8, 6, [1, 1, 1], [-0.14, 0.14, -0.48]),
  ]);
  const plateSpec: Array<[number, number]> = [
    [1.0, -0.55],
    [1.15, -0.12],
    [0.95, 0.32],
    [0.72, 0.7],
  ];
  const plates = mergeSimple(plateSpec.map(([s, z]) => sph(1, 10, 8, [0.035, 0.3 * s, 0.24 * s], [0, 0.52 + 0.06 * s, z])));
  return { body, head, eyes, plates };
}

/** Longstrider — tiny body hoisted on three immense stilt legs */
export function striderGeos() {
  const body = mergeSimple([
    sph(0.8, 16, 12, [1, 0.62, 1.1], [0, 0, 0]),
    sph(0.32, 10, 8, [1, 0.6, 1], [0, 0.42, 0]),
    xform(cone(0.12, 0.6, 5), [0.3, 0.55, 0.1], [0.2, 0, -0.4]),
    xform(cone(0.12, 0.6, 5), [-0.3, 0.55, -0.1], [-0.2, 0, 0.4]),
  ]);
  const ring = new THREE.TorusGeometry(0.84, 0.075, 6, 24);
  ring.rotateX(Math.PI / 2);
  ring.translate(0, -0.08, 0);
  const sac = sph(0.4, 12, 9, [1, 1.35, 1], [0, 0, 0]);
  return { body, ring, sac };
}

/** Skyjelly — floating translucent bell with a glowing heart */
export function jellyGeos() {
  const rim = new THREE.CylinderGeometry(0.82, 0.98, 0.26, 20, 1, true);
  rim.translate(0, -0.05, 0);
  const bell = mergeSimple([sph(1, 20, 10, [1, 0.75, 1], [0, 0, 0], Math.PI * 0.55), rim]);
  const core = sph(0.42, 12, 9, [1, 1.1, 1], [0, 0.32, 0]);
  return { bell, core };
}

/** Glidewing — manta-like sky ray with undulating two-part wings */
export function mantaGeos() {
  const body = mergeSimple([
    sph(1, 16, 8, [0.78, 0.2, 1.45], [0, 0, 0]),
    xform(cone(0.12, 0.6, 5), [0.42, 0, -1.45], [-Math.PI / 2, 0, 0]),
    xform(cone(0.12, 0.6, 5), [-0.42, 0, -1.45], [-Math.PI / 2, 0, 0]),
  ]);
  const wingInner = wingStrip((t) => -0.95 + 0.25 * t, (t) => 0.95 - 0.55 * t, 2.0, 4, 1);
  const wingOuter = wingStrip((t) => -0.7 + 0.8 * Math.pow(t, 1.4), (t) => 0.4 - 0.25 * t, 1.9, 4, 1);
  const tail = xform(cone(0.07, 3.2, 5), [0, 0, 3.2], [Math.PI / 2, 0, 0]);
  const eyes = mergeSimple([
    sph(0.07, 8, 6, [1, 1, 1], [0.34, 0.12, -1.12]),
    sph(0.07, 8, 6, [1, 1, 1], [-0.34, 0.12, -1.12]),
    sph(0.07, 8, 6, [1, 1, 1], [0, 0.02, 4.75]),
  ]);
  return { body, wingInner, wingOuter, tail, eyes };
}

/** Blobling — curious hopping jelly-critter with eye stalks */
export function blobGeos() {
  const body = sph(0.36, 18, 14, [1, 0.92, 1], [0, 0.33, 0]);
  const eye = sph(0.075, 10, 8, [1, 1, 1], [0, 0, 0]);
  return { body, eye };
}

/** Rift Wyrm — burrowing segmented serpent */
export function wyrmGeos() {
  const segment = sph(1, 12, 9, [1, 0.88, 1], [0, 0, 0]);
  const spike = cone(0.5, 1.6, 6);
  spike.translate(0, 0.8, 0);
  const head = mergeSimple([
    sph(1, 14, 10, [0.72, 0.58, 0.98], [0, 0, 0]),
    xform(cone(0.16, 0.9, 6), [0.3, -0.12, -0.95], [-Math.PI / 2 + 0.15, 0, 0.35]),
    xform(cone(0.16, 0.9, 6), [-0.3, -0.12, -0.95], [-Math.PI / 2 + 0.15, 0, -0.35]),
    sph(1, 10, 6, [0.5, 0.18, 0.7], [0, 0.42, 0.1]),
  ]);
  const eyes = mergeSimple([
    sph(0.07, 8, 6, [1, 1, 1], [0.36, 0.2, -0.62]),
    sph(0.07, 8, 6, [1, 1, 1], [-0.36, 0.2, -0.62]),
    sph(0.06, 8, 6, [1, 1, 1], [0.46, 0.08, -0.45]),
    sph(0.06, 8, 6, [1, 1, 1], [-0.46, 0.08, -0.45]),
  ]);
  return { segment, spike, head, eyes };
}

/** Titan Colossus — a walking hill, 30m+ tall, with a glowing spotted shell */
export function titanGeos() {
  const body = mergeSimple([
    sph(1, 24, 14, [9, 7.5, 12], [0, 0, 0], Math.PI * 0.6),
    sph(1, 20, 12, [7.4, 3.6, 10.6], [0, -0.6, 0]),
  ]);
  const head = mergeSimple([
    sph(1, 16, 12, [2.6, 2.3, 3.3], [0, 0, -2.2]),
    xform(cone(0.55, 4.5, 8), [1.6, 1.4, -1.6], [0.6, 0, -0.9]),
    xform(cone(0.55, 4.5, 8), [-1.6, 1.4, -1.6], [0.6, 0, 0.9]),
    sph(1, 12, 8, [1.3, 0.7, 1.6], [0, -1.3, -4.4]),
  ]);
  const eyes = mergeSimple([
    sph(0.38, 10, 8, [1, 1, 1], [1.3, 0.6, -4.6]),
    sph(0.38, 10, 8, [1, 1, 1], [-1.3, 0.6, -4.6]),
  ]);
  const spots: THREE.BufferGeometry[] = [];
  for (let i = 0; i < 22; i++) {
    const th = 0.22 + ((i * 0.618) % 1) * 0.85;
    const ph = i * 2.399;
    const r = 0.45 + ((i * 0.37) % 1) * 0.55;
    spots.push(
      sph(r, 8, 6, [1, 1, 1], [Math.sin(th) * Math.cos(ph) * 9.05, Math.cos(th) * 7.55, Math.sin(th) * Math.sin(ph) * 12.05])
    );
  }
  return { body, head, eyes, spots: mergeSimple(spots) };
}

/** Prism Crab — sideways-scuttling crab wearing a crown of glowing crystals */
export function crabGeos() {
  const body = sph(1, 14, 8, [0.52, 0.2, 0.42], [0, 0, 0]);
  const crystalParts: THREE.BufferGeometry[] = [];
  const specs: Array<[number, number, number, number, number, number]> = [
    [0.07, 0.42, 0, 0.12, 0, 0],
    [0.05, 0.3, 0.16, 0.1, 0.08, -0.35],
    [0.05, 0.28, -0.16, 0.1, -0.06, 0.35],
    [0.045, 0.24, 0.08, 0.1, 0.18, -0.2],
    [0.045, 0.26, -0.1, 0.1, -0.16, 0.25],
    [0.04, 0.2, 0.22, 0.08, -0.12, -0.5],
  ];
  for (const [r, h, x, y, z, tilt] of specs) crystalParts.push(prismCrystal(r, h, [x, y, z], [z * 1.5, 0, tilt]));
  const crystals = mergeSimple(crystalParts);
  const claw = mergeSimple([
    sph(1, 10, 8, [0.12, 0.1, 0.22], [0, 0, -0.1]),
    xform(cone(0.05, 0.22, 5), [0.04, 0, -0.38], [-Math.PI / 2, 0, 0]),
    xform(cone(0.045, 0.2, 5), [-0.04, 0, -0.36], [-Math.PI / 2, 0, 0]),
  ]);
  return { body, crystals, claw };
}

/** Glowfin — leaping luminous fish */
export function fishGeos() {
  const body = mergeSimple([
    sph(1, 14, 10, [0.14, 0.2, 0.5], [0, 0, 0]),
    xform(cone(0.1, 0.28, 4), [0, 0.22, 0.05], [0.4, 0, 0], [0.3, 1, 1]),
  ]);
  const tail = new THREE.BufferGeometry();
  tail.setAttribute(
    'position',
    new THREE.Float32BufferAttribute([0, 0, 0, 0, 0.22, 0.34, 0, -0.22, 0.34, 0, 0, 0, 0, -0.22, 0.34, 0, 0.22, 0.34], 3)
  );
  tail.computeVertexNormals();
  const stripe = sph(1, 12, 6, [0.15, 0.045, 0.42], [0, 0.03, 0]);
  return { body, tail, stripe };
}

/** Thornback — sleek prowling predator with a ridge of glowing spines */
export function thornGeos() {
  const body = mergeSimple([
    sph(1, 16, 12, [0.44, 0.42, 1.05], [0, 0, 0]),
    sph(1, 12, 10, [0.4, 0.38, 0.5], [0, 0.12, -0.55]),
  ]);
  const head = mergeSimple([
    sph(1, 14, 10, [0.26, 0.24, 0.42], [0, 0, -0.32]),
    xform(cone(0.12, 0.34, 6), [0, -0.12, -0.66], [-Math.PI / 2, 0, 0]),
    xform(cone(0.06, 0.55, 5), [0.14, 0.18, -0.2], [1.1, 0, -0.3]),
    xform(cone(0.06, 0.55, 5), [-0.14, 0.18, -0.2], [1.1, 0, 0.3]),
  ]);
  const spineParts: THREE.BufferGeometry[] = [];
  for (let i = 0; i < 7; i++) {
    const z = -0.75 + i * 0.25;
    spineParts.push(xform(cone(0.07, 0.42 - Math.abs(z) * 0.12, 5), [0, 0.42 - Math.abs(z) * 0.1, z], [0.5, 0, 0]));
  }
  const spines = mergeSimple(spineParts);
  const eyes = mergeSimple([
    sph(0.05, 8, 6, [1, 1, 1], [0.15, 0.08, -0.58]),
    sph(0.05, 8, 6, [1, 1, 1], [-0.15, 0.08, -0.58]),
  ]);
  return { body, head, spines, eyes };
}
