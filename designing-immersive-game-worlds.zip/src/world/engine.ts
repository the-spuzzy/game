import * as THREE from 'three';
import { EffectComposer } from 'three/examples/jsm/postprocessing/EffectComposer.js';
import { OutputPass } from 'three/examples/jsm/postprocessing/OutputPass.js';
import { RenderPass } from 'three/examples/jsm/postprocessing/RenderPass.js';
import { UnrealBloomPass } from 'three/examples/jsm/postprocessing/UnrealBloomPass.js';
import { CreatureCallKind, WorldAudio } from './audio';
import {
  BIOMES,
  BiomeId,
  WATER_LEVEL,
  WORLD_MAP_RADIUS,
  getRenderedTerrainHeight,
  getRenderedTerrainNormal,
  getSurfaceMaterial,
  sampleBiomeWeights,
} from './biomes';
import { ExplorerCharacter } from './character';
import { ChunkManager } from './chunkManager';
import {
  ABILITIES,
  AbilityId,
  ESSENCES,
  SPECIES_PREY_INFO,
  SlimeEvolutionState,
  TraitId,
  UserProfile,
  computeSlimeStats,
  emptyDiet,
  getAbilityCooldown,
  getActiveAccount,
} from './evolution';
import { FoliageLibrary } from './foliage';
import { GameMode, GAME_MODES, MatchState, clampMaxPlayers } from './modes';
import { clamp, lerp } from './noise';
import { AtmosphereParticles } from './particles';
import { DropAssignment, RosterEntry, getDropSpot } from './lobby';
import { NetworkAdapter } from './network';
import { EdiblePlantSystem, PlantInfo } from './plants';
import { RivalSystem } from './rivals';
import { WeatherSnapshot, WeatherSystem } from './weather';
import { SkySystem } from './sky';
import { WaterSystem } from './water';
import { TargetCreatureInfo, WildlifeSystem } from './wildlife';

export type CameraPreset = 'close' | 'balanced' | 'vista';
export type GraphicsQuality = 'high' | 'ultra';

export interface WorldHudSnapshot {
  x: number;
  y: number;
  z: number;
  bearingDeg: number; // 0 = N, 90 = E, 180 = S, 270 = W
  playerYaw: number;
  biome: BiomeId;
  altitude: number;
  timeOfDay: number; // 0..1
  timePaused: boolean;
  swimming: boolean;
  sprinting: boolean;
  gliding: boolean;
  discovered: BiomeId[];
  cameraPreset: CameraPreset;
  graphicsQuality: GraphicsQuality;
  muted: boolean;
  evo: SlimeEvolutionState;
  target: TargetCreatureInfo | null;
  attackCooldown: number;
  spitCooldown: number;
  combatFeed: string | null;
  damageFlash: number;
  damageSource: string | null;
  mode: GameMode;
  maxPlayers: number;
  match: MatchState;
  abilities: AbilityId[];
  abilityCooldowns: Record<AbilityId, number>;
  cloaked: boolean;
  weather: WeatherSnapshot;
  nearbyPlant: PlantInfo | null;
}

export interface WorldCallbacks {
  onHudUpdate: (snapshot: WorldHudSnapshot) => void;
  onBiomeEnter: (biome: BiomeId, isFirstDiscovery: boolean, altitude: number) => void;
  onEvolutionReady?: (evo: SlimeEvolutionState) => void;
  onProgressSaved?: (evo: SlimeEvolutionState, discovered: BiomeId[]) => void;
  onError?: (message: string) => void;
}

interface DeployedMine {
  mesh: THREE.Mesh;
  x: number;
  y: number;
  z: number;
  age: number;
  active: boolean;
  damage: number;
}

const ABILITY_KEYS: Record<string, AbilityId> = {
  KeyG: 'dash',
  KeyX: 'slam',
  KeyC: 'mines',
  KeyB: 'lance',
  KeyZ: 'cloak',
};

function emptyAbilityCooldowns(): Record<AbilityId, number> {
  const out = {} as Record<AbilityId, number>;
  for (const id of Object.keys(ABILITIES) as AbilityId[]) out[id] = 0;
  return out;
}

function defaultMatchState(mode: GameMode, maxPlayers: number): MatchState {
  const cfg = GAME_MODES[mode];
  return {
    mode,
    totalPlayers: maxPlayers,
    rivalsAlive: Math.max(0, maxPlayers - 1),
    playerAlive: true,
    matchOver: false,
    winner: null,
    playerWon: false,
    zoneRadius: cfg.zoneStartRadius,
    zoneTargetRadius: cfg.zoneStartRadius,
    zoneStage: 0,
    zoneTime: 0,
    zoneWarning: false,
    zoneClosesIn: 0,
    elapsed: 0,
    eliminations: 0,
    feed: null,
    realPlayers: 1,
    aiPlayers: Math.max(0, maxPlayers - 1),
    rosterNames: ['You'],
  };
}

function shortestAngleDiff(from: number, to: number): number {
  let d = ((to - from + Math.PI) % (Math.PI * 2)) - Math.PI;
  if (d < -Math.PI) d += Math.PI * 2;
  return d;
}

export class SolvaraWorldEngine {
  private readonly container: HTMLElement;
  private readonly renderer: THREE.WebGLRenderer;
  private readonly scene: THREE.Scene;
  private readonly camera: THREE.PerspectiveCamera;
  private composer: EffectComposer | null = null;
  private bloomPass: UnrealBloomPass | null = null;

  private readonly sky: SkySystem;
  private readonly water: WaterSystem;
  private readonly foliage: FoliageLibrary;
  private readonly chunks: ChunkManager;
  private readonly character: ExplorerCharacter;
  private readonly particles: AtmosphereParticles;
  private readonly wildlife: WildlifeSystem;
  private readonly rivals: RivalSystem;
  private readonly weather: WeatherSystem;
  private readonly plants: EdiblePlantSystem;
  private readonly mines: DeployedMine[] = [];
  private network: NetworkAdapter | null = null;
  private networkTimer = 0;
  public readonly audio: WorldAudio;

  private readonly callbacks: WorldCallbacks;
  private readonly isMobile: boolean;
  private graphicsQuality: GraphicsQuality;

  // Game mode: starts in live scenic vista behind title screen, transitions smoothly into 3rd-person
  private started = false;
  private introBlend = 1.0;
  private mode: GameMode = 'open-world';
  private maxPlayers = 8;
  private matchState: MatchState = defaultMatchState('open-world', 8);
  private matchOverAnnounced = false;
  private dropIntroTimer = 0;

  // Player state (exact rendered-terrain contact for the slime body)
  private readonly playerPos = new THREE.Vector3(0, 10.7, 18);
  private readonly playerVel = new THREE.Vector3(0, 0, 0);
  private playerYaw = 0.08;
  private grounded = true;
  private swimming = false;
  private wading = false;
  private landingImpact = 0;

  // Spore Slime Evolution & Combat state
  private evo: SlimeEvolutionState = computeSlimeStats(1, []);
  private attackCooldown = 0;
  private spitCooldown = 0;
  private combatFeed: string | null = null;
  private combatFeedTimer = 0;
  private damageFlash = 0;
  private damageSource: string | null = null;
  private camShake = 0;
  private gliding = false;
  private touchJumpHeld = false;
  private abilityCooldowns: Record<AbilityId, number> = emptyAbilityCooldowns();
  private cloakTimer = 0;
  private cloaked = false;
  private dashInvulnTimer = 0;

  // Unified desktop keyboard + iOS/Android virtual joystick inputs
  private readonly keys = new Set<string>();
  private joyX = 0;
  private joyY = 0; // -1 = forward, +1 = back
  private touchSprint = false;
  private jumpQueued = false;

  // 3rd-person spring-arm camera state (eye-line calibrated to 1.72m human + tall forest canopies!)
  private camYaw = 0.08;
  private camPitch = 0.21;
  private camDist = 5.2;
  private targetCamDist = 5.2;
  private shoulderOffset = 0.36;
  private cameraPreset: CameraPreset = 'balanced';
  private readonly smoothCamPos = new THREE.Vector3(0, 14, 24);
  private readonly smoothLookAt = new THREE.Vector3(0, 12.4, 15);
  private userOrbitCooldown = 0;

  // Time & Biome Discovery state
  private timeOfDay = 0.345; // Sunlit golden-morning angle for rich relief shadows & backlit foliage!
  private timePaused = false;
  private currentBiome: BiomeId = 'meadow';
  private biomeHoldTimer = 0;
  private candidateBiome: BiomeId = 'meadow';
  private readonly discovered = new Set<BiomeId>(['meadow']);
  private readonly blendedFogTint: [number, number, number] = [0.76, 0.85, 0.92];

  // Loop & event bookkeeping
  private rafId = 0;
  private lastTime = 0;
  private elapsed = 0;
  private hudTimer = 0;
  private disposed = false;
  private resizeObserver: ResizeObserver;

  // Multi-touch camera orbit & pinch-zoom tracking
  private orbitPointerId: number | null = null;
  private lastPointerX = 0;
  private lastPointerY = 0;
  private readonly pinchPointers = new Map<number, { x: number; y: number }>();
  private lastPinchDist = 0;

  private readonly WALK_SPEED = 5.4;
  private readonly SPRINT_SPEED = 10.2;
  private readonly SWIM_SPEED = 4.6;
  private readonly GRAVITY = 20.5;
  private readonly JUMP_VEL = 7.5;

  // Scratch vectors
  private readonly vForward = new THREE.Vector3();
  private readonly vRight = new THREE.Vector3();
  private readonly vDesiredCam = new THREE.Vector3();
  private readonly vDesiredLook = new THREE.Vector3();
  private readonly vIntroCam = new THREE.Vector3();
  private readonly vIntroLook = new THREE.Vector3();

  constructor(container: HTMLElement, callbacks: WorldCallbacks) {
    this.container = container;
    this.callbacks = callbacks;
    this.isMobile =
      window.matchMedia('(pointer: coarse)').matches ||
      Math.min(window.innerWidth, window.innerHeight) < 768;
    this.graphicsQuality = this.isMobile ? 'high' : 'ultra';

    const width = Math.max(1, container.clientWidth);
    const height = Math.max(1, container.clientHeight);

    this.renderer = new THREE.WebGLRenderer({
      antialias: true,
      powerPreference: 'high-performance',
      stencil: false,
    });
    const dpr = Math.min(window.devicePixelRatio || 1, this.isMobile ? 1.75 : 2.0);
    this.renderer.setPixelRatio(dpr);
    this.renderer.setSize(width, height);
    this.renderer.shadowMap.enabled = true;
    // PCFSoftShadowMap was removed in recent three.js (it logged a fallback warning)
    this.renderer.shadowMap.type = THREE.PCFShadowMap;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.06;
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;

    const canvas = this.renderer.domElement;
    canvas.style.display = 'block';
    canvas.style.width = '100%';
    canvas.style.height = '100%';
    canvas.style.touchAction = 'none';
    container.appendChild(canvas);

    this.scene = new THREE.Scene();
    this.camera = new THREE.PerspectiveCamera(55, width / height, 0.2, 2400);

    // Anisotropic texture filtering for razor-sharp leaves, bark, grass & ground micro-detail
    const anisotropy = Math.min(
      this.isMobile ? 4 : 8,
      this.renderer.capabilities.getMaxAnisotropy() || 4
    );

    // Initialize living world subsystems (ChunkManager sets global exact triangle grid cell size!)
    this.sky = new SkySystem(this.scene, this.renderer, this.isMobile);
    this.water = new WaterSystem(this.scene);
    this.foliage = new FoliageLibrary(anisotropy);
    this.chunks = new ChunkManager(
      this.scene,
      this.foliage,
      this.water,
      this.isMobile,
      anisotropy
    );
    this.character = new ExplorerCharacter();
    this.character.setAppearance(this.evo.baseColorHex, this.evo.traits, this.evo.bodyScale, this.evo.stage);
    this.particles = new AtmosphereParticles(this.scene, this.isMobile);
    this.audio = new WorldAudio();
    this.wildlife = new WildlifeSystem(
      this.scene,
      this.audio,
      this.isMobile,
      (x, z, s) => this.particles.spawnWaterRipple(x, z, s),
      (speciesId) => this.handlePreyDevoured(speciesId),
      (damage, speciesName, sx, sz) =>
        this.handlePlayerDamaged(damage, speciesName, sx, sz)
    );
    this.rivals = new RivalSystem(
      this.scene,
      (damage, sourceName, sx, sz) =>
        this.handlePlayerDamaged(damage, sourceName, sx, sz),
      (name, remaining, byPlayer) =>
        this.handleRivalEliminated(name, remaining, byPlayer)
    );

    // Pooled Spore Mines for the evolved active ability
    const mineGeo = new THREE.IcosahedronGeometry(0.26, 1);
    for (let i = 0; i < 9; i++) {
      const mat = new THREE.MeshBasicMaterial({
        color: 0x22d3ee,
        transparent: true,
        opacity: 0.9,
      });
      const mesh = new THREE.Mesh(mineGeo, mat);
      mesh.visible = false;
      mesh.renderOrder = 3;
      this.scene.add(mesh);
      this.mines.push({ mesh, x: 0, y: 0, z: 0, age: 0, active: false, damage: 20 });
    }

    this.weather = new WeatherSystem(this.scene);
    this.plants = new EdiblePlantSystem(this.scene);

    this.wildlife.setDifficulty(
      GAME_MODES[this.mode].creatureHpMult,
      GAME_MODES[this.mode].creatureDamageMult
    );

    // Setup HDR multisampled post-processing with delicate physically-based sunlight bloom!
    this.setupPostProcessing(width, height, dpr);

    // Place explorer on Wayfarer Overlook at 0.000m exact rendered terrain triangle elevation
    const startLm = BIOMES.meadow.landmark;
    const startY = getRenderedTerrainHeight(startLm.x, startLm.z);
    this.playerPos.set(startLm.x, startY, startLm.z);
    this.playerYaw = startLm.yaw;
    this.camYaw = startLm.yaw;
    this.character.root.position.copy(this.playerPos);
    this.character.root.rotation.y = this.playerYaw;
    this.scene.add(this.character.root);

    // Synchronously build surrounding chunks so the very first frame is lush and full of trees & bushes
    this.chunks.primeAround(this.playerPos.x, this.playerPos.z);

    // Neutral AI explorer symbiotes for the default Open World lobby
    this.rivals.configure(this.mode, this.maxPlayers, this.playerPos, this.evo.stage);
    this.matchState = this.rivals.getState();

    this.resizeObserver = new ResizeObserver(() => this.handleResize());
    this.resizeObserver.observe(container);
    this.bindInputs();

    this.lastTime = performance.now();
    this.loop(this.lastTime);
  }

  private setupPostProcessing(width: number, height: number, dpr: number): void {
    if (!this.renderer.capabilities.isWebGL2) return;
    try {
      const rt = new THREE.WebGLRenderTarget(
        Math.max(1, Math.floor(width * dpr)),
        Math.max(1, Math.floor(height * dpr)),
        {
          type: THREE.HalfFloatType,
          samples: this.isMobile ? 0 : 4, // 4x hardware MSAA for silky leaf & grass edges!
        }
      );
      const composer = new EffectComposer(this.renderer, rt);
      composer.setPixelRatio(dpr);
      composer.setSize(width, height);

      const renderPass = new RenderPass(this.scene, this.camera);
      composer.addPass(renderPass);

      // Subtle atmospheric HDR bloom — catches blazing sun, water diamonds, backlit canopies, fireflies & lanterns!
      const bloom = new UnrealBloomPass(
        new THREE.Vector2(Math.max(1, Math.floor(width * 0.5)), Math.max(1, Math.floor(height * 0.5))),
        0.22,
        0.58,
        1.02
      );
      composer.addPass(bloom);

      const outputPass = new OutputPass();
      composer.addPass(outputPass);

      this.composer = composer;
      this.bloomPass = bloom;
    } catch {
      this.composer = null;
      this.bloomPass = null;
    }
  }

  public setGraphicsQuality(quality: GraphicsQuality): void {
    if (this.graphicsQuality === quality) return;
    this.graphicsQuality = quality;
    const maxDpr = quality === 'ultra' ? 2.0 : 1.5;
    const dpr = Math.min(window.devicePixelRatio || 1, maxDpr);
    const w = Math.max(1, this.container.clientWidth);
    const h = Math.max(1, this.container.clientHeight);
    this.renderer.setPixelRatio(dpr);
    this.renderer.setSize(w, h);
    if (this.composer) {
      this.composer.setPixelRatio(dpr);
      this.composer.setSize(w, h);
    }
    this.chunks.setVegetationDensity(
      quality === 'ultra' ? 1.12 : 0.82,
      this.playerPos.x,
      this.playerPos.z
    );
    this.emitHud();
  }

  /** Configure or reset a game mode. Always reloads the saved evolved organism first. */
  public setGameMode(mode: GameMode, requestedPlayers?: number): void {
    this.mode = mode;
    this.dropIntroTimer = 0;
    if (mode === 'open-world') {
      this.network?.close();
      this.network = null;
    }
    this.maxPlayers = clampMaxPlayers(mode, requestedPlayers ?? this.maxPlayers);
    const cfg = GAME_MODES[mode];

    // Persistent evolution: the saved Stage, Traits, Abilities, DNA and body color carry into both modes.
    const saved = getActiveAccount();
    if (saved) this.loadProfile(saved);

    this.wildlife.setDifficulty(cfg.creatureHpMult, cfg.creatureDamageMult);
    this.abilityCooldowns = emptyAbilityCooldowns();
    this.cloakTimer = 0;
    this.cloaked = false;
    this.dashInvulnTimer = 0;
    this.deactivateMines();
    this.wildlife.setPlayerCloaked(false);
    this.rivals.setPlayerCloaked(false);
    this.character.setCloaked(false);

    const startLm = BIOMES.meadow.landmark;
    const startY = getRenderedTerrainHeight(startLm.x, startLm.z);
    this.playerPos.set(startLm.x, startY, startLm.z);
    this.playerVel.set(0, 0, 0);
    this.playerYaw = startLm.yaw;
    this.camYaw = startLm.yaw;
    this.camPitch = 0.2;
    this.grounded = true;
    this.swimming = false;
    this.wading = false;
    this.landingImpact = 0;
    this.gliding = false;
    this.jumpQueued = false;
    this.touchJumpHeld = false;
    this.joyX = 0;
    this.joyY = 0;
    this.touchSprint = false;
    this.keys.clear();

    this.character.root.position.copy(this.playerPos);
    this.character.root.rotation.y = this.playerYaw;
    this.chunks.primeAround(this.playerPos.x, this.playerPos.z);

    this.currentBiome = 'meadow';
    this.candidateBiome = 'meadow';
    this.biomeHoldTimer = 0;
    this.timeOfDay = 0.345;
    this.timePaused = false;
    this.blendedFogTint[0] = BIOMES.meadow.fogTint[0];
    this.blendedFogTint[1] = BIOMES.meadow.fogTint[1];
    this.blendedFogTint[2] = BIOMES.meadow.fogTint[2];

    this.rivals.configure(this.mode, this.maxPlayers, this.playerPos, this.evo.stage);
    this.matchState = this.rivals.getState();
    this.matchOverAnnounced = false;
    this.introBlend = 0.85;
    this.combatFeed =
      mode === 'battle-royale'
        ? `Battle Royale started — ${this.maxPlayers} pilots, last symbiote standing wins!`
        : 'Open World expedition started — your evolved organism is persistent.';
    this.combatFeedTimer = 4.5;

    this.computeThirdPersonCamera(this.vDesiredCam, this.vDesiredLook);
    this.smoothCamPos.copy(this.vDesiredCam);
    this.smoothLookAt.copy(this.vDesiredLook);
    this.camera.position.copy(this.smoothCamPos);
    this.camera.lookAt(this.smoothLookAt);
    this.emitHud();
  }

  /** Leave the match/world and show the post-login Main Menu again. */
  public returnToMenu(): void {
    this.network?.close();
    this.network = null;
    this.started = false;
    this.introBlend = 1.0;
    this.dropIntroTimer = 0;
    this.keys.clear();
    this.joyX = 0;
    this.joyY = 0;
    this.touchSprint = false;
    this.jumpQueued = false;
    this.touchJumpHeld = false;
    this.cloakTimer = 0;
    this.cloaked = false;
    this.dashInvulnTimer = 0;
    this.wildlife.setPlayerCloaked(false);
    this.rivals.setPlayerCloaked(false);
    this.character.setCloaked(false);
    this.combatFeed = null;
    this.combatFeedTimer = 0;
    this.damageFlash = 0;
    this.damageSource = null;
    this.emitHud();
  }

  /** Transition smoothly from live title vista down behind our 3rd-person traveler */
  public startExploration(
    mode: GameMode = this.mode,
    requestedPlayers?: number
  ): void {
    this.audio.unlock();
    this.setGameMode(mode, requestedPlayers);
    if (!this.started) {
      this.started = true;
      window.setTimeout(() => {
        if (!this.disposed) {
          this.audio.playBiomeDiscovery();
          this.callbacks.onBiomeEnter(
            this.currentBiome,
            false,
            Math.round(Math.max(0, this.playerPos.y))
          );
        }
      }, 650);
    }
  }


  public setNetworkAdapter(adapter: NetworkAdapter): void {
    this.network?.close();
    this.network = adapter;
    this.networkTimer = 0;
  }

  /** Start a Battle Royale match from a real-player lobby + spread-out drop assignments. */
  public startBattleRoyaleMatch(
    roster: RosterEntry[],
    assignments: DropAssignment[],
    requestedPlayers?: number,
    adapter?: NetworkAdapter | null
  ): void {
    this.audio.unlock();
    if (adapter) this.setNetworkAdapter(adapter);
    this.setGameMode('battle-royale', requestedPlayers ?? roster.length);
    const local = assignments.find((a) => a.isLocal) ?? assignments[0];
    const spot = getDropSpot(local?.dropId ?? 'lumen');
    const dropX = local?.x ?? spot.x;
    const dropZ = local?.z ?? spot.z;
    const y = getRenderedTerrainHeight(dropX, dropZ);
    // Begin an actual third-person drop from above the chosen terrain, already inside the opening storm ring.
    this.playerPos.set(dropX, y + 62, dropZ);
    this.playerVel.set(0, -3.5, 0);
    this.playerYaw = Math.atan2(-(0 - dropX), -(0 - dropZ));
    this.camYaw = this.playerYaw;
    this.grounded = false;
    this.swimming = false;
    this.wading = false;
    this.character.root.position.copy(this.playerPos);
    this.character.root.rotation.y = this.playerYaw;
    this.chunks.primeAround(dropX, dropZ);
    this.rivals.configureRoster(roster, assignments, this.playerPos, this.evo.stage);
    this.matchState = this.rivals.getState();
    this.matchOverAnnounced = false;
    this.abilityCooldowns = emptyAbilityCooldowns();
    this.cloakTimer = 0;
    this.cloaked = false;
    this.dashInvulnTimer = 0;
    this.deactivateMines();
    this.wildlife.setPlayerCloaked(false);
    this.rivals.setPlayerCloaked(false);
    this.character.setCloaked(false);
    this.dropIntroTimer = 4.1;
    this.introBlend = 0;
    this.combatFeed = `Dropped at ${spot.name}! ${roster.length} pilots · last symbiote standing wins.`;
    this.combatFeedTimer = 5;
    this.computeThirdPersonCamera(this.vDesiredCam, this.vDesiredLook);
    this.smoothCamPos.copy(this.vDesiredCam);
    this.smoothLookAt.copy(this.vDesiredLook);
    this.camera.position.copy(this.smoothCamPos);
    this.camera.lookAt(this.smoothLookAt);
    this.started = true;
    this.emitHud();
  }

  public setJoystick(x: number, y: number): void {
    this.joyX = clamp(x, -1, 1);
    this.joyY = clamp(y, -1, 1);
  }

  public setTouchSprint(active: boolean): void {
    this.touchSprint = active;
  }

  public triggerJump(): void {
    this.audio.unlock();
    this.jumpQueued = true;
  }

  public setTouchJumpHeld(held: boolean): void {
    this.touchJumpHeld = held;
  }

  /** Load or sync user profile organism into the 3D world */
  public loadProfile(profile: UserProfile): void {
    this.discovered.clear();
    for (const b of profile.discoveredBiomes ?? ['meadow']) {
      this.discovered.add(b);
    }
    this.evo = computeSlimeStats(
      profile.stage || 1,
      profile.traits || [],
      profile.speciesName || 'Lumigoo',
      profile.baseColorHex || '#2dd4bf',
      profile.dna || 0,
      profile.stageDiet || emptyDiet(),
      profile.totalDiet || emptyDiet(),
      profile.kills || 0
    );
    this.character.setAppearance(this.evo.baseColorHex, this.evo.traits, this.evo.bodyScale, this.evo.stage);
    this.emitHud();
  }

  private handlePreyDevoured(speciesId: CreatureCallKind): void {
    const info = SPECIES_PREY_INFO[speciesId];
    if (!info) return;
    const wasReady = this.evo.evolveReady;

    const nextStageDiet = { ...this.evo.stageDiet };
    const nextTotalDiet = { ...this.evo.totalDiet };
    nextStageDiet[info.primaryEssence] += 2;
    nextStageDiet[info.secondaryEssence] += 1;
    nextTotalDiet[info.primaryEssence] += 2;
    nextTotalDiet[info.secondaryEssence] += 1;

    const dnaGain = Math.round(info.dnaReward * GAME_MODES[this.mode].dnaMult);
    const newDna = this.evo.dna + dnaGain;
    const newKills = this.evo.kills + 1;
    const healFrac = this.evo.abilities.includes('regen') ? 0.4 : 0.24;
    const healHp = Math.min(this.evo.maxHp, this.evo.hp + Math.round(this.evo.maxHp * healFrac));

    this.evo = computeSlimeStats(
      this.evo.stage,
      this.evo.traits,
      this.evo.speciesName,
      this.evo.baseColorHex,
      newDna,
      nextStageDiet,
      nextTotalDiet,
      newKills,
      healHp
    );

    // Grow slime scale immediately as biomass increases!
    this.character.setAppearance(this.evo.baseColorHex, this.evo.traits, this.evo.bodyScale, this.evo.stage);

    const essDef = ESSENCES[info.primaryEssence];
    this.combatFeed = `Devoured ${info.name}! +${dnaGain} DNA (+${essDef.shortName})`;
    this.combatFeedTimer = 4.0;

    this.callbacks.onProgressSaved?.(this.evo, Array.from(this.discovered));
    if (!wasReady && this.evo.evolveReady) {
      this.audio.playEvolutionFanfare();
      this.callbacks.onEvolutionReady?.(this.evo);
    }
    this.emitHud();
  }

  private handlePlayerDamaged(
    rawDamage: number,
    speciesName: string,
    sourceX?: number,
    sourceZ?: number
  ): void {
    if (!this.started || this.matchState.matchOver) return;
    const isZoneDamage = speciesName.includes('Bio-Storm');
    if (this.dashInvulnTimer > 0 && !isZoneDamage) return;
    if (this.cloaked && !isZoneDamage) return;
    const actual = Math.max(2, Math.round(rawDamage * (1 - this.evo.armor)));
    this.evo.hp = Math.max(0, this.evo.hp - actual);
    this.combatFeed = `${speciesName} attacked! -${actual} HP`;
    this.combatFeedTimer = 2.8;
    this.damageFlash = 1.0;
    this.damageSource = speciesName;
    this.camShake = clamp(0.14 + actual * 0.008, 0.15, 0.5);
    this.audio.playPlayerHurtSound();

    // Knock the slime backward, away from the attacker
    if (sourceX !== undefined && sourceZ !== undefined) {
      const dx = this.playerPos.x - sourceX;
      const dz = this.playerPos.z - sourceZ;
      const len = Math.max(0.01, Math.hypot(dx, dz));
      const force = 5.2 + actual * 0.08;
      this.playerVel.x += (dx / len) * force;
      this.playerVel.z += (dz / len) * force;
      if (this.grounded) {
        this.playerVel.y = 2.4;
        this.grounded = false;
      }
    }

    if (this.mode === 'battle-royale' && this.evo.hp <= 0) {
      // Last-symbiote-standing rule: no reconstitution inside a Battle Royale match.
      this.evo.hp = 0;
      this.rivals.eliminatePlayer(speciesName);
      this.matchState = this.rivals.getState();
      this.combatFeed = `${speciesName} eliminated you!`;
      this.combatFeedTimer = 8;
      this.emitHud();
      return;
    }

    if (this.evo.hp <= 0) {
      // Open World reconstitutes nearby without losing traits or evolution stage
      this.evo.hp = this.evo.maxHp;
      this.combatFeed = `${this.evo.speciesName} reconstituted from biomass!`;
      this.combatFeedTimer = 3.5;
      this.character.triggerEvolutionBurst();
    }
    this.emitHud();
  }

  /** Melee Bite / Lunge Strike — also hits rival pilots and scales with Apex Sense. */
  public triggerAttack(): void {
    if (!this.started || this.attackCooldown > 0 || this.matchState.matchOver) return;
    this.audio.unlock();
    this.attackCooldown = 0.42;
    this.character.triggerAttackAnim();

    const fwdX = -Math.sin(this.playerYaw);
    const fwdZ = -Math.cos(this.playerYaw);
    const hasScythes = this.evo.traits.includes('scythe_claws');
    const reach = (2.9 + (hasScythes ? 0.9 : 0)) * Math.max(0.85, this.evo.bodyScale * 0.92);
    const senseTarget = this.evo.abilities.includes('sense')
      ? this.wildlife.getNearestTargetInfo(
          this.playerPos.x,
          this.playerPos.y,
          this.playerPos.z,
          44
        )
      : null;
    const senseBonus =
      senseTarget && senseTarget.hp < senseTarget.maxHp * 0.5 ? 1.25 : 1.0;
    const biteDamage = Math.round(this.evo.biteDamage * senseBonus);

    const res = this.wildlife.performMeleeStrike(
      this.playerPos.x,
      this.playerPos.y,
      this.playerPos.z,
      fwdX,
      fwdZ,
      biteDamage,
      reach
    );
    const rivalRes = this.rivals.applyMelee(
      this.playerPos.x,
      this.playerPos.y,
      this.playerPos.z,
      fwdX,
      fwdZ,
      biteDamage,
      reach
    );
    const plant = this.plants.consumeNearby(this.playerPos.x, this.playerPos.z, 2.6);
    if (plant) this.handlePlantEaten(plant);

    if (res.hitCount === 0 && rivalRes.hitCount > 0) {
      this.audio.playBiteSound(true);
    }
    if (rivalRes.hitCount > 0) {
      this.combatFeed = `Bite struck ${rivalRes.hitCount} rival${rivalRes.hitCount === 1 ? '' : 's'}!`;
      this.combatFeedTimer = 2.5;
    }

    const lungeTarget = res.lungeTarget ?? rivalRes.lungeTarget;
    if (lungeTarget) {
      const dx = lungeTarget.x - this.playerPos.x;
      const dz = lungeTarget.z - this.playerPos.z;
      const dist = Math.hypot(dx, dz);
      if (dist > 0.2) {
        this.playerYaw = Math.atan2(-dx, -dz);
        this.playerVel.x += (dx / dist) * 9.5;
        this.playerVel.z += (dz / dist) * 9.5;
      }
    } else {
      this.playerVel.x += fwdX * 6.5;
      this.playerVel.z += fwdZ * 6.5;
    }
    this.matchState = this.rivals.getState();
    this.emitHud();
  }

  /** Ranged Bio-Plasma / Acid Spit */
  public triggerSpit(): void {
    if (!this.started || this.spitCooldown > 0 || this.matchState.matchOver) return;
    this.audio.unlock();
    const hasGland = this.evo.traits.includes('plasma_gland');
    this.spitCooldown = hasGland ? 0.55 : 0.95;
    this.character.triggerSpitAnim();

    const fwdX = -Math.sin(this.camYaw);
    const fwdZ = -Math.cos(this.camYaw);
    const target = this.wildlife.getNearestTargetInfo(
      this.playerPos.x,
      this.playerPos.y,
      this.playerPos.z,
      34
    );
    if (target) {
      this.playerYaw = Math.atan2(-(target.x - this.playerPos.x), -(target.z - this.playerPos.z));
    } else {
      this.playerYaw = this.camYaw;
    }

    this.wildlife.fireBioProjectile(
      this.playerPos.x,
      this.playerPos.y,
      this.playerPos.z,
      fwdX,
      fwdZ,
      this.evo.spitDamage,
      this.evo.baseColorHex
    );

    const rivalHit = this.rivals.applySpit(
      this.playerPos.x,
      this.playerPos.y,
      this.playerPos.z,
      fwdX,
      fwdZ,
      this.evo.spitDamage,
      34
    );
    if (rivalHit.hit) {
      this.combatFeed = `Bio-Plasma hit ${rivalHit.name}!${rivalHit.killed ? ' Rival eliminated!' : ''}`;
      this.combatFeedTimer = 2.8;
    }
    this.emitHud();
  }

  /** Rival pilots award DNA when the player eliminates them. */
  private handleRivalEliminated(name: string, remaining: number, byPlayer: boolean): void {
    this.matchState = this.rivals.getState();
    const wasReady = this.evo.evolveReady;
    const dnaGain = byPlayer ? Math.round(36 * GAME_MODES[this.mode].dnaMult) : 0;
    const newDna = this.evo.dna + dnaGain;
    const newKills = this.evo.kills + (byPlayer ? 1 : 0);

    if (dnaGain > 0) {
      this.evo = computeSlimeStats(
        this.evo.stage,
        this.evo.traits,
        this.evo.speciesName,
        this.evo.baseColorHex,
        newDna,
        this.evo.stageDiet,
        this.evo.totalDiet,
        newKills,
        this.evo.hp
      );
      this.character.setAppearance(
        this.evo.baseColorHex,
        this.evo.traits,
        this.evo.bodyScale,
        this.evo.stage
      );
      this.audio.playDnaAbsorbSound();
      this.callbacks.onProgressSaved?.(this.evo, Array.from(this.discovered));
    }

    this.combatFeed = `${name} eliminated! ${remaining} rivals remain.${dnaGain > 0 ? ` +${dnaGain} DNA` : ''}`;
    this.combatFeedTimer = 3.6;
    if (!wasReady && this.evo.evolveReady) {
      this.audio.playEvolutionFanfare();
      this.callbacks.onEvolutionReady?.(this.evo);
    }
    this.emitHud();
  }

  private deactivateMines(): void {
    for (const m of this.mines) {
      m.active = false;
      m.mesh.visible = false;
    }
  }

  private deployMines(damage: number): void {
    const px = this.playerPos.x;
    const pz = this.playerPos.z;
    const fwdX = -Math.sin(this.camYaw);
    const fwdZ = -Math.cos(this.camYaw);
    const rightX = Math.cos(this.camYaw);
    const rightZ = -Math.sin(this.camYaw);
    const spots = [
      { x: px + fwdX * 2.4, z: pz + fwdZ * 2.4 },
      { x: px + fwdX * 1.1 + rightX * 1.8, z: pz + fwdZ * 1.1 + rightZ * 1.8 },
      { x: px + fwdX * 1.1 - rightX * 1.8, z: pz + fwdZ * 1.1 - rightZ * 1.8 },
    ];
    let placed = 0;
    for (const m of this.mines) {
      if (m.active || placed >= spots.length) continue;
      const spot = spots[placed++];
      m.x = spot.x;
      m.z = spot.z;
      m.y = getRenderedTerrainHeight(spot.x, spot.z) + 0.28;
      m.age = 0;
      m.damage = damage;
      m.active = true;
      m.mesh.position.set(m.x, m.y, m.z);
      m.mesh.scale.setScalar(1);
      m.mesh.visible = true;
      (m.mesh.material as THREE.MeshBasicMaterial).color.set(this.evo.baseColorHex);
    }
  }

  private updateMines(dt: number): void {
    for (const m of this.mines) {
      if (!m.active) continue;
      m.age += dt;
      const pulse = 1 + Math.sin(m.age * 12) * 0.12;
      m.mesh.scale.setScalar(pulse);
      (m.mesh.material as THREE.MeshBasicMaterial).opacity =
        0.76 + Math.sin(m.age * 10) * 0.18;

      const enemyNear =
        this.wildlife.hasCreatureNear(m.x, m.z, 3.2) ||
        this.rivals.hasRivalNear(m.x, m.z, 3.2);
      if (m.age > 0.65 && (enemyNear || m.age > 11)) {
        const a = this.wildlife.damageInRadius(
          m.x,
          m.z,
          4.2,
          m.damage,
          this.playerPos.x,
          this.playerPos.z
        );
        const r = this.rivals.damageAt(m.x, m.z, 4.2, m.damage, true, 'vaporized');
        const hits = a.hitCount + r.hitCount;
        if (hits > 0) {
          this.combatFeed = `Spore Mine detonated! ${hits} target${hits === 1 ? '' : 's'} hit.`;
          this.combatFeedTimer = 2.6;
        }
        this.particles.spawnFootstepEffect(m.x, m.y, m.z, 'rock', true);
        this.audio.playSpitSound();
        this.camShake = Math.max(this.camShake, 0.18);
        this.matchState = this.rivals.getState();
        m.active = false;
        m.mesh.visible = false;
      }
    }
  }

  /** Fire one of the evolution-unlocked active abilities. */
  public triggerAbility(id: AbilityId): void {
    const def = ABILITIES[id];
    if (
      !this.started ||
      !def.active ||
      this.matchState.matchOver ||
      !this.evo.abilities.includes(id) ||
      this.abilityCooldowns[id] > 0
    ) {
      return;
    }

    this.audio.unlock();
    this.abilityCooldowns[id] = getAbilityCooldown(id, this.evo.traits);
    this.character.triggerAbilityAnim(id);
    this.audio.playSpitSound();

    const px = this.playerPos.x;
    const py = this.playerPos.y;
    const pz = this.playerPos.z;
    const fwdX = -Math.sin(this.camYaw);
    const fwdZ = -Math.cos(this.camYaw);
    this.playerYaw = this.camYaw;
    let detail = '';

    switch (id) {
      case 'dash': {
        const dmg = Math.round(this.evo.spitDamage * 0.75 + 10);
        const a = this.wildlife.damageInCone(px, pz, fwdX, fwdZ, 8.5, 2.4, dmg);
        const r = this.rivals.damageInCone(px, pz, fwdX, fwdZ, 8.5, 2.4, dmg, true, 'phase-struck');
        this.playerVel.x += fwdX * 22;
        this.playerVel.z += fwdZ * 22;
        if (this.grounded) {
          this.playerVel.y = 2.0;
          this.grounded = false;
        }
        this.dashInvulnTimer = 0.45;
        detail = `${a.hitCount + r.hitCount} targets phase-struck`;
        break;
      }
      case 'slam': {
        const dmg = Math.round(this.evo.biteDamage * 1.35 + this.evo.spitDamage * 0.45);
        const a = this.wildlife.damageInRadius(px, pz, 7.6, dmg, px, pz);
        const r = this.rivals.damageAt(px, pz, 7.6, dmg, true, 'crushed');
        this.camShake = Math.max(this.camShake, 0.38);
        this.landingImpact = Math.max(this.landingImpact, 0.7);
        detail = `${a.hitCount + r.hitCount} targets crushed`;
        break;
      }
      case 'mines': {
        const dmg = Math.round(this.evo.spitDamage * 1.15 + 12);
        this.deployMines(dmg);
        detail = '3 lumispore mines armed';
        break;
      }
      case 'lance': {
        const dmg = Math.round(this.evo.spitDamage * 1.5 + 14);
        const a = this.wildlife.damageInCone(px, pz, fwdX, fwdZ, 20, 2.2, dmg);
        const r = this.rivals.damageInCone(px, pz, fwdX, fwdZ, 20, 2.2, dmg, true, 'lanced');
        detail = `${a.hitCount + r.hitCount} targets pierced`;
        break;
      }
      case 'cloak': {
        this.cloakTimer = 4.2;
        this.cloaked = true;
        this.wildlife.setPlayerCloaked(true);
        this.rivals.setPlayerCloaked(true);
        this.character.setCloaked(true);
        detail = 'wildlife and rivals lost your trail';
        break;
      }
      default:
        return;
    }

    this.matchState = this.rivals.getState();
    this.combatFeed = `${def.name}! ${detail}.`;
    this.combatFeedTimer = 3.0;
    this.emitHud();
    void py;
  }


  /** Graze nearby edible alien flora with K / the mobile Graze button. */
  public triggerEat(): void {
    if (!this.started || this.matchState.matchOver) return;
    this.audio.unlock();
    const plant = this.plants.consumeNearby(this.playerPos.x, this.playerPos.z, 3.6);
    if (!plant) {
      this.combatFeed = 'No edible flora within reach — look for glowing bulbs.';
      this.combatFeedTimer = 1.8;
      return;
    }
    this.handlePlantEaten(plant);
  }

  private handlePlantEaten(plant: PlantInfo): void {
    const wasReady = this.evo.evolveReady;
    const diet = { ...this.evo.stageDiet };
    const total = { ...this.evo.totalDiet };
    diet[plant.essence] += 2;
    total[plant.essence] += 2;
    const dnaGain = Math.round(plant.dna * GAME_MODES[this.mode].dnaMult);
    const healFrac = this.evo.abilities.includes('regen') ? 0.12 : 0.07;
    const hp = Math.min(this.evo.maxHp, this.evo.hp + Math.round(this.evo.maxHp * healFrac));
    this.evo = computeSlimeStats(
      this.evo.stage,
      this.evo.traits,
      this.evo.speciesName,
      this.evo.baseColorHex,
      this.evo.dna + dnaGain,
      diet,
      total,
      this.evo.kills,
      hp
    );
    this.character.setAppearance(this.evo.baseColorHex, this.evo.traits, this.evo.bodyScale, this.evo.stage);
    this.audio.playDnaAbsorbSound();
    const ess = ESSENCES[plant.essence];
    this.combatFeed = `Grazed ${plant.name}! +${dnaGain} DNA (+${ess.shortName}) · +HP`;
    this.combatFeedTimer = 3;
    this.callbacks.onProgressSaved?.(this.evo, Array.from(this.discovered));
    if (!wasReady && this.evo.evolveReady) {
      this.audio.playEvolutionFanfare();
      this.callbacks.onEvolutionReady?.(this.evo);
    }
    this.emitHud();
  }

  /** Evolve Slime with a selected Trait — mutates 3D anatomy, grows bigger & upgrades stats! */
  public evolveWithTrait(traitId: TraitId): void {
    this.audio.unlock();
    const nextTraits = this.evo.traits.includes(traitId)
      ? this.evo.traits
      : [...this.evo.traits, traitId];
    const nextStage = this.evo.stage + 1;
    const leftoverDna = Math.max(0, this.evo.dna - this.evo.dnaNext);

    this.evo = computeSlimeStats(
      nextStage,
      nextTraits,
      this.evo.speciesName,
      this.evo.baseColorHex,
      leftoverDna,
      emptyDiet(), // Reset stage diet so next stage adapts to what you eat next!
      this.evo.totalDiet,
      this.evo.kills
    );

    this.character.setAppearance(this.evo.baseColorHex, this.evo.traits, this.evo.bodyScale, this.evo.stage);
    this.character.triggerEvolutionBurst();
    this.audio.playEvolutionFanfare();

    const shed = nextStage === 6 ? ' BLOB FORM SHED — ASCENDED XENO-BEAST!' : '';
    this.combatFeed = `EVOLVED TO STAGE ${nextStage}! Mutated ${traitId.replace('_', ' ').toUpperCase()}!${shed}`;
    this.combatFeedTimer = 5.0;

    this.callbacks.onProgressSaved?.(this.evo, Array.from(this.discovered));
    this.emitHud();
  }

  public setTimeOfDay(t: number): void {
    this.timeOfDay = ((t % 1) + 1) % 1;
    this.emitHud();
  }

  public setTimePaused(paused: boolean): void {
    this.timePaused = paused;
    this.emitHud();
  }

  public toggleMute(): boolean {
    this.audio.unlock();
    const next = !this.audio.isMuted();
    this.audio.setMuted(next);
    this.emitHud();
    return next;
  }

  public setCameraPreset(preset: CameraPreset): void {
    this.cameraPreset = preset;
    if (preset === 'close') {
      this.targetCamDist = 3.25;
      this.shoulderOffset = 0.5;
      this.camPitch = 0.15;
    } else if (preset === 'balanced') {
      this.targetCamDist = 5.2;
      this.shoulderOffset = 0.36;
      this.camPitch = 0.21;
    } else {
      this.targetCamDist = 8.6;
      this.shoulderOffset = 0.0;
      this.camPitch = 0.28;
    }
    this.emitHud();
  }

  /** Fast-travel cleanly to any biome landmark on the World Map */
  public teleportToBiome(biomeId: BiomeId): void {
    this.audio.unlock();
    const def = BIOMES[biomeId];
    const lx = def.landmark.x;
    const lz = def.landmark.z;
    const ly = Math.max(getRenderedTerrainHeight(lx, lz), WATER_LEVEL);

    this.playerPos.set(lx, ly, lz);
    this.playerVel.set(0, 0, 0);
    this.playerYaw = def.landmark.yaw;
    this.camYaw = def.landmark.yaw;
    this.camPitch = 0.2;
    this.grounded = true;
    this.swimming = false;
    this.wading = false;
    this.introBlend = 0;

    this.character.root.position.copy(this.playerPos);
    this.character.root.rotation.y = this.playerYaw;

    this.chunks.primeAround(lx, lz);

    this.computeThirdPersonCamera(this.vDesiredCam, this.vDesiredLook);
    this.smoothCamPos.copy(this.vDesiredCam);
    this.smoothLookAt.copy(this.vDesiredLook);

    const isNew = !this.discovered.has(biomeId);
    this.discovered.add(biomeId);
    this.currentBiome = biomeId;
    this.candidateBiome = biomeId;
    this.biomeHoldTimer = 0;

    this.audio.playBiomeDiscovery();
    this.callbacks.onBiomeEnter(biomeId, isNew, Math.round(Math.max(0, ly)));
    this.emitHud();
  }

  private handleResize(): void {
    if (this.disposed) return;
    const w = Math.max(1, this.container.clientWidth);
    const h = Math.max(1, this.container.clientHeight);
    this.camera.aspect = w / h;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(w, h);
    if (this.composer) {
      this.composer.setSize(w, h);
    }
    if (this.bloomPass) {
      this.bloomPass.resolution.set(Math.max(1, Math.floor(w * 0.5)), Math.max(1, Math.floor(h * 0.5)));
    }
  }

  private onKeyDown = (e: KeyboardEvent): void => {
    if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) return;
    const code = e.code;
    if (
      code === 'Space' ||
      code === 'ArrowUp' ||
      code === 'ArrowDown' ||
      code === 'ArrowLeft' ||
      code === 'ArrowRight'
    ) {
      e.preventDefault();
    }
    this.keys.add(code);
    if (code === 'Space' && this.started) {
      this.audio.unlock();
      this.jumpQueued = true;
    } else if (code === 'KeyF' && this.started) {
      this.triggerAttack();
    } else if (code === 'KeyR' && this.started) {
      this.triggerSpit();
    } else if (ABILITY_KEYS[code] && this.started) {
      this.triggerAbility(ABILITY_KEYS[code]);
    } else if (code === 'KeyK' && this.started) {
      this.triggerEat();
    }
  };

  private onKeyUp = (e: KeyboardEvent): void => {
    this.keys.delete(e.code);
  };

  private onWindowBlur = (): void => {
    this.keys.clear();
    this.orbitPointerId = null;
    this.pinchPointers.clear();
  };

  private onPointerDown = (e: PointerEvent): void => {
    if (!this.started) return;
    this.audio.unlock();
    const canvas = this.renderer.domElement;
    canvas.setPointerCapture(e.pointerId);

    this.pinchPointers.set(e.pointerId, { x: e.clientX, y: e.clientY });
    if (this.pinchPointers.size === 2) {
      const pts = Array.from(this.pinchPointers.values());
      this.lastPinchDist = Math.hypot(pts[0].x - pts[1].x, pts[0].y - pts[1].y);
      this.orbitPointerId = null;
      return;
    }

    if (this.orbitPointerId === null) {
      this.orbitPointerId = e.pointerId;
      this.lastPointerX = e.clientX;
      this.lastPointerY = e.clientY;
    }
  };

  private onPointerMove = (e: PointerEvent): void => {
    if (!this.started) return;

    if (document.pointerLockElement === this.renderer.domElement) {
      this.camYaw -= e.movementX * 0.0028;
      this.camPitch = clamp(this.camPitch + e.movementY * 0.0024, -0.24, 1.08);
      this.userOrbitCooldown = 2.2;
      return;
    }

    if (this.pinchPointers.has(e.pointerId)) {
      this.pinchPointers.set(e.pointerId, { x: e.clientX, y: e.clientY });
    }

    // Two-finger pinch zoom on iOS & Android
    if (this.pinchPointers.size === 2) {
      const pts = Array.from(this.pinchPointers.values());
      const dist = Math.hypot(pts[0].x - pts[1].x, pts[0].y - pts[1].y);
      if (this.lastPinchDist > 10) {
        const delta = (this.lastPinchDist - dist) * 0.022;
        this.targetCamDist = clamp(this.targetCamDist + delta, 2.5, 13.0);
      }
      this.lastPinchDist = dist;
      return;
    }

    if (this.orbitPointerId === e.pointerId) {
      const dx = e.clientX - this.lastPointerX;
      const dy = e.clientY - this.lastPointerY;
      this.lastPointerX = e.clientX;
      this.lastPointerY = e.clientY;

      const sens = e.pointerType === 'touch' ? 0.0052 : 0.0044;
      this.camYaw -= dx * sens;
      this.camPitch = clamp(this.camPitch + dy * sens * 0.85, -0.22, 1.08);
      this.userOrbitCooldown = 2.4;
    }
  };

  private onPointerUp = (e: PointerEvent): void => {
    this.pinchPointers.delete(e.pointerId);
    if (this.orbitPointerId === e.pointerId) {
      this.orbitPointerId = null;
    }
    if (this.pinchPointers.size === 1) {
      const [id, pt] = Array.from(this.pinchPointers.entries())[0];
      this.orbitPointerId = id;
      this.lastPointerX = pt.x;
      this.lastPointerY = pt.y;
    }
  };

  private onWheel = (e: WheelEvent): void => {
    if (!this.started) return;
    e.preventDefault();
    this.targetCamDist = clamp(this.targetCamDist + e.deltaY * 0.0045, 2.5, 13.0);
  };

  private onContextMenu = (e: MouseEvent): void => {
    e.preventDefault();
  };

  private bindInputs(): void {
    const canvas = this.renderer.domElement;
    window.addEventListener('keydown', this.onKeyDown);
    window.addEventListener('keyup', this.onKeyUp);
    window.addEventListener('blur', this.onWindowBlur);
    canvas.addEventListener('pointerdown', this.onPointerDown);
    canvas.addEventListener('pointermove', this.onPointerMove);
    canvas.addEventListener('pointerup', this.onPointerUp);
    canvas.addEventListener('pointercancel', this.onPointerUp);
    canvas.addEventListener('wheel', this.onWheel, { passive: false });
    canvas.addEventListener('contextmenu', this.onContextMenu);
  }

  private computeThirdPersonCamera(outPos: THREE.Vector3, outLook: THREE.Vector3): void {
    const sinY = Math.sin(this.camYaw);
    const cosY = Math.cos(this.camYaw);
    this.vForward.set(-sinY, 0, -cosY);
    this.vRight.set(cosY, 0, -sinY);

    // Scale camera height & distance smoothly as your Spore Slime evolves from small Proto-Goo to Apex Leviathan!
    const sizeFactor = clamp(0.75 + this.evo.bodyScale * 0.45, 0.9, 2.2);
    const eyeHeight = (this.swimming ? 0.95 : 1.15) * sizeFactor;
    const pivotX = this.playerPos.x + this.vRight.x * this.shoulderOffset * sizeFactor;
    const pivotY = this.playerPos.y + eyeHeight;
    const pivotZ = this.playerPos.z + this.vRight.z * this.shoulderOffset * sizeFactor;

    const scaledDist = this.camDist * (0.8 + sizeFactor * 0.28);
    const horizDist = scaledDist * Math.cos(this.camPitch);
    const vertDist = scaledDist * Math.sin(this.camPitch);

    const cx = pivotX - this.vForward.x * horizDist;
    let cy = pivotY + vertDist;
    const cz = pivotZ - this.vForward.z * horizDist;

    // Exact rendered triangle surface check keeps camera cleanly above ground, grass & water!
    const groundAtCam = Math.max(getRenderedTerrainHeight(cx, cz), WATER_LEVEL) + 0.72;
    const midX = (pivotX + cx) * 0.5;
    const midZ = (pivotZ + cz) * 0.5;
    const groundAtMid = Math.max(getRenderedTerrainHeight(midX, midZ), WATER_LEVEL) + 0.58;
    const minCamY = Math.max(groundAtCam, groundAtMid * 2 - pivotY);
    if (cy < minCamY) {
      cy = minCamY;
    }

    outPos.set(cx, cy, cz);
    outLook.set(
      pivotX + this.vForward.x * 3.8,
      pivotY + 0.14 - Math.max(0, this.camPitch - 0.32) * 1.15,
      pivotZ + this.vForward.z * 3.8
    );
  }

  private loop = (now: number): void => {
    if (this.disposed) return;
    this.rafId = requestAnimationFrame(this.loop);
    try {
      this.frame(now);
    } catch (err) {
      // Stop cleanly and surface the problem instead of freezing on a broken frame
      cancelAnimationFrame(this.rafId);
      this.disposed = true;
      console.error('Solvara frame error:', err);
      this.callbacks.onError?.(err instanceof Error ? err.message : String(err));
    }
  };

  private frame(now: number): void {
    const dt = Math.min(0.05, Math.max(0.001, (now - this.lastTime) * 0.001));
    this.lastTime = now;
    this.elapsed += dt;
    if (this.dropIntroTimer > 0) {
      this.dropIntroTimer = Math.max(0, this.dropIntroTimer - dt);
    }

    if (!this.timePaused && this.started) {
      this.timeOfDay = (this.timeOfDay + dt * 0.0012) % 1.0;
    }

    if (this.started) {
      if (this.keys.has('KeyQ')) {
        this.camYaw += 1.75 * dt;
        this.userOrbitCooldown = 1.5;
      }
      if (this.keys.has('KeyE')) {
        this.camYaw -= 1.75 * dt;
        this.userOrbitCooldown = 1.5;
      }
    }

    this.userOrbitCooldown = Math.max(0, this.userOrbitCooldown - dt);
    this.attackCooldown = Math.max(0, this.attackCooldown - dt);
    this.spitCooldown = Math.max(0, this.spitCooldown - dt);
    for (const id of Object.keys(this.abilityCooldowns) as AbilityId[]) {
      this.abilityCooldowns[id] = Math.max(0, this.abilityCooldowns[id] - dt);
    }
    this.dashInvulnTimer = Math.max(0, this.dashInvulnTimer - dt);
    if (this.cloakTimer > 0) {
      this.cloakTimer = Math.max(0, this.cloakTimer - dt);
      if (this.cloakTimer <= 0) this.cloaked = false;
    }
    this.wildlife.setPlayerCloaked(this.cloaked);
    this.rivals.setPlayerCloaked(this.cloaked);
    this.character.setCloaked(this.cloaked);

    if (this.combatFeedTimer > 0) {
      this.combatFeedTimer = Math.max(0, this.combatFeedTimer - dt);
      if (this.combatFeedTimer <= 0) this.combatFeed = null;
    }
    if (this.damageFlash > 0) {
      this.damageFlash = Math.max(0, this.damageFlash - dt * 1.7);
      if (this.damageFlash <= 0) this.damageSource = null;
    }
    this.camShake = Math.max(0, this.camShake - dt * 1.15);

    // Evolved Spore Mines proximity detonation
    if (this.started && !this.matchState.matchOver) this.updateMines(dt);

    // Gentle biological regeneration, boosted by Symbiote Regeneration
    const regenRate = 2.2 * (this.evo.abilities.includes('regen') ? 2.6 : 1.0);
    if (
      this.started &&
      this.evo.hp < this.evo.maxHp &&
      !(this.mode === 'battle-royale' && this.matchState.matchOver)
    ) {
      this.evo.hp = Math.min(this.evo.maxHp, this.evo.hp + dt * regenRate);
    }

    // Update 3rd-person Spore Slime locomotion & exact triangle physics
    let horizSpeed = 0;
    let slopePitch = 0;
    let sprinting = false;
    this.gliding = false;

    if (this.started && this.introBlend < 0.75) {
      const dropping = this.mode === 'battle-royale' && this.dropIntroTimer > 2.3;
      let inX = dropping ? 0 : this.joyX;
      let inY = dropping ? 0 : this.joyY;

      if (this.keys.has('KeyW') || this.keys.has('ArrowUp')) inY -= 1;
      if (this.keys.has('KeyS') || this.keys.has('ArrowDown')) inY += 1;
      if (this.keys.has('KeyA') || this.keys.has('ArrowLeft')) inX -= 1;
      if (this.keys.has('KeyD') || this.keys.has('ArrowRight')) inX += 1;

      const mag = Math.hypot(inX, inY);
      const analogMag = Math.min(1, mag);
      if (mag > 1) {
        inX /= mag;
        inY /= mag;
      }

      const sinY = Math.sin(this.camYaw);
      const cosY = Math.cos(this.camYaw);
      const fwdAmount = -inY;
      const moveDirX = -sinY * fwdAmount + cosY * inX;
      const moveDirZ = -cosY * fwdAmount - sinY * inX;

      const wantSprint = !dropping && (
        (this.keys.has('ShiftLeft') || this.keys.has('ShiftRight') || this.touchSprint) &&
        analogMag > 0.35
      );
      sprinting = wantSprint && !this.swimming;

      let maxSpd =
        (this.swimming
          ? this.SWIM_SPEED * (wantSprint ? 1.38 : 1.0)
          : sprinting
          ? this.SPRINT_SPEED
          : this.WALK_SPEED) * this.evo.speedMult;

      if (this.wading && !this.swimming) {
        maxSpd *= 0.82;
      }

      const targetVx = moveDirX * maxSpd;
      const targetVz = moveDirZ * maxSpd;
      const accel = this.grounded || this.swimming ? 11.5 : 4.2;

      this.playerVel.x = lerp(this.playerVel.x, targetVx, Math.min(1, dt * accel));
      this.playerVel.z = lerp(this.playerVel.z, targetVz, Math.min(1, dt * accel));

      let nextX = clamp(this.playerPos.x + this.playerVel.x * dt, -1120, 1120);
      let nextZ = clamp(this.playerPos.z + this.playerVel.z * dt, -1120, 1120);
      [nextX, nextZ] = this.chunks.resolveCollisions(nextX, nextZ, 0.4);

      const curGround = getRenderedTerrainHeight(this.playerPos.x, this.playerPos.z);
      const nextGround = getRenderedTerrainHeight(nextX, nextZ);
      const stepDist = Math.hypot(nextX - this.playerPos.x, nextZ - this.playerPos.z);
      if (stepDist > 0.0001) {
        const grade = (nextGround - curGround) / stepDist;
        slopePitch = grade;
        if (grade > 1.35 && this.grounded && !this.swimming) {
          const factor = clamp(1.0 - (grade - 1.35) * 0.65, 0.15, 1.0);
          nextX = lerp(this.playerPos.x, nextX, factor);
          nextZ = lerp(this.playerPos.z, nextZ, factor);
        }
      }

      this.playerPos.x = nextX;
      this.playerPos.z = nextZ;

      // Exact 0.000m rendered triangle elevation right beneath boots!
      const groundY = getRenderedTerrainHeight(this.playerPos.x, this.playerPos.z);
      const waterDepth = WATER_LEVEL - groundY;

      this.swimming = waterDepth > 1.15 && this.playerPos.y <= WATER_LEVEL - 0.55;
      this.wading = !this.swimming && waterDepth > 0.15 && this.playerPos.y < WATER_LEVEL + 0.1;

      if (this.swimming) {
        const targetSwimY = WATER_LEVEL - 0.92;
        this.playerPos.y = lerp(this.playerPos.y, targetSwimY, Math.min(1, dt * 7));
        this.playerVel.y = 0;
        this.grounded = false;
        this.jumpQueued = false;
      } else {
        if (this.jumpQueued && this.grounded) {
          this.playerVel.y = this.JUMP_VEL * this.evo.jumpMult;
          this.grounded = false;
        }
        this.jumpQueued = false;

        // Glidewing Membranes trait: slow-fall air gliding when holding Space / Jump while descending!
        const jumpHeld = this.keys.has('Space') || this.touchJumpHeld;
        const dropGliding = this.mode === 'battle-royale' && this.dropIntroTimer > 0;
        if (
          !this.grounded &&
          ((this.evo.glide && jumpHeld && this.playerVel.y < -0.5) || dropGliding)
        ) {
          this.gliding = true;
          const gravityScale = dropGliding ? 0.46 : 0.22;
          const terminalSpeed = dropGliding ? -14 : -2.6;
          this.playerVel.y = Math.max(terminalSpeed, this.playerVel.y - this.GRAVITY * gravityScale * dt);
        } else {
          this.playerVel.y -= this.GRAVITY * dt;
        }
        this.playerPos.y += this.playerVel.y * dt;

        if (waterDepth > 1.15 && this.playerPos.y <= WATER_LEVEL - 0.92) {
          this.playerPos.y = WATER_LEVEL - 0.92;
          if (this.playerVel.y < -3) {
            this.audio.playFootstep('water', true);
            this.particles.spawnWaterRipple(this.playerPos.x, this.playerPos.z, 4.2);
          }
          this.playerVel.y = 0;
          this.swimming = true;
          this.grounded = false;
        } else if (this.playerPos.y <= groundY) {
          if (!this.grounded && this.playerVel.y < -4.2) {
            this.landingImpact = clamp(-this.playerVel.y / 14, 0.25, 1.0);
            const norm = getRenderedTerrainNormal(this.playerPos.x, this.playerPos.z);
            const surf = getSurfaceMaterial(
              this.playerPos.x,
              this.playerPos.z,
              groundY,
              norm[1]
            );
            this.audio.playFootstep(surf, true);
            this.particles.spawnFootstepEffect(
              this.playerPos.x,
              groundY,
              this.playerPos.z,
              surf,
              true
            );
          }
          this.playerPos.y = groundY;
          this.playerVel.y = 0;
          this.grounded = true;
        } else if (this.grounded && this.playerPos.y - groundY < 0.48 && this.playerVel.y <= 0) {
          // Lock smoothly onto exact downhill terrain triangles with zero micro-bounce!
          this.playerPos.y = groundY;
          this.playerVel.y = 0;
        } else {
          this.grounded = false;
        }
      }

      horizSpeed = Math.hypot(this.playerVel.x, this.playerVel.z);

      if (horizSpeed > 0.25) {
        const desiredYaw = Math.atan2(-this.playerVel.x, -this.playerVel.z);
        const diff = shortestAngleDiff(this.playerYaw, desiredYaw);
        this.playerYaw += diff * Math.min(1, dt * 11.5);

        if (this.userOrbitCooldown <= 0 && Math.abs(inX) > 0.25 && inY <= 0.1) {
          const camDiff = shortestAngleDiff(this.camYaw, desiredYaw);
          this.camYaw += camDiff * dt * (this.isMobile ? 1.35 : 0.65);
        }
      }
    }

    this.landingImpact = Math.max(0, this.landingImpact - dt * 3.8);

    this.character.root.position.copy(this.playerPos);
    this.character.root.rotation.y = this.playerYaw;

    const footStrike = this.character.update(dt, this.elapsed, {
      speed: horizSpeed,
      maxSprintSpeed: this.SPRINT_SPEED * this.evo.speedMult,
      grounded: this.grounded,
      verticalVel: this.playerVel.y,
      swimming: this.swimming,
      wading: this.wading,
      gliding: this.gliding,
      landingImpact: this.landingImpact,
      nightFactor: this.sky.state.nightFactor,
      slopePitch,
    });

    if (footStrike && this.started) {
      const groundY = getRenderedTerrainHeight(this.playerPos.x, this.playerPos.z);
      const norm = getRenderedTerrainNormal(this.playerPos.x, this.playerPos.z);
      const surface =
        this.swimming || this.wading
          ? 'water'
          : getSurfaceMaterial(this.playerPos.x, this.playerPos.z, groundY, norm[1]);
      this.audio.playFootstep(surface, sprinting);
      this.particles.spawnFootstepEffect(
        this.playerPos.x,
        groundY,
        this.playerPos.z,
        surface,
        sprinting
      );
    }

    // Smooth spring-arm 3rd-person camera (+ title vista transition)
    this.camDist = lerp(this.camDist, this.targetCamDist, Math.min(1, dt * 7));
    this.computeThirdPersonCamera(this.vDesiredCam, this.vDesiredLook);

    const camSmooth = 1.0 - Math.exp(-12.5 * dt);
    this.smoothCamPos.lerp(this.vDesiredCam, camSmooth);
    this.smoothLookAt.lerp(this.vDesiredLook, camSmooth);

    if (this.introBlend > 0.001) {
      if (this.started) {
        this.introBlend = Math.max(0, this.introBlend - dt * 0.85);
      }
      const e = this.introBlend * this.introBlend * (3.0 - 2.0 * this.introBlend);

      const orbit = Math.sin(this.elapsed * 0.13) * 8.0;
      const introX = this.playerPos.x + 4.8 + orbit;
      const introZ = this.playerPos.z + 14.5;
      const introMinY = getRenderedTerrainHeight(introX, introZ) + 3.5;
      this.vIntroCam.set(
        introX,
        Math.max(introMinY, this.playerPos.y + 7.2 + Math.cos(this.elapsed * 0.17) * 0.9),
        introZ
      );
      this.vIntroLook.set(
        this.playerPos.x - 3.5 + orbit * 0.25,
        this.playerPos.y + 4.8,
        this.playerPos.z - 55.0
      );

      this.camera.position.copy(this.smoothCamPos).lerp(this.vIntroCam, e);
      this.vDesiredLook.copy(this.smoothLookAt).lerp(this.vIntroLook, e);
      this.camera.lookAt(this.vDesiredLook);
    } else {
      this.camera.position.copy(this.smoothCamPos);
      this.camera.lookAt(this.smoothLookAt);
    }

    // Camera recoil from alien strikes (small, decaying handheld shake)
    if (this.camShake > 0.001) {
      const k = this.camShake;
      this.camera.position.x += (Math.random() - 0.5) * k;
      this.camera.position.y += (Math.random() - 0.5) * k * 0.8;
      this.camera.position.z += (Math.random() - 0.5) * k;
    }

    const targetFov = sprinting && horizSpeed > 7.0 ? 61.5 : 55.0;
    if (Math.abs(this.camera.fov - targetFov) > 0.05) {
      this.camera.fov = lerp(this.camera.fov, targetFov, Math.min(1, dt * 5.5));
      this.camera.updateProjectionMatrix();
    }

    // Stream seamless world chunks
    this.chunks.update(this.playerPos.x, this.playerPos.z, false);

    // Sample current biome with smooth hysteresis
    const weights = sampleBiomeWeights(this.playerPos.x, this.playerPos.z);
    if (weights.dominant !== this.currentBiome) {
      if (weights.dominant === this.candidateBiome) {
        this.biomeHoldTimer += dt;
        if (this.biomeHoldTimer > 1.35) {
          this.currentBiome = weights.dominant;
          this.biomeHoldTimer = 0;
          const firstTime = !this.discovered.has(this.currentBiome);
          this.discovered.add(this.currentBiome);
          if (this.started) {
            this.audio.playBiomeDiscovery();
            this.callbacks.onBiomeEnter(
              this.currentBiome,
              firstTime,
              Math.round(Math.max(0, this.playerPos.y))
            );
          }
        }
      } else {
        this.candidateBiome = weights.dominant;
        this.biomeHoldTimer = 0;
      }
    } else {
      this.biomeHoldTimer = 0;
    }

    const targetFog = BIOMES[this.currentBiome].fogTint;
    this.blendedFogTint[0] = lerp(this.blendedFogTint[0], targetFog[0], dt * 1.4);
    this.blendedFogTint[1] = lerp(this.blendedFogTint[1], targetFog[1], dt * 1.4);
    this.blendedFogTint[2] = lerp(this.blendedFogTint[2], targetFog[2], dt * 1.4);

    // Update sky, terrain cloud shadows, water, backlit botanical foliage, wildlife & particles
    this.sky.update(this.timeOfDay, this.elapsed, this.playerPos, this.blendedFogTint);
    this.weather.update(
      dt,
      this.elapsed,
      this.playerPos,
      this.currentBiome,
      this.timeOfDay,
      this.mode
    );
    this.weather.applyToFog(this.sky.fog);
    this.sky.sunLight.intensity *= this.weather.getLightMultiplier();
    const wind = this.weather.getWind();
    if (!this.grounded) {
      this.playerVel.x += wind.x * dt * 0.85;
      this.playerVel.z += wind.z * dt * 0.85;
    }
    this.chunks.updateAtmosphere(this.elapsed, this.sky.state, this.playerPos);
    this.water.update(this.elapsed, this.sky.state, this.sky.fog);
    this.foliage.update(
      this.elapsed,
      this.sky.state.sunDirection,
      this.sky.state.sunColor,
      this.sky.state.dayFactor,
      this.sky.state.nightFactor
    );
    this.wildlife.update(
      dt,
      this.elapsed,
      this.playerPos,
      this.camera,
      horizSpeed,
      this.sky.state.nightFactor
    );

    // Offline AI pilots + Battle Royale zone / win-lose resolution
    if (this.started && !this.matchState.matchOver) {
      this.matchState = this.rivals.update(
        dt,
        this.elapsed,
        this.playerPos,
        this.evo.hp
      );
      if (this.matchState.matchOver && !this.matchOverAnnounced) {
        this.matchOverAnnounced = true;
        this.keys.clear();
        this.joyX = 0;
        this.joyY = 0;
        this.touchSprint = false;
        this.combatFeed = this.matchState.playerWon
          ? 'LAST SYMBIOTE STANDING — YOU WIN!'
          : `${this.matchState.winner ?? 'The Bio-Storm'} won the match.`;
        this.combatFeedTimer = 10;
        if (this.matchState.playerWon) {
          this.audio.playEvolutionFanfare();
          this.callbacks.onProgressSaved?.(this.evo, Array.from(this.discovered));
        } else {
          this.audio.playPlayerHurtSound();
          this.damageFlash = 0.8;
          this.damageSource = this.matchState.winner;
        }
        this.emitHud();
      }
    }

    // Real-player relay sync; remote rivals are driven by their own clients.
    if (this.network && this.mode === 'battle-royale' && this.started && !this.matchState.matchOver) {
      this.networkTimer += dt;
      if (this.networkTimer >= 0.1) {
        this.networkTimer = 0;
        this.network.sendPlayerState({
          id: this.network.getLocalId(),
          name: this.evo.speciesName,
          x: this.playerPos.x,
          y: this.playerPos.y,
          z: this.playerPos.z,
          yaw: this.playerYaw,
          hp: this.evo.hp,
          alive: this.matchState.playerAlive && this.evo.hp > 0,
        });
      }
      for (const st of this.network.drainRemoteStates()) this.rivals.applyRemoteState(st);
    }

    this.plants.update(
      dt,
      this.elapsed,
      this.playerPos,
      this.weather.getKind(),
      this.weather.getRegrowthBoost()
    );
    this.particles.update(
      dt,
      this.elapsed,
      this.playerPos,
      this.currentBiome,
      this.sky.state.nightFactor,
      this.swimming || this.wading,
      horizSpeed
    );

    // Adapt ACES tone mapping & subtle golden-hour / dusk lantern bloom dynamically
    this.renderer.toneMappingExposure = lerp(1.2, 1.05, this.sky.state.dayFactor) * this.weather.getExposureMultiplier();
    if (this.bloomPass) {
      this.bloomPass.strength =
        0.19 + this.sky.state.goldenFactor * 0.14 + this.sky.state.nightFactor * 0.1;
    }

    const waterProx = clamp(1.0 - Math.max(0, this.playerPos.y - WATER_LEVEL) / 9.5, 0, 1);
    this.audio.setWeatherIntensity(this.weather.getSnapshot().intensity);
    this.audio.update(
      dt,
      this.elapsed,
      this.currentBiome,
      this.playerPos.y,
      waterProx,
      this.sky.state.dayFactor,
      this.sky.state.nightFactor,
      horizSpeed
    );

    // Render with 4x MSAA HDR Bloom + ACES Filmic on Ultra, or crisp direct ACES on High!
    if (this.composer && this.graphicsQuality === 'ultra') {
      this.composer.render(dt);
    } else {
      this.renderer.render(this.scene, this.camera);
    }

    this.hudTimer += dt;
    if (this.hudTimer >= 0.085) {
      this.hudTimer = 0;
      this.emitHud(sprinting);
    }
  };

  private emitHud(sprinting = false): void {
    const bearingDeg = (((-this.camYaw * 180) / Math.PI) % 360 + 360) % 360;
    const targetRange = this.evo.abilities.includes('sense') ? 46 : 28;
    const target = this.wildlife.getNearestTargetInfo(
      this.playerPos.x,
      this.playerPos.y,
      this.playerPos.z,
      targetRange
    );
    this.callbacks.onHudUpdate({
      x: this.playerPos.x,
      y: this.playerPos.y,
      z: this.playerPos.z,
      bearingDeg,
      playerYaw: this.playerYaw,
      biome: this.currentBiome,
      altitude: Math.round(Math.max(0, this.playerPos.y)),
      timeOfDay: this.timeOfDay,
      timePaused: this.timePaused,
      swimming: this.swimming,
      sprinting,
      gliding: this.gliding,
      discovered: Array.from(this.discovered),
      cameraPreset: this.cameraPreset,
      graphicsQuality: this.graphicsQuality,
      muted: this.audio.isMuted(),
      evo: { ...this.evo, hp: Math.round(this.evo.hp) },
      target,
      attackCooldown: this.attackCooldown,
      spitCooldown: this.spitCooldown,
      combatFeed: this.combatFeed,
      damageFlash: this.damageFlash,
      damageSource: this.damageSource,
      mode: this.mode,
      maxPlayers: this.maxPlayers,
      match: { ...this.matchState },
      abilities: [...this.evo.abilities],
      abilityCooldowns: { ...this.abilityCooldowns },
      cloaked: this.cloaked,
      weather: this.weather.getSnapshot(),
      nearbyPlant: this.plants.getNearbyInfo(),
    });
  }

  public getMapRadius(): number {
    return WORLD_MAP_RADIUS;
  }

  public dispose(): void {
    this.disposed = true;
    cancelAnimationFrame(this.rafId);
    this.resizeObserver.disconnect();
    window.removeEventListener('keydown', this.onKeyDown);
    window.removeEventListener('keyup', this.onKeyUp);
    window.removeEventListener('blur', this.onWindowBlur);
    const canvas = this.renderer.domElement;
    canvas.removeEventListener('pointerdown', this.onPointerDown);
    canvas.removeEventListener('pointermove', this.onPointerMove);
    canvas.removeEventListener('pointerup', this.onPointerUp);
    canvas.removeEventListener('pointercancel', this.onPointerUp);
    canvas.removeEventListener('wheel', this.onWheel);
    canvas.removeEventListener('contextmenu', this.onContextMenu);
    this.audio.setMuted(true);
    this.composer?.dispose();
    this.sky.dispose();
    this.chunks.dispose();
    this.renderer.dispose();
    if (canvas.parentElement === this.container) {
      this.container.removeChild(canvas);
    }
  }
}
