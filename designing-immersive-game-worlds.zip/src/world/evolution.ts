import { CreatureCallKind } from './audio';
import { BiomeId } from './biomes';

export type EssenceType = 'predator' | 'chitin' | 'gelatinous' | 'aerial';

export interface EssenceDefinition {
  id: EssenceType;
  name: string;
  shortName: string;
  color: string;
  description: string;
  sources: string;
}

export const ESSENCES: Record<EssenceType, EssenceDefinition> = {
  gelatinous: {
    id: 'gelatinous',
    name: 'Bio-Voltaic Goo DNA',
    shortName: 'Bio-Goo',
    color: '#38bdf8',
    description: 'Mutates shock tentacles, acid-plasma glands, and multi-ocular stalks.',
    sources: 'Bloblings, Skyjellies, Glowfins',
  },
  predator: {
    id: 'predator',
    name: 'Apex Predator DNA',
    shortName: 'Predator',
    color: '#fb7185',
    description: 'Mutates snapping mandibles, scythe claws, and dorsal razor spines.',
    sources: 'Vexari Grazers, Thornbacks, Rift Wyrms',
  },
  chitin: {
    id: 'chitin',
    name: 'Mineral Carapace DNA',
    shortName: 'Carapace',
    color: '#c084fc',
    description: 'Mutates crystalline armor plates, insectoid stilt-legs, and crusher claws.',
    sources: 'Prism Crabs, Longstriders, Titan Colossi',
  },
  aerial: {
    id: 'aerial',
    name: 'Aero-Membrane DNA',
    shortName: 'Aero-Fin',
    color: '#34d399',
    description: 'Mutates gliding manta wings, propulsion tail-flukes, and bio-thrusters.',
    sources: 'Glidewings, Skyjellies, Glowfins',
  },
};

export type TraitId =
  | 'mandibles'
  | 'scythe_claws'
  | 'dorsal_spines'
  | 'crystal_shell'
  | 'stilt_legs'
  | 'crusher_pincers'
  | 'shock_tentacles'
  | 'plasma_gland'
  | 'eye_stalks'
  | 'glide_wings'
  | 'tail_fluke'
  | 'phase_dash'
  | 'gravity_slam'
  | 'spore_mines'
  | 'void_lance'
  | 'phase_veil'
  | 'symbiote_regen'
  | 'apex_sense';

export type AbilityId =
  | 'dash'
  | 'slam'
  | 'mines'
  | 'lance'
  | 'cloak'
  | 'regen'
  | 'sense';

export interface AbilityDefinition {
  id: AbilityId;
  name: string;
  shortName: string;
  key: string;
  cooldown: number;
  unlockStage: number;
  active: boolean;
  description: string;
  color: string;
}

export const ABILITIES: Record<AbilityId, AbilityDefinition> = {
  dash: {
    id: 'dash',
    name: 'Phase Dash',
    shortName: 'Dash',
    key: 'G',
    cooldown: 4.5,
    unlockStage: 2,
    active: true,
    description: 'Burst forward through prey, damaging everything in your path and briefly dodging hits.',
    color: '#34d399',
  },
  slam: {
    id: 'slam',
    name: 'Gravity Slam',
    shortName: 'Slam',
    key: 'X',
    cooldown: 8,
    unlockStage: 3,
    active: true,
    description: 'Crush the ground with a radial bio-shockwave that damages and knocks back nearby enemies.',
    color: '#c084fc',
  },
  mines: {
    id: 'mines',
    name: 'Spore Mines',
    shortName: 'Mines',
    key: 'C',
    cooldown: 10,
    unlockStage: 4,
    active: true,
    description: 'Deploy three glowing proximity spores that detonate when hunters or rivals come close.',
    color: '#22d3ee',
  },
  lance: {
    id: 'lance',
    name: 'Void Lance',
    shortName: 'Lance',
    key: 'B',
    cooldown: 7,
    unlockStage: 5,
    active: true,
    description: 'Fire a piercing lance of void energy straight ahead, hitting every target in a line.',
    color: '#fb7185',
  },
  cloak: {
    id: 'cloak',
    name: 'Phase Veil',
    shortName: 'Cloak',
    key: 'Z',
    cooldown: 14,
    unlockStage: 6,
    active: true,
    description: 'Become translucent for a few seconds so wildlife and rival pilots stop targeting you.',
    color: '#a855f7',
  },
  regen: {
    id: 'regen',
    name: 'Symbiote Regeneration',
    shortName: 'Regen',
    key: 'PASSIVE',
    cooldown: 0,
    unlockStage: 0,
    active: false,
    description: 'Heal much faster over time and regain extra biomass whenever you devour prey.',
    color: '#4ade80',
  },
  sense: {
    id: 'sense',
    name: 'Apex Sense',
    shortName: 'Sense',
    key: 'PASSIVE',
    cooldown: 0,
    unlockStage: 0,
    active: false,
    description: 'Lock onto prey from farther away and deal bonus damage to wounded targets.',
    color: '#f59e0b',
  },
};

/** Abilities unlock by evolution stage; matching traits unlock them early. */
export function getUnlockedAbilities(stage: number, traits: TraitId[]): AbilityId[] {
  const owned = new Set(traits);
  const out: AbilityId[] = [];
  if (stage >= 2 || owned.has('phase_dash')) out.push('dash');
  if (stage >= 3 || owned.has('gravity_slam')) out.push('slam');
  if (stage >= 4 || owned.has('spore_mines')) out.push('mines');
  if (stage >= 5 || owned.has('void_lance')) out.push('lance');
  if (stage >= 6 || owned.has('phase_veil')) out.push('cloak');
  if (owned.has('symbiote_regen')) out.push('regen');
  if (owned.has('apex_sense')) out.push('sense');
  return out;
}

/** Trait mastery reduces that ability's cooldown. */
export function getAbilityCooldown(id: AbilityId, traits: TraitId[]): number {
  const base = ABILITIES[id].cooldown;
  const owned = new Set(traits);
  switch (id) {
    case 'dash':
      return owned.has('phase_dash') ? 2.8 : base;
    case 'slam':
      return owned.has('gravity_slam') ? 5.5 : base;
    case 'mines':
      return owned.has('spore_mines') ? 7.0 : base;
    case 'lance':
      return owned.has('void_lance') ? 4.5 : base;
    case 'cloak':
      return owned.has('phase_veil') ? 9.0 : base;
    default:
      return base;
  }
}

export interface TraitDefinition {
  id: TraitId;
  name: string;
  subtitle: string;
  essence: EssenceType;
  unlockedByText: string;
  visualMutation: string;
  gameplayEffect: string;
  ability?: AbilityId;
  accentColor: string;
  bodyTint: [number, number, number];
  glowTint: [number, number, number];
  bonuses: {
    maxHp: number;
    biteDamage: number;
    spitDamage: number;
    speedMult: number;
    jumpMult: number;
    armor: number; // 0..0.5 damage reduction
    glide: boolean;
    scaleBonus: number;
  };
}

export const TRAITS: Record<TraitId, TraitDefinition> = {
  mandibles: {
    id: 'mandibles',
    name: 'Razor Mandibles',
    subtitle: 'Predator Jaw Mutation',
    essence: 'predator',
    unlockedByText: 'Eaten Predator Prey (Grazers & Thornbacks)',
    visualMutation: 'Grows snapping articulated chitin mandibles & glowing fangs on your front.',
    gameplayEffect: '+18 Bite Damage & wider crunch arc.',
    accentColor: '#fb7185',
    bodyTint: [0.95, 0.28, 0.42],
    glowTint: [1.6, 0.35, 0.55],
    bonuses: {
      maxHp: 15,
      biteDamage: 18,
      spitDamage: 0,
      speedMult: 0.05,
      jumpMult: 0,
      armor: 0,
      glide: false,
      scaleBonus: 0.22,
    },
  },
  scythe_claws: {
    id: 'scythe_claws',
    name: 'Raptor Scythe-Arms',
    subtitle: 'Mantis Strike Limbs',
    essence: 'predator',
    unlockedByText: 'Eaten Agile Prey (Thornbacks & Grazers)',
    visualMutation: 'Sprouts twin serrated mantis scythe-arms that slash when you lunge.',
    gameplayEffect: '+15 Bite Damage, +25% Lunge Reach & +10% Speed.',
    accentColor: '#f43f5e',
    bodyTint: [0.92, 0.32, 0.30],
    glowTint: [1.7, 0.45, 0.3],
    bonuses: {
      maxHp: 20,
      biteDamage: 15,
      spitDamage: 4,
      speedMult: 0.1,
      jumpMult: 0.08,
      armor: 0.05,
      glide: false,
      scaleBonus: 0.24,
    },
  },
  dorsal_spines: {
    id: 'dorsal_spines',
    name: 'Bioluminescent Spine Crest',
    subtitle: 'Apex Ridge Spikes',
    essence: 'predator',
    unlockedByText: 'Eaten Fierce Wildlife (Thornbacks & Wyrms)',
    visualMutation: 'Erupts a row of glowing crimson-violet predator spines along your back.',
    gameplayEffect: '+12 Bite Damage, +30 Max HP & damages attackers on contact.',
    accentColor: '#f97316',
    bodyTint: [0.88, 0.38, 0.24],
    glowTint: [1.8, 0.5, 0.25],
    bonuses: {
      maxHp: 30,
      biteDamage: 12,
      spitDamage: 5,
      speedMult: 0.06,
      jumpMult: 0.05,
      armor: 0.1,
      glide: false,
      scaleBonus: 0.25,
    },
  },
  crystal_shell: {
    id: 'crystal_shell',
    name: 'Prism Crystal Carapace',
    subtitle: 'Faceted Exo-Armor',
    essence: 'chitin',
    unlockedByText: 'Eaten Shelled Prey (Prism Crabs & Longstriders)',
    visualMutation: 'Encrusts your upper dome in glowing hexagonal prism crystals & armor plates.',
    gameplayEffect: '+55 Max HP & 22% Damage Reduction.',
    accentColor: '#c084fc',
    bodyTint: [0.62, 0.42, 0.96],
    glowTint: [1.1, 0.65, 1.85],
    bonuses: {
      maxHp: 55,
      biteDamage: 8,
      spitDamage: 6,
      speedMult: 0,
      jumpMult: 0,
      armor: 0.22,
      glide: false,
      scaleBonus: 0.28,
    },
  },
  stilt_legs: {
    id: 'stilt_legs',
    name: 'Arachnid Stilt-Legs',
    subtitle: 'Six-Jointed Strider Limbs',
    essence: 'chitin',
    unlockedByText: 'Eaten Multi-Legged Prey (Crabs, Grazers & Striders)',
    visualMutation: 'Grows 6 articulated alien legs under your slime body that stride across land.',
    gameplayEffect: '+28% Movement Speed & +20% Jump Height.',
    accentColor: '#a855f7',
    bodyTint: [0.58, 0.48, 0.92],
    glowTint: [0.85, 0.65, 1.75],
    bonuses: {
      maxHp: 25,
      biteDamage: 8,
      spitDamage: 0,
      speedMult: 0.28,
      jumpMult: 0.2,
      armor: 0.08,
      glide: false,
      scaleBonus: 0.25,
    },
  },
  crusher_pincers: {
    id: 'crusher_pincers',
    name: 'Obsidian Crusher Claws',
    subtitle: 'Heavy Siege Chelae',
    essence: 'chitin',
    unlockedByText: 'Eaten Armored Prey (Prism Crabs & Wyrms)',
    visualMutation: 'Forms massive crystal-tipped crab pincers flanking your slime body.',
    gameplayEffect: '+22 Bite Damage & +35 Max HP.',
    accentColor: '#e879f9',
    bodyTint: [0.74, 0.36, 0.88],
    glowTint: [1.45, 0.5, 1.7],
    bonuses: {
      maxHp: 35,
      biteDamage: 22,
      spitDamage: 0,
      speedMult: 0.02,
      jumpMult: 0,
      armor: 0.14,
      glide: false,
      scaleBonus: 0.26,
    },
  },
  shock_tentacles: {
    id: 'shock_tentacles',
    name: 'Voltaic Whip-Tentacles',
    subtitle: 'Bio-Electric Tendrils',
    essence: 'gelatinous',
    unlockedByText: 'Eaten Gelatinous Prey (Skyjellies & Bloblings)',
    visualMutation: 'Sprouts 6 undulating, glowing jellyfish tentacles trailing from your core.',
    gameplayEffect: '+14 Bite & Spit Damage, plus bio-electric shock reach.',
    accentColor: '#38bdf8',
    bodyTint: [0.22, 0.78, 0.98],
    glowTint: [0.35, 1.55, 1.9],
    bonuses: {
      maxHp: 25,
      biteDamage: 14,
      spitDamage: 14,
      speedMult: 0.1,
      jumpMult: 0.1,
      armor: 0.05,
      glide: false,
      scaleBonus: 0.24,
    },
  },
  plasma_gland: {
    id: 'plasma_gland',
    name: 'Bio-Plasma Spitter Sacs',
    subtitle: 'Pressurized Acid Organ',
    essence: 'gelatinous',
    unlockedByText: 'Eaten Luminescent Prey (Bloblings, Jellies & Glowfins)',
    visualMutation: 'Grows pulsing neon venom sacs on your flanks & a dorsal bio-cannon.',
    gameplayEffect: '+22 Ranged Bio-Pulse Damage & faster projectile recharge.',
    accentColor: '#22d3ee',
    bodyTint: [0.18, 0.88, 0.82],
    glowTint: [0.3, 1.75, 1.55],
    bonuses: {
      maxHp: 20,
      biteDamage: 6,
      spitDamage: 22,
      speedMult: 0.06,
      jumpMult: 0.05,
      armor: 0.05,
      glide: false,
      scaleBonus: 0.22,
    },
  },
  eye_stalks: {
    id: 'eye_stalks',
    name: 'Tri-Ocular Sensor Stalks',
    subtitle: 'Compound Xeno-Vision',
    essence: 'gelatinous',
    unlockedByText: 'Eaten Curious Prey (Bloblings & Glowfins)',
    visualMutation: 'Sprouts 3 tall, expressive alien eye-stalks with glowing compound irises.',
    gameplayEffect: '+12 Bite & Spit Damage, +12% Speed & wider prey sense.',
    accentColor: '#67e8f9',
    bodyTint: [0.32, 0.84, 0.96],
    glowTint: [0.55, 1.65, 1.85],
    bonuses: {
      maxHp: 20,
      biteDamage: 12,
      spitDamage: 12,
      speedMult: 0.12,
      jumpMult: 0.1,
      armor: 0,
      glide: false,
      scaleBonus: 0.2,
    },
  },
  glide_wings: {
    id: 'glide_wings',
    name: 'Glidewing Membranes',
    subtitle: 'Bioluminescent Manta Fins',
    essence: 'aerial',
    unlockedByText: 'Eaten Aerial / Finned Prey (Glidewings & Skyjellies)',
    visualMutation: 'Unfurls sweeping bioluminescent manta wings from your sides that flap in flight.',
    gameplayEffect: '+45% Jump Height, Slow-Fall Air Gliding & +18% Speed!',
    accentColor: '#34d399',
    bodyTint: [0.2, 0.88, 0.66],
    glowTint: [0.35, 1.75, 1.25],
    bonuses: {
      maxHp: 20,
      biteDamage: 8,
      spitDamage: 10,
      speedMult: 0.18,
      jumpMult: 0.45,
      armor: 0,
      glide: true,
      scaleBonus: 0.24,
    },
  },
  tail_fluke: {
    id: 'tail_fluke',
    name: 'Propulsion Tail-Fluke',
    subtitle: 'Whip-Fin Thruster',
    essence: 'aerial',
    unlockedByText: 'Eaten Aquatic / Sky Prey (Glowfins & Glidewings)',
    visualMutation: 'Grows a long segmented tail with glowing side-fins that whips as you move.',
    gameplayEffect: '+25% Sprint & Swim Speed, +20% Jump & +10 Bite Damage.',
    accentColor: '#6ee7b7',
    bodyTint: [0.26, 0.92, 0.72],
    glowTint: [0.4, 1.8, 1.35],
    bonuses: {
      maxHp: 25,
      biteDamage: 10,
      spitDamage: 6,
      speedMult: 0.25,
      jumpMult: 0.2,
      armor: 0.05,
      glide: false,
      scaleBonus: 0.23,
    },
  },
  phase_dash: {
    id: 'phase_dash',
    name: 'Phase-Jet Pods',
    subtitle: 'Blink-Burst Thrusters',
    essence: 'aerial',
    unlockedByText: 'Eaten Fast Sky Prey (Glidewings & Glowfins)',
    visualMutation: 'Sprouts twin glowing jet-pods and swept stabilizer fins on both flanks.',
    gameplayEffect: 'Unlocks Phase Dash early, +22% Speed, +18% Jump & +8 Spit Damage.',
    ability: 'dash',
    accentColor: '#34d399',
    bodyTint: [0.18, 0.92, 0.72],
    glowTint: [0.25, 1.85, 1.35],
    bonuses: {
      maxHp: 20,
      biteDamage: 8,
      spitDamage: 8,
      speedMult: 0.22,
      jumpMult: 0.18,
      armor: 0.02,
      glide: false,
      scaleBonus: 0.2,
    },
  },
  gravity_slam: {
    id: 'gravity_slam',
    name: 'Gravitic Crush-Plates',
    subtitle: 'Seismic Chitin Fists',
    essence: 'chitin',
    unlockedByText: 'Eaten Armored Prey (Crabs, Striders & Wyrms)',
    visualMutation: 'Forms heavy faceted hammer-plates beneath your slime body that pulse before a slam.',
    gameplayEffect: 'Unlocks Gravity Slam early, +45 Max HP, +14 Bite & +12% Armor.',
    ability: 'slam',
    accentColor: '#c084fc',
    bodyTint: [0.58, 0.44, 0.94],
    glowTint: [0.95, 0.65, 1.85],
    bonuses: {
      maxHp: 45,
      biteDamage: 14,
      spitDamage: 8,
      speedMult: 0.04,
      jumpMult: 0.05,
      armor: 0.12,
      glide: false,
      scaleBonus: 0.25,
    },
  },
  spore_mines: {
    id: 'spore_mines',
    name: 'Lumispore Mine Sacs',
    subtitle: 'Proximity Detonation Organs',
    essence: 'gelatinous',
    unlockedByText: 'Eaten Gelatinous Prey (Bloblings, Skyjellies & Glowfins)',
    visualMutation: 'Grows a crown of translucent glowing spore sacs that drip living bio-mines.',
    gameplayEffect: 'Unlocks Spore Mines early, +28 Max HP & +20 Spit Damage.',
    ability: 'mines',
    accentColor: '#22d3ee',
    bodyTint: [0.16, 0.84, 0.88],
    glowTint: [0.3, 1.75, 1.85],
    bonuses: {
      maxHp: 28,
      biteDamage: 6,
      spitDamage: 20,
      speedMult: 0.06,
      jumpMult: 0.06,
      armor: 0.04,
      glide: false,
      scaleBonus: 0.21,
    },
  },
  void_lance: {
    id: 'void_lance',
    name: 'Void Lance Horn',
    subtitle: 'Piercing Bio-Cannon',
    essence: 'predator',
    unlockedByText: 'Eaten Apex Predator Prey (Thornbacks, Wyrms & Grazers)',
    visualMutation: 'Grows a long serrated void-horn emitter above the eyes with a glowing muzzle.',
    gameplayEffect: 'Unlocks Void Lance early, +18 Bite & +18 Spit Damage.',
    ability: 'lance',
    accentColor: '#fb7185',
    bodyTint: [0.94, 0.28, 0.44],
    glowTint: [1.85, 0.35, 0.65],
    bonuses: {
      maxHp: 25,
      biteDamage: 18,
      spitDamage: 18,
      speedMult: 0.08,
      jumpMult: 0.05,
      armor: 0.04,
      glide: false,
      scaleBonus: 0.23,
    },
  },
  phase_veil: {
    id: 'phase_veil',
    name: 'Phase-Veil Membranes',
    subtitle: 'Predator Invisibility Frills',
    essence: 'aerial',
    unlockedByText: 'Eaten Aerial Prey (Glidewings & Skyjellies)',
    visualMutation: 'Unfurls translucent ghost-frills that shimmer and fade your body while cloaked.',
    gameplayEffect: 'Unlocks Phase Veil early, +16% Speed & +10 Spit Damage.',
    ability: 'cloak',
    accentColor: '#a855f7',
    bodyTint: [0.42, 0.72, 0.98],
    glowTint: [0.8, 0.6, 1.9],
    bonuses: {
      maxHp: 22,
      biteDamage: 8,
      spitDamage: 10,
      speedMult: 0.16,
      jumpMult: 0.12,
      armor: 0.05,
      glide: false,
      scaleBonus: 0.2,
    },
  },
  symbiote_regen: {
    id: 'symbiote_regen',
    name: 'Regenerative Moss Shell',
    subtitle: 'Self-Healing Symbiosis',
    essence: 'chitin',
    unlockedByText: 'Eaten Shelled / Wetland Prey (Crabs, Bloblings & Glowfins)',
    visualMutation: 'Encrusts your lower membrane in living emerald moss plates that pulse with healing light.',
    gameplayEffect: 'Passive: 2.6× HP regeneration & +16% extra healing on every devour.',
    ability: 'regen',
    accentColor: '#4ade80',
    bodyTint: [0.28, 0.86, 0.48],
    glowTint: [0.35, 1.8, 0.75],
    bonuses: {
      maxHp: 50,
      biteDamage: 6,
      spitDamage: 8,
      speedMult: 0.04,
      jumpMult: 0.04,
      armor: 0.14,
      glide: false,
      scaleBonus: 0.24,
    },
  },
  apex_sense: {
    id: 'apex_sense',
    name: 'Apex Sensor Crown',
    subtitle: 'Hunter Tracking Organs',
    essence: 'predator',
    unlockedByText: 'Eaten Fierce Predator Prey (Thornbacks & Wyrms)',
    visualMutation: 'Sprouts a crown of twitching sensor antennae and three extra predator eyes.',
    gameplayEffect: 'Passive: longer target lock & +25% damage against wounded prey.',
    ability: 'sense',
    accentColor: '#f59e0b',
    bodyTint: [0.92, 0.58, 0.22],
    glowTint: [1.85, 0.85, 0.25],
    bonuses: {
      maxHp: 25,
      biteDamage: 12,
      spitDamage: 14,
      speedMult: 0.12,
      jumpMult: 0.08,
      armor: 0.06,
      glide: false,
      scaleBonus: 0.22,
    },
  },
};

export const ALL_TRAIT_IDS = Object.keys(TRAITS) as TraitId[];

export interface SpeciesPreyInfo {
  id: CreatureCallKind;
  name: string;
  tier: number; // 1 = Small prey, 2 = Medium, 3 = Large, 4 = Giant, 5 = Apex Colossal
  maxHp: number;
  dnaReward: number;
  primaryEssence: EssenceType;
  secondaryEssence: EssenceType;
  hitRadius: number;
  heightOffset: number;
  attackDamage: number;
  aggressive: boolean;
}

export const SPECIES_PREY_INFO: Record<CreatureCallKind, SpeciesPreyInfo> = {
  blob: {
    id: 'blob',
    name: 'Blobling',
    tier: 1,
    maxHp: 28,
    dnaReward: 26,
    primaryEssence: 'gelatinous',
    secondaryEssence: 'predator',
    hitRadius: 1.4,
    heightOffset: 0.5,
    attackDamage: 4,
    aggressive: false,
  },
  crab: {
    id: 'crab',
    name: 'Prism Crab',
    tier: 1,
    maxHp: 38,
    dnaReward: 32,
    primaryEssence: 'chitin',
    secondaryEssence: 'gelatinous',
    hitRadius: 1.5,
    heightOffset: 0.5,
    attackDamage: 7,
    aggressive: false,
  },
  fish: {
    id: 'fish',
    name: 'Glowfin',
    tier: 1,
    maxHp: 25,
    dnaReward: 28,
    primaryEssence: 'aerial',
    secondaryEssence: 'gelatinous',
    hitRadius: 1.5,
    heightOffset: 0.3,
    attackDamage: 3,
    aggressive: false,
  },
  jelly: {
    id: 'jelly',
    name: 'Skyjelly',
    tier: 2,
    maxHp: 46,
    dnaReward: 40,
    primaryEssence: 'gelatinous',
    secondaryEssence: 'aerial',
    hitRadius: 2.3,
    heightOffset: 0.0,
    attackDamage: 9,
    aggressive: false,
  },
  grazer: {
    id: 'grazer',
    name: 'Vexari Grazer',
    tier: 2,
    maxHp: 68,
    dnaReward: 48,
    primaryEssence: 'predator',
    secondaryEssence: 'chitin',
    hitRadius: 2.2,
    heightOffset: 1.2,
    attackDamage: 11,
    aggressive: false,
  },
  manta: {
    id: 'manta',
    name: 'Glidewing Ray',
    tier: 2,
    maxHp: 60,
    dnaReward: 52,
    primaryEssence: 'aerial',
    secondaryEssence: 'gelatinous',
    hitRadius: 2.8,
    heightOffset: 0.0,
    attackDamage: 10,
    aggressive: false,
  },
  thorn: {
    id: 'thorn',
    name: 'Thornback Stalker',
    tier: 3,
    maxHp: 95,
    dnaReward: 70,
    primaryEssence: 'predator',
    secondaryEssence: 'chitin',
    hitRadius: 2.2,
    heightOffset: 1.0,
    attackDamage: 16,
    aggressive: true,
  },
  wyrm: {
    id: 'wyrm',
    name: 'Rift Wyrm',
    tier: 3,
    maxHp: 135,
    dnaReward: 95,
    primaryEssence: 'predator',
    secondaryEssence: 'chitin',
    hitRadius: 3.0,
    heightOffset: 1.0,
    attackDamage: 20,
    aggressive: true,
  },
  strider: {
    id: 'strider',
    name: 'Longstrider',
    tier: 4,
    maxHp: 160,
    dnaReward: 110,
    primaryEssence: 'chitin',
    secondaryEssence: 'aerial',
    hitRadius: 4.5,
    heightOffset: 2.0,
    attackDamage: 18,
    aggressive: false,
  },
  titan: {
    id: 'titan',
    name: 'Titan Colossus',
    tier: 5,
    maxHp: 420,
    dnaReward: 250,
    primaryEssence: 'chitin',
    secondaryEssence: 'predator',
    hitRadius: 10.5,
    heightOffset: 3.5,
    attackDamage: 32,
    aggressive: false,
  },
};

export const STAGE_NAMES: ReadonlyArray<string> = [
  'Proto-Goo',
  'Mutant Symbiote',
  'Xeno-Stalker',
  'Bio-Ravager',
  'Apex Leviathan',
  'Ascended Xeno-Beast',
  'Starforged Colossus',
  'Void Sovereign',
  'Galactic Progenitor',
];

export function getStageTitle(stage: number): string {
  const i = Math.max(0, Math.floor(stage - 1));
  if (i < STAGE_NAMES.length) return STAGE_NAMES[i];
  return `${STAGE_NAMES[STAGE_NAMES.length - 1]} +${i - STAGE_NAMES.length + 1}`;
}

/** DNA needed to reach the next evolution stage */
export function getDnaRequiredForStage(stage: number): number {
  return Math.round(80 + (stage - 1) * 55);
}

export type DietRecord = Record<EssenceType, number>;

export function emptyDiet(): DietRecord {
  return { predator: 0, chitin: 0, gelatinous: 0, aerial: 0 };
}

export interface SlimeEvolutionState {
  speciesName: string;
  baseColorHex: string;
  stage: number; // starts at 1
  dna: number;
  dnaNext: number;
  evolveReady: boolean;
  traits: TraitId[];
  abilities: AbilityId[];
  stageDiet: DietRecord; // Essence points eaten during current stage
  totalDiet: DietRecord; // Lifetime essence points eaten
  kills: number;
  hp: number;
  maxHp: number;
  biteDamage: number;
  spitDamage: number;
  speedMult: number;
  jumpMult: number;
  armor: number;
  glide: boolean;
  ascended: boolean;
  bodyScale: number;
}

export function computeSlimeStats(
  stage: number,
  traits: TraitId[],
  speciesName = 'Xeno-Goo',
  baseColorHex = '#2dd4bf',
  dna = 0,
  stageDiet: DietRecord = emptyDiet(),
  totalDiet: DietRecord = emptyDiet(),
  kills = 0,
  currentHp?: number
): SlimeEvolutionState {
  let maxHp = 100 + (stage - 1) * 25;
  let biteDamage = 20 + (stage - 1) * 6;
  let spitDamage = 15 + (stage - 1) * 5;
  let speedMult = 1.0;
  let jumpMult = 1.0;
  let armor = 0;
  let glide = false;
  let scaleBonus = 0;

  for (const tid of traits) {
    const t = TRAITS[tid];
    if (!t) continue;
    maxHp += t.bonuses.maxHp;
    biteDamage += t.bonuses.biteDamage;
    spitDamage += t.bonuses.spitDamage;
    speedMult += t.bonuses.speedMult;
    jumpMult += t.bonuses.jumpMult;
    armor = Math.min(0.6, armor + t.bonuses.armor);
    if (t.bonuses.glide) glide = true;
    scaleBonus += t.bonuses.scaleBonus;
  }

  const dnaNext = getDnaRequiredForStage(stage);
  const progressGrowth = Math.min(1, dna / Math.max(1, dnaNext)) * 0.18;
  // Starts as a cute compact 0.76x slime and grows into a towering 2.4x+ monster!
  const bodyScale = 0.76 + scaleBonus + progressGrowth;

  return {
    speciesName,
    baseColorHex,
    stage,
    dna,
    dnaNext,
    evolveReady: dna >= dnaNext && traits.length < ALL_TRAIT_IDS.length,
    traits: [...traits],
    abilities: getUnlockedAbilities(stage, traits),
    stageDiet: { ...stageDiet },
    totalDiet: { ...totalDiet },
    kills,
    hp: currentHp !== undefined ? Math.min(maxHp, Math.max(1, currentHp)) : maxHp,
    maxHp,
    biteDamage,
    spitDamage,
    speedMult,
    jumpMult,
    armor,
    glide,
    ascended: stage >= 6,
    bodyScale,
  };
}

/**
 * Select 3 Evolution Trait choices tailored to what the player has been eating!
 * Prioritizes unowned traits matching the player's top eaten EssenceType(s).
 */
export function getDietTraitChoices(
  ownedTraits: TraitId[],
  stageDiet: DietRecord,
  totalDiet: DietRecord
): TraitDefinition[] {
  const owned = new Set(ownedTraits);
  const available = ALL_TRAIT_IDS.filter((id) => !owned.has(id)).map((id) => TRAITS[id]);
  if (available.length <= 3) return available;

  // Score each essence by what the player ate this stage (plus a small tiebreaker from lifetime diet)
  const essenceScores: Record<EssenceType, number> = {
    predator: stageDiet.predator * 3 + totalDiet.predator * 0.5,
    chitin: stageDiet.chitin * 3 + totalDiet.chitin * 0.5,
    gelatinous: stageDiet.gelatinous * 3 + totalDiet.gelatinous * 0.5,
    aerial: stageDiet.aerial * 3 + totalDiet.aerial * 0.5,
  };

  // Sort essences highest-first
  const rankedEssences = (Object.keys(essenceScores) as EssenceType[]).sort(
    (a, b) => essenceScores[b] - essenceScores[a]
  );

  const chosen: TraitDefinition[] = [];
  const pickedIds = new Set<TraitId>();

  // 1st & 2nd slots come directly from the player's top eaten diet essences
  for (const ess of rankedEssences) {
    const matching = available.filter((t) => t.essence === ess && !pickedIds.has(t.id));
    for (const m of matching) {
      if (chosen.length < 2) {
        chosen.push(m);
        pickedIds.add(m.id);
      }
    }
  }

  // 3rd slot comes from second-highest diet essence or a complementary mutation
  for (const ess of rankedEssences.slice(1)) {
    const match = available.find((t) => t.essence === ess && !pickedIds.has(t.id));
    if (match && chosen.length < 3) {
      chosen.push(match);
      pickedIds.add(match.id);
    }
  }

  for (const t of available) {
    if (chosen.length >= 3) break;
    if (!pickedIds.has(t.id)) {
      chosen.push(t);
      pickedIds.add(t.id);
    }
  }

  return chosen;
}

// ────────────────────── USER ACCOUNT & PERSISTENCE SYSTEM ──────────────────────

export interface UserProfile {
  username: string;
  displayName: string;
  passwordHash: string;
  speciesName: string;
  baseColorHex: string;
  stage: number;
  dna: number;
  traits: TraitId[];
  stageDiet: DietRecord;
  totalDiet: DietRecord;
  kills: number;
  discoveredBiomes: BiomeId[];
  lastLoginAt: number;
}

/** Lightweight skill estimate for same-bracket Battle Royale matchmaking.
 * Uses persistent stage, mutation depth, and prey experience; it is not an Elo rating.
 */
export function getMatchmakingRating(profile: UserProfile): number {
  const stageScore = Math.max(0, profile.stage - 1) * 145;
  const mutationScore = Math.min(11, profile.traits.length) * 42;
  const huntScore = Math.sqrt(Math.max(0, profile.kills)) * 28;
  const dnaScore = Math.min(260, Math.max(0, profile.dna) * 0.08);
  return Math.max(500, Math.min(2600, Math.round(650 + stageScore + mutationScore + huntScore + dnaScore)));
}

export function getMatchmakingBracket(profile: UserProfile): number {
  return Math.max(0, Math.min(9, Math.floor(getMatchmakingRating(profile) / 350)));
}

export function getMatchmakingRoom(profile: UserProfile): string {
  return `MM-S${getMatchmakingBracket(profile)}`;
}

const ACCOUNTS_KEY = 'solvara_accounts_v1';
const ACTIVE_USER_KEY = 'solvara_active_user_v1';

function simpleHash(str: string): string {
  let h = 2166136261 >>> 0;
  for (let i = 0; i < str.length; i++) {
    h ^= str.charCodeAt(i);
    h = Math.imul(h, 16777619) >>> 0;
  }
  return h.toString(16);
}

export function loadAllAccounts(): Record<string, UserProfile> {
  try {
    const raw = localStorage.getItem(ACCOUNTS_KEY);
    if (!raw) return {};
    return JSON.parse(raw) as Record<string, UserProfile>;
  } catch {
    return {};
  }
}

function saveAllAccounts(accounts: Record<string, UserProfile>): void {
  try {
    localStorage.setItem(ACCOUNTS_KEY, JSON.stringify(accounts));
  } catch {
    /* ignore quota errors */
  }
}

export function getActiveAccount(): UserProfile | null {
  try {
    const username = localStorage.getItem(ACTIVE_USER_KEY);
    if (!username) return null;
    const accounts = loadAllAccounts();
    return accounts[username.toLowerCase()] ?? null;
  } catch {
    return null;
  }
}

export function registerOrLoginAccount(
  usernameInput: string,
  passwordInput: string,
  mode: 'login' | 'register',
  speciesNameInput = 'Lumigoo',
  baseColorHex = '#2dd4bf'
): { ok: boolean; profile?: UserProfile; error?: string } {
  const cleanUser = usernameInput.trim();
  if (cleanUser.length < 2) {
    return { ok: false, error: 'Callsign must be at least 2 characters.' };
  }
  const key = cleanUser.toLowerCase();
  const accounts = loadAllAccounts();
  const passHash = simpleHash(passwordInput || 'solvara');

  if (mode === 'login') {
    const existing = accounts[key];
    if (!existing) {
      return { ok: false, error: 'Account not found. Switch to Create Account or use Quick Play!' };
    }
    if (existing.passwordHash !== passHash && passwordInput !== '') {
      return { ok: false, error: 'Incorrect password for this callsign.' };
    }
    existing.lastLoginAt = Date.now();
    accounts[key] = existing;
    saveAllAccounts(accounts);
    try {
      localStorage.setItem(ACTIVE_USER_KEY, key);
    } catch {
      /* ignore */
    }
    return { ok: true, profile: existing };
  }

  // Register or overwrite
  const profile: UserProfile = {
    username: key,
    displayName: cleanUser,
    passwordHash: passHash,
    speciesName: speciesNameInput.trim() || 'Lumigoo',
    baseColorHex: baseColorHex || '#2dd4bf',
    stage: 1,
    dna: 0,
    traits: [],
    stageDiet: emptyDiet(),
    totalDiet: emptyDiet(),
    kills: 0,
    discoveredBiomes: ['meadow'],
    lastLoginAt: Date.now(),
  };

  accounts[key] = profile;
  saveAllAccounts(accounts);
  try {
    localStorage.setItem(ACTIVE_USER_KEY, key);
  } catch {
    /* ignore */
  }
  return { ok: true, profile };
}

export function saveProfileProgress(
  username: string,
  evo: SlimeEvolutionState,
  discoveredBiomes: BiomeId[]
): void {
  const key = username.toLowerCase();
  const accounts = loadAllAccounts();
  const existing = accounts[key];
  if (!existing) return;
  existing.speciesName = evo.speciesName;
  existing.baseColorHex = evo.baseColorHex;
  existing.stage = evo.stage;
  existing.dna = evo.dna;
  existing.traits = [...evo.traits];
  existing.stageDiet = { ...evo.stageDiet };
  existing.totalDiet = { ...evo.totalDiet };
  existing.kills = evo.kills;
  existing.discoveredBiomes = [...discoveredBiomes];
  existing.lastLoginAt = Date.now();
  accounts[key] = existing;
  saveAllAccounts(accounts);
}

export function resetProfileOrganism(
  username: string,
  speciesName: string,
  baseColorHex: string
): UserProfile | null {
  const key = username.toLowerCase();
  const accounts = loadAllAccounts();
  const existing = accounts[key];
  if (!existing) return null;
  existing.speciesName = speciesName.trim() || 'Lumigoo';
  existing.baseColorHex = baseColorHex;
  existing.stage = 1;
  existing.dna = 0;
  existing.traits = [];
  existing.stageDiet = emptyDiet();
  existing.totalDiet = emptyDiet();
  existing.kills = 0;
  existing.lastLoginAt = Date.now();
  accounts[key] = existing;
  saveAllAccounts(accounts);
  return existing;
}

export function logoutActiveAccount(): void {
  try {
    localStorage.removeItem(ACTIVE_USER_KEY);
  } catch {
    /* ignore */
  }
}
