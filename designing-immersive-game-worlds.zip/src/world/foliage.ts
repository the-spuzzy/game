import * as THREE from 'three';
import { getRenderedTerrainHeight } from './biomes';
import { BotanicalTextureSet, createBotanicalTextureSet } from './textures';

export interface FoliageAtmosphereUniforms {
  uTime: { value: number };
  uSunDir: { value: THREE.Vector3 };
  uSunColor: { value: THREE.Color };
  uDayFactor: { value: number };
  uNightGlow: { value: number };
}

interface GeoPart {
  geo: THREE.BufferGeometry;
  color?: THREE.Color;
  topColor?: THREE.Color;
}

/** Merge BufferGeometries preserving position, normal, uv, and optional vertex color */
function mergeGeos(parts: GeoPart[], withVertexColor = false): THREE.BufferGeometry {
  const converted: THREE.BufferGeometry[] = [];
  let totalVerts = 0;

  for (const part of parts) {
    const g = part.geo.index ? part.geo.toNonIndexed() : part.geo.clone();
    if (!g.attributes.normal) g.computeVertexNormals();
    const pos = g.attributes.position as THREE.BufferAttribute;
    const count = pos.count;

    if (!g.attributes.uv) {
      g.setAttribute('uv', new THREE.BufferAttribute(new Float32Array(count * 2), 2));
    }

    if (withVertexColor) {
      const colors = new Float32Array(count * 3);
      if (part.color && part.topColor) {
        let minY = Infinity;
        let maxY = -Infinity;
        for (let i = 0; i < count; i++) {
          const y = pos.getY(i);
          if (y < minY) minY = y;
          if (y > maxY) maxY = y;
        }
        const span = Math.max(0.001, maxY - minY);
        const norm = g.attributes.normal as THREE.BufferAttribute;
        const tmp = new THREE.Color();
        for (let i = 0; i < count; i++) {
          const ty = (pos.getY(i) - minY) / span;
          const ny = norm.getY(i) * 0.5 + 0.5;
          tmp.copy(part.color).lerp(part.topColor, Math.max(0, Math.min(1, ty * 0.65 + ny * 0.35)));
          colors[i * 3] = tmp.r;
          colors[i * 3 + 1] = tmp.g;
          colors[i * 3 + 2] = tmp.b;
        }
      } else {
        const c = part.color ?? new THREE.Color(1, 1, 1);
        for (let i = 0; i < count; i++) {
          colors[i * 3] = c.r;
          colors[i * 3 + 1] = c.g;
          colors[i * 3 + 2] = c.b;
        }
      }
      g.setAttribute('color', new THREE.BufferAttribute(colors, 3));
    }

    converted.push(g);
    totalVerts += count;
    part.geo.dispose();
  }

  const positions = new Float32Array(totalVerts * 3);
  const normals = new Float32Array(totalVerts * 3);
  const uvs = new Float32Array(totalVerts * 2);
  const colors = withVertexColor ? new Float32Array(totalVerts * 3) : null;

  let offset = 0;
  for (const g of converted) {
    const pos = g.attributes.position as THREE.BufferAttribute;
    const norm = g.attributes.normal as THREE.BufferAttribute;
    const uv = g.attributes.uv as THREE.BufferAttribute;
    positions.set(pos.array as Float32Array, offset * 3);
    normals.set(norm.array as Float32Array, offset * 3);
    uvs.set(uv.array as Float32Array, offset * 2);
    if (colors) {
      const col = g.attributes.color as THREE.BufferAttribute;
      colors.set(col.array as Float32Array, offset * 3);
    }
    offset += pos.count;
    g.dispose();
  }

  const merged = new THREE.BufferGeometry();
  merged.setAttribute('position', new THREE.BufferAttribute(positions, 3));
  merged.setAttribute('normal', new THREE.BufferAttribute(normals, 3));
  merged.setAttribute('uv', new THREE.BufferAttribute(uvs, 2));
  if (colors) merged.setAttribute('color', new THREE.BufferAttribute(colors, 3));
  merged.computeBoundingSphere();
  return merged;
}

/**
 * Apply spherical-crown outward normals + interior-to-exterior vertex color AO
 * (Classic Ghost of Tsushima / Horizon foliage technique: makes alpha leaf clusters
 * shade like soft, voluminous, sun-drenched 3D botanical crowns!)
 */
function applySphericalCrownShading(
  geo: THREE.BufferGeometry,
  centerX: number,
  centerY: number,
  centerZ: number,
  maxRadius: number,
  innerAO = 0.56,
  upBias = 0.35
): THREE.BufferGeometry {
  const pos = geo.attributes.position as THREE.BufferAttribute;
  const norm = geo.attributes.normal as THREE.BufferAttribute;
  const colors = new Float32Array(pos.count * 3);
  const v = new THREE.Vector3();

  for (let i = 0; i < pos.count; i++) {
    const px = pos.getX(i);
    const py = pos.getY(i);
    const pz = pos.getZ(i);
    v.set(px - centerX, py - centerY, pz - centerZ);
    const dist = v.length();
    const t = Math.max(0, Math.min(1, dist / Math.max(0.1, maxRadius)));
    const heightBoost = Math.max(0, Math.min(0.18, ((py - centerY) / Math.max(0.1, maxRadius)) * 0.18));
    const ao = Math.min(1.06, innerAO + (1.0 - innerAO) * Math.pow(t, 0.72) + heightBoost);

    v.normalize();
    v.y += upBias;
    v.normalize();
    norm.setXYZ(i, v.x, v.y, v.z);

    colors[i * 3] = ao;
    colors[i * 3 + 1] = ao;
    colors[i * 3 + 2] = ao;
  }

  geo.setAttribute('color', new THREE.BufferAttribute(colors, 3));
  return geo;
}

/** Build a gently cupped botanical leaf-cluster card facing outward from canopy center */
function makeCurvedLeafCard(size: number, cupDepth = 0.22): THREE.BufferGeometry {
  const g = new THREE.PlaneGeometry(size, size, 2, 2);
  const pos = g.attributes.position as THREE.BufferAttribute;
  for (let i = 0; i < pos.count; i++) {
    const x = pos.getX(i) / (size * 0.5);
    const y = pos.getY(i) / (size * 0.5);
    pos.setZ(i, -(x * x + y * y) * cupDepth);
  }
  return g;
}

/** Build a tapered woody limb cylinder between two exact 3D points (zero gaps!) */
function makeBranchSegment(
  ax: number,
  ay: number,
  az: number,
  bx: number,
  by: number,
  bz: number,
  rBottom: number,
  rTop: number,
  radialSegs = 7,
  uvRepeatY = 2.0
): THREE.BufferGeometry {
  const dir = new THREE.Vector3(bx - ax, by - ay, bz - az);
  const len = dir.length();
  const g = new THREE.CylinderGeometry(rTop, rBottom, len, radialSegs, 1, false);
  const uv = g.attributes.uv as THREE.BufferAttribute;
  for (let i = 0; i < uv.count; i++) {
    uv.setY(i, uv.getY(i) * uvRepeatY);
  }
  const quat = new THREE.Quaternion().setFromUnitVectors(
    new THREE.Vector3(0, 1, 0),
    dir.normalize()
  );
  g.applyQuaternion(quat);
  g.translate((ax + bx) * 0.5, (ay + by) * 0.5, (az + bz) * 0.5);
  return g;
}

/** Create photorealistic PBR botanical material with alpha cutout, backlit SSS, cloud shadows & leaf flutter */
function createBotanicalMaterial(
  atmo: FoliageAtmosphereUniforms,
  options: {
    map?: THREE.Texture | null;
    bumpMap?: THREE.Texture | null;
    bumpScale?: number;
    color?: number;
    vertexColors?: boolean;
    alphaTest?: number;
    doubleSide?: boolean;
    roughness?: number;
    swayAmp: number;
    flutterAmp: number;
    heightRef: number;
    subsurface: number;
    petalTintOnly?: boolean;
    neutralize?: boolean;
    neutralGain?: number;
    glow?: number;
  }
): THREE.MeshStandardMaterial {
  const mat = new THREE.MeshStandardMaterial({
    map: options.map ?? null,
    bumpMap: options.bumpMap ?? null,
    bumpScale: options.bumpScale ?? 0,
    color: options.color ?? 0xffffff,
    vertexColors: options.vertexColors ?? false,
    alphaTest: options.alphaTest ?? 0,
    side: options.doubleSide ? THREE.DoubleSide : THREE.FrontSide,
    roughness: options.roughness ?? 0.78,
    metalness: 0.01,
    envMapIntensity: 0.72,
  });

  const subsurf = options.subsurface;
  const petalOnly = Boolean(options.petalTintOnly);
  // Alien world: strip Earth-green from textures so per-instance colors define every hue
  const neutralize = options.neutralize ?? Boolean(options.map);
  // Dark source textures (pine needles, fronds) need more lift so alien tints don't crush to black
  const neutralGain = options.neutralGain ?? 2.0;
  // Bioluminescent veins & tips glow softly at night
  const glowAmt = options.glow ?? subsurf * 0.55;

  // Every material built by this factory shares the same onBeforeCompile source text, which
  // three.js uses as its program cache key — give each variant its own key so bushes, ferns,
  // grass & flowers don't silently reuse another plant's compiled shader constants.
  const programKey = [
    'botanical',
    options.swayAmp,
    options.flutterAmp,
    options.heightRef,
    subsurf,
    glowAmt,
    petalOnly,
    neutralize,
    neutralGain,
    Boolean(options.doubleSide),
  ].join('|');
  mat.customProgramCacheKey = () => programKey;

  mat.onBeforeCompile = (shader) => {
    shader.uniforms.uWindTime = atmo.uTime;
    shader.uniforms.uSunDir = atmo.uSunDir;
    shader.uniforms.uSunColor = atmo.uSunColor;
    shader.uniforms.uDayFactor = atmo.uDayFactor;
    shader.uniforms.uNightGlow = atmo.uNightGlow;

    shader.vertexShader = shader.vertexShader
      .replace(
        '#include <common>',
        `#include <common>
        uniform float uWindTime;
        varying vec3 vFolWorldPos;
        varying float vTipFactor;
        ${petalOnly ? 'varying vec3 vPetalTint;' : ''}`
      )
      .replace(
        '#include <color_vertex>',
        petalOnly
          ? `#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )
              vColor = vec4(1.0);
            #endif
            #ifdef USE_INSTANCING_COLOR
              vPetalTint = instanceColor.rgb;
            #else
              vPetalTint = vec3(1.0);
            #endif`
          : `#include <color_vertex>`
      )
      .replace(
        '#include <begin_vertex>',
        `#include <begin_vertex>
        float hFactor = clamp(position.y / ${options.heightRef.toFixed(2)}, 0.0, 1.35);
        vTipFactor = clamp(hFactor, 0.0, 1.0);
        float bend = hFactor * hFactor;
        #ifdef USE_INSTANCING
          vec3 instOrigin = vec3(instanceMatrix[3][0], instanceMatrix[3][1], instanceMatrix[3][2]);
        #else
          vec3 instOrigin = vec3(0.0);
        #endif
        float gustPhase = uWindTime * 1.45 + instOrigin.x * 0.07 + instOrigin.z * 0.055;
        float gust = sin(gustPhase) * 0.68 + sin(gustPhase * 2.1) * 0.32;
        float crossGust = cos(gustPhase * 0.82 + 1.2) * 0.48;
        // Delicate per-leaf micro flutter
        float flutter = sin(uWindTime * 4.2 + position.x * 3.1 + position.z * 2.7 + instOrigin.x) * ${options.flutterAmp.toFixed(4)} * vTipFactor;
        transformed.x += gust * bend * ${options.swayAmp.toFixed(3)} + flutter;
        transformed.z += crossGust * bend * ${options.swayAmp.toFixed(3)} + flutter * 0.7;
        transformed.y += flutter * 0.35;`
      )
      .replace(
        '#include <worldpos_vertex>',
        `#include <worldpos_vertex>
        vec4 folWp = vec4(transformed, 1.0);
        #ifdef USE_INSTANCING
          folWp = instanceMatrix * folWp;
        #endif
        vFolWorldPos = (modelMatrix * folWp).xyz;`
      );

    shader.fragmentShader = shader.fragmentShader
      .replace(
        '#include <common>',
        `#include <common>
        uniform float uWindTime;
        uniform vec3 uSunDir;
        uniform vec3 uSunColor;
        uniform float uDayFactor;
        uniform float uNightGlow;
        varying vec3 vFolWorldPos;
        varying float vTipFactor;
        ${petalOnly ? 'varying vec3 vPetalTint;' : ''}
        float fHash(vec2 p) {
          return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453123);
        }
        float fNoise(vec2 p) {
          vec2 i = floor(p);
          vec2 f = fract(p);
          f = f * f * (3.0 - 2.0 * f);
          return mix(
            mix(fHash(i), fHash(i + vec2(1.0, 0.0)), f.x),
            mix(fHash(i + vec2(0.0, 1.0)), fHash(i + vec2(1.0, 1.0)), f.x),
            f.y
          );
        }`
      )
      .replace(
        '#include <map_fragment>',
        petalOnly
          ? `float folLum = 0.6;
            #ifdef USE_MAP
              vec4 sampledDiffuseColor = texture2D( map, vMapUv );
              float minCh = min(sampledDiffuseColor.r, min(sampledDiffuseColor.g, sampledDiffuseColor.b));
              float petalMask = smoothstep(0.36, 0.68, minCh);
              folLum = dot(sampledDiffuseColor.rgb, vec3(0.3, 0.59, 0.11));
              // Alien stems turn luminous teal; petals take each blossom's glowing tint
              vec3 alienStem = vec3(folLum) * vec3(0.55, 1.1, 1.05) * 1.6;
              sampledDiffuseColor.rgb = mix(alienStem, sampledDiffuseColor.rgb * vPetalTint, petalMask);
              folLum = mix(folLum * 0.5, 0.9, petalMask);
              diffuseColor *= sampledDiffuseColor;
            #endif`
          : `float folLum = 0.6;
            #ifdef USE_MAP
              vec4 sampledDiffuseColor = texture2D( map, vMapUv );
              folLum = dot(sampledDiffuseColor.rgb, vec3(0.3, 0.59, 0.11));
              ${neutralize ? `sampledDiffuseColor.rgb = min(vec3(folLum * ${neutralGain.toFixed(2)}), vec3(1.25));` : ''}
              diffuseColor *= sampledDiffuseColor;
            #endif`
      )
      .replace(
        '#include <normal_fragment_begin>',
        // Keep spherical outward crown normals facing smoothly on both sides of botanical leaf cards!
        options.doubleSide && subsurf > 0.01
          ? `float faceDirection = 1.0;
             vec3 normal = normalize( vNormal );
             vec3 nonPerturbedNormal = normal;`
          : `#include <normal_fragment_begin>`
      )
      .replace(
        '#include <lights_fragment_end>',
        `#include <lights_fragment_end>
        // Synced drifting cloud shadow across forests & meadows
        vec2 cUv = vFolWorldPos.xz * 0.0042 + vec2(uWindTime * 0.011, uWindTime * 0.005);
        float cShadow = 1.0 - smoothstep(0.54, 0.76, fNoise(cUv) * 0.65 + fNoise(cUv * 2.1) * 0.35) * 0.34 * uDayFactor;
        reflectedLight.directDiffuse *= cShadow;
        float folGlowMask = smoothstep(0.14, 0.5, folLum) * (0.35 + 0.65 * vTipFactor);
        reflectedLight.directDiffuse += diffuseColor.rgb * folGlowMask * uNightGlow * ${glowAmt.toFixed(3)};

        ${
          subsurf > 0.001
            ? `// Realistic backlit golden-green foliage subsurface translucency!
               vec3 viewToFrag = normalize(vFolWorldPos - cameraPosition);
               float backLight = pow(clamp(dot(viewToFrag, uSunDir), 0.0, 1.0), 2.4);
               vec3 viewSun = normalize((viewMatrix * vec4(uSunDir, 0.0)).xyz);
               float sunWrap = clamp(dot(normal, viewSun) * 0.5 + 0.5, 0.0, 1.0);
               float sss = (backLight * 0.82 + sunWrap * 0.30) * (0.35 + 0.65 * vTipFactor) * ${subsurf.toFixed(2)} * uDayFactor * cShadow;
               reflectedLight.directDiffuse += diffuseColor.rgb * uSunColor * sss;`
            : ''
        }`
      )
      .replace(
        '#include <fog_fragment>',
        `#ifdef USE_FOG
          float fFog = clamp(1.0 - exp( - fogDensity * fogDensity * vFogDepth * vFogDepth ), 0.0, 1.0);
          vec3 vRay = normalize(vFolWorldPos - cameraPosition);
          float sAlign = pow(max(dot(vRay, uSunDir), 0.0), 4.0);
          vec3 aFog = fogColor + uSunColor * sAlign * 0.24 * uDayFactor;
          gl_FragColor.rgb = mix( gl_FragColor.rgb, aFog, fFog );
        #endif`
      );
  };

  return mat;
}

/** 1. Towering Old-Growth Douglas Fir / Conifer (15.8m base height, rooted to -0.85m) */
function buildConiferGeos(heightScale = 1.0, droop = 0.24): {
  trunk: THREE.BufferGeometry;
  canopy: THREE.BufferGeometry;
} {
  const H = 15.8 * heightScale;
  const trunkParts: GeoPart[] = [];

  // Main furrowed trunk deeply rooted (-0.85m) so steep hills NEVER leave a gap
  trunkParts.push({
    geo: makeBranchSegment(0, -0.85, 0, 0, H * 0.94, 0, 0.42 * heightScale, 0.06, 8, 7.0),
  });
  // 4 flared organic root buttresses gripping the forest soil
  for (let r = 0; r < 4; r++) {
    const a = (r / 4) * Math.PI * 2 + 0.4;
    trunkParts.push({
      geo: makeBranchSegment(
        Math.cos(a) * 0.56 * heightScale,
        -0.55,
        Math.sin(a) * 0.56 * heightScale,
        Math.cos(a) * 0.14 * heightScale,
        1.15,
        Math.sin(a) * 0.14 * heightScale,
        0.18 * heightScale,
        0.11 * heightScale,
        5,
        1.2
      ),
    });
  }

  // 10 lush tiered whorls of sweeping botanical pine-bough fronds (clear trunk below 2.9m!)
  const canopyParts: GeoPart[] = [];
  const tiers = 10;
  for (let t = 0; t < tiers; t++) {
    const u = t / (tiers - 1); // 0 = lowest mature boughs, 1 = high crown
    const y = (2.95 + u * 11.8) * heightScale;
    const boughLen = (3.85 * (1.0 - Math.pow(u, 1.12) * 0.76) + 0.35) * heightScale;
    const boughWid = boughLen * 0.92;
    const count = t < 4 ? 5 : t < 8 ? 4 : 3;

    for (let k = 0; k < count; k++) {
      const ang = (k / count) * Math.PI * 2 + t * 0.78;
      // Plane UV: v=0 at trunk attachment, v=1 at outer branch tip
      const g = new THREE.PlaneGeometry(boughWid, boughLen, 2, 2);
      g.translate(0, boughLen * 0.46, 0); // Anchor base cleanly inside trunk!
      g.rotateX(Math.PI * 0.5 + droop - u * 0.38); // Lower boughs sweep down gracefully, top shoots angle skyward!

      // Subtle natural bough arch & radial roll
      const pos = g.attributes.position as THREE.BufferAttribute;
      for (let i = 0; i < pos.count; i++) {
        const pz = pos.getZ(i);
        const px = pos.getX(i);
        const out = Math.max(0, pz / boughLen);
        pos.setY(i, pos.getY(i) - out * out * 0.28 + Math.abs(px) * 0.08);
      }
      g.rotateZ((k % 2 === 0 ? 1 : -1) * 0.12);
      g.rotateY(ang);
      g.translate(0, y, 0);
      canopyParts.push({ geo: g });
    }
  }

  // Crown leader spire at very top (crossed vertical pine shoots)
  for (let c = 0; c < 2; c++) {
    const top = new THREE.PlaneGeometry(1.55 * heightScale, 2.5 * heightScale, 1, 1);
    top.rotateY((c * Math.PI) / 2 + 0.3);
    top.translate(0, H - 0.9 * heightScale, 0);
    canopyParts.push({ geo: top });
  }

  const canopy = mergeGeos(canopyParts, false);
  applySphericalCrownShading(canopy, 0, 8.6 * heightScale, 0, 4.6 * heightScale, 0.54, 0.42);
  return { trunk: mergeGeos(trunkParts, false), canopy };
}

/** 2. Majestic Broadleaf Oak Tree (12.4m base height, walkable 3.4m trunk clearance) */
function buildOakGeos(): { trunk: THREE.BufferGeometry; canopy: THREE.BufferGeometry } {
  const trunkParts: GeoPart[] = [];

  // Sturdy gnarled trunk + root buttresses down to -0.80m
  trunkParts.push({ geo: makeBranchSegment(0, -0.8, 0, 0.08, 3.65, -0.05, 0.54, 0.38, 9, 3.0) });
  for (let r = 0; r < 5; r++) {
    const a = (r / 5) * Math.PI * 2;
    trunkParts.push({
      geo: makeBranchSegment(
        Math.cos(a) * 0.72,
        -0.55,
        Math.sin(a) * 0.72,
        Math.cos(a) * 0.2,
        1.25,
        Math.sin(a) * 0.2,
        0.22,
        0.13,
        5,
        1.2
      ),
    });
  }

  // 5 spreading primary limbs + sub-branches supporting 7 lush foliage sub-crowns
  const limbs = [
    { sx: 0.05, sy: 3.45, sz: -0.04, ex: -2.25, ey: 6.3, ez: 1.25, r0: 0.26, r1: 0.11, cr: 2.4 },
    { sx: 0.08, sy: 3.5, sz: -0.04, ex: 2.35, ey: 6.5, ez: -1.1, r0: 0.27, r1: 0.11, cr: 2.45 },
    { sx: 0.06, sy: 3.55, sz: -0.02, ex: 1.35, ey: 6.8, ez: 2.15, r0: 0.24, r1: 0.10, cr: 2.3 },
    { sx: 0.04, sy: 3.5, sz: -0.06, ex: -1.45, ey: 6.7, ez: -2.05, r0: 0.24, r1: 0.10, cr: 2.3 },
    { sx: 0.08, sy: 3.55, sz: -0.05, ex: 0.12, ey: 8.85, ez: 0.08, r0: 0.28, r1: 0.11, cr: 2.65 },
  ];

  const crownCenters: Array<{ x: number; y: number; z: number; r: number }> = [];
  for (const l of limbs) {
    trunkParts.push({
      geo: makeBranchSegment(l.sx, l.sy, l.sz, l.ex, l.ey, l.ez, l.r0, l.r1, 7, 2.4),
    });
    crownCenters.push({ x: l.ex * 1.14, y: l.ey + 0.95, z: l.ez * 1.14, r: l.cr });
  }
  // Upper dome clusters for full rich silhouette
  crownCenters.push({ x: -1.1, y: 9.2, z: 0.65, r: 2.25 });
  crownCenters.push({ x: 1.15, y: 9.3, z: -0.6, r: 2.25 });

  // Place 5 multi-angled curved botanical leaf-branch cards per sub-crown (35 total)
  const canopyParts: GeoPart[] = [];
  crownCenters.forEach((cc, cIdx) => {
    for (let k = 0; k < 5; k++) {
      const card = makeCurvedLeafCard(cc.r * 1.62, 0.28);
      const yaw = (k / 5) * Math.PI * 2 + cIdx * 1.13;
      const pitch = k === 4 ? -Math.PI * 0.42 : -0.28 + (k % 2) * 0.48;
      card.rotateX(pitch);
      card.rotateY(yaw);
      const off = k === 4 ? 0.35 : cc.r * 0.34;
      card.translate(
        cc.x + Math.sin(yaw) * off,
        cc.y + (k === 4 ? cc.r * 0.36 : (k % 2 - 0.4) * 0.45),
        cc.z + Math.cos(yaw) * off
      );
      canopyParts.push({ geo: card });
    }
  });

  const canopy = mergeGeos(canopyParts, false);
  applySphericalCrownShading(canopy, 0, 7.6, 0, 5.2, 0.52, 0.38);
  return { trunk: mergeGeos(trunkParts, false), canopy };
}

/** 3. Graceful Twin-Stem Silver Birch / Autumn Maple (12.0m base height, rooted to -0.75m) */
function buildBirchGeos(): { trunk: THREE.BufferGeometry; canopy: THREE.BufferGeometry } {
  const trunkParts: GeoPart[] = [];

  // Primary silver-white birch stem + slender companion fork
  trunkParts.push({ geo: makeBranchSegment(0, -0.75, 0, 0.18, 4.4, 0.05, 0.31, 0.19, 8, 1.0) });
  trunkParts.push({ geo: makeBranchSegment(0.18, 4.35, 0.05, 0.42, 9.6, -0.18, 0.19, 0.06, 7, 1.0) });
  trunkParts.push({ geo: makeBranchSegment(-0.04, 0.8, 0.02, -0.95, 5.2, 0.45, 0.21, 0.12, 7, 1.0) });
  trunkParts.push({ geo: makeBranchSegment(-0.95, 5.15, 0.45, -1.45, 8.7, 0.72, 0.12, 0.05, 6, 1.0) });
  // Graceful side limbs
  trunkParts.push({ geo: makeBranchSegment(0.22, 4.5, 0.04, 1.75, 7.1, 0.85, 0.13, 0.05, 6, 1.0) });
  trunkParts.push({ geo: makeBranchSegment(0.25, 5.2, 0.0, -0.35, 7.6, -1.55, 0.12, 0.05, 6, 1.0) });

  const clusters = [
    { x: 0.4, y: 10.2, z: -0.15, r: 2.05 },
    { x: -1.45, y: 8.8, z: 0.72, r: 1.95 },
    { x: 1.75, y: 7.4, z: 0.85, r: 1.95 },
    { x: -0.35, y: 7.8, z: -1.55, r: 1.9 },
    { x: 1.15, y: 6.1, z: -1.1, r: 1.85 },
    { x: -1.3, y: 5.8, z: -0.35, r: 1.85 },
    { x: 0.15, y: 5.4, z: 1.25, r: 1.8 },
  ];

  const canopyParts: GeoPart[] = [];
  clusters.forEach((c, idx) => {
    for (let k = 0; k < 4; k++) {
      const card = makeCurvedLeafCard(c.r * 1.58, 0.24);
      const yaw = (k / 4) * Math.PI * 2 + idx * 0.9;
      card.rotateX(k === 3 ? -1.15 : -0.2 + (k % 2) * 0.45);
      card.rotateY(yaw);
      card.translate(
        c.x + Math.sin(yaw) * c.r * 0.28,
        c.y + (k - 1.5) * 0.28,
        c.z + Math.cos(yaw) * c.r * 0.28
      );
      canopyParts.push({ geo: card });
    }
  });

  const canopy = mergeGeos(canopyParts, false);
  applySphericalCrownShading(canopy, 0, 7.5, 0, 4.4, 0.58, 0.36);
  return { trunk: mergeGeos(trunkParts, false), canopy };
}

/** 4. Young Woodland Understory Sapling (4.9m base height — natural forest mid-story!) */
function buildSaplingGeos(): { trunk: THREE.BufferGeometry; canopy: THREE.BufferGeometry } {
  const trunkParts: GeoPart[] = [
    { geo: makeBranchSegment(0, -0.55, 0, 0.08, 2.3, 0, 0.13, 0.08, 6, 1.5) },
    { geo: makeBranchSegment(0.08, 2.25, 0, 0.65, 3.7, 0.35, 0.075, 0.03, 5, 1.0) },
    { geo: makeBranchSegment(0.08, 2.25, 0, -0.62, 3.85, -0.3, 0.075, 0.03, 5, 1.0) },
    { geo: makeBranchSegment(0.08, 2.25, 0, 0.05, 4.2, -0.25, 0.075, 0.03, 5, 1.0) },
  ];

  const clusters = [
    { x: 0.72, y: 3.75, z: 0.4, r: 1.18 },
    { x: -0.68, y: 3.9, z: -0.35, r: 1.22 },
    { x: 0.05, y: 4.35, z: -0.15, r: 1.28 },
    { x: -0.15, y: 2.95, z: 0.68, r: 1.08 },
  ];

  const canopyParts: GeoPart[] = [];
  clusters.forEach((c, idx) => {
    for (let k = 0; k < 3; k++) {
      const card = makeCurvedLeafCard(c.r * 1.55, 0.18);
      const yaw = (k / 3) * Math.PI * 2 + idx;
      card.rotateX(-0.28 + (k % 2) * 0.5);
      card.rotateY(yaw);
      card.translate(c.x, c.y, c.z);
      canopyParts.push({ geo: card });
    }
  });

  const canopy = mergeGeos(canopyParts, false);
  applySphericalCrownShading(canopy, 0, 3.6, 0, 2.2, 0.6, 0.42);
  return { trunk: mergeGeos(trunkParts, false), canopy };
}

/** 5. Graceful Curved Tropical Coconut Palm with 14 Feathered Pinnate Fronds (11.8m height) */
function buildPalmGeos(): { trunk: THREE.BufferGeometry; canopy: THREE.BufferGeometry } {
  const trunkParts: GeoPart[] = [];

  // Smooth continuous quadratic Bezier trunk curve (ZERO kinks or gaps!) from y=-0.75 to y=10.3
  const segs = 9;
  const pointAt = (t: number): [number, number, number] => {
    const x = 1.95 * t - 0.35 * t * t;
    const y = -0.75 + 11.05 * t;
    const z = Math.sin(t * Math.PI) * 0.25;
    return [x, y, z];
  };

  for (let i = 0; i < segs; i++) {
    const t0 = i / segs;
    const t1 = (i + 1) / segs;
    const [ax, ay, az] = pointAt(t0);
    const [bx, by, bz] = pointAt(t1);
    const r0 = 0.34 * (1 - t0 * 0.52) + (i === 0 ? 0.08 : 0);
    const r1 = 0.34 * (1 - t1 * 0.52);
    trunkParts.push({ geo: makeBranchSegment(ax, ay, az, bx, by, bz, r0, r1, 8, 0.9) });
  }

  const [cx, cy, cz] = pointAt(1.0);

  // Cluster of 5 ripe coconuts right under the frond crown
  for (let c = 0; c < 5; c++) {
    const a = (c / 5) * Math.PI * 2;
    const nut = new THREE.SphereGeometry(0.17, 7, 6);
    nut.translate(cx + Math.cos(a) * 0.22, cy - 0.18, cz + Math.sin(a) * 0.22);
    trunkParts.push({ geo: nut });
  }

  // 14 lush arching feathered pinnate palm fronds radiating in 2 natural tiers!
  const canopyParts: GeoPart[] = [];
  const frondCount = 14;
  for (let f = 0; f < frondCount; f++) {
    const upperTier = f % 2 === 0;
    const angle = (f / frondCount) * Math.PI * 2 + (upperTier ? 0.08 : 0);
    const len = upperTier ? 4.15 : 4.55;
    const wid = 1.65;

    // Plane UV: v=0 at bottom (-len/2), v=1 at tip (+len/2)
    const g = new THREE.PlaneGeometry(wid, len, 2, 7);
    const pos = g.attributes.position as THREE.BufferAttribute;
    for (let i = 0; i < pos.count; i++) {
      const px = pos.getX(i);
      const u = (pos.getY(i) + len * 0.5) / len; // 0 = crown stem, 1 = drooping frond tip
      const rise = upperTier ? 1.45 : 0.72;
      const droop = upperTier ? 1.35 : 2.15;
      const archY = Math.sin(u * Math.PI * 0.72) * rise - u * u * droop;
      const outZ = u * len * 0.92;
      const vFold = -Math.abs(px) * 0.22 * Math.sin(u * Math.PI);
      pos.setXYZ(i, px, archY + vFold, outZ);
    }

    g.rotateY(angle);
    g.translate(cx, cy + 0.05, cz);
    canopyParts.push({ geo: g });
  }

  const canopy = mergeGeos(canopyParts, false);
  applySphericalCrownShading(canopy, cx, cy + 0.4, cz, 4.5, 0.62, 0.55);
  return { trunk: mergeGeos(trunkParts, false), canopy };
}

/** 6. Fenland Weeping Willow (10.8m height, buttressed mossy trunk & trailing curtains) */
function buildWillowGeos(): { trunk: THREE.BufferGeometry; canopy: THREE.BufferGeometry } {
  const trunkParts: GeoPart[] = [];
  trunkParts.push({ geo: makeBranchSegment(0, -0.8, 0, 0, 3.8, 0, 0.62, 0.42, 9, 2.8) });

  // Mossy swamp root buttresses
  for (let r = 0; r < 5; r++) {
    const a = (r / 5) * Math.PI * 2 + 0.2;
    trunkParts.push({
      geo: makeBranchSegment(
        Math.cos(a) * 0.85,
        -0.6,
        Math.sin(a) * 0.85,
        Math.cos(a) * 0.25,
        1.5,
        Math.sin(a) * 0.25,
        0.24,
        0.14,
        5,
        1.2
      ),
    });
  }

  const canopyParts: GeoPart[] = [];
  // 5 graceful arching willow boughs + dome canopy
  for (let b = 0; b < 5; b++) {
    const a = (b / 5) * Math.PI * 2;
    const ex = Math.cos(a) * 2.65;
    const ez = Math.sin(a) * 2.65;
    trunkParts.push({ geo: makeBranchSegment(0, 3.6, 0, ex, 6.6, ez, 0.24, 0.09, 6, 2.2) });

    for (let k = 0; k < 3; k++) {
      const card = makeCurvedLeafCard(3.4, 0.3);
      card.rotateX(-0.55 + k * 0.35);
      card.rotateY(a + k * 1.1);
      card.translate(ex * 0.92, 7.4 + k * 0.45, ez * 0.92);
      canopyParts.push({ geo: card });
    }
  }

  // 18 delicate weeping leaf curtains cascading down cleanly to y = 1.9m (walkable head height!)
  for (let i = 0; i < 18; i++) {
    const a = (i / 18) * Math.PI * 2;
    const rad = 2.4 + (i % 3) * 0.68;
    const h = 3.9 + (i % 2) * 0.6;
    const drape = new THREE.PlaneGeometry(1.65, h, 1, 2);
    drape.rotateY(-a + Math.PI * 0.35);
    drape.translate(Math.cos(a) * rad, 1.9 + h * 0.5, Math.sin(a) * rad);
    canopyParts.push({ geo: drape });
  }

  const canopy = mergeGeos(canopyParts, false);
  applySphericalCrownShading(canopy, 0, 6.2, 0, 4.8, 0.55, 0.4);
  return { trunk: mergeGeos(trunkParts, false), canopy };
}

/** 7. Ribbed Sonoran Saguaro Cactus (5.4m height, rooted to -0.55m) */
function buildCactusGeo(): THREE.BufferGeometry {
  const parts: GeoPart[] = [];
  const baseC = new THREE.Color().setRGB(0.18, 0.34, 0.15, THREE.SRGBColorSpace);
  const topC = new THREE.Color().setRGB(0.32, 0.50, 0.23, THREE.SRGBColorSpace);

  const fluteCylinder = (rTop: number, rBot: number, len: number): THREE.BufferGeometry => {
    const g = new THREE.CylinderGeometry(rTop, rBot, len, 16, 1);
    const p = g.attributes.position as THREE.BufferAttribute;
    for (let i = 0; i < p.count; i++) {
      const x = p.getX(i);
      const z = p.getZ(i);
      const a = Math.atan2(z, x);
      const rib = 1.0 + Math.cos(a * 8.0) * 0.075;
      p.setX(i, x * rib);
      p.setZ(i, z * rib);
    }
    g.computeVertexNormals();
    return g;
  };

  // Main ribbed trunk (-0.55m to +5.15m)
  const main = fluteCylinder(0.28, 0.35, 5.7);
  main.translate(0, 2.3, 0);
  parts.push({ geo: main, color: baseC, topColor: topC });
  const cap = new THREE.SphereGeometry(0.28, 10, 7);
  cap.translate(0, 5.15, 0);
  parts.push({ geo: cap, color: topC });

  // Left classic Saguaro arm with welded elbow sphere
  const aL1 = fluteCylinder(0.2, 0.21, 0.92);
  aL1.rotateZ(Math.PI / 2);
  aL1.translate(-0.55, 2.75, 0);
  parts.push({ geo: aL1, color: baseC, topColor: topC });
  const elL = new THREE.SphereGeometry(0.2, 8, 6);
  elL.translate(-0.98, 2.75, 0);
  parts.push({ geo: elL, color: baseC });
  const aL2 = fluteCylinder(0.18, 0.2, 1.85);
  aL2.translate(-0.98, 3.68, 0);
  parts.push({ geo: aL2, color: baseC, topColor: topC });
  const capL = new THREE.SphereGeometry(0.18, 8, 6);
  capL.translate(-0.98, 4.6, 0);
  parts.push({ geo: capL, color: topC });

  // Right arm (asymmetrical natural height)
  const aR1 = fluteCylinder(0.18, 0.2, 0.84);
  aR1.rotateZ(Math.PI / 2);
  aR1.translate(0.52, 2.15, 0.08);
  parts.push({ geo: aR1, color: baseC, topColor: topC });
  const elR = new THREE.SphereGeometry(0.185, 8, 6);
  elR.translate(0.92, 2.15, 0.08);
  parts.push({ geo: elR, color: baseC });
  const aR2 = fluteCylinder(0.17, 0.185, 1.55);
  aR2.translate(0.92, 2.92, 0.08);
  parts.push({ geo: aR2, color: baseC, topColor: topC });
  const capR = new THREE.SphereGeometry(0.17, 8, 6);
  capR.translate(0.92, 3.7, 0.08);
  parts.push({ geo: capR, color: topC });

  return mergeGeos(parts, true);
}

/** 8. Full Lush 360° Botanical Bush / Flowering Shrub (1.12m tall, rooted to -0.22m!) */
function buildBotanicalBushGeo(width = 1.65, height = 1.34): THREE.BufferGeometry {
  const parts: GeoPart[] = [];

  // 5 radial upright curved shrub planes for thick, full leafy volume from every side
  for (let i = 0; i < 5; i++) {
    const a = (i / 5) * Math.PI + i * 0.11;
    const g = new THREE.PlaneGeometry(width, height, 2, 2);
    const pos = g.attributes.position as THREE.BufferAttribute;
    for (let v = 0; v < pos.count; v++) {
      const px = pos.getX(v);
      const py = pos.getY(v);
      pos.setZ(v, -(px * px) * 0.16 - Math.max(0, py) * 0.08);
    }
    g.translate(0, height * 0.5 - 0.22, 0); // Rooted -0.22m into ground -> top = 1.12m!
    g.rotateX((i % 2 === 0 ? 1 : -1) * 0.18); // Gentle outward bush splay
    g.rotateY(a);
    parts.push({ geo: g });
  }

  // 2 gently domed upper canopy caps so looking down from 3rd-person camera sees plush dense leaves!
  for (let c = 0; c < 2; c++) {
    const cap = makeCurvedLeafCard(width * 0.88, 0.22);
    cap.rotateX(-Math.PI * 0.42);
    cap.rotateY(c * 1.57 + 0.4);
    cap.translate(0, height * 0.52, 0);
    parts.push({ geo: cap });
  }

  const merged = mergeGeos(parts, false);
  applySphericalCrownShading(merged, 0, height * 0.34, 0, width * 0.62, 0.54, 0.52);
  return merged;
}

/** 9. Woodland Sword Fern / Tropical Frond Rosette (0.68m tall, rooted to -0.12m!) */
function buildFernGeo(): THREE.BufferGeometry {
  const parts: GeoPart[] = [];
  const frondCount = 9;
  for (let f = 0; f < frondCount; f++) {
    const inner = f >= 6;
    const angle = (f / (inner ? 3 : 6)) * Math.PI * 2 + (inner ? 0.52 : 0);
    const len = inner ? 0.82 : 1.06;
    const wid = inner ? 0.44 : 0.54;
    const g = new THREE.PlaneGeometry(wid, len, 1, 4);
    const pos = g.attributes.position as THREE.BufferAttribute;
    for (let i = 0; i < pos.count; i++) {
      const px = pos.getX(i);
      const u = (pos.getY(i) + len * 0.5) / len; // 0 = soil base, 1 = frond tip
      const y = -0.12 + Math.sin(u * Math.PI * 0.66) * (inner ? 0.76 : 0.62) - u * u * 0.12;
      const z = u * len * (inner ? 0.62 : 0.86);
      pos.setXYZ(i, px, y, z);
    }
    g.rotateY(angle);
    parts.push({ geo: g });
  }
  const merged = mergeGeos(parts, false);
  applySphericalCrownShading(merged, 0, 0.18, 0, 0.95, 0.6, 0.68);
  return merged;
}

/** 10. Sculptural Desert Agave / Spiny Yucca Rosette (0.78m tall, rooted to -0.15m) */
function buildAgaveGeo(): THREE.BufferGeometry {
  const parts: GeoPart[] = [];
  const baseC = new THREE.Color().setRGB(0.24, 0.38, 0.28, THREE.SRGBColorSpace);
  const tipC = new THREE.Color().setRGB(0.48, 0.64, 0.50, THREE.SRGBColorSpace);

  const leaves = 13;
  for (let i = 0; i < leaves; i++) {
    const inner = i >= 8;
    const a = (i / (inner ? 5 : 8)) * Math.PI * 2 + (inner ? 0.35 : 0);
    const len = inner ? 0.78 : 0.92;
    const cone = new THREE.ConeGeometry(0.11, len, 4);
    cone.scale(1.0, 1.0, 0.38);
    cone.translate(0, len * 0.5, 0);
    cone.rotateX(inner ? 0.42 : 0.92);
    cone.rotateY(a);
    cone.translate(0, -0.12, 0);
    parts.push({ geo: cone, color: baseC, topColor: tipC });
  }
  return mergeGeos(parts, true);
}

/** 11. Waterside Cattail Reeds (1.68m tall, coaxially aligned heads, rooted to -0.50m!) */
function buildReedGeo(): THREE.BufferGeometry {
  const parts: GeoPart[] = [];
  const stalkBot = new THREE.Color().setRGB(0.18, 0.28, 0.11, THREE.SRGBColorSpace);
  const stalkTop = new THREE.Color().setRGB(0.44, 0.58, 0.22, THREE.SRGBColorSpace);
  const headCol = new THREE.Color().setRGB(0.32, 0.18, 0.08, THREE.SRGBColorSpace);

  const specs = [
    { x: 0, z: 0, h: 1.68, rx: 0.06, rz: 0.05, head: true },
    { x: 0.24, z: 0.15, h: 1.52, rx: -0.08, rz: -0.09, head: true },
    { x: -0.22, z: 0.19, h: 1.62, rx: 0.09, rz: 0.11, head: true },
    { x: 0.14, z: -0.24, h: 1.44, rx: -0.07, rz: 0.08, head: true },
    { x: -0.2, z: -0.18, h: 1.72, rx: 0.05, rz: -0.1, head: true },
  ];

  for (const o of specs) {
    const totalLen = o.h + 0.5; // Starts at y = -0.50m underwater!
    const stalk = new THREE.CylinderGeometry(0.018, 0.034, totalLen, 5);
    stalk.translate(0, totalLen * 0.5 - 0.5, 0);
    stalk.rotateX(o.rx);
    stalk.rotateZ(o.rz);
    stalk.translate(o.x, 0, o.z);
    parts.push({ geo: stalk, color: stalkBot, topColor: stalkTop });

    if (o.head) {
      // Exact coaxial cattail head before rotation — NEVER detaches from stalk!
      const head = new THREE.CylinderGeometry(0.048, 0.048, 0.28, 6);
      head.translate(0, o.h - 0.26, 0);
      head.rotateX(o.rx);
      head.rotateZ(o.rz);
      head.translate(o.x, 0, o.z);
      parts.push({ geo: head, color: headCol });
    }

    // Companion arching sword-like reed blade
    const blade = new THREE.ConeGeometry(0.045, o.h * 0.85, 3);
    blade.scale(1, 1, 0.25);
    blade.translate(0, o.h * 0.42 - 0.25, 0);
    blade.rotateX(o.rx * 2.2 + 0.16);
    blade.rotateZ(o.rz * 2.2);
    blade.translate(o.x + 0.05, 0, o.z - 0.04);
    parts.push({ geo: blade, color: stalkBot, topColor: stalkTop });
  }
  return mergeGeos(parts, true);
}

/** 12. Floating Water Lily Pads + Lotus Blossom (sits flat right on WATER_LEVEL!) */
function buildWaterLilyGeo(): THREE.BufferGeometry {
  const parts: GeoPart[] = [];
  const padDark = new THREE.Color().setRGB(0.14, 0.34, 0.14, THREE.SRGBColorSpace);
  const padLight = new THREE.Color().setRGB(0.28, 0.52, 0.21, THREE.SRGBColorSpace);
  const lotus = new THREE.Color().setRGB(0.98, 0.88, 0.92, THREE.SRGBColorSpace);

  const pads = [
    { x: 0, z: 0, r: 0.38, a: 0.2 },
    { x: 0.52, z: 0.28, r: 0.32, a: 2.1 },
    { x: -0.38, z: 0.42, r: 0.28, a: 4.3 },
  ];
  for (const p of pads) {
    // Classic notched circle lily pad!
    const g = new THREE.CircleGeometry(p.r, 11, 0.22, Math.PI * 2 - 0.44);
    g.rotateX(-Math.PI / 2);
    g.rotateY(p.a);
    g.translate(p.x, 0.03, p.z);
    parts.push({ geo: g, color: padDark, topColor: padLight });
  }
  // Delicate lotus blossom atop primary pad
  const bloom = new THREE.ConeGeometry(0.11, 0.09, 7);
  bloom.rotateX(Math.PI);
  bloom.translate(0.06, 0.075, 0.04);
  parts.push({ geo: bloom, color: lotus });
  return mergeGeos(parts, true);
}

/** 13. Fallen Moss-Draped Forest Log (3.6m long, nestled firmly into soil) */
function buildFallenLogGeo(): THREE.BufferGeometry {
  const g = new THREE.CylinderGeometry(0.21, 0.26, 3.6, 9, 3);
  g.rotateZ(Math.PI / 2);
  const uv = g.attributes.uv as THREE.BufferAttribute;
  for (let i = 0; i < uv.count; i++) {
    uv.setY(i, uv.getY(i) * 2.5);
  }
  g.translate(0, 0.11, 0); // Rests heavily embedded 38% into mossy forest loam!
  return g;
}

/** 14. Sculpted Geological Boulder with Deep -0.55m Buried Skirt (ZERO floating on slopes!) */
function buildBoulderGeo(): THREE.BufferGeometry {
  const g = new THREE.IcosahedronGeometry(1.05, 2);
  const pos = g.attributes.position as THREE.BufferAttribute;
  for (let i = 0; i < pos.count; i++) {
    let x = pos.getX(i);
    let y = pos.getY(i);
    let z = pos.getZ(i);
    // Crisp geological rock planes & facets
    const n =
      Math.sin(x * 2.1 + 0.7) * Math.cos(y * 1.9 - 0.4) * 0.22 +
      Math.sin(z * 2.7 + x * 1.4) * 0.14 +
      Math.cos(x * 5.2 - z * 4.8 + y * 3.9) * 0.05;
    x *= (1.18 + n);
    z *= (1.02 + n);
    if (y < 0) {
      // Extend base gently downward as buried foundation skirt so edges never hover on hills!
      y = y * 0.65 - 0.12;
    } else {
      y = y * (0.78 + n * 0.7);
    }
    pos.setXYZ(i, x, y + 0.16, z);
  }
  g.computeVertexNormals();
  return mergeGeos(
    [
      {
        geo: g,
        color: new THREE.Color().setRGB(0.46, 0.45, 0.44, THREE.SRGBColorSpace),
        topColor: new THREE.Color().setRGB(0.88, 0.87, 0.85, THREE.SRGBColorSpace),
      },
    ],
    true
  );
}

/** 15. Lush Star-Crossed Botanical Grass Clump (0.45m realistic height, rooted to -0.09m!) */
function buildBotanicalGrassGeo(): THREE.BufferGeometry {
  const parts: GeoPart[] = [];
  const wid = 0.78;
  const h = 0.54; // -0.09m buried root to +0.45m realistic shin-to-knee tip!

  for (let i = 0; i < 3; i++) {
    const a = (i / 3) * Math.PI;
    const g = new THREE.PlaneGeometry(wid, h, 1, 2);
    const pos = g.attributes.position as THREE.BufferAttribute;
    for (let v = 0; v < pos.count; v++) {
      const py = pos.getY(v) + h * 0.5; // 0..h
      const t = py / h;
      pos.setY(v, py - 0.09);
      pos.setZ(v, t * t * 0.11 * (i % 2 === 0 ? 1 : -1)); // Natural graceful windward curve
    }
    g.rotateY(a);
    g.translate(Math.cos(a) * 0.06, 0, Math.sin(a) * 0.06);
    parts.push({ geo: g });
  }

  const merged = mergeGeos(parts, false);
  // Set normals pointing straight up (0, 1, 0) so grass lighting matches the ground seamlessly!
  const norm = merged.attributes.normal as THREE.BufferAttribute;
  for (let i = 0; i < norm.count; i++) {
    norm.setXYZ(i, 0, 1, 0);
  }
  return merged;
}

/** 16. Stemmed Botanical Wildflower Clump (0.42m realistic height, rooted to -0.08m!) */
function buildBotanicalFlowerGeo(): THREE.BufferGeometry {
  const parts: GeoPart[] = [];
  const wid = 0.62;
  const h = 0.50; // -0.08m buried green stem root to +0.42m blossom height!

  for (let i = 0; i < 3; i++) {
    const a = (i / 3) * Math.PI + 0.25;
    const g = new THREE.PlaneGeometry(wid, h, 1, 2);
    g.translate(0, h * 0.5 - 0.08, 0);
    g.rotateX((i % 2 === 0 ? 1 : -1) * 0.12);
    g.rotateY(a);
    parts.push({ geo: g });
  }

  const merged = mergeGeos(parts, false);
  const norm = merged.attributes.normal as THREE.BufferAttribute;
  for (let i = 0; i < norm.count; i++) {
    norm.setXYZ(i, 0, 1, 0);
  }
  return merged;
}

export class FoliageLibrary {
  // Tree trunk + botanical canopy pairs (exact real-world meter scale!)
  public readonly pineTrunkGeo: THREE.BufferGeometry;
  public readonly pineCanopyGeo: THREE.BufferGeometry;
  public readonly snowPineTrunkGeo: THREE.BufferGeometry;
  public readonly snowPineCanopyGeo: THREE.BufferGeometry;
  public readonly oakTrunkGeo: THREE.BufferGeometry;
  public readonly oakCanopyGeo: THREE.BufferGeometry;
  public readonly birchTrunkGeo: THREE.BufferGeometry;
  public readonly birchCanopyGeo: THREE.BufferGeometry;
  public readonly saplingTrunkGeo: THREE.BufferGeometry;
  public readonly saplingCanopyGeo: THREE.BufferGeometry;
  public readonly palmTrunkGeo: THREE.BufferGeometry;
  public readonly palmCanopyGeo: THREE.BufferGeometry;
  public readonly willowTrunkGeo: THREE.BufferGeometry;
  public readonly willowCanopyGeo: THREE.BufferGeometry;

  // Understory bushes, ferns, desert flora, marsh plants, rocks, logs, grass & flowers
  public readonly cactusGeo: THREE.BufferGeometry;
  public readonly bushGeo: THREE.BufferGeometry;
  public readonly flowerBushGeo: THREE.BufferGeometry;
  public readonly fernGeo: THREE.BufferGeometry;
  public readonly agaveGeo: THREE.BufferGeometry;
  public readonly reedGeo: THREE.BufferGeometry;
  public readonly lilyGeo: THREE.BufferGeometry;
  public readonly logGeo: THREE.BufferGeometry;
  public readonly rockGeo: THREE.BufferGeometry;
  public readonly grassGeo: THREE.BufferGeometry;
  public readonly flowerGeo: THREE.BufferGeometry;

  // Photorealistic PBR & wind-animated botanical materials
  public readonly barkMat: THREE.MeshStandardMaterial;
  public readonly birchBarkMat: THREE.MeshStandardMaterial;
  public readonly pineCanopyMat: THREE.MeshStandardMaterial;
  public readonly snowPineCanopyMat: THREE.MeshStandardMaterial;
  public readonly broadleafCanopyMat: THREE.MeshStandardMaterial;
  public readonly deciduousCanopyMat: THREE.MeshStandardMaterial;
  public readonly frondMat: THREE.MeshStandardMaterial;
  public readonly bushMat: THREE.MeshStandardMaterial;
  public readonly flowerBushMat: THREE.MeshStandardMaterial;
  public readonly fernMat: THREE.MeshStandardMaterial;
  public readonly rockMat: THREE.MeshStandardMaterial;
  public readonly reedMat: THREE.MeshStandardMaterial;
  public readonly grassMat: THREE.MeshStandardMaterial;
  public readonly flowerMat: THREE.MeshStandardMaterial;
  public readonly lanternGlowMat: THREE.MeshStandardMaterial;

  private readonly tex: BotanicalTextureSet;
  private readonly atmoUniforms: FoliageAtmosphereUniforms = {
    uTime: { value: 0 },
    uSunDir: { value: new THREE.Vector3(0.4, 0.65, -0.65) },
    uSunColor: { value: new THREE.Color(0xfff4de) },
    uDayFactor: { value: 1 },
    uNightGlow: { value: 0.15 },
  };

  constructor(anisotropy = 4) {
    this.tex = createBotanicalTextureSet(anisotropy);

    const pine = buildConiferGeos(1.0, 0.24);
    this.pineTrunkGeo = pine.trunk;
    this.pineCanopyGeo = pine.canopy;

    const snowPine = buildConiferGeos(0.88, 0.34); // Heavy snow droops spruce boughs realistically!
    this.snowPineTrunkGeo = snowPine.trunk;
    this.snowPineCanopyGeo = snowPine.canopy;

    const oak = buildOakGeos();
    this.oakTrunkGeo = oak.trunk;
    this.oakCanopyGeo = oak.canopy;

    const birch = buildBirchGeos();
    this.birchTrunkGeo = birch.trunk;
    this.birchCanopyGeo = birch.canopy;

    const sapling = buildSaplingGeos();
    this.saplingTrunkGeo = sapling.trunk;
    this.saplingCanopyGeo = sapling.canopy;

    const palm = buildPalmGeos();
    this.palmTrunkGeo = palm.trunk;
    this.palmCanopyGeo = palm.canopy;

    const willow = buildWillowGeos();
    this.willowTrunkGeo = willow.trunk;
    this.willowCanopyGeo = willow.canopy;

    this.cactusGeo = buildCactusGeo();
    this.bushGeo = buildBotanicalBushGeo(1.75, 1.38);
    this.flowerBushGeo = buildBotanicalBushGeo(1.55, 1.22);
    this.fernGeo = buildFernGeo();
    this.agaveGeo = buildAgaveGeo();
    this.reedGeo = buildReedGeo();
    this.lilyGeo = buildWaterLilyGeo();
    this.logGeo = buildFallenLogGeo();
    this.rockGeo = buildBoulderGeo();
    this.grassGeo = buildBotanicalGrassGeo();
    this.flowerGeo = buildBotanicalFlowerGeo();

    // Rich fissured bark with real bump relief & synced trunk sway
    this.barkMat = createBotanicalMaterial(this.atmoUniforms, {
      map: this.tex.barkMap,
      bumpMap: this.tex.barkBump,
      bumpScale: 0.14,
      color: 0x7c6148,
      roughness: 0.91,
      swayAmp: 0.22,
      flutterAmp: 0.0,
      heightRef: 13.5,
      subsurface: 0.0,
    });

    this.birchBarkMat = createBotanicalMaterial(this.atmoUniforms, {
      map: this.tex.birchBark,
      bumpMap: this.tex.barkBump,
      bumpScale: 0.06,
      color: 0xf4efe8,
      roughness: 0.84,
      swayAmp: 0.24,
      flutterAmp: 0.0,
      heightRef: 12.0,
      subsurface: 0.0,
    });

    // Alpha-cutout botanical canopies with backlit sunlit subsurface glow & leaf flutter!
    this.pineCanopyMat = createBotanicalMaterial(this.atmoUniforms, {
      map: this.tex.pineBough,
      neutralGain: 9.0,
      vertexColors: true,
      alphaTest: 0.36,
      doubleSide: true,
      roughness: 0.8,
      swayAmp: 0.28,
      flutterAmp: 0.032,
      heightRef: 14.5,
      subsurface: 0.52,
    });

    this.snowPineCanopyMat = createBotanicalMaterial(this.atmoUniforms, {
      map: this.tex.snowPineBough,
      neutralGain: 3.4,
      vertexColors: true,
      alphaTest: 0.34,
      doubleSide: true,
      roughness: 0.72,
      swayAmp: 0.22,
      flutterAmp: 0.024,
      heightRef: 13.0,
      subsurface: 0.35,
    });

    this.broadleafCanopyMat = createBotanicalMaterial(this.atmoUniforms, {
      map: this.tex.broadleaf,
      vertexColors: true,
      alphaTest: 0.38,
      doubleSide: true,
      roughness: 0.74,
      swayAmp: 0.28,
      flutterAmp: 0.045,
      heightRef: 11.5,
      subsurface: 0.78,
    });

    this.deciduousCanopyMat = createBotanicalMaterial(this.atmoUniforms, {
      map: this.tex.deciduousTint,
      vertexColors: true,
      alphaTest: 0.38,
      doubleSide: true,
      roughness: 0.72,
      swayAmp: 0.3,
      flutterAmp: 0.052,
      heightRef: 11.5,
      subsurface: 0.88,
    });

    this.frondMat = createBotanicalMaterial(this.atmoUniforms, {
      map: this.tex.frond,
      neutralGain: 3.6,
      vertexColors: true,
      alphaTest: 0.34,
      doubleSide: true,
      roughness: 0.68,
      swayAmp: 0.42,
      flutterAmp: 0.065,
      heightRef: 11.5,
      subsurface: 0.85,
    });

    this.bushMat = createBotanicalMaterial(this.atmoUniforms, {
      map: this.tex.bushLeaf,
      vertexColors: true,
      alphaTest: 0.38,
      doubleSide: true,
      roughness: 0.76,
      swayAmp: 0.085,
      flutterAmp: 0.022,
      heightRef: 1.25,
      subsurface: 0.68,
    });

    this.flowerBushMat = createBotanicalMaterial(this.atmoUniforms, {
      map: this.tex.flowerBush,
      vertexColors: true,
      alphaTest: 0.38,
      doubleSide: true,
      roughness: 0.74,
      swayAmp: 0.08,
      flutterAmp: 0.022,
      heightRef: 1.15,
      subsurface: 0.68,
    });

    this.fernMat = createBotanicalMaterial(this.atmoUniforms, {
      map: this.tex.frond,
      neutralGain: 3.6,
      vertexColors: true,
      alphaTest: 0.34,
      doubleSide: true,
      roughness: 0.72,
      swayAmp: 0.1,
      flutterAmp: 0.025,
      heightRef: 0.75,
      subsurface: 0.82,
    });

    this.rockMat = new THREE.MeshStandardMaterial({
      vertexColors: true,
      bumpMap: this.tex.barkBump,
      bumpScale: 0.08,
      roughness: 0.88,
      metalness: 0.03,
      envMapIntensity: 0.7,
    });

    this.reedMat = createBotanicalMaterial(this.atmoUniforms, {
      vertexColors: true,
      roughness: 0.78,
      doubleSide: true,
      swayAmp: 0.19,
      flutterAmp: 0.015,
      heightRef: 1.65,
      subsurface: 0.45,
    });

    this.grassMat = createBotanicalMaterial(this.atmoUniforms, {
      map: this.tex.grassClump,
      alphaTest: 0.36,
      doubleSide: true,
      roughness: 0.76,
      swayAmp: 0.16,
      flutterAmp: 0.018,
      heightRef: 0.48,
      subsurface: 0.78,
    });

    this.flowerMat = createBotanicalMaterial(this.atmoUniforms, {
      map: this.tex.wildflower,
      alphaTest: 0.36,
      doubleSide: true,
      roughness: 0.68,
      swayAmp: 0.14,
      flutterAmp: 0.018,
      heightRef: 0.44,
      subsurface: 0.62,
      petalTintOnly: true,
    });

    this.lanternGlowMat = new THREE.MeshStandardMaterial({
      color: 0xffd88a,
      emissive: new THREE.Color(0xff9d3b),
      emissiveIntensity: 2.2,
      roughness: 0.22,
    });
  }

  /** Create a human-scaled Wayfarer Cairn & timber lantern post with EVERY piece snapped to exact ground! */
  public createLandmarkShrine(x: number, z: number): THREE.Group {
    const group = new THREE.Group();
    const cairnY = getRenderedTerrainHeight(x, z);

    // Stacked weathered cairn stones (0.95m waist height, rooted firmly in ground)
    const stoneSizes = [
      { r: 0.54, sy: 0.36, py: 0.08 },
      { r: 0.42, sy: 0.32, py: 0.34 },
      { r: 0.31, sy: 0.28, py: 0.56 },
      { r: 0.21, sy: 0.24, py: 0.74 },
    ];
    stoneSizes.forEach((s, i) => {
      const m = new THREE.Mesh(this.rockGeo, this.rockMat);
      m.scale.set(s.r, s.sy, s.r * 0.92);
      m.position.set(x + (i % 2 === 0 ? 1 : -1) * 0.02, cairnY + s.py, z);
      m.rotation.y = i * 1.1;
      m.castShadow = true;
      m.receiveShadow = true;
      group.add(m);
    });

    // Timber waypost (realistic 2.25m trail-sign height, embedded -0.35m into its OWN exact ground height!)
    const px = x + 0.88;
    const pz = z + 0.14;
    const postGroundY = getRenderedTerrainHeight(px, pz);

    const post = new THREE.Mesh(new THREE.CylinderGeometry(0.075, 0.105, 2.6, 8), this.barkMat);
    post.position.set(px, postGroundY + 0.95, pz); // -0.35m buried to +2.25m top!
    post.castShadow = true;
    post.receiveShadow = true;
    group.add(post);

    const arm = new THREE.Mesh(new THREE.CylinderGeometry(0.048, 0.058, 0.78, 6), this.barkMat);
    arm.rotation.z = Math.PI / 2 - 0.1;
    arm.position.set(px - 0.32, postGroundY + 2.12, pz);
    arm.castShadow = true;
    group.add(arm);

    const metalMat = new THREE.MeshStandardMaterial({
      color: 0x3b332b,
      roughness: 0.45,
      metalness: 0.65,
    });
    const cap = new THREE.Mesh(new THREE.ConeGeometry(0.18, 0.14, 7), metalMat);
    cap.position.set(px - 0.62, postGroundY + 1.98, pz);
    group.add(cap);

    const lantern = new THREE.Mesh(
      new THREE.CylinderGeometry(0.1, 0.085, 0.24, 7),
      this.lanternGlowMat
    );
    lantern.position.set(px - 0.62, postGroundY + 1.81, pz);
    group.add(lantern);

    const base = new THREE.Mesh(new THREE.CylinderGeometry(0.1, 0.11, 0.05, 7), metalMat);
    base.position.set(px - 0.62, postGroundY + 1.68, pz);
    group.add(base);

    return group;
  }

  public update(
    elapsed: number,
    sunDir: THREE.Vector3,
    sunColor: THREE.Color,
    dayFactor: number,
    nightFactor: number
  ): void {
    this.atmoUniforms.uTime.value = elapsed;
    this.atmoUniforms.uSunDir.value.copy(sunDir);
    this.atmoUniforms.uSunColor.value.copy(sunColor);
    this.atmoUniforms.uDayFactor.value = dayFactor;
    this.atmoUniforms.uNightGlow.value = 0.1 + nightFactor * 1.25;
    this.lanternGlowMat.emissiveIntensity =
      1.2 + nightFactor * 2.8 + Math.sin(elapsed * 5.2) * 0.16;
  }
}
