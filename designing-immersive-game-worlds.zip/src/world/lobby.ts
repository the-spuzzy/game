import { BiomeId } from './biomes';

export interface DropSpot {
  id: string;
  name: string;
  biome: BiomeId;
  x: number;
  z: number;
  color: string;
}

/** Deliberately spread across the whole 1.8 km continent so drops do not cluster. */
export const DROP_SPOTS: DropSpot[] = [
  { id: 'lumen', name: 'Lumen Ridge', biome: 'meadow', x: 0, z: 18, color: '#5eead4' },
  { id: 'cryo', name: 'Cryo Spires', biome: 'alpine', x: -35, z: -395, color: '#bae6fd' },
  { id: 'crimson', name: 'Crimson Highlands', biome: 'autumn', x: 275, z: -215, color: '#fb7185' },
  { id: 'ashen', name: 'Ashen Rift', biome: 'wasteland', x: 540, z: -276, color: '#f472b6' },
  { id: 'rust', name: 'Rust Dunes', biome: 'desert', x: 524, z: 226, color: '#fb923c' },
  { id: 'glass', name: 'Glass Shoals', biome: 'coast', x: 28, z: 285, color: '#67e8f9' },
  { id: 'glowmire', name: 'Glowmire', biome: 'wetland', x: -275, z: 195, color: '#86efac' },
  { id: 'verdigris', name: 'Verdigris Tangle', biome: 'jungle', x: -440, z: 426, color: '#34d399' },
  { id: 'driftgrass', name: 'Driftgrass Steppes', biome: 'plains', x: 322, z: 28, color: '#fdba74' },
  { id: 'spirecap', name: 'Spirecap Woods', biome: 'forest', x: -265, z: -115, color: '#c4b5fd' },
];

export const AI_NAMES = [
  'Nyx-02',
  'Vyr-07',
  'Oozik-11',
  'Krel-04',
  'Zoa-09',
  'Muru-13',
  'Vex-06',
  'Qilo-08',
  'Sarn-15',
  'Talu-03',
  'Ixo-12',
];

export interface RosterEntry {
  id: string;
  name: string;
  isAI: boolean;
  isLocal: boolean;
  ready: boolean;
  dropId: string | null;
}

export interface DropAssignment {
  playerId: string;
  playerName: string;
  dropId: string;
  dropName: string;
  x: number;
  z: number;
  isAI: boolean;
  isLocal: boolean;
}

export function getDropSpot(id: string): DropSpot {
  return DROP_SPOTS.find((s) => s.id === id) ?? DROP_SPOTS[0];
}

/**
 * Spread-out drop assignment:
 * 1) honor real-player drop votes when possible,
 * 2) fill every remaining pilot with the farthest available point from already chosen spots.
 */
export function assignDropSpots(
  roster: RosterEntry[],
  votes: Record<string, string>
): DropAssignment[] {
  const used = new Set<string>();
  const chosen: DropAssignment[] = [];
  let overflowIndex = 0;

  const pick = (entry: RosterEntry): { spot: DropSpot; x: number; z: number } => {
    const vote = entry.dropId ?? votes[entry.id];
    if (vote && !used.has(vote)) {
      const spot = DROP_SPOTS.find((s) => s.id === vote);
      if (spot) {
        used.add(spot.id);
        return { spot, x: spot.x, z: spot.z };
      }
    }

    const available = DROP_SPOTS.filter((s) => !used.has(s.id));
    if (available.length === 0) {
      // More pilots than fixed zones: orbit the overflow pilot around a base zone.
      const seed = (entry.id.charCodeAt(0) || 112) + overflowIndex * 37;
      const base = DROP_SPOTS[seed % DROP_SPOTS.length];
      const angle = (seed * 2.399) % (Math.PI * 2);
      const dist = 22 + (overflowIndex % 4) * 7;
      overflowIndex++;
      return {
        spot: base,
        x: base.x + Math.cos(angle) * dist,
        z: base.z + Math.sin(angle) * dist,
      };
    }

    let best = available[0];
    let bestScore = -Infinity;
    for (let i = 0; i < available.length; i++) {
      const s = available[i];
      let minDist = Infinity;
      for (const c of chosen) minDist = Math.min(minDist, Math.hypot(s.x - c.x, s.z - c.z));
      if (!chosen.length) minDist = 1000 - i * 0.01;
      const jitter = ((entry.id.charCodeAt(0) + i * 17) % 13) * 0.01;
      const score = minDist + jitter;
      if (score > bestScore) {
        bestScore = score;
        best = s;
      }
    }
    used.add(best.id);
    return { spot: best, x: best.x, z: best.z };
  };

  const ordered = [...roster].sort((a, b) => {
    if (a.isAI !== b.isAI) return a.isAI ? 1 : -1;
    if (a.isLocal !== b.isLocal) return a.isLocal ? -1 : 1;
    return a.id.localeCompare(b.id);
  });

  for (const entry of ordered) {
    const { spot, x, z } = pick(entry);
    chosen.push({
      playerId: entry.id,
      playerName: entry.name,
      dropId: spot.id,
      dropName: spot.name,
      x,
      z,
      isAI: entry.isAI,
      isLocal: entry.isLocal,
    });
  }

  return chosen;
}
