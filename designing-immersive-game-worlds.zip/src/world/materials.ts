import * as THREE from 'three';

export interface TerrainShaderUniforms {
  uTime: { value: number };
  uSunDir: { value: THREE.Vector3 };
  uSunColor: { value: THREE.Color };
  uDayFactor: { value: number };
  uFocusPos: { value: THREE.Vector3 };
  uInnerRadius: { value: number };
  uNightGlow: { value: number };
}

/** Seamless multi-octave ground relief bump texture */
function createGroundDetailBumpTexture(anisotropy: number): THREE.CanvasTexture {
  const size = 512;
  const canvas = document.createElement('canvas');
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext('2d')!;
  const img = ctx.createImageData(size, size);
  const data = img.data;

  const tileHash = (ix: number, iy: number, period: number, seed: number): number => {
    const x = ((ix % period) + period) % period;
    const y = ((iy % period) + period) % period;
    const s = Math.sin(x * 127.1 + y * 311.7 + seed * 74.7) * 43758.5453;
    return s - Math.floor(s);
  };

  const tileNoise = (u: number, v: number, period: number, seed: number): number => {
    const gx = u * period;
    const gy = v * period;
    const ix = Math.floor(gx);
    const iy = Math.floor(gy);
    const fx = gx - ix;
    const fy = gy - iy;
    const sx = fx * fx * (3 - 2 * fx);
    const sy = fy * fy * (3 - 2 * fy);
    const a = tileHash(ix, iy, period, seed);
    const b = tileHash(ix + 1, iy, period, seed);
    const c = tileHash(ix, iy + 1, period, seed);
    const d = tileHash(ix + 1, iy + 1, period, seed);
    return a + (b - a) * sx + (c - a) * sy + (a - b - c + d) * sx * sy;
  };

  for (let y = 0; y < size; y++) {
    const v = y / size;
    for (let x = 0; x < size; x++) {
      const u = x / size;
      const n =
        tileNoise(u, v, 8, 1) * 0.34 +
        tileNoise(u, v, 24, 2) * 0.28 +
        tileNoise(u, v, 64, 3) * 0.22 +
        tileNoise(u, v, 160, 4) * 0.16;
      const val = Math.max(0, Math.min(255, Math.floor(n * 255)));
      const idx = (y * size + x) * 4;
      data[idx] = val;
      data[idx + 1] = val;
      data[idx + 2] = val;
      data[idx + 3] = 255;
    }
  }

  ctx.putImageData(img, 0, 0);
  const tex = new THREE.CanvasTexture(canvas);
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.anisotropy = anisotropy;
  tex.needsUpdate = true;
  return tex;
}

/**
 * Alien PBR terrain: multi-scale ground detail, cliff strata, drifting cloud shadows,
 * directional aerial haze and bioluminescent moss / vein / rift-fissure glow at night.
 */
export function createTerrainMaterial(
  sharedUniforms: TerrainShaderUniforms,
  anisotropy: number,
  isDistant = false
): THREE.MeshStandardMaterial {
  const bumpTex = isDistant ? null : createGroundDetailBumpTexture(anisotropy);

  const mat = new THREE.MeshStandardMaterial({
    vertexColors: true,
    roughness: 0.88,
    metalness: 0.02,
    bumpMap: bumpTex,
    bumpScale: isDistant ? 0 : 0.34,
    envMapIntensity: 0.65,
    flatShading: false,
  });

  mat.customProgramCacheKey = () => (isDistant ? 'terrain-distant' : 'terrain-near');

  mat.onBeforeCompile = (shader) => {
    shader.uniforms.uTime = sharedUniforms.uTime;
    shader.uniforms.uSunDir = sharedUniforms.uSunDir;
    shader.uniforms.uSunColor = sharedUniforms.uSunColor;
    shader.uniforms.uDayFactor = sharedUniforms.uDayFactor;
    shader.uniforms.uFocusPos = sharedUniforms.uFocusPos;
    shader.uniforms.uInnerRadius = sharedUniforms.uInnerRadius;
    shader.uniforms.uNightGlow = sharedUniforms.uNightGlow;

    shader.vertexShader = shader.vertexShader
      .replace(
        '#include <common>',
        `#include <common>
        attribute vec4 aGlow;
        uniform vec3 uFocusPos;
        uniform float uInnerRadius;
        varying vec3 vWorldPos;
        varying vec3 vWorldNorm;
        varying vec4 vGlowCol;`
      )
      .replace(
        '#include <begin_vertex>',
        isDistant
          ? `#include <begin_vertex>
            vGlowCol = aGlow;
            vec4 preWp = modelMatrix * vec4(transformed, 1.0);
            float focusDist = length(preWp.xz - uFocusPos.xz);
            float tuck = 1.0 - smoothstep(uInnerRadius * 0.72, uInnerRadius * 1.04, focusDist);
            transformed.y -= tuck * 3.8;`
          : `#include <begin_vertex>
            vGlowCol = aGlow;`
      )
      .replace(
        '#include <worldpos_vertex>',
        `#include <worldpos_vertex>
        vWorldPos = (modelMatrix * vec4(transformed, 1.0)).xyz;
        vWorldNorm = normalize(mat3(modelMatrix) * objectNormal);`
      );

    shader.fragmentShader = shader.fragmentShader
      .replace(
        '#include <common>',
        `#include <common>
        uniform float uTime;
        uniform vec3 uSunDir;
        uniform vec3 uSunColor;
        uniform float uDayFactor;
        uniform float uNightGlow;
        varying vec3 vWorldPos;
        varying vec3 vWorldNorm;
        varying vec4 vGlowCol;

        float solHash(vec2 p) {
          return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453123);
        }
        float solNoise(vec2 p) {
          vec2 i = floor(p);
          vec2 f = fract(p);
          f = f * f * (3.0 - 2.0 * f);
          float a = solHash(i);
          float b = solHash(i + vec2(1.0, 0.0));
          float c = solHash(i + vec2(0.0, 1.0));
          float d = solHash(i + vec2(1.0, 1.0));
          return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
        }
        float solFbm3(vec2 p) {
          float v = 0.0;
          v += 0.54 * solNoise(p);
          v += 0.30 * solNoise(p * 2.13 + vec2(7.3, -4.1));
          v += 0.16 * solNoise(p * 4.42 - vec2(3.7, 9.2));
          return v;
        }`
      )
      .replace(
        '#include <color_fragment>',
        `#include <color_fragment>
        float slopeAmt = 1.0 - clamp(vWorldNorm.y, 0.0, 1.0);
        float camDist = length(cameraPosition - vWorldPos);
        float nearDetail = 1.0 - smoothstep(25.0, 165.0, camDist);

        float nMacro = solNoise(vWorldPos.xz * 0.075);
        float nMed = solNoise(vWorldPos.xz * 0.45);
        float nFine = solNoise(vWorldPos.xz * 2.4);
        float nPebble = solNoise(vWorldPos.xz * 9.5);
        float detailMod = 0.82 + nMacro * 0.14 + nMed * 0.14 + (nFine * 0.11 + (nPebble - 0.5) * 0.12) * nearDetail;

        // Iridescent alien hue drift across moss fields
        float hueShift = (nMacro - 0.5) * 0.08;
        diffuseColor.r *= 1.0 + hueShift;
        diffuseColor.b *= 1.0 - hueShift * 0.6;

        if (slopeAmt > 0.16) {
          float strata = sin(vWorldPos.y * 2.55 + nMed * 3.1) * 0.5 + 0.5;
          float fineStrata = sin(vWorldPos.y * 8.4 + nFine * 2.0) * 0.5 + 0.5;
          float fissureX = solNoise(vec2(vWorldPos.z * 0.58, vWorldPos.y * 1.45));
          float fissureZ = solNoise(vec2(vWorldPos.x * 0.58, vWorldPos.y * 1.45));
          float fissure = mix(fissureX, fissureZ, abs(vWorldNorm.z));
          float creviceAO = smoothstep(0.12, 0.48, fissure);
          float rockTex = mix(0.66, 1.22, strata * 0.52 + fineStrata * 0.18 + creviceAO * 0.30);
          detailMod = mix(detailMod, rockTex, smoothstep(0.16, 0.40, slopeAmt));
        }

        float sandiness = smoothstep(0.05, 0.18, diffuseColor.r - diffuseColor.b)
          * smoothstep(0.12, 0.42, diffuseColor.g)
          * (1.0 - smoothstep(0.18, 0.36, slopeAmt));
        if (sandiness > 0.04 && nearDetail > 0.02) {
          float rippleCoord = vWorldPos.x * 3.8 + vWorldPos.z * 2.2 + nMed * 2.6;
          float ripple = pow(sin(rippleCoord) * 0.5 + 0.5, 1.6) - 0.45;
          detailMod += ripple * 0.09 * sandiness * nearDetail;
        }

        float farMottle = smoothstep(140.0, 340.0, camDist) * (1.0 - smoothstep(0.25, 0.5, slopeAmt));
        if (farMottle > 0.01 && vWorldPos.y > 2.0 && vWorldPos.y < 52.0) {
          float canopyPattern = solNoise(vWorldPos.xz * 0.24);
          detailMod *= mix(1.0, 0.8 + canopyPattern * 0.34, farMottle * 0.6);
        }

        diffuseColor.rgb *= detailMod;

        float wetShore = 1.0 - smoothstep(-0.15, 0.72, vWorldPos.y);
        diffuseColor.rgb *= mix(1.0, 0.58, wetShore * 0.9);
        `
      )
      .replace(
        '#include <roughnessmap_fragment>',
        `#include <roughnessmap_fragment>
        float wetRough = 1.0 - smoothstep(-0.08, 0.68, vWorldPos.y);
        float isSnow = smoothstep(0.55, 0.82, diffuseColor.b) * smoothstep(12.0, 26.0, vWorldPos.y);
        float rockSlope = smoothstep(0.22, 0.48, 1.0 - clamp(vWorldNorm.y, 0.0, 1.0));
        float sparkle = isSnow * step(0.972, solHash(floor(vWorldPos.xz * 18.0))) * 0.55;
        roughnessFactor = mix(0.90, 0.72, rockSlope);
        roughnessFactor = mix(roughnessFactor, 0.55, isSnow) - sparkle;
        roughnessFactor = mix(roughnessFactor, 0.12, wetRough);
        roughnessFactor = clamp(roughnessFactor, 0.08, 0.97);`
      )
      .replace(
        '#include <emissivemap_fragment>',
        `#include <emissivemap_fragment>
        // Bioluminescent ground: glowing moss speckles, living veins & magma-pink rift fissures
        float glowStrength = vGlowCol.r + vGlowCol.g + vGlowCol.b;
        if (glowStrength > 0.01 && uNightGlow > 0.01) {
          // Fine, sparse moss speckles (faded with distance so they never shimmer or blotch),
          // thin wandering veins, and a faint field shimmer so distant meadows still breathe
          float gNear = 1.0 - smoothstep(18.0, 110.0, camDist);
          float gSpeck = smoothstep(0.8, 0.95, solNoise(vWorldPos.xz * 3.1)) * (0.45 + 0.55 * solNoise(vWorldPos.xz * 0.13));
          float gVein = (1.0 - smoothstep(0.006, 0.03, abs(solNoise(vWorldPos.xz * 0.19) - 0.5))) * 0.42;
          float gFiss = 1.0 - smoothstep(0.008, 0.045, abs(solNoise(vWorldPos.xz * 0.07 + 3.1) - 0.5));
          float gLife = (gSpeck * gNear + gVein) * 0.8 + 0.06;
          float gPattern = mix(gLife, gFiss * 1.6 + gSpeck * 0.2 * gNear + 0.04, vGlowCol.a);
          float gPulse = 0.78 + 0.22 * sin(uTime * 0.9 + solNoise(vWorldPos.xz * 0.05) * 6.283);
          float gFade = 1.0 - smoothstep(-0.2, 0.25, -vWorldPos.y);
          totalEmissiveRadiance += vGlowCol.rgb * gPattern * gPulse * gFade * uNightGlow * 0.85;
        }`
      )
      .replace(
        '#include <lights_fragment_end>',
        `#include <lights_fragment_end>
        vec2 cloudUv = vWorldPos.xz * 0.0042 + vec2(uTime * 0.011, uTime * 0.005);
        float cloudCover = solFbm3(cloudUv);
        float cloudShadow = 1.0 - smoothstep(0.54, 0.76, cloudCover) * 0.36 * uDayFactor;
        reflectedLight.directDiffuse *= cloudShadow;
        reflectedLight.directSpecular *= cloudShadow;`
      )
      .replace(
        '#include <fog_fragment>',
        `#ifdef USE_FOG
          float solFogFactor = 1.0 - exp( - fogDensity * fogDensity * vFogDepth * vFogDepth );
          solFogFactor = clamp(solFogFactor, 0.0, 1.0);
          vec3 viewRay = normalize(vWorldPos - cameraPosition);
          float sunAlign = pow(max(dot(viewRay, uSunDir), 0.0), 4.0);
          vec3 aerialCol = fogColor + uSunColor * sunAlign * 0.24 * uDayFactor;
          gl_FragColor.rgb = mix( gl_FragColor.rgb, aerialCol, solFogFactor );
        #endif`
      );
  };

  return mat;
}
