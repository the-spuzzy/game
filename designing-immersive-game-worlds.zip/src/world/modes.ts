/** Game-mode definitions for SOLVARA. */

export type GameMode = 'open-world' | 'battle-royale';

export interface GameModeConfig {
  id: GameMode;
  name: string;
  tagline: string;
  description: string;
  accent: string;
  minPlayers: number;
  maxPlayers: number;
  creatureHpMult: number;
  creatureDamageMult: number;
  dnaMult: number;
  persistentEvolution: boolean;
  battleRoyale: boolean;
  zoneStartRadius: number;
  zoneEndRadius: number;
  matchDuration: number;
}

export const GAME_MODES: Record<GameMode, GameModeConfig> = {
  'open-world': {
    id: 'open-world',
    name: 'Open World',
    tagline: 'Persistent Evolution Expedition',
    description:
      'Explore all 10 alien regions with living weather and edible alien flora. Your evolved Stage, Traits, DNA and Abilities stay saved on this profile. Wildlife is tougher here, but grants more DNA.',
    accent: '#2dd4bf',
    minPlayers: 1,
    maxPlayers: 24,
    creatureHpMult: 1.85,
    creatureDamageMult: 1.3,
    dnaMult: 1.45,
    persistentEvolution: true,
    battleRoyale: false,
    zoneStartRadius: 0,
    zoneEndRadius: 0,
    matchDuration: 0,
  },
  'battle-royale': {
    id: 'battle-royale',
    name: 'Battle Royale',
    tagline: 'Last Symbiote Standing',
    description:
      'Skill-matched real players queue automatically, AI fills open slots, and pilots inspect their drop before the shrinking Bio-Storm begins. Custom rooms are also available.',
    accent: '#fb7185',
    minPlayers: 2,
    maxPlayers: 12,
    creatureHpMult: 1.35,
    creatureDamageMult: 1.45,
    dnaMult: 1.0,
    persistentEvolution: true,
    battleRoyale: true,
    // Every fixed / overflow drop site lies inside this initial ring.
    zoneStartRadius: 780,
    zoneEndRadius: 18,
    matchDuration: 210,
  },
};

export const GAME_MODE_LIST: GameModeConfig[] = [
  GAME_MODES['open-world'],
  GAME_MODES['battle-royale'],
];

export function clampMaxPlayers(mode: GameMode, requested: number): number {
  const cfg = GAME_MODES[mode];
  return Math.max(cfg.minPlayers, Math.min(cfg.maxPlayers, Math.round(requested)));
}

export interface MatchState {
  mode: GameMode;
  totalPlayers: number;
  rivalsAlive: number;
  playerAlive: boolean;
  matchOver: boolean;
  winner: string | null;
  playerWon: boolean;
  zoneRadius: number;
  zoneTargetRadius: number;
  zoneStage: number;
  zoneTime: number;
  zoneWarning: boolean;
  zoneClosesIn: number;
  elapsed: number;
  eliminations: number;
  feed: string | null;
  realPlayers: number;
  aiPlayers: number;
  rosterNames: string[];
}
