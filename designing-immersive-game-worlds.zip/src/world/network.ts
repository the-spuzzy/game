/** Lightweight real-player lobby networking.
 *
 * - BroadcastChannel works between tabs on the same browser/origin with no server.
 * - Optional WebSocket relay supports real players on other devices.
 *   Run `node lobby-server.mjs` and open the game with `?ws=ws://your-host:8787`.
 *
 * There is no authoritative server: each client simulates its own AI rivals and
 * broadcasts its player transform. This is a lightweight prototype relay, not
 * a production netcode stack.
 */

export interface NetworkPlayerState {
  id: string;
  name: string;
  x: number;
  y: number;
  z: number;
  yaw: number;
  hp: number;
  alive: boolean;
}

export interface NetworkAdapter {
  sendPlayerState(state: NetworkPlayerState): void;
  drainRemoteStates(): NetworkPlayerState[];
  getLocalId(): string;
  close(): void;
}

export interface LobbyPeer {
  id: string;
  name: string;
  ready: boolean;
  dropId: string | null;
  isLocal: boolean;
}

export type LobbyPhase = 'lobby' | 'drop' | 'launch';
export type RelayStatus = 'local' | 'connecting' | 'connected' | 'error';

export interface LobbyNetworkState {
  peers: LobbyPeer[];
  hostId: string;
  phase: LobbyPhase;
  countdown: number;
  dropVotes: Record<string, string>;
  relayStatus: RelayStatus;
}

export interface LobbyNetworkOptions {
  room: string;
  name: string;
  relayUrl?: string;
  onState: (state: LobbyNetworkState) => void;
}

interface WireMessage {
  type: string;
  room?: string;
  id?: string;
  name?: string;
  ready?: boolean;
  dropId?: string | null;
  peer?: LobbyPeer;
  peers?: LobbyPeer[];
  hostId?: string;
  countdown?: number;
  x?: number;
  y?: number;
  z?: number;
  yaw?: number;
  hp?: number;
  alive?: boolean;
}

export class LobbyNetwork implements NetworkAdapter {
  public readonly room: string;
  public readonly name: string;
  private readonly id: string;
  private readonly onState: (state: LobbyNetworkState) => void;
  private readonly relayUrl?: string;
  private readonly peers = new Map<string, LobbyPeer>();
  private channel: BroadcastChannel | null = null;
  private socket: WebSocket | null = null;
  private relayStatus: RelayStatus = 'local';
  private phase: LobbyPhase = 'lobby';
  private countdown = 0;
  private countdownTimer: number | null = null;
  private remoteStates: NetworkPlayerState[] = [];
  private closed = false;

  constructor(opts: LobbyNetworkOptions) {
    this.room = opts.room.replace(/[^a-zA-Z0-9_-]/g, '').slice(0, 24) || 'SOLVARA';
    this.name = opts.name || 'Explorer';
    this.relayUrl = opts.relayUrl?.trim() || undefined;
    this.onState = opts.onState;
    this.id = `p-${Math.random().toString(36).slice(2, 10)}`;

    const local: LobbyPeer = {
      id: this.id,
      name: this.name,
      ready: false,
      dropId: null,
      isLocal: true,
    };
    this.peers.set(this.id, local);

    try {
      this.channel = new BroadcastChannel(`solvara-lobby-${this.room}`);
      this.channel.onmessage = (e) => this.handle(e.data as WireMessage);
    } catch {
      this.channel = null;
    }

    if (this.relayUrl) {
      this.relayStatus = 'connecting';
      try {
        this.socket = new WebSocket(this.relayUrl);
        this.socket.onopen = () => {
          this.relayStatus = 'connected';
          this.sendToSocket({ type: 'join', room: this.room, id: this.id, name: this.name });
          this.emit();
        };
        this.socket.onmessage = (e) => {
          try {
            this.handle(JSON.parse(String(e.data)) as WireMessage);
          } catch {
            /* ignore malformed relay messages */
          }
        };
        this.socket.onerror = () => {
          this.relayStatus = 'error';
          this.emit();
        };
        this.socket.onclose = () => {
          if (this.relayStatus === 'connected') this.relayStatus = 'error';
          this.emit();
        };
      } catch {
        this.relayStatus = 'error';
        this.socket = null;
      }
    }

    // Announce presence to same-origin tabs and the relay.
    this.broadcast({
      type: 'hello',
      room: this.room,
      id: this.id,
      name: this.name,
      peer: local,
    });
    if (this.socket?.readyState === WebSocket.OPEN) {
      this.sendToSocket({ type: 'join', room: this.room, id: this.id, name: this.name });
    }
    this.emit();
  }

  public getLocalId(): string {
    return this.id;
  }

  public getRelayStatus(): RelayStatus {
    return this.relayStatus;
  }

  public setReady(ready: boolean): void {
    const p = this.peers.get(this.id);
    if (!p) return;
    p.ready = ready;
    this.broadcast({
      type: 'state',
      room: this.room,
      id: this.id,
      name: this.name,
      ready,
      dropId: p.dropId,
      peer: p,
    });
    this.emit();
  }

  public setDrop(dropId: string): void {
    const p = this.peers.get(this.id);
    if (!p) return;
    p.dropId = dropId;
    this.broadcast({
      type: 'state',
      room: this.room,
      id: this.id,
      name: this.name,
      ready: p.ready,
      dropId,
      peer: p,
    });
    this.emit();
  }

  public beginDrop(): void {
    this.broadcast({ type: 'begin', room: this.room, id: this.id, countdown: 6 });
    this.startCountdown(6);
  }

  public sendPlayerState(state: NetworkPlayerState): void {
    this.broadcast({
      type: 'player-state',
      room: this.room,
      id: state.id,
      name: state.name,
      x: state.x,
      y: state.y,
      z: state.z,
      yaw: state.yaw,
      hp: state.hp,
      alive: state.alive,
    });
  }

  public drainRemoteStates(): NetworkPlayerState[] {
    const out = this.remoteStates;
    this.remoteStates = [];
    return out;
  }

  public close(): void {
    if (this.closed) return;
    this.closed = true;
    this.broadcast({ type: 'leave', room: this.room, id: this.id });
    if (this.countdownTimer !== null) window.clearInterval(this.countdownTimer);
    try {
      this.channel?.close();
    } catch {
      /* ignore */
    }
    this.channel = null;
    try {
      this.socket?.close();
    } catch {
      /* ignore */
    }
    this.socket = null;
  }

  private startCountdown(seconds: number): void {
    if (this.countdownTimer !== null) window.clearInterval(this.countdownTimer);
    this.phase = 'drop';
    this.countdown = seconds;
    this.emit();
    this.countdownTimer = window.setInterval(() => {
      this.countdown = Math.max(0, this.countdown - 1);
      if (this.countdown <= 0) {
        if (this.countdownTimer !== null) window.clearInterval(this.countdownTimer);
        this.countdownTimer = null;
        this.phase = 'launch';
      }
      this.emit();
    }, 1000);
  }

  private broadcast(msg: WireMessage): void {
    try {
      this.channel?.postMessage(msg);
    } catch {
      /* ignore */
    }
    this.sendToSocket(msg);
  }

  private sendToSocket(msg: WireMessage): void {
    if (this.socket && this.socket.readyState === WebSocket.OPEN) {
      try {
        this.socket.send(JSON.stringify(msg));
      } catch {
        /* ignore */
      }
    }
  }

  private handle(msg: WireMessage): void {
    if (!msg || msg.room !== this.room || !msg.type) return;
    if (msg.id === this.id && msg.type !== 'presence') return;

    switch (msg.type) {
      case 'hello': {
        if (msg.id && msg.peer) {
          this.peers.set(msg.id, { ...msg.peer, isLocal: false });
          // Reply so the new tab learns about us.
          this.broadcast({
            type: 'presence',
            room: this.room,
            id: this.id,
            peer: this.peers.get(this.id)!,
          });
        }
        break;
      }
      case 'presence': {
        if (Array.isArray(msg.peers)) {
          // Relay sends the authoritative full roster.
          const local = this.peers.get(this.id);
          this.peers.clear();
          if (local) this.peers.set(this.id, local);
          for (const p of msg.peers) {
            if (p.id === this.id) continue;
            this.peers.set(p.id, { ...p, isLocal: false });
          }
        } else if (msg.id && msg.peer) {
          this.peers.set(msg.id, { ...msg.peer, isLocal: false });
        }
        break;
      }
      case 'state': {
        if (!msg.id) break;
        const existing = this.peers.get(msg.id);
        this.peers.set(msg.id, {
          id: msg.id,
          name: msg.name ?? existing?.name ?? 'Pilot',
          ready: Boolean(msg.ready),
          dropId: msg.dropId ?? null,
          isLocal: false,
        });
        break;
      }
      case 'begin': {
        this.startCountdown(msg.countdown ?? 6);
        break;
      }
      case 'player-state': {
        if (msg.id && msg.name !== undefined) {
          this.remoteStates.push({
            id: msg.id,
            name: msg.name,
            x: Number(msg.x) || 0,
            y: Number(msg.y) || 0,
            z: Number(msg.z) || 0,
            yaw: Number(msg.yaw) || 0,
            hp: Number(msg.hp) || 0,
            alive: Boolean(msg.alive),
          });
          if (this.remoteStates.length > 80) this.remoteStates.shift();
        }
        break;
      }
      case 'leave': {
        if (msg.id) this.peers.delete(msg.id);
        break;
      }
      default:
        break;
    }
    this.emit();
  }

  private emit(): void {
    const peers = Array.from(this.peers.values()).sort((a, b) => a.id.localeCompare(b.id));
    const hostId = peers[0]?.id ?? this.id;
    const dropVotes: Record<string, string> = {};
    for (const p of peers) {
      if (p.dropId) dropVotes[p.id] = p.dropId;
    }
    this.onState({
      peers,
      hostId,
      phase: this.phase,
      countdown: this.countdown,
      dropVotes,
      relayStatus: this.relayStatus,
    });
  }
}
