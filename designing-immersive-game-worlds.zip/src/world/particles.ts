import * as THREE from 'three';
import { BiomeId, SurfaceMaterial, WATER_LEVEL } from './biomes';
import { lerp } from './noise';

function createSoftParticleTexture(): THREE.CanvasTexture {
  const s = 64;
  const c = document.createElement('canvas');
  c.width = s;
  c.height = s;
  const ctx = c.getContext('2d')!;
  const grad = ctx.createRadialGradient(s / 2, s / 2, 2, s / 2, s / 2, s / 2);
  grad.addColorStop(0, 'rgba(255,255,255,1)');
  grad.addColorStop(0.45, 'rgba(255,255,255,0.65)');
  grad.addColorStop(1, 'rgba(255,255,255,0)');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, s, s);
  const tex = new THREE.CanvasTexture(c);
  tex.needsUpdate = true;
  return tex;
}

interface FootPuff {
  mesh: THREE.Mesh;
  vx: number;
  vy: number;
  vz: number;
  age: number;
  life: number;
  startScale: number;
}

interface WaterRipple {
  mesh: THREE.Mesh;
  age: number;
  life: number;
  maxScale: number;
}

export class AtmosphereParticles {
  private readonly points: THREE.Points;
  private readonly count: number;
  private readonly offsets: Float32Array;
  private readonly phases: Float32Array;
  private readonly posAttr: THREE.BufferAttribute;
  private readonly pointMat: THREE.PointsMaterial;
  private readonly targetColor = new THREE.Color(0xfff6d8);

  // Pooled footstep puffs & water ripple rings (zero runtime GC!)
  private readonly puffs: FootPuff[] = [];
  private readonly ripples: WaterRipple[] = [];
  private puffCursor = 0;
  private rippleCursor = 0;
  private rippleTimer = 0;

  private readonly boxW = 38;
  private readonly boxH = 16;

  constructor(scene: THREE.Scene, isMobile: boolean) {
    this.count = isMobile ? 160 : 280;
    this.offsets = new Float32Array(this.count * 3);
    this.phases = new Float32Array(this.count);
    const positions = new Float32Array(this.count * 3);

    for (let i = 0; i < this.count; i++) {
      this.offsets[i * 3] = (Math.random() - 0.5) * this.boxW;
      this.offsets[i * 3 + 1] = Math.random() * this.boxH;
      this.offsets[i * 3 + 2] = (Math.random() - 0.5) * this.boxW;
      this.phases[i] = Math.random() * Math.PI * 2;
    }

    const geo = new THREE.BufferGeometry();
    this.posAttr = new THREE.BufferAttribute(positions, 3);
    geo.setAttribute('position', this.posAttr);

    const sprite = createSoftParticleTexture();
    this.pointMat = new THREE.PointsMaterial({
      map: sprite,
      color: 0xfff6d8,
      size: 0.16,
      transparent: true,
      opacity: 0.65,
      depthWrite: false,
      blending: THREE.AdditiveBlending,
      sizeAttenuation: true,
    });

    this.points = new THREE.Points(geo, this.pointMat);
    this.points.frustumCulled = false;
    scene.add(this.points);

    // Pre-allocate footstep dust/snow/splash puffs
    const puffGeo = new THREE.SphereGeometry(0.12, 6, 5);
    for (let i = 0; i < 20; i++) {
      const mat = new THREE.MeshBasicMaterial({
        color: 0xd8ccb4,
        transparent: true,
        opacity: 0,
        depthWrite: false,
      });
      const mesh = new THREE.Mesh(puffGeo, mat);
      mesh.visible = false;
      scene.add(mesh);
      this.puffs.push({ mesh, vx: 0, vy: 0, vz: 0, age: 99, life: 0.5, startScale: 1 });
    }

    // Pre-allocate expanding water ripple rings
    const ringGeo = new THREE.RingGeometry(0.28, 0.36, 24);
    ringGeo.rotateX(-Math.PI / 2);
    for (let i = 0; i < 12; i++) {
      const mat = new THREE.MeshBasicMaterial({
        color: 0xe8f8ff,
        transparent: true,
        opacity: 0,
        depthWrite: false,
        side: THREE.DoubleSide,
      });
      const mesh = new THREE.Mesh(ringGeo, mat);
      mesh.visible = false;
      mesh.renderOrder = 3;
      scene.add(mesh);
      this.ripples.push({ mesh, age: 99, life: 1.4, maxScale: 3.2 });
    }
  }

  public spawnFootstepEffect(
    x: number,
    y: number,
    z: number,
    surface: SurfaceMaterial,
    isRunning: boolean
  ): void {
    if (surface === 'water') {
      this.spawnWaterRipple(x, z, isRunning ? 3.6 : 2.5);
    }

    // Spawn 2 tiny tactile ground puffs on snow, sand, dirt, water, or sprinting on grass
    if (surface === 'grass' && !isRunning) return;
    const count = isRunning ? 2 : 1;
    for (let k = 0; k < count; k++) {
      const p = this.puffs[this.puffCursor];
      this.puffCursor = (this.puffCursor + 1) % this.puffs.length;

      const mat = p.mesh.material as THREE.MeshBasicMaterial;
      if (surface === 'snow') mat.color.setHex(0xf2f7fc);
      else if (surface === 'sand') mat.color.setHex(0xdfc797);
      else if (surface === 'water') mat.color.setHex(0xdcf6ff);
      else if (surface === 'rock') mat.color.setHex(0xa8a5a0);
      else mat.color.setHex(0xb8a382);

      const py = surface === 'water' ? WATER_LEVEL + 0.08 : y + 0.06;
      p.mesh.position.set(
        x + (Math.random() - 0.5) * 0.28,
        py,
        z + (Math.random() - 0.5) * 0.28
      );
      p.vx = (Math.random() - 0.5) * 0.9;
      p.vy = (surface === 'water' ? 1.15 : 0.55) + Math.random() * 0.45;
      p.vz = (Math.random() - 0.5) * 0.9;
      p.age = 0;
      p.life = 0.42 + Math.random() * 0.2;
      p.startScale = isRunning ? 1.15 : 0.78;
      p.mesh.visible = true;
    }
  }

  public spawnWaterRipple(x: number, z: number, maxScale = 2.8): void {
    const r = this.ripples[this.rippleCursor];
    this.rippleCursor = (this.rippleCursor + 1) % this.ripples.length;
    r.mesh.position.set(x, WATER_LEVEL + 0.05, z);
    r.mesh.scale.setScalar(0.5);
    r.age = 0;
    r.life = 1.45;
    r.maxScale = maxScale;
    r.mesh.visible = true;
  }

  public update(
    dt: number,
    elapsed: number,
    playerPos: THREE.Vector3,
    biome: BiomeId,
    nightFactor: number,
    inWater: boolean,
    playerSpeed: number
  ): void {
    // Configure biome-specific ambient atmosphere behavior
    let vx = 0.6;
    let vy = -0.18;
    let vz = 0.35;
    let targetSize = 0.14;
    let targetOpacity = 0.55;
    let normalBlend = false;

    const glowMode =
      biome === 'wetland' ||
      biome === 'jungle' ||
      (nightFactor > 0.4 && biome !== 'alpine' && biome !== 'desert' && biome !== 'wasteland');

    if (biome === 'alpine') {
      // Lilac-tinged crystalline snowfall drifting off the Cryo Spires
      this.targetColor.setHex(0xdfe6ff);
      vx = 1.65;
      vy = -2.35;
      vz = 0.85;
      targetSize = 0.22;
      targetOpacity = 0.86;
      normalBlend = true;
    } else if (biome === 'wasteland') {
      // Rising magenta rift embers & drifting ash
      this.targetColor.setHex(0xff5fa8);
      vx = 0.9;
      vy = 0.55;
      vz = 0.4;
      targetSize = 0.13;
      targetOpacity = lerp(0.62, 0.95, nightFactor);
    } else if (biome === 'autumn') {
      // Fluttering scarlet bloom petals
      this.targetColor.setHex(0xff4f6d);
      vx = 1.55;
      vy = -1.15;
      vz = 0.72;
      targetSize = 0.24;
      targetOpacity = 0.82;
      normalBlend = true;
    } else if (glowMode) {
      // Bioluminescent spore motes (green in the mire & jungle, cyan-violet elsewhere)
      this.targetColor.setHex(
        biome === 'wetland' ? 0x8dff7a : biome === 'jungle' ? 0x6dffc0 : biome === 'forest' ? 0xc28bff : 0x7af6ff
      );
      vx = 0.22;
      vy = 0.16;
      vz = 0.18;
      targetSize = 0.23;
      targetOpacity = lerp(0.7, 0.96, nightFactor);
    } else if (biome === 'desert') {
      // Wind-swept iron-rust sand motes
      this.targetColor.setHex(0xff9a5c);
      vx = 3.6;
      vy = -0.25;
      vz = 1.4;
      targetSize = 0.15;
      targetOpacity = 0.48;
      normalBlend = true;
    } else if (biome === 'plains') {
      // Coral driftgrass seed-fluff riding the steppe winds
      this.targetColor.setHex(0xffc59a);
      vx = 2.1;
      vy = 0.05;
      vz = 0.9;
      targetSize = 0.17;
      targetOpacity = 0.6;
    } else {
      // Glittering alien pollen & sea sparkle
      this.targetColor.setHex(biome === 'coast' ? 0xb8d8ff : biome === 'forest' ? 0xd0b8ff : 0x9ff7ff);
      vx = 0.48;
      vy = -0.08;
      vz = 0.3;
      targetSize = 0.15;
      targetOpacity = 0.56;
    }

    this.pointMat.color.lerp(this.targetColor, Math.min(1, dt * 2.5));
    this.pointMat.size = lerp(this.pointMat.size, targetSize, Math.min(1, dt * 3));
    this.pointMat.opacity = lerp(this.pointMat.opacity, targetOpacity, Math.min(1, dt * 3));
    const desiredBlending = normalBlend ? THREE.NormalBlending : THREE.AdditiveBlending;
    if (this.pointMat.blending !== desiredBlending) {
      this.pointMat.blending = desiredBlending;
      this.pointMat.needsUpdate = true;
    }

    // Wrap particles seamlessly in a moving 3D volume around the player
    const halfW = this.boxW * 0.5;
    const arr = this.posAttr.array as Float32Array;
    for (let i = 0; i < this.count; i++) {
      const i3 = i * 3;
      const ph = this.phases[i];

      let ox = this.offsets[i3] + (vx + Math.sin(elapsed * 1.1 + ph) * 0.45) * dt;
      let oy = this.offsets[i3 + 1] + (vy + Math.cos(elapsed * 1.4 + ph * 1.7) * 0.25) * dt;
      let oz = this.offsets[i3 + 2] + (vz + Math.cos(elapsed * 0.9 + ph) * 0.45) * dt;

      // Wrap relative to player smoothly
      let wx = ox;
      let wz = oz;
      const relX = ((wx - playerPos.x + halfW) % this.boxW + this.boxW) % this.boxW - halfW;
      const relZ = ((wz - playerPos.z + halfW) % this.boxW + this.boxW) % this.boxW - halfW;
      const relY = ((oy % this.boxH) + this.boxH) % this.boxH;

      ox = playerPos.x + relX;
      oy = relY;
      oz = playerPos.z + relZ;

      this.offsets[i3] = ox;
      this.offsets[i3 + 1] = oy;
      this.offsets[i3 + 2] = oz;

      arr[i3] = ox;
      arr[i3 + 1] = playerPos.y - 1.2 + oy;
      arr[i3 + 2] = oz;
    }
    this.posAttr.needsUpdate = true;

    // Gentle idle water ripples when standing or swimming in water
    if (inWater) {
      this.rippleTimer -= dt * (playerSpeed > 0.4 ? 2.4 : 0.85);
      if (this.rippleTimer <= 0) {
        this.rippleTimer = 0.55;
        this.spawnWaterRipple(playerPos.x, playerPos.z, playerSpeed > 0.4 ? 3.2 : 2.1);
      }
    }

    // Update footstep puffs
    for (let i = 0; i < this.puffs.length; i++) {
      const p = this.puffs[i];
      if (!p.mesh.visible) continue;
      p.age += dt;
      if (p.age >= p.life) {
        p.mesh.visible = false;
        continue;
      }
      const t = p.age / p.life;
      p.mesh.position.x += p.vx * dt;
      p.mesh.position.y += p.vy * dt;
      p.mesh.position.z += p.vz * dt;
      p.vy -= 1.8 * dt;
      p.mesh.scale.setScalar(p.startScale * (0.7 + t * 1.4));
      (p.mesh.material as THREE.MeshBasicMaterial).opacity = (1 - t) * 0.46;
    }

    // Update expanding water ripples
    for (let i = 0; i < this.ripples.length; i++) {
      const r = this.ripples[i];
      if (!r.mesh.visible) continue;
      r.age += dt;
      if (r.age >= r.life) {
        r.mesh.visible = false;
        continue;
      }
      const t = r.age / r.life;
      r.mesh.scale.setScalar(lerp(0.45, r.maxScale, Math.pow(t, 0.72)));
      (r.mesh.material as THREE.MeshBasicMaterial).opacity = (1 - t) * (1 - t) * 0.52;
    }
  }
}
