import * as THREE from 'three';
import {
  WATER_LEVEL,
  getRenderedTerrainHeight,
  sampleBiomeWeights,
} from './biomes';
import { ESSENCES, EssenceType } from './evolution';
import { WeatherKind } from './weather';
import { hashSeed } from './noise';

export interface PlantInfo {
  name: string;
  essence: EssenceType;
  essenceName: string;
  essenceColor: string;
  dna: number;
  heal: number;
  distance: number;
  x: number;
  z: number;
}

interface PlantNode {
  group: THREE.Group;
  fruit: THREE.Mesh;
  stem: THREE.Mesh;
  ring: THREE.Mesh;
  fruitMat: THREE.MeshStandardMaterial;
  ringMat: THREE.MeshBasicMaterial;
  x: number;
  y: number;
  z: number;
  active: boolean;
  respawn: number;
  phase: number;
  info: Omit<PlantInfo, 'distance'>;
}

const PLANT_ESSENCE: Record<string, EssenceType> = {
  meadow: 'gelatinous',
  plains: 'predator',
  forest: 'gelatinous',
  jungle: 'gelatinous',
  alpine: 'chitin',
  autumn: 'predator',
  wasteland: 'predator',
  desert: 'chitin',
  coast: 'aerial',
  wetland: 'gelatinous',
};

const PLANT_NAME: Record<string, string> = {
  meadow: 'Glowcap Bulb',
  plains: 'Driftgrass Seedpod',
  forest: 'Sporecap Pearl',
  jungle: 'Verdigris Fruit',
  alpine: 'Frostberry Shard',
  autumn: 'Emberleaf Bud',
  wasteland: 'Ashroot Nodule',
  desert: 'Prism Melon',
  coast: 'Coral Puff',
  wetland: 'Lantern Reed Bud',
};

const CELL = 20;
const RADIUS = 3;
const NODE_COUNT = (RADIUS * 2 + 1) * (RADIUS * 2 + 1);

/** Streamed, glowing edible alien flora. Press K / Graze to devour nearby plants. */
export class EdiblePlantSystem {
  private readonly scene: THREE.Scene;
  private readonly nodes: PlantNode[] = [];
  private readonly stemGeo = new THREE.CylinderGeometry(0.045, 0.075, 0.5, 6);
  private readonly fruitGeo = new THREE.IcosahedronGeometry(0.24, 1);
  private readonly ringGeo = new THREE.TorusGeometry(0.42, 0.035, 5, 18);
  private lastPX = Number.NaN;
  private lastPZ = Number.NaN;
  private nearest: PlantInfo | null = null;

  constructor(scene: THREE.Scene) {
    this.scene = scene;
    this.ringGeo.rotateX(Math.PI / 2);

    for (let i = 0; i < NODE_COUNT; i++) {
      const fruitMat = new THREE.MeshStandardMaterial({
        color: 0x2dd4bf,
        emissive: 0x2dd4bf,
        emissiveIntensity: 1.3,
        roughness: 0.28,
        metalness: 0.05,
      });
      const ringMat = new THREE.MeshBasicMaterial({
        color: 0x2dd4bf,
        transparent: true,
        opacity: 0.35,
        depthWrite: false,
        side: THREE.DoubleSide,
      });
      const group = new THREE.Group();
      const stem = new THREE.Mesh(this.stemGeo, new THREE.MeshStandardMaterial({
        color: 0x4b7a52,
        roughness: 0.75,
      }));
      stem.position.y = 0.25;
      group.add(stem);

      const fruit = new THREE.Mesh(this.fruitGeo, fruitMat);
      fruit.position.y = 0.62;
      fruit.castShadow = true;
      group.add(fruit);

      const ring = new THREE.Mesh(this.ringGeo, ringMat);
      ring.position.y = 0.05;
      group.add(ring);

      group.visible = false;
      scene.add(group);

      this.nodes.push({
        group,
        fruit,
        stem,
        ring,
        fruitMat,
        ringMat,
        x: 0,
        y: 0,
        z: 0,
        active: false,
        respawn: 0,
        phase: Math.random() * Math.PI * 2,
        info: {
          name: 'Glowcap Bulb',
          essence: 'gelatinous',
          essenceName: ESSENCES.gelatinous.shortName,
          essenceColor: ESSENCES.gelatinous.color,
          dna: 12,
          heal: 10,
          x: 0,
          z: 0,
        },
      });
    }
  }

  private rebuild(px: number, pz: number): void {
    const baseCX = Math.floor(px / CELL);
    const baseCZ = Math.floor(pz / CELL);
    let idx = 0;
    for (let dz = -RADIUS; dz <= RADIUS; dz++) {
      for (let dx = -RADIUS; dx <= RADIUS; dx++) {
        const node = this.nodes[idx++];
        const cx = baseCX + dx;
        const cz = baseCZ + dz;
        const r1 = hashSeed(cx, cz, 81);
        const r2 = hashSeed(cx, cz, 82);
        const r3 = hashSeed(cx, cz, 83);
        const r4 = hashSeed(cx, cz, 84);
        const wx = cx * CELL + r1 * CELL;
        const wz = cz * CELL + r2 * CELL;

        const w = sampleBiomeWeights(wx, wz);
        const dominant = w.dominant;
        const essence = PLANT_ESSENCE[dominant] ?? 'gelatinous';
        const essDef = ESSENCES[essence];
        const h = getRenderedTerrainHeight(wx, wz);

        const viable = h > WATER_LEVEL + 0.6 && r3 > 0.18;
        node.active = viable;
        node.respawn = 0;
        node.x = wx;
        node.z = wz;
        node.y = h;
        node.group.visible = viable;
        node.group.position.set(wx, h, wz);
        node.group.scale.setScalar(0.78 + r4 * 0.55);
        const col = new THREE.Color(essDef.color);
        node.fruitMat.color.copy(col);
        node.fruitMat.emissive.copy(col);
        node.ringMat.color.copy(col);
        node.info = {
          name: PLANT_NAME[dominant] ?? 'Xeno Bulb',
          essence,
          essenceName: essDef.shortName,
          essenceColor: essDef.color,
          dna: Math.round(10 + r3 * 12 + w[dominant] * 8),
          heal: Math.round(8 + r4 * 14),
          x: wx,
          z: wz,
        };
      }
    }
    this.lastPX = px;
    this.lastPZ = pz;
  }

  public update(
    dt: number,
    elapsed: number,
    playerPos: THREE.Vector3,
    weatherKind: WeatherKind,
    regrowthBoost: number
  ): void {
    if (
      Number.isNaN(this.lastPX) ||
      Math.hypot(playerPos.x - this.lastPX, playerPos.z - this.lastPZ) > CELL * 0.75
    ) {
      this.rebuild(playerPos.x, playerPos.z);
    }

    const wet =
      weatherKind === 'plasma_rain' ||
      weatherKind === 'spore_drift' ||
      weatherKind === 'aurora_mist' ||
      weatherKind === 'bio_storm';
    const boost = 1 + Math.max(0, regrowthBoost) * (wet ? 1.3 : 0.4);

    let nearest: PlantInfo | null = null;
    let nearestDist = Infinity;

    for (const node of this.nodes) {
      if (!node.active) {
        node.respawn -= dt * boost;
        if (node.respawn <= 0 && node.group.position.y > WATER_LEVEL) {
          node.active = true;
          node.group.visible = true;
          node.group.scale.setScalar(0.2);
        } else {
          continue;
        }
      }

      const pulse = 1 + Math.sin(elapsed * 2.6 + node.phase) * 0.08;
      node.fruit.scale.setScalar(pulse);
      node.fruit.rotation.y += dt * 1.1;
      node.ring.rotation.y += dt * 0.7;
      node.ringMat.opacity = 0.28 + Math.sin(elapsed * 2.1 + node.phase) * 0.1;
      const s = node.group.scale.x;
      if (s < 0.75) node.group.scale.setScalar(Math.min(0.9, s + dt * 1.4));

      const d = Math.hypot(node.x - playerPos.x, node.z - playerPos.z);
      if (d < nearestDist) {
        nearestDist = d;
        nearest = { ...node.info, distance: Math.round(d) };
      }
    }

    this.nearest = nearest && nearestDist < 22 ? nearest : null;
  }

  public getNearbyInfo(): PlantInfo | null {
    return this.nearest;
  }

  public consumeNearby(px: number, pz: number, radius: number): PlantInfo | null {
    let best: PlantNode | null = null;
    let bestDist = radius;
    for (const node of this.nodes) {
      if (!node.active) continue;
      const d = Math.hypot(node.x - px, node.z - pz);
      if (d <= bestDist) {
        bestDist = d;
        best = node;
      }
    }
    if (!best) return null;

    best.active = false;
    best.group.visible = false;
    best.respawn = 15;
    return { ...best.info, distance: Math.round(bestDist) };
  }

  public dispose(): void {
    for (const n of this.nodes) this.scene.remove(n.group);
    this.stemGeo.dispose();
    this.fruitGeo.dispose();
    this.ringGeo.dispose();
  }
}
