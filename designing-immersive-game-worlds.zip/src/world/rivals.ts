import * as THREE from 'three';
import { WATER_LEVEL, getRenderedTerrainHeight } from './biomes';
import { GameMode, GAME_MODES, GAME_MODE_LIST, MatchState } from './modes';
import { DropAssignment, RosterEntry } from './lobby';
import { clamp, lerp } from './noise';
import { NetworkPlayerState } from './network';

export type PlayerDamageCallback = (
  damage: number,
  sourceName: string,
  sourceX?: number,
  sourceZ?: number
) => void;

export type RivalEliminatedCallback = (
  name: string,
  remaining: number,
  byPlayer: boolean
) => void;

interface RivalPilot {
  index: number;
  name: string;
  alive: boolean;
  group: THREE.Group;
  dome: THREE.Mesh;
  core: THREE.Mesh;
  ring: THREE.Mesh;
  barFill: THREE.Mesh;
  gooMat: THREE.MeshStandardMaterial;
  x: number;
  y: number;
  z: number;
  yaw: number;
  hp: number;
  maxHp: number;
  speed: number;
  scale: number;
  wanderAngle: number;
  homeX: number;
  homeZ: number;
  attackTimer: number;
  skirmishTimer: number;
  bobPhase: number;
  color: THREE.Color;
  isReal: boolean;
  networkControlled: boolean;
  remoteId: string;
  remoteTimer: number;
  dropTimer: number;
  attackMode: number;
  attackCooldown: number;
  menaceTimer: number;
  hurtTimer: number;
  retaliateTimer: number;
  attackDidHit: boolean;
}

interface Tracer {
  mesh: THREE.Mesh;
  age: number;
  life: number;
  active: boolean;
}

interface Burst {
  mesh: THREE.Mesh;
  age: number;
  life: number;
  active: boolean;
}

const RIVAL_NAMES = [
  'Nyx-02',
  'Vyr-07',
  'Oozik-11',
  'Krel-04',
  'Zoa-09',
  'Muru-13',
  'Vex-06',
  'Qilo-08',
  'Sarn-15',
  'Talu-03',
  'Ixo-12',
];

const RIVAL_COLORS = [
  '#f43f5e',
  '#a855f7',
  '#f59e0b',
  '#38bdf8',
  '#4ade80',
  '#fb7185',
  '#c084fc',
  '#22d3ee',
  '#facc15',
  '#34d399',
  '#e879f9',
];

const _up = new THREE.Vector3(0, 1, 0);
const _dir = new THREE.Vector3();
const _mid = new THREE.Vector3();
const _q = new THREE.Quaternion();

function angleDiff(from: number, to: number): number {
  let d = ((to - from + Math.PI) % (Math.PI * 2)) - Math.PI;
  if (d < -Math.PI) d += Math.PI * 2;
  return d;
}

function groundY(x: number, z: number): number {
  return Math.max(WATER_LEVEL, getRenderedTerrainHeight(x, z)) + 0.05;
}

/**
 * Offline "multiplayer" simulation:
 * - Open World spawns neutral AI explorer symbiotes up to the mode player cap.
 * - Battle Royale spawns hostile rival pilots, a shrinking zone, bot-vs-bot combat,
 *   and a proper last-symbiote-standing win/lose state.
 */
export class RivalSystem {
  private readonly scene: THREE.Scene;
  private readonly onPlayerDamaged: PlayerDamageCallback;
  private readonly onRivalEliminated: RivalEliminatedCallback;
  private readonly rivals: RivalPilot[] = [];
  private readonly tracers: Tracer[] = [];
  private readonly bursts: Burst[] = [];
  private readonly zoneMesh: THREE.Mesh;
  private readonly zoneMat: THREE.MeshBasicMaterial;
  private readonly zoneWall: THREE.Mesh;
  private readonly zoneWallMat: THREE.MeshBasicMaterial;
  private readonly zoneTopRing: THREE.Mesh;
  private readonly zoneBeaconBatch: THREE.InstancedMesh;

  private mode: GameMode = 'open-world';
  private totalPlayers = 8;
  private rivalsAlive = 0;
  private playerAlive = true;
  private matchOver = false;
  private winner: string | null = null;
  private playerWon = false;
  private playerCloaked = false;
  private playerDamageCooldown = 0;
  private zoneDamageCooldown = 0;
  private zoneRadius = 250;
  private zoneTargetRadius = 250;
  private zoneStage = 0;
  private zoneTimer = 0;
  private zoneWarningStage = -1;
  private elapsed = 0;
  private eliminations = 0;
  private feed: string | null = null;
  private feedTimer = 0;
  private centerX = 0;
  private centerZ = 18;
  private playerStage = 1;
  private realPlayers = 1;
  private aiPlayers = 0;
  private rosterNames: string[] = ['You'];

  private readonly domeGeo = new THREE.SphereGeometry(0.65, 16, 12);
  private readonly skirtGeo = new THREE.CylinderGeometry(0.58, 0.72, 0.28, 14, 1);
  private readonly coreGeo = new THREE.IcosahedronGeometry(0.22, 1);
  private readonly eyeGeo = new THREE.SphereGeometry(0.075, 8, 6);
  private readonly ringGeo = new THREE.TorusGeometry(1, 0.028, 6, 48);
  private readonly tracerGeo = new THREE.CylinderGeometry(0.035, 0.035, 1, 6);
  private readonly burstGeo = new THREE.SphereGeometry(0.38, 8, 6);
  private readonly eyeMat = new THREE.MeshStandardMaterial({ color: 0x0a0f1a, roughness: 0.15 });
  private readonly barBgMat = new THREE.MeshBasicMaterial({ color: 0x111827 });
  private readonly tracerMat = new THREE.MeshBasicMaterial({
    color: 0x67e8f9,
    transparent: true,
    opacity: 0.9,
  });
  private readonly zoneBeaconDummy = new THREE.Object3D();

  constructor(
    scene: THREE.Scene,
    onPlayerDamaged: PlayerDamageCallback,
    onRivalEliminated: RivalEliminatedCallback
  ) {
    this.scene = scene;
    this.onPlayerDamaged = onPlayerDamaged;
    this.onRivalEliminated = onRivalEliminated;

    this.domeGeo.scale(1.06, 0.86, 1.12);
    this.ringGeo.rotateX(Math.PI / 2);

    const maxModePlayers = Math.max(...GAME_MODE_LIST.map((mode) => mode.maxPlayers));
    for (let i = 0; i < maxModePlayers - 1; i++) {
      this.rivals.push(this.createRival(i));
    }

    for (let i = 0; i < 14; i++) {
      const mesh = new THREE.Mesh(
        this.tracerGeo,
        this.tracerMat.clone()
      );
      mesh.visible = false;
      scene.add(mesh);
      this.tracers.push({ mesh, age: 0, life: 0.22, active: false });
    }

    for (let i = 0; i < 20; i++) {
      const mat = new THREE.MeshBasicMaterial({
        color: 0xfb7185,
        transparent: true,
        opacity: 0.75,
        depthWrite: false,
      });
      const mesh = new THREE.Mesh(this.burstGeo, mat);
      mesh.visible = false;
      scene.add(mesh);
      this.bursts.push({ mesh, age: 0, life: 0.5, active: false });
    }

    this.zoneMat = new THREE.MeshBasicMaterial({
      color: 0xf43f5e,
      transparent: true,
      opacity: 0.55,
      depthWrite: false,
      side: THREE.DoubleSide,
    });
    this.zoneMesh = new THREE.Mesh(this.ringGeo, this.zoneMat);
    this.zoneMesh.rotation.x = 0;
    this.zoneMesh.visible = false;
    this.zoneMesh.renderOrder = 3;
    scene.add(this.zoneMesh);

    // A tall translucent storm curtain makes the distant boundary visible in-world,
    // instead of relying on a tiny ground circle at the horizon.
    const wallGeo = new THREE.CylinderGeometry(1, 1, 115, 128, 1, true);
    this.zoneWallMat = new THREE.MeshBasicMaterial({
      color: 0xf43f8e,
      transparent: true,
      opacity: 0.105,
      depthWrite: false,
      side: THREE.DoubleSide,
      blending: THREE.AdditiveBlending,
    });
    this.zoneWall = new THREE.Mesh(wallGeo, this.zoneWallMat);
    this.zoneWall.visible = false;
    this.zoneWall.renderOrder = 2;
    scene.add(this.zoneWall);

    const topGeo = new THREE.TorusGeometry(1, 0.014, 5, 160);
    topGeo.rotateX(Math.PI / 2);
    this.zoneTopRing = new THREE.Mesh(
      topGeo,
      new THREE.MeshBasicMaterial({
        color: 0xff4c9a,
        transparent: true,
        opacity: 0.72,
        depthWrite: false,
        side: THREE.DoubleSide,
        blending: THREE.AdditiveBlending,
      })
    );
    this.zoneTopRing.visible = false;
    this.zoneTopRing.renderOrder = 3;
    scene.add(this.zoneTopRing);

    const beaconGeo = new THREE.CylinderGeometry(0.04, 0.04, 84, 5);
    const beaconMat = new THREE.MeshBasicMaterial({
      color: 0xff8bc2,
      transparent: true,
      opacity: 0.55,
      depthWrite: false,
      blending: THREE.AdditiveBlending,
    });
    this.zoneBeaconBatch = new THREE.InstancedMesh(beaconGeo, beaconMat, 40);
    this.zoneBeaconBatch.frustumCulled = false;
    this.zoneBeaconBatch.count = 0;
    this.zoneBeaconBatch.renderOrder = 3;
    scene.add(this.zoneBeaconBatch);
  }

  private createRival(index: number): RivalPilot {
    const color = new THREE.Color(RIVAL_COLORS[index % RIVAL_COLORS.length]);
    const gooMat = new THREE.MeshStandardMaterial({
      color,
      emissive: color.clone().multiplyScalar(0.45),
      emissiveIntensity: 0.9,
      roughness: 0.24,
      metalness: 0.04,
      transparent: true,
      opacity: 0.88,
    });
    const coreMat = new THREE.MeshStandardMaterial({
      color: color.clone().offsetHSL(0, 0.05, 0.22),
      emissive: color.clone().multiplyScalar(1.4),
      emissiveIntensity: 1.5,
      roughness: 0.2,
    });

    const group = new THREE.Group();
    const dome = new THREE.Mesh(this.domeGeo, gooMat);
    dome.position.set(0, 0.55, 0);
    dome.castShadow = true;
    group.add(dome);

    const skirt = new THREE.Mesh(this.skirtGeo, gooMat);
    skirt.position.set(0, 0.16, 0.02);
    skirt.castShadow = true;
    group.add(skirt);

    const core = new THREE.Mesh(this.coreGeo, coreMat);
    core.position.set(0, 0.5, 0);
    group.add(core);

    for (const side of [-1, 1]) {
      const eye = new THREE.Mesh(this.eyeGeo, this.eyeMat);
      eye.position.set(side * 0.22, 0.78, -0.48);
      group.add(eye);
    }

    const ring = new THREE.Mesh(this.ringGeo, new THREE.MeshBasicMaterial({
      color,
      transparent: true,
      opacity: 0.55,
      depthWrite: false,
    }));
    ring.scale.setScalar(0.95);
    ring.position.set(0, 0.04, 0);
    group.add(ring);

    const barBg = new THREE.Mesh(new THREE.BoxGeometry(1.1, 0.09, 0.04), this.barBgMat);
    barBg.position.set(0, 1.55, 0);
    group.add(barBg);
    const barFill = new THREE.Mesh(
      new THREE.BoxGeometry(1.06, 0.06, 0.05),
      new THREE.MeshBasicMaterial({ color })
    );
    barFill.position.set(0, 1.55, 0.03);
    group.add(barFill);

    group.visible = false;
    this.scene.add(group);

    return {
      index,
      name: RIVAL_NAMES[index % RIVAL_NAMES.length],
      alive: false,
      group,
      dome,
      core,
      ring,
      barFill,
      gooMat,
      x: 0,
      y: 0,
      z: 0,
      yaw: 0,
      hp: 100,
      maxHp: 100,
      speed: 4,
      scale: 1,
      wanderAngle: Math.random() * Math.PI * 2,
      homeX: 0,
      homeZ: 0,
      attackTimer: 0,
      skirmishTimer: 0,
      bobPhase: Math.random() * 10,
      color,
      isReal: false,
      networkControlled: false,
      remoteId: '',
      remoteTimer: 0,
      dropTimer: 0,
      attackMode: 0,
      attackCooldown: 0,
      menaceTimer: 0,
      hurtTimer: 0,
      retaliateTimer: 0,
      attackDidHit: false,
    };
  }

  /** Configure / reset a mode. Open World keeps neutral AI explorers; BR is a live match. */
  public configure(
    mode: GameMode,
    totalPlayers: number,
    playerPos: THREE.Vector3,
    playerStage = 1
  ): void {
    const cfg = GAME_MODES[mode];
    this.mode = mode;
    this.totalPlayers = clamp(totalPlayers, cfg.minPlayers, cfg.maxPlayers);
    this.playerStage = Math.max(1, playerStage);
    this.centerX = playerPos.x;
    this.centerZ = playerPos.z;
    this.rivalsAlive = 0;
    this.realPlayers = 1;
    this.aiPlayers = Math.max(0, this.totalPlayers - 1);
    this.rosterNames = ['You'];
    this.playerAlive = true;
    this.matchOver = false;
    this.winner = null;
    this.playerWon = false;
    this.playerCloaked = false;
    this.playerDamageCooldown = 0;
    this.zoneDamageCooldown = 0;
    this.elapsed = 0;
    this.zoneStage = 0;
    this.zoneTimer = 0;
    this.zoneWarningStage = -1;
    this.zoneRadius = cfg.battleRoyale ? cfg.zoneStartRadius : 0;
    this.zoneTargetRadius = cfg.battleRoyale ? cfg.zoneStartRadius : 0;
    this.eliminations = 0;
    this.feed = mode === 'battle-royale' ? 'Bio-Storm match started! Last symbiote standing wins.' : null;
    this.feedTimer = 4;

    const count = Math.max(0, this.totalPlayers - 1);
    const spawnRadius = mode === 'battle-royale' ? 58 : 22;

    for (let i = 0; i < this.rivals.length; i++) {
      const r = this.rivals[i];
      r.alive = i < count;
      r.group.visible = r.alive;
      r.isReal = false;
      r.networkControlled = false;
      r.remoteId = '';
      r.remoteTimer = 0;
      r.dropTimer = 0;
      if (!r.alive) continue;

      const a = (i / Math.max(1, count)) * Math.PI * 2 + 0.4 + (Math.random() - 0.5) * 0.35;
      const dist = spawnRadius + (i % 3) * 14 + Math.random() * 16;
      r.x = this.centerX + Math.cos(a) * dist;
      r.z = this.centerZ + Math.sin(a) * dist;
      r.y = groundY(r.x, r.z);
      r.homeX = r.x;
      r.homeZ = r.z;
      r.yaw = a + Math.PI;
      r.wanderAngle = a;
      r.scale = 0.85 + (i % 4) * 0.09;
      r.maxHp = Math.round(90 + this.playerStage * 26 + i * 5 + (cfg.battleRoyale ? 20 : 0));
      r.hp = r.maxHp;
      r.speed = 3.4 + (i % 3) * 0.55;
      r.attackTimer = 1 + Math.random() * 2;
      r.skirmishTimer = 2 + Math.random() * 3;
      r.group.position.set(r.x, r.y, r.z);
      r.group.scale.setScalar(r.scale);
      r.barFill.scale.x = 1;
      this.rivalsAlive++;
    }

    this.zoneMesh.visible = cfg.battleRoyale;
    this.zoneWall.visible = cfg.battleRoyale;
    this.zoneTopRing.visible = cfg.battleRoyale;
    this.zoneBeaconBatch.visible = cfg.battleRoyale;
    if (cfg.battleRoyale) {
      this.updateZoneVisuals(0);
    }
  }


  /** Spawn a lobby roster at spread-out drop points. Real players are network-controlled. */
  public configureRoster(
    roster: RosterEntry[],
    assignments: DropAssignment[],
    playerPos: THREE.Vector3,
    playerStage = 1
  ): void {
    const cfg = GAME_MODES['battle-royale'];
    this.mode = 'battle-royale';
    this.totalPlayers = Math.max(cfg.minPlayers, Math.min(cfg.maxPlayers, roster.length));
    this.playerStage = Math.max(1, playerStage);
    this.centerX = 0;
    this.centerZ = 0;
    this.rivalsAlive = 0;
    this.realPlayers = roster.filter((r) => !r.isAI).length;
    this.aiPlayers = roster.filter((r) => r.isAI).length;
    this.rosterNames = roster.map((r) => r.name);
    this.playerAlive = true;
    this.matchOver = false;
    this.winner = null;
    this.playerWon = false;
    this.playerCloaked = false;
    this.playerDamageCooldown = 0;
    this.zoneDamageCooldown = 0;
    this.elapsed = 0;
    this.zoneStage = 0;
    this.zoneTimer = 0;
    this.zoneWarningStage = -1;
    this.zoneRadius = cfg.zoneStartRadius;
    this.zoneTargetRadius = cfg.zoneStartRadius;
    this.eliminations = 0;
    this.feed = 'Bio-Storm match started! Last symbiote standing wins.';
    this.feedTimer = 4;

    const others = roster.filter((r) => !r.isLocal).slice(0, this.rivals.length);
    for (let i = 0; i < this.rivals.length; i++) {
      const r = this.rivals[i];
      const entry = others[i];
      r.alive = Boolean(entry);
      r.group.visible = r.alive;
      if (!entry) continue;

      const a = assignments.find((x) => x.playerId === entry.id);
      r.x = a?.x ?? playerPos.x + Math.cos(i) * 80;
      r.z = a?.z ?? playerPos.z + Math.sin(i) * 80;
      const landingY = groundY(r.x, r.z);
      // AI rivals start visibly above their assigned ground point and descend into the opening ring.
      r.dropTimer = entry.isAI ? 3.8 : 0;
      r.y = landingY + (entry.isAI ? 54 : 0);
      r.homeX = r.x;
      r.homeZ = r.z;
      r.yaw = Math.atan2(-(0 - r.x), -(0 - r.z));
      r.wanderAngle = r.yaw;
      r.name = entry.name;
      r.remoteId = entry.isAI ? '' : entry.id;
      r.isReal = !entry.isAI;
      r.networkControlled = !entry.isAI;
      r.remoteTimer = 0;
      r.scale = 0.88 + (i % 4) * 0.08;
      r.maxHp = Math.round(100 + this.playerStage * 28 + i * 5);
      r.hp = r.maxHp;
      r.speed = 3.5 + (i % 3) * 0.55;
      r.attackTimer = 1 + Math.random() * 2;
      r.skirmishTimer = 2 + Math.random() * 3;
      r.attackMode = 0;
      r.attackCooldown = 0;
      r.menaceTimer = 0;
      r.hurtTimer = 0;
      r.retaliateTimer = 0;
      r.attackDidHit = false;
      r.group.position.set(r.x, r.y, r.z);
      r.group.rotation.y = r.yaw;
      r.group.scale.setScalar(r.scale);
      r.barFill.scale.x = 1;
      r.barFill.position.x = 0;
      this.rivalsAlive++;
    }

    this.zoneMesh.visible = true;
    this.zoneWall.visible = true;
    this.zoneTopRing.visible = true;
    this.zoneBeaconBatch.visible = true;
    this.updateZoneVisuals(0);
  }

  /** Apply a real remote player's transform from the lobby relay. */
  public applyRemoteState(state: NetworkPlayerState): void {
    const r = this.rivals.find(
      (v) => v.alive && (v.remoteId === state.id || v.name === state.name)
    );
    if (!r) return;
    r.remoteTimer = 0;
    r.networkControlled = true;
    if (!state.alive) {
      if (r.alive) this.eliminateRival(r, false, 'eliminated');
      return;
    }
    r.x = state.x;
    r.z = state.z;
    r.y = Number.isFinite(state.y) ? state.y : groundY(state.x, state.z);
    r.yaw = state.yaw;
    r.hp = Math.max(1, state.hp);
    const ratio = clamp(r.hp / r.maxHp, 0, 1);
    r.barFill.scale.x = Math.max(0.02, ratio);
    r.barFill.position.x = -(1 - ratio) * 0.53;
    r.group.position.set(r.x, r.y, r.z);
    r.group.rotation.y = r.yaw;
    r.group.visible = true;
  }

  public setPlayerCloaked(active: boolean): void {
    this.playerCloaked = active;
  }

  private updateZoneVisuals(elapsed: number): void {
    const radius = Math.max(2, this.zoneRadius);
    const floor = groundY(this.centerX, this.centerZ);
    this.zoneMesh.position.set(this.centerX, floor + 0.15, this.centerZ);
    this.zoneMesh.scale.setScalar(radius);
    this.zoneMat.opacity = 0.48 + Math.sin(elapsed * 2.2) * 0.1;

    // A tall, translucent curtain makes the storm boundary legible all around the horizon.
    this.zoneWall.position.set(this.centerX, floor + 100, this.centerZ);
    this.zoneWall.scale.set(radius, 1, radius);
    this.zoneWallMat.opacity = 0.075 + (0.5 + 0.5 * Math.sin(elapsed * 1.8)) * 0.045;
    this.zoneTopRing.position.set(this.centerX, floor + 201, this.centerZ);
    this.zoneTopRing.scale.setScalar(radius);

    const count = 40;
    for (let i = 0; i < count; i++) {
      const a = (i / count) * Math.PI * 2;
      this.zoneBeaconDummy.position.set(
        this.centerX + Math.cos(a) * radius,
        floor + 68,
        this.centerZ + Math.sin(a) * radius
      );
      this.zoneBeaconDummy.rotation.set(0, 0, 0);
      this.zoneBeaconDummy.scale.set(1, 1, 1);
      this.zoneBeaconDummy.updateMatrix();
      this.zoneBeaconBatch.setMatrixAt(i, this.zoneBeaconDummy.matrix);
      this.zoneBeaconBatch.setColorAt(
        i,
        new THREE.Color(i % 4 === 0 ? 0xf0abfc : 0xfb7185)
      );
    }
    this.zoneBeaconBatch.count = count;
    this.zoneBeaconBatch.instanceMatrix.needsUpdate = true;
    if (this.zoneBeaconBatch.instanceColor) this.zoneBeaconBatch.instanceColor.needsUpdate = true;
  }

  public eliminatePlayer(winnerName = 'Bio-Storm'): void {
    if (this.matchOver) return;
    this.playerAlive = false;
    this.matchOver = true;
    this.winner = winnerName;
    this.playerWon = false;
    this.setFeed(`${winnerName} eliminated you. Match over.`, 8);
  }

  public getState(): MatchState {
    return {
      mode: this.mode,
      totalPlayers: this.totalPlayers,
      rivalsAlive: this.rivalsAlive,
      playerAlive: this.playerAlive,
      matchOver: this.matchOver,
      winner: this.winner,
      playerWon: this.playerWon,
      zoneRadius: this.zoneRadius,
      zoneTargetRadius: this.zoneTargetRadius,
      zoneStage: this.zoneStage,
      zoneTime: this.zoneTimer,
      zoneWarning: this.mode === 'battle-royale' && this.zoneStage < 5 && this.zoneTimer >= 25,
      zoneClosesIn: this.mode === 'battle-royale' && this.zoneStage < 5
        ? Math.max(0, Math.ceil(35 - this.zoneTimer))
        : 0,
      elapsed: this.elapsed,
      eliminations: this.eliminations,
      feed: this.feed,
      realPlayers: this.realPlayers,
      aiPlayers: this.aiPlayers,
      rosterNames: [...this.rosterNames],
    };
  }

  private setFeed(text: string, seconds = 3): void {
    this.feed = text;
    this.feedTimer = seconds;
  }

  private eliminateRival(r: RivalPilot, byPlayer: boolean, cause = 'eliminated'): void {
    if (!r.alive) return;
    r.alive = false;
    r.group.visible = false;
    this.rivalsAlive = Math.max(0, this.rivalsAlive - 1);
    this.eliminations++;
    this.spawnBurst(r.x, r.y + 0.6, r.z, r.color);
    this.setFeed(`${r.name} ${cause}! ${this.rivalsAlive} rivals remain.`, 3.5);
    this.onRivalEliminated(r.name, this.rivalsAlive, byPlayer);
    if (this.mode === 'battle-royale' && this.rivalsAlive === 0 && this.playerAlive && !this.matchOver) {
      this.matchOver = true;
      this.playerAlive = true;
      this.playerWon = true;
      this.winner = 'YOU';
      this.setFeed('LAST SYMBIOTE STANDING — YOU WIN!', 10);
    }
  }

  private spawnBurst(x: number, y: number, z: number, color: THREE.Color): void {
    const b = this.bursts.find((v) => !v.active) ?? this.bursts[0];
    b.active = true;
    b.age = 0;
    (b.mesh.material as THREE.MeshBasicMaterial).color.copy(color);
    b.mesh.position.set(x, y, z);
    b.mesh.scale.setScalar(0.4);
    b.mesh.visible = true;
  }

  private spawnTracer(from: THREE.Vector3, to: THREE.Vector3, color: THREE.Color): void {
    const t = this.tracers.find((v) => !v.active) ?? this.tracers[0];
    t.active = true;
    t.age = 0;
    (t.mesh.material as THREE.MeshBasicMaterial).color.copy(color);
    _dir.subVectors(to, from);
    const len = Math.max(0.01, _dir.length());
    _dir.multiplyScalar(1 / len);
    _mid.addVectors(from, to).multiplyScalar(0.5);
    _q.setFromUnitVectors(_up, _dir);
    t.mesh.position.copy(_mid);
    t.mesh.quaternion.copy(_q);
    t.mesh.scale.set(1, len, 1);
    t.mesh.visible = true;
  }

  private applyDamage(r: RivalPilot, damage: number, byPlayer: boolean, cause = 'eliminated'): boolean {
    if (!r.alive) return false;
    r.hp -= Math.max(1, Math.round(damage));
    const ratio = clamp(r.hp / r.maxHp, 0, 1);
    r.barFill.scale.x = Math.max(0.02, ratio);
    r.barFill.position.x = -(1 - ratio) * 0.53;
    r.gooMat.emissiveIntensity = 2.2;
    this.spawnBurst(r.x, r.y + 0.6, r.z, r.color);
    if (r.hp <= 0) {
      this.eliminateRival(r, byPlayer, cause);
      return true;
    }
    return false;
  }

  public hasRivalNear(x: number, z: number, radius: number): boolean {
    for (const r of this.rivals) {
      if (!r.alive) continue;
      if (Math.hypot(r.x - x, r.z - z) <= radius + r.scale) return true;
    }
    return false;
  }

  /** Radial damage from Gravity Slam, Spore Mines, etc. */
  public damageAt(
    x: number,
    z: number,
    radius: number,
    damage: number,
    byPlayer = true,
    cause = 'eliminated'
  ): { hitCount: number; killedCount: number } {
    let hitCount = 0;
    let killedCount = 0;
    for (const r of this.rivals) {
      if (!r.alive) continue;
      if (Math.hypot(r.x - x, r.z - z) > radius + r.scale) continue;
      hitCount++;
      if (this.applyDamage(r, damage, byPlayer, cause)) killedCount++;
    }
    return { hitCount, killedCount };
  }

  /** Cone damage from Void Lance / Phase Dash. */
  public damageInCone(
    px: number,
    pz: number,
    fwdX: number,
    fwdZ: number,
    range: number,
    halfWidth: number,
    damage: number,
    byPlayer = true,
    cause = 'eliminated'
  ): { hitCount: number; killedCount: number; nearest: { x: number; z: number } | null } {
    let hitCount = 0;
    let killedCount = 0;
    let nearest: { x: number; z: number } | null = null;
    let best = Infinity;
    for (const r of this.rivals) {
      if (!r.alive) continue;
      const dx = r.x - px;
      const dz = r.z - pz;
      const along = dx * fwdX + dz * fwdZ;
      const perp = Math.abs(dx * -fwdZ + dz * fwdX);
      if (along < -0.5 || along > range || perp > halfWidth + r.scale) continue;
      const dist = Math.hypot(dx, dz);
      if (dist < best) {
        best = dist;
        nearest = { x: r.x, z: r.z };
      }
      hitCount++;
      if (this.applyDamage(r, damage, byPlayer, cause)) killedCount++;
    }
    return { hitCount, killedCount, nearest };
  }

  /** Melee Bite hits rivals. */
  public applyMelee(
    px: number,
    _py: number,
    pz: number,
    fwdX: number,
    fwdZ: number,
    damage: number,
    reach: number
  ): { hitCount: number; killedCount: number; lungeTarget: { x: number; z: number } | null } {
    const cone = this.damageInCone(px, pz, fwdX, fwdZ, reach + 2.0, reach * 0.85, damage, true, 'devoured');
    return {
      hitCount: cone.hitCount,
      killedCount: cone.killedCount,
      lungeTarget: cone.nearest,
    };
  }

  /** Bio-Plasma Spit auto-targets the nearest rival in front of the player. */
  public applySpit(
    px: number,
    py: number,
    pz: number,
    fwdX: number,
    fwdZ: number,
    damage: number,
    range = 34
  ): { hit: boolean; killed: boolean; name: string | null } {
    let best: RivalPilot | null = null;
    let bestScore = Infinity;
    for (const r of this.rivals) {
      if (!r.alive) continue;
      const dx = r.x - px;
      const dz = r.z - pz;
      const dist = Math.hypot(dx, dz);
      if (dist > range) continue;
      const dot = (dx * fwdX + dz * fwdZ) / Math.max(0.01, dist);
      if (dot < 0.35) continue;
      const score = dist * (2 - dot);
      if (score < bestScore) {
        bestScore = score;
        best = r;
      }
    }

    if (!best) return { hit: false, killed: false, name: null };
    const from = new THREE.Vector3(px, py + 0.9, pz);
    const to = new THREE.Vector3(best.x, best.y + 0.6, best.z);
    this.spawnTracer(from, to, new THREE.Color(0x67e8f9));
    const killed = this.applyDamage(best, damage, true, 'dissolved');
    return { hit: true, killed, name: best.name };
  }

  /** Per-frame AI, zone collapse, bot-vs-bot combat and win/lose resolution. */
  public update(
    dt: number,
    elapsed: number,
    playerPos: THREE.Vector3,
    playerHp: number
  ): MatchState {
    const cfg = GAME_MODES[this.mode];
    this.elapsed += dt;
    this.playerDamageCooldown = Math.max(0, this.playerDamageCooldown - dt);
    this.zoneDamageCooldown = Math.max(0, this.zoneDamageCooldown - dt);
    if (this.feedTimer > 0) {
      this.feedTimer = Math.max(0, this.feedTimer - dt);
      if (this.feedTimer <= 0) this.feed = null;
    }

    if (cfg.battleRoyale && !this.matchOver) {
      this.zoneTimer += dt;
      if (
        this.zoneStage < 5 &&
        this.zoneTimer >= 25 &&
        this.zoneWarningStage !== this.zoneStage
      ) {
        this.zoneWarningStage = this.zoneStage;
        this.setFeed(
          `BIO-STORM WARNING — closing in 10s. Move inside ${Math.round(this.zoneRadius)}m.`,
          5
        );
      }
      if (this.zoneStage < 5 && this.zoneTimer > 35) {
        this.zoneStage++;
        this.zoneTimer = 0;
        this.zoneTargetRadius = Math.round(
          lerp(cfg.zoneStartRadius, cfg.zoneEndRadius, this.zoneStage / 5)
        );
        this.setFeed(`Bio-Storm collapsing! Zone ${this.zoneRadius.toFixed(0)}m → ${this.zoneTargetRadius}m`, 4);
      }
      this.zoneRadius = lerp(this.zoneRadius, this.zoneTargetRadius, Math.min(1, dt * 0.35));
      this.updateZoneVisuals(elapsed);
    }

    if (playerHp <= 0 && this.playerAlive && cfg.battleRoyale && !this.matchOver) {
      this.eliminatePlayer(this.rivals.find((r) => r.alive)?.name ?? 'Bio-Storm');
    }

    for (const r of this.rivals) {
      if (!r.alive) continue;
      if (r.networkControlled) {
        r.remoteTimer += dt;
        if (r.remoteTimer > 6) r.networkControlled = false;
        r.group.position.set(r.x, r.y + Math.sin(r.bobPhase) * 0.05, r.z);
        r.group.rotation.y = r.yaw;
        r.ring.rotation.y = elapsed * 0.8;
        r.core.rotation.y = elapsed * 1.8;
        continue;
      }
      if (r.dropTimer > 0) {
        r.dropTimer = Math.max(0, r.dropTimer - dt);
        const floor = groundY(r.x, r.z);
        r.y = Math.max(floor, r.y - dt * 16);
        r.bobPhase += dt * 4;
        r.group.position.set(r.x, r.y + Math.sin(r.bobPhase) * 0.08, r.z);
        r.group.rotation.y = r.yaw;
        continue;
      }
      r.gooMat.emissiveIntensity = lerp(r.gooMat.emissiveIntensity, 0.9, Math.min(1, dt * 5));
      r.bobPhase += dt * 3.4;
      r.attackTimer = Math.max(0, r.attackTimer - dt);
      r.skirmishTimer = Math.max(0, r.skirmishTimer - dt);

      const playerDist = Math.hypot(playerPos.x - r.x, playerPos.z - r.z);
      const inZone =
        !cfg.battleRoyale || Math.hypot(r.x - this.centerX, r.z - this.centerZ) <= this.zoneRadius;

      if (cfg.battleRoyale && !inZone) {
        r.hp -= dt * 7.5;
        r.barFill.scale.x = Math.max(0.02, clamp(r.hp / r.maxHp, 0, 1));
        if (r.hp <= 0) {
          this.eliminateRival(r, false, 'consumed by the Bio-Storm');
          continue;
        }
      }

      // Bots slowly damage each other so the match always resolves
      if (cfg.battleRoyale && this.elapsed > 55) {
        r.hp -= dt * 0.35;
        if (r.hp <= 0) {
          this.eliminateRival(r, false, 'lost biomass in the Bio-Storm');
          continue;
        }
      }

      let targetX = r.homeX + Math.cos(r.wanderAngle) * 10;
      let targetZ = r.homeZ + Math.sin(r.wanderAngle) * 10;
      let chasingPlayer = false;

      if (cfg.battleRoyale && this.playerAlive && !this.playerCloaked && !this.matchOver) {
        // The closest few rivals actively hunt the player; others fight bots / rotate inward
        if (playerDist < 70 || this.rivalsAlive <= 3) {
          targetX = playerPos.x;
          targetZ = playerPos.z;
          chasingPlayer = true;
        } else {
          // Pull toward the safe zone center
          const pull = 0.55;
          targetX = lerp(r.homeX, this.centerX, pull);
          targetZ = lerp(r.homeZ, this.centerZ, pull);
        }
      } else if (!cfg.battleRoyale) {
        // Neutral open-world explorers drift gently around their spawn
        r.wanderAngle += dt * 0.25;
        targetX = r.homeX + Math.cos(r.wanderAngle) * 9;
        targetZ = r.homeZ + Math.sin(r.wanderAngle) * 9;
      }

      // Find nearest other alive bot for skirmishes
      let nearest: RivalPilot | null = null;
      let nearestDist = Infinity;
      if (cfg.battleRoyale) {
        for (const other of this.rivals) {
          if (!other.alive || other === r) continue;
          const d = Math.hypot(other.x - r.x, other.z - r.z);
          if (d < nearestDist) {
            nearestDist = d;
            nearest = other;
          }
        }
      }

      if (!chasingPlayer && nearest && nearestDist < 48) {
        targetX = nearest.x;
        targetZ = nearest.z;
      }

      const dx = targetX - r.x;
      const dz = targetZ - r.z;
      const distToTarget = Math.hypot(dx, dz);
      if (distToTarget > 1.2) {
        const desiredYaw = Math.atan2(-dx, -dz);
        r.yaw += angleDiff(r.yaw, desiredYaw) * Math.min(1, dt * 4.5);
        const spd = r.speed * (chasingPlayer ? 1.15 : 0.7);
        const nx = r.x + (dx / distToTarget) * spd * dt;
        const nz = r.z + (dz / distToTarget) * spd * dt;
        const h = groundY(nx, nz);
        if (h > WATER_LEVEL - 1.5) {
          r.x = nx;
          r.z = nz;
          r.y = h;
        }
      }

      // Attack player
      if (
        chasingPlayer &&
        playerDist < 3.3 &&
        r.attackTimer <= 0 &&
        this.playerDamageCooldown <= 0 &&
        this.playerAlive &&
        !this.matchOver
      ) {
        r.attackTimer = 2.0 + Math.random();
        this.playerDamageCooldown = 0.9;
        const dmg = Math.round(7 + this.playerStage * 1.6 + (r.index % 3));
        this.onPlayerDamaged(dmg, r.name, r.x, r.z);
        this.spawnTracer(
          new THREE.Vector3(r.x, r.y + 0.6, r.z),
          new THREE.Vector3(playerPos.x, playerPos.y + 0.6, playerPos.z),
          r.color
        );
      }

      // Bot-vs-bot skirmish
      if (
        cfg.battleRoyale &&
        nearest &&
        nearestDist < 4.5 &&
        r.skirmishTimer <= 0 &&
        !this.matchOver
      ) {
        r.skirmishTimer = 1.8 + Math.random() * 1.5;
        const dmg = 9 + (r.index % 4) * 2;
        this.applyDamage(nearest, dmg, false, 'eliminated by a rival');
        this.spawnTracer(
          new THREE.Vector3(r.x, r.y + 0.6, r.z),
          new THREE.Vector3(nearest.x, nearest.y + 0.6, nearest.z),
          r.color
        );
      }

      r.group.position.set(r.x, r.y + Math.sin(r.bobPhase) * 0.05, r.z);
      r.group.rotation.y = r.yaw;
      r.ring.rotation.y = elapsed * 0.8;
      r.core.rotation.y = elapsed * 1.8;
      r.dome.scale.set(
        1 + Math.sin(r.bobPhase) * 0.035,
        1 - Math.sin(r.bobPhase) * 0.05,
        1 + Math.sin(r.bobPhase) * 0.035
      );
    }

    // Zone damages the player outside the safe ring
    if (
      cfg.battleRoyale &&
      !this.matchOver &&
      this.playerAlive &&
      this.zoneDamageCooldown <= 0
    ) {
      const dx = playerPos.x - this.centerX;
      const dz = playerPos.z - this.centerZ;
      const dist = Math.hypot(dx, dz);
      if (dist > this.zoneRadius) {
        this.zoneDamageCooldown = 1.0;
        // Source is placed outside the player so engine knockback pushes them toward center
        const inv = 1 / Math.max(0.01, dist);
        const sx = playerPos.x + dx * inv * 10;
        const sz = playerPos.z + dz * inv * 10;
        this.onPlayerDamaged(7, 'The Collapsing Bio-Storm', sx, sz);
        this.setFeed('Outside the Bio-Storm safe zone! Move inward!', 2.2);
      }
    }

    // Zone rival pressure / final resolution
    if (cfg.battleRoyale && !this.matchOver && this.elapsed > cfg.matchDuration) {
      // Sudden death: eliminate the weakest remaining bot
      const alive = this.rivals.filter((r) => r.alive);
      if (alive.length > 1) {
        alive.sort((a, b) => a.hp - b.hp);
        this.eliminateRival(alive[0], false, 'lost to sudden death');
      } else if (alive.length === 1) {
        this.eliminateRival(alive[0], false, 'lost to sudden death');
      }
    }

    // Update pooled tracers / bursts
    for (const t of this.tracers) {
      if (!t.active) continue;
      t.age += dt;
      const k = 1 - t.age / t.life;
      (t.mesh.material as THREE.MeshBasicMaterial).opacity = clamp(k, 0, 1);
      if (t.age >= t.life) {
        t.active = false;
        t.mesh.visible = false;
      }
    }
    for (const b of this.bursts) {
      if (!b.active) continue;
      b.age += dt;
      const k = 1 - b.age / b.life;
      b.mesh.scale.setScalar(0.4 + (1 - k) * 2.2);
      (b.mesh.material as THREE.MeshBasicMaterial).opacity = clamp(k, 0, 0.85);
      if (b.age >= b.life) {
        b.active = false;
        b.mesh.visible = false;
      }
    }

    return this.getState();
  }

  public dispose(): void {
    for (const r of this.rivals) this.scene.remove(r.group);
    for (const t of this.tracers) this.scene.remove(t.mesh);
    for (const b of this.bursts) this.scene.remove(b.mesh);
    this.scene.remove(this.zoneMesh);
    this.scene.remove(this.zoneWall);
    this.scene.remove(this.zoneTopRing);
    this.scene.remove(this.zoneBeaconBatch);
    this.zoneWall.geometry.dispose();
    (this.zoneWall.material as THREE.Material).dispose();
    this.zoneTopRing.geometry.dispose();
    (this.zoneTopRing.material as THREE.Material).dispose();
    this.zoneBeaconBatch.geometry.dispose();
    (this.zoneBeaconBatch.material as THREE.Material).dispose();
  }
}
