import * as THREE from 'three';
import { clamp, lerp, smoothstep } from './noise';

export interface AtmosphereState {
  sunDirection: THREE.Vector3;
  sunColor: THREE.Color;
  horizonColor: THREE.Color;
  zenithColor: THREE.Color;
  dayFactor: number;
  goldenFactor: number;
  nightFactor: number;
}

const SKY_VERTEX = /* glsl */ `
  varying vec3 vWorldDir;
  void main() {
    vec4 wp = modelMatrix * vec4(position, 1.0);
    vWorldDir = normalize(position);
    gl_Position = projectionMatrix * viewMatrix * wp;
  }
`;

const SKY_FRAGMENT = /* glsl */ `
  precision highp float;
  varying vec3 vWorldDir;

  uniform vec3 uSunDir;
  uniform vec3 uSun2Dir;
  uniform vec3 uZenithColor;
  uniform vec3 uHorizonColor;
  uniform vec3 uSunColor;
  uniform float uTime;
  uniform float uDayFactor;
  uniform float uGoldenFactor;
  uniform float uNightFactor;

  float hash21(vec2 p) {
    p = fract(p * vec2(234.34, 435.345));
    p += dot(p, p + 34.23);
    return fract(p.x * p.y);
  }

  float noise(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    vec2 u = f * f * (3.0 - 2.0 * f);
    return mix(
      mix(hash21(i), hash21(i + vec2(1.0, 0.0)), u.x),
      mix(hash21(i + vec2(0.0, 1.0)), hash21(i + vec2(1.0, 1.0)), u.x),
      u.y
    );
  }

  float cloudFbm(vec2 p) {
    float v = 0.0;
    float a = 0.52;
    mat2 rot = mat2(0.8, 0.6, -0.6, 0.8);
    for (int i = 0; i < 5; i++) {
      v += a * noise(p);
      p = rot * p * 2.04 + vec2(13.1, -7.4);
      a *= 0.49;
    }
    return v;
  }

  void main() {
    vec3 dir = normalize(vWorldDir);
    float elev = clamp(dir.y, 0.0, 1.0);
    float horizonCurve = pow(1.0 - elev, 2.5);
    vec3 sky = mix(uZenithColor, uHorizonColor, horizonCurve);

    // Thin violet aerosol band hugging the alien horizon
    sky += vec3(0.32, 0.06, 0.38) * pow(1.0 - elev, 9.0) * (0.18 + uGoldenFactor * 0.25) * clamp(uDayFactor + uGoldenFactor, 0.0, 1.0);

    float sunDot = dot(dir, uSunDir);
    float mieGlow = pow(max(sunDot, 0.0), 5.0) * (0.34 + uGoldenFactor * 0.55);
    float wideHaze = pow(max(sunDot, 0.0), 1.8) * pow(1.0 - elev, 2.2) * (0.25 + uGoldenFactor * 0.65);
    sky += uSunColor * (mieGlow + wideHaze) * clamp(uDayFactor + uGoldenFactor * 0.8, 0.0, 1.2);

    float aboveHorizon = smoothstep(-0.04, 0.03, dir.y);

    // Primary star
    float sunDisc = smoothstep(0.9984, 0.9993, sunDot);
    float sunCorona = pow(max(sunDot, 0.0), 80.0) * 1.2;
    sky += uSunColor * (sunCorona + sunDisc * 3.4) * aboveHorizon * smoothstep(-0.08, 0.04, uSunDir.y);

    // Blue-white companion star
    float s2 = dot(dir, uSun2Dir);
    float disc2 = smoothstep(0.99955, 0.99978, s2);
    float glow2 = pow(max(s2, 0.0), 160.0) * 0.9 + pow(max(s2, 0.0), 14.0) * 0.07;
    sky += vec3(0.55, 0.85, 1.0) * (disc2 * 3.0 + glow2) * aboveHorizon * smoothstep(-0.1, 0.05, uSun2Dir.y);

    if (uNightFactor > 0.01 && dir.y > 0.0) {
      vec2 starUv = dir.xz / (dir.y + 0.35) * 150.0;
      vec2 starCell = floor(starUv);
      vec2 starF = fract(starUv) - 0.5;
      float rnd = hash21(starCell);
      if (rnd > 0.95) {
        float dist = length(starF);
        float twinkle = 0.7 + 0.3 * sin(uTime * 2.4 + rnd * 90.0);
        float star = smoothstep(0.24, 0.02, dist) * twinkle * smoothstep(0.95, 0.999, rnd);
        vec3 starTint = mix(vec3(0.7, 0.85, 1.0), vec3(1.0, 0.8, 0.95), fract(rnd * 17.3));
        sky += starTint * star * uNightFactor * smoothstep(0.03, 0.28, dir.y) * 1.4;
      }

      // Vivid magenta-cyan nebula river
      float band = exp(-pow((dir.x * 0.7 - dir.z * 0.5) * 2.6, 2.0));
      float neb = cloudFbm(dir.xz * 3.6 + 2.0);
      float neb2 = cloudFbm(dir.xz * 7.0 - 4.0);
      vec3 nebCol = mix(vec3(0.42, 0.08, 0.5), vec3(0.06, 0.32, 0.5), neb2);
      sky += nebCol * neb * band * uNightFactor * smoothstep(0.06, 0.4, dir.y) * 0.65;

      // Shimmering aurora curtains
      float az = atan(dir.x, dir.z);
      float curtain = sin(az * 5.0 + uTime * 0.12 + noise(vec2(az * 2.5, uTime * 0.04)) * 3.5) * 0.5 + 0.5;
      float aBand = smoothstep(0.1, 0.24, dir.y) * (1.0 - smoothstep(0.32, 0.68, dir.y));
      float rays = noise(vec2(az * 38.0, dir.y * 3.0 - uTime * 0.25));
      vec3 aurCol = mix(vec3(0.1, 1.0, 0.65), vec3(0.85, 0.25, 1.0), smoothstep(0.16, 0.5, dir.y));
      sky += aurCol * curtain * curtain * aBand * (0.35 + 0.65 * rays) * 0.42 * uNightFactor;
    }

    // Lilac & peach alien cloud decks
    if (dir.y > 0.025) {
      vec2 cloudPlane = dir.xz / (dir.y + 0.14);
      vec2 wind = vec2(uTime * 0.011, uTime * 0.005);
      float base = cloudFbm(cloudPlane * 0.95 + wind);
      float detail = cloudFbm(cloudPlane * 2.3 - wind * 0.6);
      float density = smoothstep(0.5, 0.79, base * 0.76 + detail * 0.24);
      float sunSample = cloudFbm(cloudPlane * 0.95 + wind + uSunDir.xz * 0.12);
      float litEdge = clamp(1.0 - (sunSample - base) * 2.8, 0.25, 1.15);
      vec3 cloudDark = mix(vec3(0.06, 0.05, 0.14), mix(vec3(0.5, 0.44, 0.66), vec3(0.42, 0.26, 0.42), uGoldenFactor), uDayFactor);
      vec3 cloudBright = mix(vec3(0.14, 0.12, 0.26), mix(vec3(0.98, 0.9, 0.98), uSunColor * 1.08, uGoldenFactor * 0.82), clamp(uDayFactor + uGoldenFactor * 0.5, 0.0, 1.0));
      float silver = pow(max(sunDot, 0.0), 8.0) * 0.35 * (1.0 - density * 0.5);
      vec3 cloudCol = mix(cloudDark, cloudBright, litEdge) + uSunColor * silver * uDayFactor;
      float cirrus = smoothstep(0.58, 0.86, cloudFbm(vec2(cloudPlane.x * 1.9, cloudPlane.y * 0.55) - wind * 0.35));
      vec3 cirrusCol = mix(cloudBright, uSunColor * 1.12, uGoldenFactor * 0.6);
      float horizonFade = smoothstep(0.025, 0.22, dir.y);
      sky = mix(sky, cirrusCol, cirrus * horizonFade * 0.24 * clamp(uDayFactor + uGoldenFactor, 0.15, 1.0));
      sky = mix(sky, cloudCol, density * horizonFade * 0.8);
    }

    if (dir.y < 0.0) {
      sky = mix(uHorizonColor, uHorizonColor * 0.65, clamp(-dir.y * 4.0, 0.0, 1.0));
    }

    gl_FragColor = vec4(sky, 1.0);
    #include <tonemapping_fragment>
    #include <colorspace_fragment>
  }
`;

const BODY_VERTEX = /* glsl */ `
  varying vec2 vUv;
  varying vec3 vNormalW;
  void main() {
    vUv = uv;
    vNormalW = normalize(mat3(modelMatrix) * normal);
    gl_Position = projectionMatrix * viewMatrix * modelMatrix * vec4(position, 1.0);
  }
`;

const BODY_FRAGMENT = /* glsl */ `
  uniform sampler2D uMap;
  uniform vec3 uSunDir;
  uniform vec3 uSunColor;
  uniform vec3 uHaze;
  uniform float uHazeAmt;
  uniform float uGlow;
  varying vec2 vUv;
  varying vec3 vNormalW;
  void main() {
    vec3 tex = texture2D(uMap, vUv).rgb;
    vec3 n = normalize(vNormalW);
    float lambert = max(dot(n, uSunDir), 0.0);
    float terminator = smoothstep(-0.08, 0.25, dot(n, uSunDir));
    vec3 col = tex * (uSunColor * (lambert * 1.25 + terminator * 0.08) + vec3(0.05, 0.04, 0.09) * uGlow);
    col = mix(col, uHaze, uHazeAmt);
    gl_FragColor = vec4(col, 1.0);
    #include <tonemapping_fragment>
    #include <colorspace_fragment>
  }
`;

function createGasGiantTexture(): THREE.CanvasTexture {
  const w = 512;
  const h = 256;
  const c = document.createElement('canvas');
  c.width = w;
  c.height = h;
  const ctx = c.getContext('2d')!;
  const img = ctx.createImageData(w, h);
  const d = img.data;
  const palette: Array<[number, number, number]> = [
    [232, 196, 168],
    [214, 150, 128],
    [246, 226, 202],
    [176, 120, 150],
    [228, 176, 140],
    [150, 112, 168],
    [240, 210, 180],
  ];
  for (let y = 0; y < h; y++) {
    const lat = y / h;
    for (let x = 0; x < w; x++) {
      const u = (x / w) * Math.PI * 2;
      const turb =
        Math.sin(u * 3 + lat * 40) * 0.012 + Math.sin(u * 7 - lat * 90) * 0.006 + Math.sin(u * 13 + lat * 160) * 0.003;
      const t = (lat + turb) * 14.0;
      // Positive modulo: lat + turb can dip below 0 near the pole, and JS `%` keeps the sign
      const n = palette.length;
      const i0 = ((Math.floor(t) % n) + n) % n;
      const i1 = (i0 + 1) % n;
      const f = t - Math.floor(t);
      const s = f * f * (3 - 2 * f);
      let r = palette[i0][0] + (palette[i1][0] - palette[i0][0]) * s;
      let g = palette[i0][1] + (palette[i1][1] - palette[i0][1]) * s;
      let b = palette[i0][2] + (palette[i1][2] - palette[i0][2]) * s;
      // Great storm eye
      const dx = (x / w - 0.62) * 3.2;
      const dy = (lat - 0.64) * 6.0;
      const storm = Math.exp(-(dx * dx + dy * dy) * 2.2);
      r = r * (1 - storm * 0.45) + 196 * storm * 0.45;
      g = g * (1 - storm * 0.45) + 92 * storm * 0.45;
      b = b * (1 - storm * 0.45) + 110 * storm * 0.45;
      const idx = (y * w + x) * 4;
      d[idx] = r;
      d[idx + 1] = g;
      d[idx + 2] = b;
      d[idx + 3] = 255;
    }
  }
  ctx.putImageData(img, 0, 0);
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.needsUpdate = true;
  return tex;
}

function createMoonTexture(tint: [number, number, number]): THREE.CanvasTexture {
  const s = 128;
  const c = document.createElement('canvas');
  c.width = s;
  c.height = s;
  const ctx = c.getContext('2d')!;
  ctx.fillStyle = `rgb(${tint[0]},${tint[1]},${tint[2]})`;
  ctx.fillRect(0, 0, s, s);
  let seed = 991;
  const rnd = () => {
    seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0;
    return seed / 4294967296;
  };
  for (let i = 0; i < 46; i++) {
    const x = rnd() * s;
    const y = rnd() * s;
    const r = 2 + rnd() * 10;
    ctx.fillStyle = `rgba(0,0,0,${0.12 + rnd() * 0.22})`;
    ctx.beginPath();
    ctx.arc(x, y, r, 0, Math.PI * 2);
    ctx.fill();
  }
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.needsUpdate = true;
  return tex;
}

function createRingTexture(): THREE.CanvasTexture {
  const w = 512;
  const c = document.createElement('canvas');
  c.width = w;
  c.height = 4;
  const ctx = c.getContext('2d')!;
  for (let x = 0; x < w; x++) {
    const t = x / w;
    const band = 0.55 + 0.45 * Math.sin(t * 60.0) * Math.sin(t * 23.0 + 1.3);
    const gap = t > 0.62 && t < 0.67 ? 0.05 : 1.0;
    const edge = Math.min(1, t * 8) * Math.min(1, (1 - t) * 5);
    const a = Math.max(0, band * gap * edge) * 0.78;
    const r = 236 - t * 40;
    const g = 214 - t * 60;
    const b = 222 - t * 20;
    ctx.fillStyle = `rgba(${r | 0},${g | 0},${b | 0},${a.toFixed(3)})`;
    ctx.fillRect(x, 0, 1, 4);
  }
  const tex = new THREE.CanvasTexture(c);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.needsUpdate = true;
  return tex;
}

export class SkySystem {
  public readonly skyMesh: THREE.Mesh;
  public readonly sunLight: THREE.DirectionalLight;
  public readonly fillLight: THREE.DirectionalLight;
  public readonly hemiLight: THREE.HemisphereLight;
  public readonly fog: THREE.FogExp2;
  public readonly state: AtmosphereState;

  private readonly uniforms: {
    uSunDir: { value: THREE.Vector3 };
    uSun2Dir: { value: THREE.Vector3 };
    uZenithColor: { value: THREE.Color };
    uHorizonColor: { value: THREE.Color };
    uSunColor: { value: THREE.Color };
    uTime: { value: number };
    uDayFactor: { value: number };
    uGoldenFactor: { value: number };
    uNightFactor: { value: number };
  };

  private readonly scene: THREE.Scene;
  private envRenderTarget: THREE.WebGLRenderTarget | null = null;
  private readonly shadowTarget: THREE.Object3D;

  // Celestial bodies of the Solvara system
  private readonly celestial = new THREE.Group();
  private readonly bodyMats: THREE.ShaderMaterial[] = [];
  private readonly ringMat: THREE.MeshBasicMaterial;
  private readonly planetDir = new THREE.Vector3(0.55, 0.36, -0.75).normalize();
  private readonly sun2Dir = new THREE.Vector3();
  private readonly hazeColor = new THREE.Color();

  private readonly cDayZenith = new THREE.Color(0x3d47b0);
  private readonly cGoldenZenith = new THREE.Color(0x4a2a7d);
  private readonly cNightZenith = new THREE.Color(0x07051a);
  private readonly cDayHorizon = new THREE.Color(0xeab8d2);
  private readonly cGoldenHorizon = new THREE.Color(0xff7f5e);
  private readonly cNightHorizon = new THREE.Color(0x1c1444);
  private readonly cDaySun = new THREE.Color(0xfff0dc);
  private readonly cGoldenSun = new THREE.Color(0xff8a5c);
  private readonly cNightMoon = new THREE.Color(0x8f9cff);
  private readonly cGroundDay = new THREE.Color(0x40334f);
  private readonly cGroundNight = new THREE.Color(0x0b0a16);
  private readonly cBiomeFog = new THREE.Color();

  constructor(scene: THREE.Scene, renderer: THREE.WebGLRenderer, isMobile: boolean) {
    this.scene = scene;
    this.state = {
      sunDirection: new THREE.Vector3(0.4, 0.65, -0.65).normalize(),
      sunColor: new THREE.Color(0xfff0dc),
      horizonColor: new THREE.Color(0xeab8d2),
      zenithColor: new THREE.Color(0x3d47b0),
      dayFactor: 1,
      goldenFactor: 0,
      nightFactor: 0,
    };

    this.uniforms = {
      uSunDir: { value: this.state.sunDirection },
      uSun2Dir: { value: this.sun2Dir },
      uZenithColor: { value: this.state.zenithColor },
      uHorizonColor: { value: this.state.horizonColor },
      uSunColor: { value: this.state.sunColor },
      uTime: { value: 0 },
      uDayFactor: { value: 1 },
      uGoldenFactor: { value: 0 },
      uNightFactor: { value: 0 },
    };

    const skyGeo = new THREE.SphereGeometry(1650, 40, 28);
    const skyMat = new THREE.ShaderMaterial({
      vertexShader: SKY_VERTEX,
      fragmentShader: SKY_FRAGMENT,
      uniforms: this.uniforms,
      side: THREE.BackSide,
      depthWrite: false,
      fog: false,
    });
    this.skyMesh = new THREE.Mesh(skyGeo, skyMat);
    this.skyMesh.frustumCulled = false;
    this.skyMesh.renderOrder = -10;
    scene.add(this.skyMesh);

    // Giant ringed gas world, rendered with its own true-sun terminator
    const makeBody = (radius: number, tex: THREE.Texture, dir: THREE.Vector3, dist: number, segs: number) => {
      const mat = new THREE.ShaderMaterial({
        vertexShader: BODY_VERTEX,
        fragmentShader: BODY_FRAGMENT,
        uniforms: {
          uMap: { value: tex },
          uSunDir: { value: this.state.sunDirection },
          uSunColor: { value: new THREE.Color(1, 1, 1) },
          uHaze: { value: new THREE.Color() },
          uHazeAmt: { value: 0.3 },
          uGlow: { value: 1.0 },
        },
        fog: false,
      });
      const mesh = new THREE.Mesh(new THREE.SphereGeometry(radius, segs, Math.round(segs * 0.6)), mat);
      mesh.position.copy(dir).multiplyScalar(dist);
      mesh.frustumCulled = false;
      this.bodyMats.push(mat);
      this.celestial.add(mesh);
      return mesh;
    };

    const planetPivot = new THREE.Group();
    planetPivot.position.copy(this.planetDir).multiplyScalar(1420);
    planetPivot.rotation.set(0.38, 0.2, 0.46);
    this.celestial.add(planetPivot);

    const planetMat = new THREE.ShaderMaterial({
      vertexShader: BODY_VERTEX,
      fragmentShader: BODY_FRAGMENT,
      uniforms: {
        uMap: { value: createGasGiantTexture() },
        uSunDir: { value: this.state.sunDirection },
        uSunColor: { value: new THREE.Color(1, 1, 1) },
        uHaze: { value: new THREE.Color() },
        uHazeAmt: { value: 0.3 },
        uGlow: { value: 1.0 },
      },
      fog: false,
    });
    this.bodyMats.push(planetMat);
    const planet = new THREE.Mesh(new THREE.SphereGeometry(215, 64, 40), planetMat);
    planet.frustumCulled = false;
    planetPivot.add(planet);

    const ringGeo = new THREE.RingGeometry(290, 520, 160, 1);
    const ringUv = ringGeo.attributes.uv as THREE.BufferAttribute;
    const ringPos = ringGeo.attributes.position as THREE.BufferAttribute;
    for (let i = 0; i < ringPos.count; i++) {
      const r = Math.hypot(ringPos.getX(i), ringPos.getY(i));
      ringUv.setXY(i, (r - 290) / (520 - 290), 0.5);
    }
    ringGeo.rotateX(-Math.PI / 2);
    this.ringMat = new THREE.MeshBasicMaterial({
      map: createRingTexture(),
      transparent: true,
      side: THREE.DoubleSide,
      depthWrite: false,
      fog: false,
    });
    const ring = new THREE.Mesh(ringGeo, this.ringMat);
    ring.frustumCulled = false;
    planetPivot.add(ring);

    makeBody(30, createMoonTexture([196, 186, 222]), new THREE.Vector3(0.18, 0.56, -0.81).normalize(), 1320, 32);
    makeBody(19, createMoonTexture([214, 150, 120]), new THREE.Vector3(-0.72, 0.31, -0.33).normalize(), 1260, 24);
    scene.add(this.celestial);

    // Alien-tinted PBR image-based lighting
    try {
      const pmrem = new THREE.PMREMGenerator(renderer);
      const envScene = new THREE.Scene();
      const envGeo = new THREE.SphereGeometry(20, 24, 16);
      const envPos = envGeo.attributes.position as THREE.BufferAttribute;
      const envColors = new Float32Array(envPos.count * 3);
      const cZen = new THREE.Color(0x4a50b8);
      const cHor = new THREE.Color(0xf0c4d8);
      const cGnd = new THREE.Color(0x3b2e4d);
      const cSun = new THREE.Color(0xfff0dc);
      const tmp = new THREE.Color();
      for (let i = 0; i < envPos.count; i++) {
        const vx = envPos.getX(i) / 20;
        const vy = envPos.getY(i) / 20;
        const vz = envPos.getZ(i) / 20;
        if (vy >= 0) {
          tmp.copy(cHor).lerp(cZen, Math.pow(vy, 0.55));
          const sunGlow = Math.pow(Math.max(0, vx * 0.5 + vy * 0.7 - vz * 0.5), 6) * 1.4;
          tmp.lerp(cSun, Math.min(1, sunGlow));
        } else {
          tmp.copy(cHor).lerp(cGnd, Math.min(1, -vy * 2.5));
        }
        envColors[i * 3] = tmp.r;
        envColors[i * 3 + 1] = tmp.g;
        envColors[i * 3 + 2] = tmp.b;
      }
      envGeo.setAttribute('color', new THREE.BufferAttribute(envColors, 3));
      envScene.add(
        new THREE.Mesh(envGeo, new THREE.MeshBasicMaterial({ vertexColors: true, side: THREE.BackSide }))
      );
      this.envRenderTarget = pmrem.fromScene(envScene, 0.04);
      this.scene.environment = this.envRenderTarget.texture;
      this.scene.environmentIntensity = 0.65;
      envGeo.dispose();
      pmrem.dispose();
    } catch {
      // Hemisphere + fill lights cover unsupported devices
    }

    this.sunLight = new THREE.DirectionalLight(0xfff0dc, 2.85);
    this.sunLight.castShadow = true;
    const maxTex = renderer.capabilities.maxTextureSize || 2048;
    const shadowRes = isMobile ? 1024 : Math.min(maxTex, 3072);
    this.sunLight.shadow.mapSize.set(shadowRes, shadowRes);
    const d = isMobile ? 54 : 68;
    this.sunLight.shadow.camera.left = -d;
    this.sunLight.shadow.camera.right = d;
    this.sunLight.shadow.camera.top = d;
    this.sunLight.shadow.camera.bottom = -d;
    this.sunLight.shadow.camera.near = 4;
    this.sunLight.shadow.camera.far = 250;
    this.sunLight.shadow.bias = -0.00038;
    this.sunLight.shadow.normalBias = 0.028;
    this.sunLight.shadow.radius = 2.0;

    this.shadowTarget = new THREE.Object3D();
    scene.add(this.shadowTarget);
    this.sunLight.target = this.shadowTarget;
    scene.add(this.sunLight);

    this.fillLight = new THREE.DirectionalLight(0xb8a8f0, 0.5);
    this.fillLight.castShadow = false;
    scene.add(this.fillLight);

    this.hemiLight = new THREE.HemisphereLight(0xc0b0f0, 0x40334f, 0.88);
    scene.add(this.hemiLight);

    this.fog = new THREE.FogExp2(0xeab8d2, 0.00115);
    scene.fog = this.fog;
  }

  /**
   * @param timeOfDay [0, 1): 0.25 sunrise, 0.5 noon, 0.75 sunset, 0 midnight
   */
  public update(
    timeOfDay: number,
    elapsed: number,
    focusPos: THREE.Vector3,
    biomeFogTint: [number, number, number]
  ): void {
    this.uniforms.uTime.value = elapsed;
    this.skyMesh.position.copy(focusPos);
    this.celestial.position.copy(focusPos);

    const angle = (timeOfDay - 0.25) * Math.PI * 2.0;
    const sunElev = Math.sin(angle) * 0.86;
    const horiz = Math.sqrt(Math.max(0.001, 1.0 - sunElev * sunElev));
    const sunAzim = Math.cos(angle);

    this.state.sunDirection.set(sunAzim * horiz * 0.88, sunElev, -0.46 * horiz + sunAzim * 0.16).normalize();

    // Companion star trails the primary along the ecliptic
    const ca = Math.cos(0.5);
    const sa = Math.sin(0.5);
    const sd = this.state.sunDirection;
    this.sun2Dir.set(sd.x * ca - sd.z * sa, sd.y - 0.07, sd.x * sa + sd.z * ca).normalize();

    const dayFactor = smoothstep(-0.08, 0.24, sunElev);
    const goldenFactor = smoothstep(-0.1, 0.05, sunElev) * (1.0 - smoothstep(0.08, 0.34, sunElev));
    const nightFactor = smoothstep(0.04, -0.18, sunElev);

    this.state.dayFactor = dayFactor;
    this.state.goldenFactor = goldenFactor;
    this.state.nightFactor = nightFactor;
    this.uniforms.uDayFactor.value = dayFactor;
    this.uniforms.uGoldenFactor.value = goldenFactor;
    this.uniforms.uNightFactor.value = nightFactor;

    this.state.zenithColor
      .copy(this.cNightZenith)
      .lerp(this.cDayZenith, dayFactor)
      .lerp(this.cGoldenZenith, goldenFactor * 0.72);

    this.cBiomeFog.setRGB(biomeFogTint[0], biomeFogTint[1], biomeFogTint[2], THREE.SRGBColorSpace);
    this.state.horizonColor
      .copy(this.cNightHorizon)
      .lerp(this.cDayHorizon, dayFactor)
      .lerp(this.cBiomeFog, dayFactor * 0.35)
      .lerp(this.cGoldenHorizon, goldenFactor * 0.82);

    this.state.sunColor
      .copy(this.cNightMoon)
      .lerp(this.cDaySun, dayFactor)
      .lerp(this.cGoldenSun, goldenFactor * 0.88);

    // At night the giant ringed world bathes the land in violet planetshine
    const lightDir =
      sunElev >= -0.04
        ? this.state.sunDirection
        : this.fillLight.position.copy(this.planetDir).normalize();

    const snap = 1.5;
    const sx = Math.round(focusPos.x / snap) * snap;
    const sz = Math.round(focusPos.z / snap) * snap;
    this.shadowTarget.position.set(sx, focusPos.y, sz);
    this.sunLight.position.set(
      sx + lightDir.x * 105,
      focusPos.y + Math.max(22, lightDir.y * 105),
      sz + lightDir.z * 105
    );
    this.sunLight.color.copy(this.state.sunColor);
    this.sunLight.intensity = lerp(0.62, 2.75, dayFactor) + goldenFactor * 0.35;

    this.fillLight.position.set(focusPos.x - lightDir.x * 50, focusPos.y + 35, focusPos.z - lightDir.z * 50);
    this.fillLight.color.copy(this.state.horizonColor);
    this.fillLight.intensity = lerp(0.2, 0.55, dayFactor);

    this.hemiLight.color.copy(this.state.horizonColor);
    this.hemiLight.groundColor.copy(this.cGroundNight).lerp(this.cGroundDay, dayFactor);
    this.hemiLight.intensity = lerp(0.32, 0.85, dayFactor);
    this.scene.environmentIntensity = lerp(0.16, 0.62, dayFactor);

    // Celestial bodies: sunlit terminators, daylight sky veil, soft night glow
    this.hazeColor.copy(this.state.horizonColor).lerp(this.state.zenithColor, 0.55);
    const veil = clamp(dayFactor * 0.42 - goldenFactor * 0.12, 0, 0.5);
    for (const m of this.bodyMats) {
      (m.uniforms.uSunColor.value as THREE.Color).copy(this.cDaySun).lerp(this.cGoldenSun, goldenFactor * 0.6);
      (m.uniforms.uHaze.value as THREE.Color).copy(this.hazeColor);
      m.uniforms.uHazeAmt.value = veil;
      m.uniforms.uGlow.value = 0.8 + nightFactor * 1.6;
    }
    const ringLight = 0.35 + dayFactor * 0.6 + nightFactor * 0.25;
    this.ringMat.color.setRGB(ringLight, ringLight, ringLight);
    this.ringMat.opacity = 1.0 - veil * 0.6;

    this.fog.color.copy(this.state.horizonColor);
    this.fog.density = lerp(0.00125, 0.00095, clamp(dayFactor - goldenFactor * 0.35, 0, 1));
  }

  public dispose(): void {
    this.envRenderTarget?.dispose();
    this.skyMesh.geometry.dispose();
    (this.skyMesh.material as THREE.Material).dispose();
  }
}
