import * as THREE from 'three';

function makeRng(seed: number): () => number {
  let s = seed >>> 0;
  return () => {
    s = (Math.imul(s, 1664525) + 1013904223) >>> 0;
    return s / 4294967296;
  };
}

/**
 * Fill RGB of transparent pixels with matte color (keeping alpha = 0)
 * so mipmaps & bilinear filtering NEVER produce dark/white fringe halos on leaf edges!
 */
function applyCleanAlphaMatte(
  ctx: CanvasRenderingContext2D,
  w: number,
  h: number,
  r: number,
  g: number,
  b: number
): void {
  const img = ctx.getImageData(0, 0, w, h);
  const d = img.data;
  for (let i = 0; i < d.length; i += 4) {
    const a = d[i + 3];
    if (a === 0) {
      d[i] = r;
      d[i + 1] = g;
      d[i + 2] = b;
    } else if (a < 255) {
      // Un-premultiply edge blend cleanly toward matte color
      const t = a / 255;
      d[i] = Math.min(255, Math.round(d[i] * t + r * (1 - t)));
      d[i + 1] = Math.min(255, Math.round(d[i + 1] * t + g * (1 - t)));
      d[i + 2] = Math.min(255, Math.round(d[i + 2] * t + b * (1 - t)));
    }
  }
  ctx.putImageData(img, 0, 0);
}

function finalizeBotanicalTex(
  canvas: HTMLCanvasElement,
  anisotropy: number,
  srgb = true
): THREE.CanvasTexture {
  const tex = new THREE.CanvasTexture(canvas);
  tex.anisotropy = anisotropy;
  tex.generateMipmaps = true;
  tex.minFilter = THREE.LinearMipmapLinearFilter;
  tex.magFilter = THREE.LinearFilter;
  tex.wrapS = THREE.ClampToEdgeWrapping;
  tex.wrapT = THREE.ClampToEdgeWrapping;
  if (srgb) tex.colorSpace = THREE.SRGBColorSpace;
  tex.needsUpdate = true;
  return tex;
}

/** Paint a single realistic veined ovate/serrated leaf */
function drawDetailedLeaf(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  len: number,
  wid: number,
  angle: number,
  baseCol: string,
  tipCol: string,
  veinCol: string,
  lobed = false
): void {
  ctx.save();
  ctx.translate(x, y);
  ctx.rotate(angle);

  const grad = ctx.createLinearGradient(0, 0, len, 0);
  grad.addColorStop(0, baseCol);
  grad.addColorStop(1, tipCol);
  ctx.fillStyle = grad;

  ctx.beginPath();
  ctx.moveTo(0, 0);
  if (lobed) {
    // Oak-style gently lobed leaf silhouette
    ctx.bezierCurveTo(len * 0.18, -wid * 0.65, len * 0.32, -wid * 0.35, len * 0.42, -wid * 0.92);
    ctx.bezierCurveTo(len * 0.56, -wid * 1.05, len * 0.65, -wid * 0.52, len * 0.78, -wid * 0.72);
    ctx.quadraticCurveTo(len * 0.94, -wid * 0.42, len, 0);
    ctx.quadraticCurveTo(len * 0.94, wid * 0.42, len * 0.78, wid * 0.72);
    ctx.bezierCurveTo(len * 0.65, wid * 0.52, len * 0.56, wid * 1.05, len * 0.42, wid * 0.92);
    ctx.bezierCurveTo(len * 0.32, wid * 0.35, len * 0.18, wid * 0.65, 0, 0);
  } else {
    // Crisp pointed ovate birch/beech/shrub leaf
    ctx.bezierCurveTo(len * 0.24, -wid, len * 0.72, -wid * 0.85, len, 0);
    ctx.bezierCurveTo(len * 0.72, wid * 0.85, len * 0.24, wid, 0, 0);
  }
  ctx.closePath();
  ctx.fill();

  // Subtle central midrib vein for close-up botanical realism
  ctx.strokeStyle = veinCol;
  ctx.lineWidth = Math.max(0.8, wid * 0.08);
  ctx.beginPath();
  ctx.moveTo(len * 0.05, 0);
  ctx.lineTo(len * 0.86, 0);
  ctx.stroke();

  ctx.restore();
}

/** 1. Rich Broadleaf Oak / Woodland Canopy Spray (512x512) */
function createBroadleafTexture(anisotropy: number): THREE.CanvasTexture {
  const s = 512;
  const c = document.createElement('canvas');
  c.width = s;
  c.height = s;
  const ctx = c.getContext('2d')!;
  const rnd = makeRng(1041);

  // Subtle woody interior twigs
  ctx.strokeStyle = '#3e2d1e';
  ctx.lineCap = 'round';
  for (let b = 0; b < 7; b++) {
    const a = -Math.PI * 0.5 + (b - 3) * 0.36;
    ctx.lineWidth = 4.5;
    ctx.beginPath();
    ctx.moveTo(s * 0.5, s * 0.78);
    ctx.quadraticCurveTo(
      s * 0.5 + Math.cos(a) * 90,
      s * 0.55 + Math.sin(a) * 60,
      s * 0.5 + Math.cos(a) * 195,
      s * 0.5 + Math.sin(a) * 185
    );
    ctx.stroke();
  }

  // 155 layered lobed oak leaves from deep shadowed interior to bright sunlit tips
  const count = 155;
  for (let i = 0; i < count; i++) {
    const layer = i / count; // 0 = dark interior AO, 1 = sunlit outer canopy
    const r = (0.12 + Math.pow(rnd(), 0.68) * 0.78) * (s * 0.44);
    const theta = rnd() * Math.PI * 2;
    const lx = s * 0.5 + Math.cos(theta) * r;
    const ly = s * 0.5 + Math.sin(theta) * r * 0.94;

    const len = 44 + rnd() * 36;
    const wid = len * (0.34 + rnd() * 0.14);
    const ang = theta + (rnd() - 0.5) * 1.15;

    const gBase = Math.round(58 + layer * 54 + rnd() * 14);
    const rBase = Math.round(gBase * (0.56 + rnd() * 0.1));
    const bBase = Math.round(gBase * 0.36);

    const gTip = Math.min(225, Math.round(gBase * 1.32 + 16));
    const rTip = Math.min(210, Math.round(gTip * (0.68 + layer * 0.08)));
    const bTip = Math.round(gTip * 0.38);

    drawDetailedLeaf(
      ctx,
      lx,
      ly,
      len,
      wid,
      ang,
      `rgb(${rBase},${gBase},${bBase})`,
      `rgb(${rTip},${gTip},${bTip})`,
      `rgba(${Math.min(255, rTip + 22)},${Math.min(255, gTip + 24)},${bTip + 12},0.45)`,
      true
    );
  }

  applyCleanAlphaMatte(ctx, s, s, 68, 106, 42);
  return finalizeBotanicalTex(c, anisotropy);
}

/** 2. Neutral-Luminous Birch / Autumn Maple / Willow Leaf Spray (tinted per instance!) */
function createDeciduousTintTexture(anisotropy: number): THREE.CanvasTexture {
  const s = 512;
  const c = document.createElement('canvas');
  c.width = s;
  c.height = s;
  const ctx = c.getContext('2d')!;
  const rnd = makeRng(2089);

  // Delicate slender twigs
  ctx.strokeStyle = '#5c4b3c';
  ctx.lineCap = 'round';
  for (let b = 0; b < 8; b++) {
    const a = (b / 8) * Math.PI * 2;
    ctx.lineWidth = 3.2;
    ctx.beginPath();
    ctx.moveTo(s * 0.5, s * 0.54);
    ctx.lineTo(s * 0.5 + Math.cos(a) * 185, s * 0.5 + Math.sin(a) * 180);
    ctx.stroke();
  }

  // 165 crisp pointed leaves with natural value depth (multiplied by gold/crimson/amber/willow-green)
  const count = 165;
  for (let i = 0; i < count; i++) {
    const layer = i / count;
    const r = Math.pow(rnd(), 0.65) * (s * 0.43);
    const theta = rnd() * Math.PI * 2;
    const lx = s * 0.5 + Math.cos(theta) * r;
    const ly = s * 0.5 + Math.sin(theta) * r;

    const len = 38 + rnd() * 32;
    const wid = len * (0.36 + rnd() * 0.14);
    const ang = theta + (rnd() - 0.5) * 1.25;

    const v0 = Math.round(118 + layer * 88 + (rnd() - 0.5) * 18);
    const v1 = Math.min(252, Math.round(v0 * 1.2 + 18));
    drawDetailedLeaf(
      ctx,
      lx,
      ly,
      len,
      wid,
      ang,
      `rgb(${v0},${Math.round(v0 * 0.97)},${Math.round(v0 * 0.88)})`,
      `rgb(${v1},${Math.round(v1 * 0.99)},${Math.round(v1 * 0.92)})`,
      `rgba(255,252,240,0.45)`,
      false
    );
  }

  applyCleanAlphaMatte(ctx, s, s, 185, 178, 162);
  return finalizeBotanicalTex(c, anisotropy);
}

/** 3. Realistic Conifer Pine / Spruce Bough Fan (with optional snow mantle!) */
function createPineBoughTexture(anisotropy: number, snowy: boolean): THREE.CanvasTexture {
  const s = 512;
  const c = document.createElement('canvas');
  c.width = s;
  c.height = s;
  const ctx = c.getContext('2d')!;
  const rnd = makeRng(snowy ? 3319 : 3107);

  // Branch radiates from bottom-center (u=0.5, v=0.06 -> y=480) outward to tip (y=28)
  const drawNeedleShoot = (x0: number, y0: number, x1: number, y1: number, width: number) => {
    const dx = x1 - x0;
    const dy = y1 - y0;
    const len = Math.hypot(dx, dy);
    const ang = Math.atan2(dy, dx);
    const steps = Math.floor(len / 3.4);

    // Dense overlapping conifer needles along both sides of shoot
    for (let i = 0; i <= steps; i++) {
      const t = i / Math.max(1, steps);
      const px = x0 + dx * t;
      const py = y0 + dy * t;
      const taper = 1.0 - Math.pow(t, 1.8) * 0.62;
      const nLen = width * taper * (0.78 + rnd() * 0.42);

      for (const side of [-1, 1]) {
        const nAng = ang + side * (0.58 + rnd() * 0.34);
        const shade = 0.68 + t * 0.35 + rnd() * 0.25;
        const r = Math.round((snowy ? 22 : 28) * shade);
        const g = Math.round((snowy ? 66 : 74) * shade);
        const b = Math.round((snowy ? 52 : 34) * shade);
        ctx.strokeStyle = `rgb(${r},${g},${b})`;
        ctx.lineWidth = 2.6 + rnd() * 1.2;
        ctx.lineCap = 'round';
        ctx.beginPath();
        ctx.moveTo(px, py);
        ctx.lineTo(px + Math.cos(nAng) * nLen, py + Math.sin(nAng) * nLen);
        ctx.stroke();
      }
    }

    // Warm reddish-brown woody twig spine
    ctx.strokeStyle = '#4e3522';
    ctx.lineWidth = Math.max(1.8, width * 0.11);
    ctx.beginPath();
    ctx.moveTo(x0, y0);
    ctx.lineTo(x0 + dx * 0.86, y0 + dy * 0.86);
    ctx.stroke();

    // Soft alpine snow cushions resting atop spruce shoots!
    if (snowy) {
      const puffs = Math.max(3, Math.floor(len / 26));
      for (let p = 1; p < puffs; p++) {
        const t = p / puffs;
        if (rnd() < 0.22) continue;
        const sx = x0 + dx * t + (rnd() - 0.5) * 10;
        const sy = y0 + dy * t + (rnd() - 0.5) * 10;
        const rad = width * (1 - t * 0.45) * (0.38 + rnd() * 0.28);
        const grad = ctx.createRadialGradient(sx - rad * 0.2, sy - rad * 0.2, 2, sx, sy, rad);
        grad.addColorStop(0, 'rgba(248,252,255,0.96)');
        grad.addColorStop(0.65, 'rgba(218,232,246,0.90)');
        grad.addColorStop(1, 'rgba(185,208,228,0)');
        ctx.fillStyle = grad;
        ctx.beginPath();
        ctx.arc(sx, sy, rad, 0, Math.PI * 2);
        ctx.fill();
      }
    }
  };

  // Main central leader shoot
  drawNeedleShoot(s * 0.5, s * 0.95, s * 0.5, s * 0.06, 42);

  // 7 pairs of lush fanning lateral shoots + sub-twiglets
  const pairs = [
    { t: 0.14, spread: 205, rise: 115, w: 38 },
    { t: 0.27, spread: 215, rise: 130, w: 38 },
    { t: 0.40, spread: 195, rise: 125, w: 35 },
    { t: 0.53, spread: 168, rise: 112, w: 33 },
    { t: 0.65, spread: 135, rise: 95, w: 30 },
    { t: 0.77, spread: 96, rise: 72, w: 26 },
    { t: 0.87, spread: 58, rise: 48, w: 22 },
  ];

  for (const p of pairs) {
    const sy = s * (0.94 - p.t * 0.82);
    for (const side of [-1, 1]) {
      const ex = s * 0.5 + side * p.spread;
      const ey = sy - p.rise;
      drawNeedleShoot(s * 0.5, sy, ex, ey, p.w);
      // Secondary fork shoot for lush full bough density
      const mx = s * 0.5 + side * p.spread * 0.48;
      const my = sy - p.rise * 0.48;
      drawNeedleShoot(mx, my, mx + side * p.spread * 0.34, my - p.rise * 0.68, p.w * 0.76);
      drawNeedleShoot(mx, my, mx + side * p.spread * 0.44, my + p.rise * 0.15, p.w * 0.72);
    }
  }

  if (snowy) {
    applyCleanAlphaMatte(ctx, s, s, 96, 128, 122);
  } else {
    applyCleanAlphaMatte(ctx, s, s, 32, 68, 34);
  }
  return finalizeBotanicalTex(c, anisotropy);
}

/** 4. Feathered Pinnate Palm & Woodland Sword Fern Frond (512x512) */
function createFrondTexture(anisotropy: number): THREE.CanvasTexture {
  const s = 512;
  const c = document.createElement('canvas');
  c.width = s;
  c.height = s;
  const ctx = c.getContext('2d')!;
  const rnd = makeRng(4211);

  // Frond grows along +Y of UV (canvas bottom y=500 -> top y=14)
  const pairs = 34;
  for (let i = 0; i < pairs; i++) {
    const t = i / (pairs - 1); // 0 = base, 1 = tip
    const py = s * (0.94 - t * 0.89);
    const env = Math.sin(Math.pow(t, 0.65) * Math.PI * 0.96);
    const leafLen = (32 + env * 192) * (0.94 + rnd() * 0.1);
    const leafWid = 8.5 + env * 7.5;

    for (const side of [-1, 1]) {
      const baseV = Math.round(78 + t * 52 + rnd() * 14);
      const grad = ctx.createLinearGradient(s * 0.5, py, s * 0.5 + side * leafLen, py - 35);
      grad.addColorStop(0, `rgb(${Math.round(baseV * 0.62)},${baseV},${Math.round(baseV * 0.34)})`);
      grad.addColorStop(
        1,
        `rgb(${Math.round(baseV * 0.96)},${Math.min(220, Math.round(baseV * 1.38))},${Math.round(baseV * 0.44)})`
      );
      ctx.fillStyle = grad;

      const tipX = s * 0.5 + side * leafLen;
      const tipY = py - leafLen * (0.28 + t * 0.26);
      const ctrlX = s * 0.5 + side * leafLen * 0.54;
      const ctrlY = py - leafLen * (0.34 + t * 0.22);

      ctx.beginPath();
      ctx.moveTo(s * 0.5, py + leafWid * 0.38);
      ctx.quadraticCurveTo(ctrlX, ctrlY - leafWid * 0.65, tipX, tipY);
      ctx.quadraticCurveTo(ctrlX, ctrlY + leafWid * 0.55, s * 0.5, py - leafWid * 0.38);
      ctx.closePath();
      ctx.fill();
    }
  }

  // Central tapered green-gold stem (rachis)
  const stemGrad = ctx.createLinearGradient(0, s, 0, 0);
  stemGrad.addColorStop(0, '#4f5e28');
  stemGrad.addColorStop(1, '#8cb044');
  ctx.fillStyle = stemGrad;
  ctx.beginPath();
  ctx.moveTo(s * 0.5 - 6.5, s * 0.99);
  ctx.lineTo(s * 0.5 + 6.5, s * 0.99);
  ctx.lineTo(s * 0.5 + 1.2, s * 0.03);
  ctx.lineTo(s * 0.5 - 1.2, s * 0.03);
  ctx.closePath();
  ctx.fill();

  applyCleanAlphaMatte(ctx, s, s, 72, 114, 42);
  return finalizeBotanicalTex(c, anisotropy);
}

/** 5. Dense Leafy Bush & Flowering Shrub Spray (512x512, neutral-luminous for biome tinting!) */
function createBushTexture(anisotropy: number, withBlossoms: boolean): THREE.CanvasTexture {
  const s = 512;
  const c = document.createElement('canvas');
  c.width = s;
  c.height = s;
  const ctx = c.getContext('2d')!;
  const rnd = makeRng(withBlossoms ? 5519 : 5101);

  // Branching woody shrub stems grounded cleanly at bottom (y = s)
  ctx.strokeStyle = '#4a3828';
  ctx.lineCap = 'round';
  for (let b = 0; b < 9; b++) {
    const spread = (b - 4) * 48;
    ctx.lineWidth = 5.5 - Math.abs(b - 4) * 0.5;
    ctx.beginPath();
    ctx.moveTo(s * 0.5 + spread * 0.22, s * 0.98);
    ctx.quadraticCurveTo(
      s * 0.5 + spread * 0.65,
      s * 0.62,
      s * 0.5 + spread * 1.05,
      s * (0.22 + rnd() * 0.24)
    );
    ctx.stroke();
  }

  // 240 dense layered shrub leaves — darker near ground base (natural ground AO!), bright on crown
  const count = 240;
  for (let i = 0; i < count; i++) {
    const layer = i / count;
    // Rounded natural mound silhouette anchored firmly to bottom
    const a = -Math.PI + rnd() * Math.PI; // upper dome
    const rad = Math.pow(rnd(), 0.58);
    const lx = s * 0.5 + Math.cos(a) * rad * 225;
    const ly = s * 0.84 + Math.sin(a) * rad * 365 + (rnd() - 0.5) * 48;
    if (ly < 24 || ly > s - 10) continue;

    const heightFactor = 1.0 - ly / s; // 0 = ground AO, 1 = sunlit top
    const len = 28 + rnd() * 26;
    const wid = len * (0.44 + rnd() * 0.16);
    const ang = -Math.PI * 0.5 + (lx - s * 0.5) * 0.004 + (rnd() - 0.5) * 1.5;

    const vBase = Math.round((85 + layer * 72 + heightFactor * 52) * (0.9 + rnd() * 0.16));
    const vTip = Math.min(250, Math.round(vBase * 1.24 + 16));
    drawDetailedLeaf(
      ctx,
      lx,
      ly,
      len,
      wid,
      ang,
      `rgb(${Math.round(vBase * 0.92)},${vBase},${Math.round(vBase * 0.84)})`,
      `rgb(${Math.round(vTip * 0.96)},${vTip},${Math.round(vTip * 0.88)})`,
      `rgba(255,255,245,0.38)`,
      false
    );
  }

  // Scatter delicate 5-petal woodland blossoms on flowering bushes
  if (withBlossoms) {
    for (let f = 0; f < 26; f++) {
      const a = -Math.PI * 0.92 + rnd() * Math.PI * 0.84;
      const rad = 0.35 + rnd() * 0.55;
      const fx = s * 0.5 + Math.cos(a) * rad * 205;
      const fy = s * 0.80 + Math.sin(a) * rad * 335;
      if (fy < 36 || fy > s * 0.82) continue;

      const pRad = 7.5 + rnd() * 5.5;
      const isPink = f % 3 === 0;
      ctx.fillStyle = isPink ? '#ffd6e6' : '#fffdf4';
      for (let p = 0; p < 5; p++) {
        const pa = (p / 5) * Math.PI * 2 + f;
        ctx.beginPath();
        ctx.arc(fx + Math.cos(pa) * pRad * 0.62, fy + Math.sin(pa) * pRad * 0.62, pRad * 0.52, 0, Math.PI * 2);
        ctx.fill();
      }
      ctx.fillStyle = '#f8be38';
      ctx.beginPath();
      ctx.arc(fx, fy, pRad * 0.34, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  applyCleanAlphaMatte(ctx, s, s, 145, 155, 132);
  return finalizeBotanicalTex(c, anisotropy);
}

/** 6. Lush 34-Blade Botanical Meadow Grass & Seed-Head Clump (512x512) */
function createGrassClumpTexture(anisotropy: number): THREE.CanvasTexture {
  const s = 512;
  const c = document.createElement('canvas');
  c.width = s;
  c.height = s;
  const ctx = c.getContext('2d')!;
  const rnd = makeRng(6247);

  const blades = 38;
  for (let i = 0; i < blades; i++) {
    const layer = i / blades;
    const baseX = s * (0.12 + rnd() * 0.76);
    const baseY = s;
    const height = s * (0.48 + rnd() * 0.47);
    const lean = (baseX - s * 0.5) * 0.42 + (rnd() - 0.5) * 115;
    const tipX = Math.max(12, Math.min(s - 12, baseX + lean));
    const tipY = s - height;
    const ctrlX = baseX + lean * 0.38;
    const ctrlY = s - height * 0.62;
    const halfW = 6.5 + rnd() * 5.5;

    // Grounded dark root AO -> rich mid blade -> luminous sunlit tip (tinted per instance!)
    const vMid = Math.round(145 + layer * 68 + rnd() * 20);
    const vTip = Math.min(255, vMid + 42);
    const grad = ctx.createLinearGradient(baseX, baseY, tipX, tipY);
    grad.addColorStop(0, 'rgb(68, 72, 58)');
    grad.addColorStop(0.32, `rgb(${Math.round(vMid * 0.94)}, ${vMid}, ${Math.round(vMid * 0.86)})`);
    grad.addColorStop(1, `rgb(${vTip}, ${vTip}, ${Math.round(vTip * 0.9)})`);

    ctx.fillStyle = grad;
    ctx.beginPath();
    ctx.moveTo(baseX - halfW, baseY);
    ctx.quadraticCurveTo(ctrlX - halfW * 0.48, ctrlY, tipX, tipY);
    ctx.quadraticCurveTo(ctrlX + halfW * 0.48, ctrlY, baseX + halfW, baseY);
    ctx.closePath();
    ctx.fill();

    // Occasional delicate golden grass seed plume on tall blades
    if (i > blades - 6 && height > s * 0.76) {
      ctx.fillStyle = 'rgba(246, 238, 202, 0.92)';
      for (let k = 0; k < 6; k++) {
        const st = 0.80 + k * 0.032;
        const sx = (1 - st) * (1 - st) * baseX + 2 * (1 - st) * st * ctrlX + st * st * tipX;
        const sy = (1 - st) * (1 - st) * baseY + 2 * (1 - st) * st * ctrlY + st * st * tipY;
        ctx.beginPath();
        ctx.ellipse(sx + (k % 2 === 0 ? 4 : -4), sy, 3.2, 6.8, (k % 2 === 0 ? 1 : -1) * 0.35, 0, Math.PI * 2);
        ctx.fill();
      }
    }
  }

  applyCleanAlphaMatte(ctx, s, s, 148, 156, 134);
  return finalizeBotanicalTex(c, anisotropy);
}

/** 7. Stemmed Botanical Wildflower Clump (green stems at root + bright white tintable petals!) */
function createWildflowerTexture(anisotropy: number): THREE.CanvasTexture {
  const s = 512;
  const c = document.createElement('canvas');
  c.width = s;
  c.height = s;
  const ctx = c.getContext('2d')!;
  const rnd = makeRng(7331);

  const flowers = [
    { bx: 0.24, tx: 0.20, ty: 0.28, r: 36 },
    { bx: 0.42, tx: 0.38, ty: 0.16, r: 42 },
    { bx: 0.56, tx: 0.58, ty: 0.24, r: 40 },
    { bx: 0.72, tx: 0.78, ty: 0.32, r: 35 },
    { bx: 0.48, tx: 0.48, ty: 0.40, r: 33 },
  ];

  // Basal leafy green grass & foliage grounded firmly at y = s
  for (let l = 0; l < 14; l++) {
    const bx = s * (0.18 + rnd() * 0.64);
    const len = 110 + rnd() * 95;
    const ang = -Math.PI * 0.5 + (rnd() - 0.5) * 0.95;
    drawDetailedLeaf(
      ctx,
      bx,
      s,
      len,
      16 + rnd() * 8,
      ang,
      '#243d18',
      '#4f7a2d',
      'rgba(120,165,70,0.4)',
      false
    );
  }

  // Slender curving green flower stems rooted at y = s
  ctx.lineCap = 'round';
  for (const fl of flowers) {
    const x0 = fl.bx * s;
    const x1 = fl.tx * s;
    const y1 = fl.ty * s;
    const cx = (x0 + x1) * 0.5 + (rnd() - 0.5) * 24;
    const cy = (s + y1) * 0.5;

    const sg = ctx.createLinearGradient(x0, s, x1, y1);
    sg.addColorStop(0, '#233b18');
    sg.addColorStop(1, '#588632');
    ctx.strokeStyle = sg;
    ctx.lineWidth = 7.5;
    ctx.beginPath();
    ctx.moveTo(x0, s);
    ctx.quadraticCurveTo(cx, cy, x1, y1);
    ctx.stroke();

    // Small stem leaves
    drawDetailedLeaf(ctx, cx, cy + 25, 48, 14, -0.65, '#335822', '#5b8a34', 'rgba(130,175,80,0.35)');
    drawDetailedLeaf(ctx, cx, cy + 55, 44, 13, -2.45, '#335822', '#5b8a34', 'rgba(130,175,80,0.35)');
  }

  // Crisp multi-petal pure-white flower blossoms (shader tints white petals by instanceColor!)
  for (const fl of flowers) {
    const fx = fl.tx * s;
    const fy = fl.ty * s;
    const petals = 9;
    for (let p = 0; p < petals; p++) {
      const pa = (p / petals) * Math.PI * 2 + fx * 0.01;
      ctx.save();
      ctx.translate(fx, fy);
      ctx.rotate(pa);
      const pg = ctx.createLinearGradient(0, 0, fl.r, 0);
      pg.addColorStop(0, '#e6e6e6');
      pg.addColorStop(1, '#ffffff');
      ctx.fillStyle = pg;
      ctx.beginPath();
      ctx.ellipse(fl.r * 0.56, 0, fl.r * 0.48, fl.r * 0.22, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    }

    // Warm golden stamen center
    const cg = ctx.createRadialGradient(fx, fy, 1, fx, fy, fl.r * 0.28);
    cg.addColorStop(0, '#c87212');
    cg.addColorStop(0.7, '#f5b824');
    cg.addColorStop(1, '#ffe066');
    ctx.fillStyle = cg;
    ctx.beginPath();
    ctx.arc(fx, fy, fl.r * 0.26, 0, Math.PI * 2);
    ctx.fill();
  }

  applyCleanAlphaMatte(ctx, s, s, 96, 128, 72);
  return finalizeBotanicalTex(c, anisotropy);
}

/** 8. Deeply Fissured Old-Growth Bark Albedo + Bump Map (256x512) */
export function createDetailedBarkTextures(anisotropy: number): {
  map: THREE.CanvasTexture;
  bumpMap: THREE.CanvasTexture;
} {
  const w = 256;
  const h = 512;
  const albCanvas = document.createElement('canvas');
  albCanvas.width = w;
  albCanvas.height = h;
  const albCtx = albCanvas.getContext('2d')!;
  const albImg = albCtx.createImageData(w, h);

  const bmpCanvas = document.createElement('canvas');
  bmpCanvas.width = w;
  bmpCanvas.height = h;
  const bmpCtx = bmpCanvas.getContext('2d')!;
  const bmpImg = bmpCtx.createImageData(w, h);

  const ad = albImg.data;
  const bd = bmpImg.data;

  for (let y = 0; y < h; y++) {
    const v = (y / h) * Math.PI * 2;
    for (let x = 0; x < w; x++) {
      const u = (x / w) * Math.PI * 2;
      // Seamless periodic deep bark ridges & narrow dark fissures
      const warp = Math.sin(v * 3.0 + Math.cos(u * 4.0)) * 0.55;
      const ridge1 = Math.sin(u * 11.0 + warp) * 0.5 + 0.5;
      const ridge2 = Math.sin(u * 23.0 - Math.sin(v * 6.0) * 0.8) * 0.5 + 0.5;
      const plate = Math.sin(v * 8.0 + u * 3.0) * 0.5 + 0.5;
      const micro = Math.sin(u * 53.0 + v * 37.0) * 0.08;

      const heightVal = Math.max(
        0,
        Math.min(1, Math.pow(ridge1 * 0.65 + ridge2 * 0.35, 0.72) * (0.82 + plate * 0.18) + micro)
      );

      // Subtle natural olive lichen patch on bark plates
      const moss = Math.max(0, Math.sin(u * 3.0 + 1.2) * Math.cos(v * 2.0 - 0.5) - 0.62) * heightVal;

      const shade = 0.42 + heightVal * 0.58;
      const r = Math.min(255, Math.round((198 * shade) * (1 - moss) + 125 * moss));
      const g = Math.min(255, Math.round((176 * shade) * (1 - moss) + 158 * moss));
      const b = Math.min(255, Math.round((152 * shade) * (1 - moss) + 104 * moss));

      const idx = (y * w + x) * 4;
      ad[idx] = r;
      ad[idx + 1] = g;
      ad[idx + 2] = b;
      ad[idx + 3] = 255;

      const bv = Math.round(heightVal * 255);
      bd[idx] = bv;
      bd[idx + 1] = bv;
      bd[idx + 2] = bv;
      bd[idx + 3] = 255;
    }
  }

  albCtx.putImageData(albImg, 0, 0);
  bmpCtx.putImageData(bmpImg, 0, 0);

  const map = new THREE.CanvasTexture(albCanvas);
  map.wrapS = THREE.RepeatWrapping;
  map.wrapT = THREE.RepeatWrapping;
  map.anisotropy = anisotropy;
  map.colorSpace = THREE.SRGBColorSpace;
  map.needsUpdate = true;

  const bumpMap = new THREE.CanvasTexture(bmpCanvas);
  bumpMap.wrapS = THREE.RepeatWrapping;
  bumpMap.wrapT = THREE.RepeatWrapping;
  bumpMap.anisotropy = anisotropy;
  bumpMap.needsUpdate = true;

  return { map, bumpMap };
}

/** 9. Authentic Silver-White Birch Bark with Horizontal Charcoal Lenticels */
export function createBirchBarkTexture(anisotropy: number): THREE.CanvasTexture {
  const w = 256;
  const h = 512;
  const c = document.createElement('canvas');
  c.width = w;
  c.height = h;
  const ctx = c.getContext('2d')!;
  const rnd = makeRng(9127);

  // Warm papery silver-white birch base
  const grad = ctx.createLinearGradient(0, h, 0, 0);
  grad.addColorStop(0, '#4f4841'); // Gnarled dark root base
  grad.addColorStop(0.14, '#cfc7bc');
  grad.addColorStop(0.5, '#eae4da');
  grad.addColorStop(1, '#dfd8cc');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, w, h);

  // Warm amber peeling bark strips + dark charcoal horizontal lenticel dashes
  for (let i = 0; i < 220; i++) {
    const x = rnd() * w;
    const y = rnd() * h;
    const len = 10 + rnd() * 38;
    const thick = 1.2 + rnd() * 3.8;
    const dark = rnd() > 0.25;
    ctx.fillStyle = dark
      ? `rgba(42, 36, 32, ${0.45 + rnd() * 0.48})`
      : `rgba(178, 136, 98, ${0.28 + rnd() * 0.25})`;
    ctx.fillRect(x, y, len, thick);
    if (x + len > w) ctx.fillRect(x - w, y, len, thick); // Seamless wrap
  }

  // Larger dark diamond branch scars
  for (let k = 0; k < 18; k++) {
    const x = rnd() * w;
    const y = h * (0.12 + rnd() * 0.85);
    ctx.fillStyle = 'rgba(34, 29, 25, 0.85)';
    ctx.beginPath();
    ctx.ellipse(x, y, 12 + rnd() * 12, 4 + rnd() * 5, 0, 0, Math.PI * 2);
    ctx.fill();
  }

  const tex = new THREE.CanvasTexture(c);
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.ClampToEdgeWrapping;
  tex.anisotropy = anisotropy;
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.needsUpdate = true;
  return tex;
}

/** 10. Soft Grounded Ambient-Occlusion Contact Shadow Decal */
export function createContactShadowTexture(): THREE.CanvasTexture {
  const s = 128;
  const c = document.createElement('canvas');
  c.width = s;
  c.height = s;
  const ctx = c.getContext('2d')!;
  const grad = ctx.createRadialGradient(s / 2, s / 2, 4, s / 2, s / 2, s / 2);
  grad.addColorStop(0, 'rgba(8, 12, 10, 0.62)');
  grad.addColorStop(0.45, 'rgba(8, 12, 10, 0.32)');
  grad.addColorStop(0.78, 'rgba(8, 12, 10, 0.08)');
  grad.addColorStop(1, 'rgba(8, 12, 10, 0)');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, s, s);
  const tex = new THREE.CanvasTexture(c);
  tex.needsUpdate = true;
  return tex;
}

export interface BotanicalTextureSet {
  broadleaf: THREE.CanvasTexture;
  deciduousTint: THREE.CanvasTexture;
  pineBough: THREE.CanvasTexture;
  snowPineBough: THREE.CanvasTexture;
  frond: THREE.CanvasTexture;
  bushLeaf: THREE.CanvasTexture;
  flowerBush: THREE.CanvasTexture;
  grassClump: THREE.CanvasTexture;
  wildflower: THREE.CanvasTexture;
  barkMap: THREE.CanvasTexture;
  barkBump: THREE.CanvasTexture;
  birchBark: THREE.CanvasTexture;
}

export function createBotanicalTextureSet(anisotropy: number): BotanicalTextureSet {
  const bark = createDetailedBarkTextures(anisotropy);
  return {
    broadleaf: createBroadleafTexture(anisotropy),
    deciduousTint: createDeciduousTintTexture(anisotropy),
    pineBough: createPineBoughTexture(anisotropy, false),
    snowPineBough: createPineBoughTexture(anisotropy, true),
    frond: createFrondTexture(anisotropy),
    bushLeaf: createBushTexture(anisotropy, false),
    flowerBush: createBushTexture(anisotropy, true),
    grassClump: createGrassClumpTexture(anisotropy),
    wildflower: createWildflowerTexture(anisotropy),
    barkMap: bark.map,
    barkBump: bark.bumpMap,
    birchBark: createBirchBarkTexture(anisotropy),
  };
}
