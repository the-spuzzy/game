import * as THREE from 'three';
import { WATER_LEVEL, getRenderedTerrainHeight, getTerrainHeight } from './biomes';
import { AtmosphereState } from './sky';

const WATER_VERTEX = /* glsl */ `
  attribute float aDepth;

  uniform float uTime;

  varying vec3 vWorldPos;
  varying float vDepth;
  varying float vFogDepth;

  void main() {
    vDepth = aDepth;
    vec4 wp = modelMatrix * vec4(position, 1.0);

    // Gentle vertical wave swell scaled by depth so shoreline stays pinned cleanly
    float swellAmp = smoothstep(0.0, 2.5, aDepth) * 0.11;
    wp.y += (
      sin(wp.x * 0.24 + uTime * 1.45) * 0.55 +
      cos(wp.z * 0.29 - uTime * 1.18 + wp.x * 0.11) * 0.45
    ) * swellAmp;

    vWorldPos = wp.xyz;
    vec4 mvPos = viewMatrix * wp;
    vFogDepth = -mvPos.z;
    gl_Position = projectionMatrix * mvPos;
  }
`;

const WATER_FRAGMENT = /* glsl */ `
  precision highp float;

  varying vec3 vWorldPos;
  varying float vDepth;
  varying float vFogDepth;

  uniform float uTime;
  uniform vec3 uSunDir;
  uniform vec3 uSunColor;
  uniform vec3 uSkyHorizon;
  uniform vec3 uSkyZenith;
  uniform vec3 uFogColor;
  uniform float uFogDensity;
  uniform float uDayFactor;

  float wHash(vec2 p) {
    return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453123);
  }

  float wNoise(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    return mix(
      mix(wHash(i), wHash(i + vec2(1.0, 0.0)), f.x),
      mix(wHash(i + vec2(0.0, 1.0)), wHash(i + vec2(1.0, 1.0)), f.x),
      f.y
    );
  }

  // Multi-octave capillary & swell ripple height for photorealistic shimmering water normals
  float waveHeight(vec2 p, float t) {
    float w = 0.0;
    w += sin(p.x * 0.88 + p.y * 0.42 + t * 1.72) * 0.28;
    w += sin(p.x * -0.58 + p.y * 1.14 - t * 1.48) * 0.24;
    w += sin(p.x * 1.95 + p.y * 1.62 + t * 2.35) * 0.12;
    w += wNoise(p * 0.92 + vec2(t * 0.46, t * 0.28)) * 0.50;
    w += wNoise(p * 2.55 - vec2(t * 0.65, -t * 0.42)) * 0.28;
    w += wNoise(p * 5.80 + vec2(t * 0.95, t * 0.72)) * 0.14;
    return w;
  }

  void main() {
    if (vDepth < -0.14) discard;

    vec2 p = vWorldPos.xz;
    float distFade = 1.0 - smoothstep(45.0, 340.0, vFogDepth);

    // Perturbed capillary normal (fades smoothly at far distance for clean horizon reflections)
    float eps = 0.18;
    float hC = waveHeight(p, uTime);
    float hX = waveHeight(p + vec2(eps, 0.0), uTime);
    float hZ = waveHeight(p + vec2(0.0, eps), uTime);
    float normStrength = mix(0.06, 0.30, distFade);
    vec3 N = normalize(vec3((hC - hX) * normStrength, 1.0, (hC - hZ) * normStrength));

    vec3 V = normalize(cameraPosition - vWorldPos);
    float NoV = clamp(dot(N, V), 0.001, 1.0);

    // Physically based Schlick Fresnel reflection (F0 = 0.022 for pure water)
    float fresnel = 0.022 + 0.978 * pow(1.0 - NoV, 4.6);

    // Alien liquid: luminous teal shallows -> indigo depths -> violet abyss
    vec3 shallowCol = vec3(0.03, 0.46, 0.5) * mix(0.25, 1.0, uDayFactor);
    vec3 midCol = vec3(0.05, 0.12, 0.36) * mix(0.25, 1.0, uDayFactor);
    vec3 deepCol = vec3(0.028, 0.016, 0.12) * mix(0.25, 1.0, uDayFactor);

    float dMid = smoothstep(0.18, 3.0, vDepth);
    float dDeep = smoothstep(2.6, 11.5, vDepth);
    vec3 waterBody = mix(mix(shallowCol, midCol, dMid), deepCol, dDeep);

    // Shimmering dual-layer underwater sun caustics network in clear shallows
    if (vDepth < 3.2 && distFade > 0.08) {
      float c1 = wNoise(p * 2.1 + N.xz * 2.8 + vec2(uTime * 0.58, -uTime * 0.38));
      float c2 = wNoise(p * 3.4 - N.xz * 2.2 + vec2(-uTime * 0.44, uTime * 0.52));
      float caust = pow(clamp(1.0 - abs(c1 - c2) * 2.4, 0.0, 1.0), 3.2);
      caust *= (1.0 - smoothstep(0.05, 3.0, vDepth));
      waterBody += uSunColor * caust * 0.34 * uDayFactor * distFade;
    }

    // Bioluminescent plankton sparkling cyan & violet on the wavelets at night
    float nightW = 1.0 - uDayFactor;
    if (nightW > 0.02 && distFade > 0.03) {
      float pk = wNoise(p * 1.6 + N.xz * 3.0 + vec2(uTime * 0.21, -uTime * 0.17));
      float sparkle = smoothstep(0.7, 0.92, pk) * (0.6 + 0.4 * sin(uTime * 3.1 + p.x * 2.0 + p.y));
      float lumWave = smoothstep(0.55, 0.95, hC * 0.6);
      vec3 plankton = mix(vec3(0.1, 0.95, 1.0), vec3(0.75, 0.3, 1.0), wNoise(p * 0.08));
      waterBody += plankton * (sparkle * 0.85 + lumWave * 0.1) * nightW * distFade;
    }

    // Sky + subtle sunlit shoreline canopy reflection
    vec3 R = reflect(-V, N);
    vec3 skyRefl = mix(uSkyHorizon, uSkyZenith, clamp(pow(max(R.y, 0.0), 0.62), 0.0, 1.0));
    float sunInRefl = pow(max(dot(R, uSunDir), 0.0), 6.0);
    skyRefl += uSunColor * sunInRefl * 0.32 * uDayFactor;

    vec3 col = mix(waterBody, skyRefl, clamp(fresnel * 0.92, 0.04, 0.94));

    // Crisp glittering solar/lunar diamond sparkle path across wavelets (catches subtle HDR bloom!)
    vec3 L = normalize(vec3(uSunDir.x, abs(uSunDir.y) + 0.06, uSunDir.z));
    vec3 H = normalize(L + V);
    float specDiamond = pow(max(dot(N, H), 0.0), 320.0) * 4.2;
    float specBroad = pow(max(dot(N, H), 0.0), 36.0) * 0.30;
    col += uSunColor * (specDiamond + specBroad) * mix(0.38, 1.2, uDayFactor);

    // Animated frothy shoreline foam bands lapping at beaches & river rocks
    float shoreZone = 1.0 - smoothstep(0.0, 1.15, max(vDepth, 0.0));
    if (shoreZone > 0.01) {
      float foamNoise = wNoise(p * 1.7 + vec2(uTime * 0.35, -uTime * 0.25));
      float surfWave = sin(vDepth * 11.5 - uTime * 2.6 + foamNoise * 3.4) * 0.5 + 0.5;
      float edgeFoam = smoothstep(0.28, 0.02, max(vDepth, 0.0));
      float lapFoam = smoothstep(0.55, 0.88, surfWave) * shoreZone * 0.72;
      float foam = clamp(edgeFoam * 0.85 + lapFoam, 0.0, 1.0) * (0.65 + 0.35 * foamNoise);
      vec3 foamCol = mix(vec3(0.45, 0.52, 0.62), vec3(0.95, 0.97, 0.99), uDayFactor);
      col = mix(col, foamCol, foam * 0.82);
    }

    // Soft shoreline transparency so water feathers naturally onto wet sand
    float alpha = clamp(smoothstep(-0.08, 0.26, vDepth) * mix(0.68, 0.96, smoothstep(0.15, 2.8, vDepth)), 0.0, 0.97);

    // Match scene FogExp2 for seamless distant ocean horizon
    float fogFactor = 1.0 - exp(-uFogDensity * uFogDensity * vFogDepth * vFogDepth);
    col = mix(col, uFogColor, clamp(fogFactor, 0.0, 1.0));

    gl_FragColor = vec4(col, alpha);
    #include <tonemapping_fragment>
    #include <colorspace_fragment>
  }
`;

export class WaterSystem {
  public readonly material: THREE.ShaderMaterial;
  private readonly outerOcean: THREE.Mesh;

  constructor(scene: THREE.Scene) {
    this.material = new THREE.ShaderMaterial({
      vertexShader: WATER_VERTEX,
      fragmentShader: WATER_FRAGMENT,
      transparent: true,
      depthWrite: false,
      uniforms: {
        uTime: { value: 0 },
        uSunDir: { value: new THREE.Vector3(0.4, 0.6, -0.6) },
        uSunColor: { value: new THREE.Color(0xfff4de) },
        uSkyHorizon: { value: new THREE.Color(0xb8d8f2) },
        uSkyZenith: { value: new THREE.Color(0x2868b8) },
        uFogColor: { value: new THREE.Color(0xb8d8f2) },
        uFogDensity: { value: 0.00118 },
        uDayFactor: { value: 1.0 },
      },
    });

    // Distant ocean sheet covering far southern coast & beyond streamed chunk ring
    this.outerOcean = this.buildOuterOceanMesh();
    scene.add(this.outerOcean);
  }

  private buildOuterOceanMesh(): THREE.Mesh {
    const size = 2800;
    const segs = 96;
    const geo = new THREE.PlaneGeometry(size, size, segs, segs);
    geo.rotateX(-Math.PI / 2);

    const pos = geo.attributes.position as THREE.BufferAttribute;
    const depths = new Float32Array(pos.count);
    for (let i = 0; i < pos.count; i++) {
      const wx = pos.getX(i);
      const wz = pos.getZ(i);
      const h = getTerrainHeight(wx, wz);
      depths[i] = WATER_LEVEL - h;
      pos.setY(i, WATER_LEVEL - 0.04); // Tiny offset so chunk water smoothly wins indoors
    }
    geo.setAttribute('aDepth', new THREE.BufferAttribute(depths, 1));
    const mesh = new THREE.Mesh(geo, this.material);
    mesh.renderOrder = 1;
    return mesh;
  }

  /** Build a high-resolution per-chunk water mesh only if this chunk contains water */
  public createChunkWater(
    originX: number,
    originZ: number,
    chunkSize: number,
    segments: number,
    heightSampler?: (x: number, z: number) => number
  ): THREE.Mesh | null {
    const step = chunkSize / segments;
    const vertCount = (segments + 1) * (segments + 1);
    const depths = new Float32Array(vertCount);
    let hasWater = false;

    let idx = 0;
    for (let iz = 0; iz <= segments; iz++) {
      const wz = originZ + iz * step - chunkSize * 0.5;
      for (let ix = 0; ix <= segments; ix++) {
        const wx = originX + ix * step - chunkSize * 0.5;
        const d =
          WATER_LEVEL - (heightSampler ? heightSampler(wx, wz) : getRenderedTerrainHeight(wx, wz));
        depths[idx++] = d;
        if (d > -0.05) hasWater = true;
      }
    }

    if (!hasWater) return null;

    const geo = new THREE.PlaneGeometry(chunkSize, chunkSize, segments, segments);
    geo.rotateX(-Math.PI / 2);
    geo.setAttribute('aDepth', new THREE.BufferAttribute(depths, 1));

    const mesh = new THREE.Mesh(geo, this.material);
    mesh.position.set(originX, WATER_LEVEL, originZ);
    mesh.renderOrder = 2;
    return mesh;
  }

  public update(elapsed: number, atmo: AtmosphereState, fog: THREE.FogExp2): void {
    const u = this.material.uniforms;
    u.uTime.value = elapsed;
    u.uSunDir.value.copy(atmo.sunDirection);
    u.uSunColor.value.copy(atmo.sunColor);
    u.uSkyHorizon.value.copy(atmo.horizonColor);
    u.uSkyZenith.value.copy(atmo.zenithColor);
    u.uFogColor.value.copy(fog.color);
    u.uFogDensity.value = fog.density;
    u.uDayFactor.value = atmo.dayFactor;
  }
}
