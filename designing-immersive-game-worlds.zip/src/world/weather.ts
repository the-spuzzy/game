import * as THREE from 'three';
import { BiomeId } from './biomes';
import { GameMode } from './modes';
import { clamp, lerp } from './noise';

export type WeatherKind =
  | 'clear'
  | 'spore_drift'
  | 'crystal_snow'
  | 'ash_storm'
  | 'rust_winds'
  | 'plasma_rain'
  | 'aurora_mist'
  | 'bio_storm';

export interface WeatherSnapshot {
  kind: WeatherKind;
  name: string;
  description: string;
  intensity: number;
  color: string;
  windLabel: string;
}

interface WeatherDefinition {
  name: string;
  description: string;
  color: string;
  tint: THREE.Color;
  fallSpeed: number;
  windX: number;
  windZ: number;
  fogDensityMult: number;
  lightMult: number;
  exposureMult: number;
  particleSize: number;
  particleOpacity: number;
  regrowthBoost: number;
  lightning: boolean;
  particles: number;
}

const DEFS: Record<WeatherKind, WeatherDefinition> = {
  clear: {
    name: 'Radiant Xenosky',
    description: 'Warm twin-sun light and calm drifting spores.',
    color: '#fcd34d',
    tint: new THREE.Color('#ffd8a8'),
    fallSpeed: 0.4,
    windX: 0.5,
    windZ: 0.2,
    fogDensityMult: 1,
    lightMult: 1,
    exposureMult: 1,
    particleSize: 0.09,
    particleOpacity: 0.22,
    regrowthBoost: 0.15,
    lightning: false,
    particles: 90,
  },
  spore_drift: {
    name: 'Bioluminescent Spore Drift',
    description: 'Glowing jungle spores drift on a warm living breeze. Plants regrow faster.',
    color: '#4ade80',
    tint: new THREE.Color('#78d6a8'),
    fallSpeed: 0.9,
    windX: 1.2,
    windZ: 0.5,
    fogDensityMult: 1.25,
    lightMult: 0.92,
    exposureMult: 0.96,
    particleSize: 0.14,
    particleOpacity: 0.68,
    regrowthBoost: 0.9,
    lightning: false,
    particles: 340,
  },
  crystal_snow: {
    name: 'Crystal Snowfall',
    description: 'Singing ice needles fall across the Cryo Spires.',
    color: '#bae6fd',
    tint: new THREE.Color('#b9d8ff'),
    fallSpeed: 3.1,
    windX: 1.8,
    windZ: 0.7,
    fogDensityMult: 1.5,
    lightMult: 0.78,
    exposureMult: 0.92,
    particleSize: 0.13,
    particleOpacity: 0.82,
    regrowthBoost: -0.25,
    lightning: false,
    particles: 420,
  },
  ash_storm: {
    name: 'Ashen Rift Storm',
    description: 'Hot obsidian ash and red lightning sweep the badlands.',
    color: '#fb7185',
    tint: new THREE.Color('#b46a72'),
    fallSpeed: 1.8,
    windX: 3.4,
    windZ: 1.1,
    fogDensityMult: 1.85,
    lightMult: 0.62,
    exposureMult: 0.86,
    particleSize: 0.16,
    particleOpacity: 0.72,
    regrowthBoost: -0.5,
    lightning: true,
    particles: 400,
  },
  rust_winds: {
    name: 'Rust Dune Winds',
    description: 'Iron-red sand hisses across the open steppes and dunes.',
    color: '#fb923c',
    tint: new THREE.Color('#e3a06a'),
    fallSpeed: 0.7,
    windX: 4.2,
    windZ: 1.6,
    fogDensityMult: 1.45,
    lightMult: 0.82,
    exposureMult: 0.94,
    particleSize: 0.12,
    particleOpacity: 0.55,
    regrowthBoost: -0.15,
    lightning: false,
    particles: 330,
  },
  plasma_rain: {
    name: 'Plasma Monsoon',
    description: 'Violet rain crackles with bio-electric charge. Flora thrives.',
    color: '#c084fc',
    tint: new THREE.Color('#9c7bd8'),
    fallSpeed: 4.4,
    windX: 1.1,
    windZ: -0.8,
    fogDensityMult: 1.55,
    lightMult: 0.7,
    exposureMult: 0.9,
    particleSize: 0.12,
    particleOpacity: 0.8,
    regrowthBoost: 1.2,
    lightning: true,
    particles: 460,
  },
  aurora_mist: {
    name: 'Aurora Mist',
    description: 'Cool aurora haze rolls over the coast and glowing mire.',
    color: '#67e8f9',
    tint: new THREE.Color('#86c8dc'),
    fallSpeed: 0.35,
    windX: 0.7,
    windZ: 0.9,
    fogDensityMult: 1.32,
    lightMult: 0.86,
    exposureMult: 0.95,
    particleSize: 0.18,
    particleOpacity: 0.42,
    regrowthBoost: 0.6,
    lightning: false,
    particles: 240,
  },
  bio_storm: {
    name: 'Collapsing Bio-Storm',
    description: 'Battle Royale weather: magenta lightning and violent living winds.',
    color: '#f472b6',
    tint: new THREE.Color('#c65a9e'),
    fallSpeed: 2.6,
    windX: 2.8,
    windZ: -1.4,
    fogDensityMult: 1.7,
    lightMult: 0.68,
    exposureMult: 0.88,
    particleSize: 0.15,
    particleOpacity: 0.75,
    regrowthBoost: 0.25,
    lightning: true,
    particles: 420,
  },
};

const BIOME_WEATHER: Record<BiomeId, WeatherKind[]> = {
  meadow: ['clear', 'spore_drift', 'aurora_mist'],
  plains: ['rust_winds', 'clear', 'plasma_rain'],
  forest: ['spore_drift', 'aurora_mist', 'plasma_rain'],
  jungle: ['spore_drift', 'plasma_rain', 'aurora_mist'],
  alpine: ['crystal_snow', 'aurora_mist', 'crystal_snow'],
  autumn: ['rust_winds', 'spore_drift', 'plasma_rain'],
  wasteland: ['ash_storm', 'rust_winds', 'ash_storm'],
  desert: ['rust_winds', 'clear', 'plasma_rain'],
  coast: ['aurora_mist', 'plasma_rain', 'clear'],
  wetland: ['spore_drift', 'aurora_mist', 'plasma_rain'],
};

function hashString(s: string): number {
  let h = 2166136261 >>> 0;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619) >>> 0;
  }
  return (h >>> 0) / 4294967296;
}

export class WeatherSystem {
  private readonly scene: THREE.Scene;
  private readonly points: THREE.Points;
  private readonly material: THREE.PointsMaterial;
  private readonly positions: Float32Array;
  private readonly lightning: THREE.PointLight;
  private readonly maxParticles = 480;
  private currentKind: WeatherKind = 'clear';
  private intensity = 0.2;
  private targetIntensity = 0.2;
  private lastCycle = -1;
  private lightningTimer = 0;

  constructor(scene: THREE.Scene) {
    this.scene = scene;
    this.positions = new Float32Array(this.maxParticles * 3);
    for (let i = 0; i < this.maxParticles; i++) {
      this.positions[i * 3] = (Math.random() - 0.5) * 90;
      this.positions[i * 3 + 1] = Math.random() * 32;
      this.positions[i * 3 + 2] = (Math.random() - 0.5) * 90;
    }
    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.BufferAttribute(this.positions, 3));
    this.material = new THREE.PointsMaterial({
      color: 0xffffff,
      size: 0.14,
      transparent: true,
      opacity: 0.6,
      depthWrite: false,
      sizeAttenuation: true,
    });
    this.points = new THREE.Points(geo, this.material);
    this.points.frustumCulled = false;
    scene.add(this.points);

    this.lightning = new THREE.PointLight(0xf0abfc, 0, 120, 1.4);
    scene.add(this.lightning);
  }

  public getKind(): WeatherKind {
    return this.currentKind;
  }

  public getSnapshot(): WeatherSnapshot {
    const d = DEFS[this.currentKind];
    const windMag = Math.hypot(d.windX, d.windZ);
    const windLabel = windMag > 3 ? 'Strong winds' : windMag > 1.3 ? 'Living breeze' : 'Calm';
    return {
      kind: this.currentKind,
      name: d.name,
      description: d.description,
      intensity: this.intensity,
      color: d.color,
      windLabel,
    };
  }

  public getRegrowthBoost(): number {
    return DEFS[this.currentKind].regrowthBoost * this.intensity;
  }

  public getLightMultiplier(): number {
    return lerp(1, DEFS[this.currentKind].lightMult, this.intensity);
  }

  public getExposureMultiplier(): number {
    return lerp(1, DEFS[this.currentKind].exposureMult, this.intensity);
  }

  public getFogDensityMult(): number {
    return lerp(1, DEFS[this.currentKind].fogDensityMult, this.intensity);
  }

  public getTint(): THREE.Color {
    return DEFS[this.currentKind].tint;
  }

  public getWind(): { x: number; z: number } {
    const d = DEFS[this.currentKind];
    return { x: d.windX * this.intensity, z: d.windZ * this.intensity };
  }

  public applyToFog(fog: THREE.FogExp2): void {
    fog.density *= this.getFogDensityMult();
    fog.color.lerp(this.getTint(), this.intensity * 0.22);
  }

  public update(
    dt: number,
    elapsed: number,
    playerPos: THREE.Vector3,
    biome: BiomeId,
    _timeOfDay: number,
    mode: GameMode
  ): void {
    const cycle = Math.floor(elapsed / 62);
    if (cycle !== this.lastCycle) {
      this.lastCycle = cycle;
      const options = mode === 'battle-royale' ? ['bio_storm', 'plasma_rain'] : BIOME_WEATHER[biome];
      const pick = Math.floor(hashString(`${biome}:${mode}:${cycle}`) * options.length);
      this.currentKind = options[Math.min(options.length - 1, pick)] as WeatherKind;
      this.targetIntensity =
        this.currentKind === 'clear'
          ? 0.18
          : 0.55 + hashString(`${this.currentKind}:${cycle}`) * 0.4;
    }
    this.intensity = lerp(this.intensity, this.targetIntensity, Math.min(1, dt * 0.7));

    const d = DEFS[this.currentKind];
    const activeCount = Math.max(1, Math.min(this.maxParticles, Math.round(d.particles * this.intensity)));
    this.points.geometry.setDrawRange(0, activeCount);
    this.material.color.set(d.color);
    this.material.size = d.particleSize;
    this.material.opacity = d.particleOpacity * clamp(this.intensity + 0.2, 0, 1);

    const pos = this.positions;
    const boxW = 90;
    const boxH = 34;
    for (let i = 0; i < activeCount; i++) {
      let x = pos[i * 3] + d.windX * dt * (1 + this.intensity);
      let y = pos[i * 3 + 1] - d.fallSpeed * dt * (1 + this.intensity * 0.8);
      let z = pos[i * 3 + 2] + d.windZ * dt * (1 + this.intensity);
      if (y < -2) {
        y = boxH;
        x = (Math.random() - 0.5) * boxW;
        z = (Math.random() - 0.5) * boxW;
      }
      if (x > boxW * 0.5) x -= boxW;
      if (x < -boxW * 0.5) x += boxW;
      if (z > boxW * 0.5) z -= boxW;
      if (z < -boxW * 0.5) z += boxW;
      pos[i * 3] = x;
      pos[i * 3 + 1] = y;
      pos[i * 3 + 2] = z;
    }
    this.points.geometry.attributes.position.needsUpdate = true;
    this.points.position.set(playerPos.x, playerPos.y, playerPos.z);

    // Storm lightning: brief magenta illumination around the player
    this.lightningTimer -= dt;
    if (d.lightning && this.lightningTimer <= 0) {
      this.lightningTimer = 2.2 + Math.random() * 5.5;
      this.lightning.intensity = 4.5 + Math.random() * 3.5;
      this.lightning.color.set(d.color);
    }
    this.lightning.intensity = Math.max(0, this.lightning.intensity - dt * 22);
    this.lightning.position.set(playerPos.x, playerPos.y + 18, playerPos.z - 6);
  }

  public dispose(): void {
    this.scene.remove(this.points);
    this.scene.remove(this.lightning);
    this.points.geometry.dispose();
    this.material.dispose();
  }
}
