import * as THREE from 'three';
import { CreatureCallKind, WorldAudio } from './audio';
import {
  BIOME_LIST,
  BiomeWeights,
  WATER_LEVEL,
  getRenderedTerrainHeight,
  sampleBiomeWeights,
  sampleRenderedTerrain,
} from './biomes';
import {
  CreatureMaterials,
  PartBatch,
  blobGeos,
  crabGeos,
  createCreatureMaterials,
  fishGeos,
  grazerGeos,
  jellyGeos,
  mantaGeos,
  striderGeos,
  thornGeos,
  titanGeos,
  unitSegment,
  wyrmGeos,
} from './creatures';
import { ESSENCES, EssenceType, SPECIES_PREY_INFO } from './evolution';
import { clamp, lerp } from './noise';

type SpeciesId = CreatureCallKind;

export interface TargetCreatureInfo {
  speciesId: SpeciesId;
  name: string;
  tier: number;
  hp: number;
  maxHp: number;
  dnaReward: number;
  essence: EssenceType;
  essenceName: string;
  essenceColor: string;
  distance: number;
  x: number;
  y: number;
  z: number;
}

interface BioProjectile {
  mesh: THREE.Mesh;
  x: number;
  y: number;
  z: number;
  vx: number;
  vy: number;
  vz: number;
  damage: number;
  age: number;
  active: boolean;
}

interface DnaOrb {
  mesh: THREE.Mesh;
  x: number;
  y: number;
  z: number;
  vx: number;
  vy: number;
  vz: number;
  age: number;
  speciesId: SpeciesId;
  active: boolean;
}

interface SpeciesSpec {
  id: SpeciesId;
  max: number;
  group: [number, number];
  spread: number;
  minDist: number;
  maxDist: number;
  despawn: number;
  terrain: 'land' | 'water' | 'air';
  minNormalY: number;
  habitat: (w: BiomeWeights) => number;
  hear: number;
  call: [number, number];
}

interface Creature {
  active: boolean;
  x: number;
  y: number;
  z: number;
  yaw: number;
  pitch: number;
  roll: number;
  speed: number;
  tx: number;
  tz: number;
  state: number;
  timer: number;
  phase: number;
  scale: number;
  seed: number;
  group: number;
  ox: number;
  oz: number;
  alt: number;
  groundY: number;
  groundTimer: number;
  callTimer: number;
  a: number;
  b: number;
  color: THREE.Color;
  glow: THREE.Color;
  trail: Float32Array | null;
  trailHead: number;
  trailAcc: number;
  hp: number;
  maxHp: number;
  hurtTimer: number;
  retaliateTimer: number;
  menaceTimer: number;
  attackMode: number; // 0 idle, 1 telegraph, 2 strike, 3 recover
  attackTimer: number;
  attackCooldown: number;
  attackDidHit: boolean;
}

interface AttackSpec {
  detect: number;
  reach: number;
  charge: number;
  cooldown: number;
  pulse: boolean;
}

interface Group {
  id: number;
  sp: SpeciesId;
  members: number;
  tx: number;
  tz: number;
  timer: number;
  alarm: number;
  fx: number;
  fz: number;
  cx: number;
  cz: number;
  sumX: number;
  sumZ: number;
  cnt: number;
  radius: number;
  angle: number;
  angSpeed: number;
  alt: number;
  groundAlt: number;
  altTimer: number;
  swoop: number;
  swoopTimer: number;
}

type Batches = Record<string, PartBatch>;

const TRAIL_STEP = 0.25;
const TRAIL_LEN = 64;
const WYRM_SEGMENTS = 14;

const _root = new THREE.Matrix4();
const _local = new THREE.Matrix4();
const _local2 = new THREE.Matrix4();
const _world = new THREE.Matrix4();
const _q = new THREE.Quaternion();
const _e = new THREE.Euler();
const _p = new THREE.Vector3();
const _s = new THREE.Vector3();
const _dir = new THREE.Vector3();
const _A = new THREE.Vector3();
const _B = new THREE.Vector3();
const _K = new THREE.Vector3();
const _down = new THREE.Vector3(0, -1, 0);
const _n: [number, number, number] = [0, 1, 0];
const _glow = new THREE.Color();
const _tint = new THREE.Color();
const _camFwd = new THREE.Vector3();

function angleDiff(from: number, to: number): number {
  let d = ((to - from + Math.PI) % (Math.PI * 2)) - Math.PI;
  if (d < -Math.PI) d += Math.PI * 2;
  return d;
}

function rootM(x: number, y: number, z: number, yaw: number, pitch: number, roll: number, s: number): void {
  _e.set(pitch, yaw, roll, 'YXZ');
  _q.setFromEuler(_e);
  _root.compose(_p.set(x, y, z), _q, _s.set(s, s, s));
}

function trs(
  out: THREE.Matrix4,
  x: number,
  y: number,
  z: number,
  rx: number,
  ry: number,
  rz: number,
  sx = 1,
  sy = 1,
  sz = 1
): THREE.Matrix4 {
  _e.set(rx, ry, rz, 'XYZ');
  _q.setFromEuler(_e);
  return out.compose(_p.set(x, y, z), _q, _s.set(sx, sy, sz));
}

/** Limb segment matrix stretching the unit segment from a to b */
function seg(out: THREE.Matrix4, a: THREE.Vector3, b: THREE.Vector3, thick: number): THREE.Matrix4 {
  _dir.subVectors(b, a);
  const len = Math.max(0.0001, _dir.length());
  _dir.multiplyScalar(1 / len);
  _q.setFromUnitVectors(_down, _dir);
  return out.compose(a, _q, _s.set(thick, len, thick));
}

function toWorld(local: THREE.Matrix4): THREE.Matrix4 {
  return _world.multiplyMatrices(_root, local);
}

const C = (r: number, g: number, b: number) => new THREE.Color().setRGB(r, g, b, THREE.SRGBColorSpace);
const H = (r: number, g: number, b: number) => new THREE.Color(r, g, b);

const PAL = {
  grazerSkin: [C(0.86, 0.58, 0.42), C(0.62, 0.52, 0.78), C(0.92, 0.78, 0.58), C(0.46, 0.62, 0.72)],
  grazerGlow: [H(0.25, 1.4, 1.5), H(1.4, 0.35, 1.0), H(1.5, 0.9, 0.25)],
  striderSkin: [C(0.88, 0.85, 0.94), C(0.75, 0.82, 0.9)],
  striderGlow: [H(0.3, 1.5, 1.6), H(1.6, 0.8, 0.3)],
  jellySkin: [C(0.55, 0.85, 1.0), C(1.0, 0.6, 0.9), C(0.75, 0.6, 1.0), C(0.5, 1.0, 0.8)],
  jellyGlow: [H(0.4, 1.6, 1.8), H(1.8, 0.5, 1.4), H(1.0, 0.6, 1.9)],
  mantaSkin: [C(0.22, 0.2, 0.35), C(0.3, 0.22, 0.42), C(0.18, 0.28, 0.38)],
  mantaGlow: [H(0.3, 1.6, 1.8), H(1.7, 0.4, 1.2)],
  blobSkin: [C(1.0, 0.6, 0.8), C(0.6, 1.0, 0.6), C(0.5, 0.85, 1.0), C(1.0, 0.9, 0.45), C(0.8, 0.6, 1.0)],
  blobGlow: [H(1.6, 1.6, 1.3), H(1.2, 1.7, 1.7)],
  wyrmSkin: [C(0.3, 0.24, 0.28), C(0.42, 0.3, 0.26), C(0.25, 0.2, 0.3)],
  wyrmGlow: [H(1.8, 0.35, 0.9), H(1.9, 0.6, 0.2)],
  titanSkin: [C(0.48, 0.44, 0.52), C(0.55, 0.48, 0.42)],
  titanGlow: [H(0.35, 1.5, 1.6), H(1.4, 0.5, 1.5)],
  crabSkin: [C(0.3, 0.32, 0.44), C(0.42, 0.3, 0.38), C(0.85, 0.82, 0.92)],
  crabGlow: [H(0.4, 1.4, 1.9), H(1.5, 0.45, 1.7), H(0.5, 1.8, 1.4)],
  fishSkin: [C(0.3, 0.4, 0.6), C(0.5, 0.3, 0.6)],
  fishGlow: [H(0.3, 1.8, 1.6), H(1.7, 0.4, 1.6)],
  thornSkin: [C(0.16, 0.14, 0.2), C(0.24, 0.16, 0.2), C(0.14, 0.2, 0.2)],
  thornGlow: [H(1.8, 0.25, 0.4), H(0.3, 1.7, 0.9)],
};

function pick<T>(arr: T[]): T {
  return arr[Math.floor(Math.random() * arr.length)];
}

/** Per-species attack-back behavior: detection radius, strike reach, charge speed & cooldown */
const ATTACK_DATA: Record<SpeciesId, AttackSpec> = {
  grazer: { detect: 11, reach: 3.6, charge: 8.5, cooldown: 2.4, pulse: false },
  strider: { detect: 14, reach: 6.0, charge: 3.0, cooldown: 4.0, pulse: false },
  jelly: { detect: 7, reach: 5.0, charge: 0, cooldown: 3.4, pulse: true },
  manta: { detect: 13, reach: 6.2, charge: 0, cooldown: 4.2, pulse: true },
  blob: { detect: 5, reach: 2.2, charge: 5.0, cooldown: 2.8, pulse: false },
  wyrm: { detect: 13, reach: 4.6, charge: 7.5, cooldown: 3.2, pulse: false },
  titan: { detect: 20, reach: 13.0, charge: 1.2, cooldown: 5.2, pulse: true },
  crab: { detect: 8, reach: 2.8, charge: 5.2, cooldown: 2.2, pulse: false },
  fish: { detect: 5, reach: 2.5, charge: 4.0, cooldown: 2.8, pulse: true },
  thorn: { detect: 15, reach: 3.8, charge: 9.5, cooldown: 2.6, pulse: false },
};

/**
 * Alien wildlife ecosystem: a living population of ten made-up species
 * spawning around the explorer with herding, flocking, curiosity, stalking,
 * burrowing & leaping behaviors — plus synthesized calls.
 */
export class WildlifeSystem {
  private readonly audio: WorldAudio;
  private readonly onSplash: (x: number, z: number, scale: number) => void;
  private readonly mats: CreatureMaterials;
  private readonly specs: SpeciesSpec[];
  private readonly specMap: Record<SpeciesId, SpeciesSpec>;
  private readonly pools: Record<SpeciesId, Creature[]>;
  private readonly batches: Record<SpeciesId, Batches>;
  private readonly groups = new Map<number, Group>();
  private readonly campfires: Array<{ flames: THREE.Mesh[]; phase: number }> = [];
  private readonly projectiles: BioProjectile[] = [];
  private readonly dnaOrbs: DnaOrb[] = [];
  private readonly targetRingMesh: THREE.Mesh;
  private readonly targetRingMat: THREE.MeshBasicMaterial;
  private onPreyDevoured?: (speciesId: SpeciesId) => void;
  private onPlayerDamaged?: (damage: number, speciesName: string, sourceX?: number, sourceZ?: number) => void;

  private nextGroup = 1;
  private spawnCursor = 0;
  private primed = false;
  private lastPX = 0;
  private lastPZ = 0;
  private callCooldown = 0;
  private playerHitCooldown = 0;
  private hpMult = 1.0;
  private dmgMult = 1.0;
  private playerCloaked = false;
  private readonly windX = 0.83;
  private readonly windZ = 0.55;

  constructor(
    scene: THREE.Scene,
    audio: WorldAudio,
    isMobile: boolean,
    onSplash: (x: number, z: number, scale: number) => void,
    onPreyDevoured?: (speciesId: SpeciesId) => void,
    onPlayerDamaged?: (damage: number, speciesName: string, sourceX?: number, sourceZ?: number) => void
  ) {
    this.audio = audio;
    this.onSplash = onSplash;
    this.onPreyDevoured = onPreyDevoured;
    this.onPlayerDamaged = onPlayerDamaged;
    this.mats = createCreatureMaterials();

    const S = (desktop: number, mobile: number) => (isMobile ? mobile : desktop);
    this.specs = [
      { id: 'grazer', max: S(36, 18), group: [4, 8], spread: 10, minDist: 28, maxDist: 175, despawn: 270, terrain: 'land', minNormalY: 0.82, habitat: (w) => w.plains + w.meadow * 0.85 + w.autumn * 0.65 + w.desert * 0.2, hear: 120, call: [9, 22] },
      { id: 'strider', max: S(8, 4), group: [1, 3], spread: 18, minDist: 65, maxDist: 220, despawn: 340, terrain: 'land', minNormalY: 0.7, habitat: (w) => w.plains * 0.95 + w.wasteland * 0.85 + w.desert * 0.75 + w.coast * 0.35 + w.meadow * 0.35, hear: 380, call: [16, 34] },
      { id: 'jelly', max: S(28, 14), group: [2, 5], spread: 12, minDist: 16, maxDist: 155, despawn: 240, terrain: 'air', minNormalY: 0, habitat: (w) => 0.35 + w.wetland * 0.75 + w.meadow * 0.75 + w.jungle * 0.75 + w.coast * 0.55 + w.forest * 0.5, hear: 45, call: [7, 16] },
      { id: 'manta', max: S(18, 9), group: [4, 7], spread: 0, minDist: 45, maxDist: 195, despawn: 360, terrain: 'air', minNormalY: 0, habitat: (w) => 0.45 + w.coast * 0.65 + w.plains * 0.55 + w.alpine * 0.35, hear: 140, call: [8, 18] },
      { id: 'blob', max: S(28, 14), group: [3, 6], spread: 6, minDist: 14, maxDist: 115, despawn: 170, terrain: 'land', minNormalY: 0.75, habitat: (w) => w.meadow + w.forest * 0.9 + w.jungle * 0.9 + w.wetland * 0.75 + w.coast * 0.4, hear: 30, call: [4, 10] },
      { id: 'wyrm', max: S(5, 3), group: [1, 2], spread: 20, minDist: 55, maxDist: 170, despawn: 260, terrain: 'land', minNormalY: 0.6, habitat: (w) => w.wasteland + w.desert * 0.95 + w.plains * 0.18, hear: 90, call: [12, 26] },
      { id: 'titan', max: S(3, 2), group: [1, 1], spread: 0, minDist: 175, maxDist: 320, despawn: 560, terrain: 'land', minNormalY: 0.72, habitat: (w) => w.plains + w.wasteland * 0.9 + w.desert * 0.7 + w.alpine * 0.5 + w.meadow * 0.35, hear: 650, call: [24, 48] },
      { id: 'crab', max: S(22, 11), group: [3, 6], spread: 7, minDist: 18, maxDist: 115, despawn: 170, terrain: 'land', minNormalY: 0.65, habitat: (w) => w.alpine + w.coast * 0.9 + w.wasteland * 0.8 + w.desert * 0.4 + w.meadow * 0.55, hear: 25, call: [5, 12] },
      { id: 'fish', max: S(16, 8), group: [2, 4], spread: 6, minDist: 14, maxDist: 110, despawn: 150, terrain: 'water', minNormalY: 0, habitat: () => 1.0, hear: 40, call: [6, 14] },
      { id: 'thorn', max: S(8, 4), group: [1, 2], spread: 8, minDist: 38, maxDist: 155, despawn: 230, terrain: 'land', minNormalY: 0.8, habitat: (w) => w.forest + w.jungle * 0.9 + w.autumn * 0.85 + w.meadow * 0.45, hear: 70, call: [10, 22] },
    ];

    const specMap = {} as Record<SpeciesId, SpeciesSpec>;
    const pools = {} as Record<SpeciesId, Creature[]>;
    for (const s of this.specs) {
      specMap[s.id] = s;
      pools[s.id] = [];
      for (let i = 0; i < s.max; i++) pools[s.id].push(this.blankCreature());
    }
    this.specMap = specMap;
    this.pools = pools;

    const m = this.mats;
    const seg7 = unitSegment(7);
    const seg5 = unitSegment(5);
    const g = grazerGeos();
    const st = striderGeos();
    const je = jellyGeos();
    const ma = mantaGeos();
    const bl = blobGeos();
    const wy = wyrmGeos();
    const ti = titanGeos();
    const cr = crabGeos();
    const fi = fishGeos();
    const th = thornGeos();
    const mx = (id: SpeciesId) => specMap[id].max;

    this.batches = {
      grazer: {
        body: new PartBatch(scene, g.body, m.skin, mx('grazer'), 1, true),
        head: new PartBatch(scene, g.head, m.skin, mx('grazer'), 1, true),
        eyes: new PartBatch(scene, g.eyes, m.glow, mx('grazer'), 1, false),
        plates: new PartBatch(scene, g.plates, m.glow, mx('grazer'), 1, false),
        upper: new PartBatch(scene, seg7, m.skin, mx('grazer'), 6, true),
        lower: new PartBatch(scene, seg5, m.skin, mx('grazer'), 6, false),
      },
      strider: {
        body: new PartBatch(scene, st.body, m.skin, mx('strider'), 1, true),
        ring: new PartBatch(scene, st.ring, m.glow, mx('strider'), 1, false),
        sac: new PartBatch(scene, st.sac, m.glow, mx('strider'), 1, false),
        upper: new PartBatch(scene, seg7, m.skin, mx('strider'), 3, true),
        lower: new PartBatch(scene, seg7, m.skin, mx('strider'), 3, true),
      },
      jelly: {
        bell: new PartBatch(scene, je.bell, m.jelly, mx('jelly'), 1, false),
        core: new PartBatch(scene, je.core, m.glow, mx('jelly'), 1, false),
        tent: new PartBatch(scene, seg5, m.jelly, mx('jelly'), 18, false),
      },
      manta: {
        body: new PartBatch(scene, ma.body, m.wing, mx('manta'), 1, true),
        wingIn: new PartBatch(scene, ma.wingInner, m.wing, mx('manta'), 2, true),
        wingOut: new PartBatch(scene, ma.wingOuter, m.wing, mx('manta'), 2, true),
        tail: new PartBatch(scene, ma.tail, m.wing, mx('manta'), 1, false),
        eyes: new PartBatch(scene, ma.eyes, m.glow, mx('manta'), 1, false),
      },
      blob: {
        body: new PartBatch(scene, bl.body, m.skin, mx('blob'), 1, true),
        stalk: new PartBatch(scene, seg5, m.skin, mx('blob'), 2, false),
        eye: new PartBatch(scene, bl.eye, m.glow, mx('blob'), 2, false),
      },
      wyrm: {
        seg: new PartBatch(scene, wy.segment, m.skin, mx('wyrm'), WYRM_SEGMENTS, true),
        spike: new PartBatch(scene, wy.spike, m.glow, mx('wyrm'), WYRM_SEGMENTS, false),
        head: new PartBatch(scene, wy.head, m.skin, mx('wyrm'), 1, true),
        eyes: new PartBatch(scene, wy.eyes, m.glow, mx('wyrm'), 1, false),
      },
      titan: {
        body: new PartBatch(scene, ti.body, m.skin, mx('titan'), 1, true),
        spots: new PartBatch(scene, ti.spots, m.glow, mx('titan'), 1, false),
        head: new PartBatch(scene, ti.head, m.skin, mx('titan'), 1, true),
        eyes: new PartBatch(scene, ti.eyes, m.glow, mx('titan'), 1, false),
        upper: new PartBatch(scene, seg7, m.skin, mx('titan'), 4, true),
        lower: new PartBatch(scene, seg7, m.skin, mx('titan'), 4, true),
        tendril: new PartBatch(scene, seg5, m.glow, mx('titan'), 18, false),
      },
      crab: {
        body: new PartBatch(scene, cr.body, m.skin, mx('crab'), 1, true),
        crystals: new PartBatch(scene, cr.crystals, m.glow, mx('crab'), 1, false),
        upper: new PartBatch(scene, seg5, m.skin, mx('crab'), 6, false),
        lower: new PartBatch(scene, seg5, m.skin, mx('crab'), 6, false),
        claw: new PartBatch(scene, cr.claw, m.skin, mx('crab'), 2, false),
      },
      fish: {
        body: new PartBatch(scene, fi.body, m.skin, mx('fish'), 1, false),
        stripe: new PartBatch(scene, fi.stripe, m.glow, mx('fish'), 1, false),
        tail: new PartBatch(scene, fi.tail, m.wing, mx('fish'), 1, false),
      },
      thorn: {
        body: new PartBatch(scene, th.body, m.skin, mx('thorn'), 1, true),
        spines: new PartBatch(scene, th.spines, m.glow, mx('thorn'), 1, false),
        head: new PartBatch(scene, th.head, m.skin, mx('thorn'), 1, true),
        eyes: new PartBatch(scene, th.eyes, m.glow, mx('thorn'), 1, false),
        upper: new PartBatch(scene, seg7, m.skin, mx('thorn'), 4, true),
        lower: new PartBatch(scene, seg5, m.skin, mx('thorn'), 4, false),
        tail: new PartBatch(scene, seg5, m.skin, mx('thorn'), 4, false),
      },
    };

    // Target Lock Ring around nearest huntable creature
    const ringGeo = new THREE.RingGeometry(0.9, 1.12, 32);
    ringGeo.rotateX(-Math.PI / 2);
    this.targetRingMat = new THREE.MeshBasicMaterial({
      color: 0x38bdf8,
      transparent: true,
      opacity: 0.72,
      side: THREE.DoubleSide,
      depthWrite: false,
    });
    this.targetRingMesh = new THREE.Mesh(ringGeo, this.targetRingMat);
    this.targetRingMesh.visible = false;
    this.targetRingMesh.renderOrder = 4;
    scene.add(this.targetRingMesh);

    // Pooled Bio-Plasma Spit Projectiles
    const projGeo = new THREE.IcosahedronGeometry(0.28, 1);
    const projMat = new THREE.MeshBasicMaterial({ color: 0x38bdf8 });
    for (let i = 0; i < 12; i++) {
      const mesh = new THREE.Mesh(projGeo, projMat.clone());
      mesh.visible = false;
      scene.add(mesh);
      this.projectiles.push({
        mesh,
        x: 0,
        y: 0,
        z: 0,
        vx: 0,
        vy: 0,
        vz: 0,
        damage: 15,
        age: 0,
        active: false,
      });
    }

    // Pooled Glowing DNA / Biomass Orbs dropped when wildlife is killed
    const orbGeo = new THREE.OctahedronGeometry(0.26, 1);
    for (let i = 0; i < 32; i++) {
      const mat = new THREE.MeshBasicMaterial({
        color: 0x2dd4bf,
        transparent: true,
        opacity: 0.92,
      });
      const mesh = new THREE.Mesh(orbGeo, mat);
      mesh.visible = false;
      scene.add(mesh);
      this.dnaOrbs.push({
        mesh,
        x: 0,
        y: 0,
        z: 0,
        vx: 0,
        vy: 0,
        vz: 0,
        age: 0,
        speciesId: 'blob',
        active: false,
      });
    }

    this.initLandmarkCampfires(scene);
  }

  /** Open World monsters are tougher; Battle Royale monsters hit harder. */
  public setDifficulty(hpMult: number, dmgMult: number): void {
    this.hpMult = clamp(hpMult, 0.5, 4);
    this.dmgMult = clamp(dmgMult, 0.5, 4);
  }

  /** Phase Veil makes wildlife stop actively targeting the player. */
  public setPlayerCloaked(active: boolean): void {
    this.playerCloaked = active;
  }

  public hasCreatureNear(x: number, z: number, radius: number): boolean {
    for (const spec of this.specs) {
      for (const c of this.pools[spec.id]) {
        if (!c.active) continue;
        if (Math.hypot(c.x - x, c.z - z) <= radius + SPECIES_PREY_INFO[spec.id].hitRadius * c.scale) {
          return true;
        }
      }
    }
    return false;
  }

  /** Radial damage for Gravity Slam and Spore Mines. */
  public damageInRadius(
    x: number,
    z: number,
    radius: number,
    damage: number,
    px: number,
    pz: number
  ): { hitCount: number; killedCount: number } {
    let hitCount = 0;
    let killedCount = 0;
    for (const spec of this.specs) {
      const info = SPECIES_PREY_INFO[spec.id];
      for (const c of this.pools[spec.id]) {
        if (!c.active) continue;
        if (Math.hypot(c.x - x, c.z - z) > radius + info.hitRadius * c.scale) continue;
        hitCount++;
        if (this.damageCreature(c, spec.id, damage, px, pz)) killedCount++;
      }
    }
    return { hitCount, killedCount };
  }

  /** Cone damage for Void Lance / Phase Dash. */
  public damageInCone(
    px: number,
    pz: number,
    fwdX: number,
    fwdZ: number,
    range: number,
    halfWidth: number,
    damage: number
  ): { hitCount: number; killedCount: number } {
    let hitCount = 0;
    let killedCount = 0;
    for (const spec of this.specs) {
      const info = SPECIES_PREY_INFO[spec.id];
      for (const c of this.pools[spec.id]) {
        if (!c.active) continue;
        const dx = c.x - px;
        const dz = c.z - pz;
        const along = dx * fwdX + dz * fwdZ;
        const perp = Math.abs(dx * -fwdZ + dz * fwdX);
        if (along < -0.5 || along > range || perp > halfWidth + info.hitRadius * c.scale) continue;
        hitCount++;
        if (this.damageCreature(c, spec.id, damage, px, pz)) killedCount++;
      }
    }
    return { hitCount, killedCount };
  }

  private blankCreature(): Creature {
    return {
      active: false,
      x: 0,
      y: 0,
      z: 0,
      yaw: 0,
      pitch: 0,
      roll: 0,
      speed: 0,
      tx: 0,
      tz: 0,
      state: 0,
      timer: 0,
      phase: 0,
      scale: 1,
      seed: 0,
      group: 0,
      ox: 0,
      oz: 0,
      alt: 0,
      groundY: 0,
      groundTimer: 0,
      callTimer: 0,
      a: 0,
      b: 0,
      color: new THREE.Color(1, 1, 1),
      glow: new THREE.Color(1, 1, 1),
      trail: null,
      trailHead: 0,
      trailAcc: 0,
      hp: 30,
      maxHp: 30,
      hurtTimer: 0,
      retaliateTimer: 0,
      menaceTimer: 0,
      attackMode: 0,
      attackTimer: 0,
      attackCooldown: 0,
      attackDidHit: false,
    };
  }

  private initLandmarkCampfires(scene: THREE.Scene): void {
    const stoneMat = new THREE.MeshStandardMaterial({ color: 0x4f4a5c, roughness: 0.92 });
    const logMat = new THREE.MeshStandardMaterial({ color: 0x3a2a3a, roughness: 0.94 });
    const emberMat = new THREE.MeshStandardMaterial({
      color: 0xff5a18,
      emissive: new THREE.Color(0xff4208),
      emissiveIntensity: 2.4,
      roughness: 0.6,
    });
    const flameOuterMat = new THREE.MeshBasicMaterial({ color: 0xff7b1c, transparent: true, opacity: 0.88 });
    const flameCoreMat = new THREE.MeshBasicMaterial({ color: 0xffe478, transparent: true, opacity: 0.94 });
    const stoneGeo = new THREE.DodecahedronGeometry(0.16, 0);
    const logGeo = new THREE.CylinderGeometry(0.065, 0.075, 0.78, 6);
    const flameGeo = new THREE.ConeGeometry(0.18, 0.56, 6);

    BIOME_LIST.forEach((b, idx) => {
      const fx = b.landmark.x + 2.4;
      const fz = b.landmark.z - 3.6;
      const fy = getRenderedTerrainHeight(fx, fz);
      if (fy < WATER_LEVEL + 0.35) return;
      const group = new THREE.Group();
      group.position.set(fx, fy, fz);
      for (let s = 0; s < 8; s++) {
        const a = (s / 8) * Math.PI * 2;
        const ox = Math.cos(a) * 0.48;
        const oz = Math.sin(a) * 0.48;
        const st = new THREE.Mesh(stoneGeo, stoneMat);
        st.scale.set(1.12, 0.72, 0.96);
        st.position.set(ox, getRenderedTerrainHeight(fx + ox, fz + oz) - fy + 0.04, oz);
        st.rotation.y = a;
        st.castShadow = true;
        group.add(st);
      }
      for (let l = 0; l < 3; l++) {
        const log = new THREE.Mesh(logGeo, logMat);
        log.rotation.z = Math.PI / 2 - 0.25;
        log.rotation.y = (l / 3) * Math.PI;
        log.position.set(0, 0.11, 0);
        group.add(log);
      }
      const coals = new THREE.Mesh(new THREE.SphereGeometry(0.24, 7, 5), emberMat);
      coals.scale.set(1, 0.35, 1);
      coals.position.set(0, 0.07, 0);
      group.add(coals);
      const flames: THREE.Mesh[] = [];
      const fSpecs = [
        { x: 0, z: 0, s: 1.0, mat: flameOuterMat },
        { x: 0.06, z: -0.05, s: 0.72, mat: flameOuterMat },
        { x: -0.03, z: 0.04, s: 0.58, mat: flameCoreMat },
      ];
      for (const f of fSpecs) {
        const fl = new THREE.Mesh(flameGeo, f.mat);
        fl.position.set(f.x, 0.32 * f.s + 0.08, f.z);
        fl.scale.setScalar(f.s);
        group.add(fl);
        flames.push(fl);
      }
      scene.add(group);
      this.campfires.push({ flames, phase: idx * 1.9 });
    });
  }

  private countActive(id: SpeciesId): number {
    let n = 0;
    for (const c of this.pools[id]) if (c.active) n++;
    return n;
  }

  private allocate(id: SpeciesId): Creature | null {
    for (const c of this.pools[id]) {
      if (!c.active) {
        c.active = true;
        return c;
      }
    }
    return null;
  }

  private deactivate(c: Creature): void {
    c.active = false;
    const g = this.groups.get(c.group);
    if (g) g.members--;
  }

  private despawnAll(): void {
    for (const s of this.specs) for (const c of this.pools[s.id]) c.active = false;
    this.groups.clear();
  }

  private prime(px: number, pz: number): void {
    for (const spec of this.specs) {
      let attempts = 0;
      while (this.countActive(spec.id) < Math.ceil(spec.max * 0.75) && attempts < 70) {
        this.trySpawnGroup(spec, px, pz, true);
        attempts++;
      }
    }
  }

  private trySpawnGroup(spec: SpeciesSpec, px: number, pz: number, initial: boolean): boolean {
    const ang = Math.random() * Math.PI * 2;
    const minD = initial ? spec.minDist * 0.35 : spec.minDist;
    let d = minD + Math.random() * (spec.maxDist - minD);
    const ux = Math.cos(ang);
    const uz = Math.sin(ang);
    // Never pop creatures into view: in-view spawns are pushed out into the haze
    if (!initial && ux * _camFwd.x + uz * _camFwd.z > 0.5) d = Math.max(d, spec.maxDist * 0.9);
    const x = px + ux * d;
    const z = pz + uz * d;
    const w = sampleBiomeWeights(x, z);
    const suit = clamp(spec.habitat(w), 0, 1);
    if (suit < 0.15 || Math.random() > suit) return false;
    const h = sampleRenderedTerrain(x, z, _n);
    if (spec.terrain === 'land' && (h < WATER_LEVEL + 0.8 || _n[1] < spec.minNormalY)) return false;
    if (spec.terrain === 'water' && h > WATER_LEVEL - 1.3) return false;

    const count = spec.group[0] + Math.floor(Math.random() * (spec.group[1] - spec.group[0] + 1));
    const gid = this.nextGroup++;
    const group: Group = {
      id: gid,
      sp: spec.id,
      members: 0,
      tx: x,
      tz: z,
      timer: 2 + Math.random() * 4,
      alarm: 0,
      fx: 0,
      fz: 0,
      cx: x,
      cz: z,
      sumX: 0,
      sumZ: 0,
      cnt: 0,
      radius: 40 + Math.random() * 45,
      angle: Math.random() * Math.PI * 2,
      angSpeed: (Math.random() < 0.5 ? -1 : 1) * (0.1 + Math.random() * 0.08),
      alt: 26 + Math.random() * 26,
      groundAlt: Math.max(WATER_LEVEL, h),
      altTimer: 0,
      swoop: 0,
      swoopTimer: 20 + Math.random() * 40,
    };
    this.groups.set(gid, group);
    for (let k = 0; k < count; k++) {
      const c = this.allocate(spec.id);
      if (!c) break;
      group.members++;
      c.group = gid;
      this.initCreature(c, spec, group, k, count, h);
    }
    if (group.members === 0) {
      this.groups.delete(gid);
      return false;
    }
    return true;
  }

  private initCreature(c: Creature, spec: SpeciesSpec, g: Group, k: number, count: number, h: number): void {
    const x = g.tx;
    const z = g.tz;
    c.seed = Math.random();
    c.callTimer = spec.call[0] + Math.random() * spec.call[1];
    c.state = 0;
    c.timer = Math.random() * 3;
    c.phase = Math.random() * 10;
    c.speed = 0;
    c.pitch = 0;
    c.roll = 0;
    c.a = 0;
    c.b = 0;
    c.alt = 0;
    c.groundTimer = 0;
    c.yaw = Math.random() * Math.PI * 2;
    const ang = Math.random() * Math.PI * 2;
    const r = k === 0 ? 0 : Math.random() * spec.spread;
    c.x = x + Math.cos(ang) * r;
    c.z = z + Math.sin(ang) * r;
    c.ox = c.x - x;
    c.oz = c.z - z;
    c.tx = c.x;
    c.tz = c.z;
    if (spec.terrain === 'land') {
      const hh = sampleRenderedTerrain(c.x, c.z, _n);
      if (hh < WATER_LEVEL + 0.5) {
        c.x = x;
        c.z = z;
        c.groundY = h;
      } else {
        c.groundY = hh;
      }
    } else {
      c.groundY = Math.max(WATER_LEVEL, h);
    }
    c.y = c.groundY;

    switch (spec.id) {
      case 'grazer':
        c.scale = 0.85 + Math.random() * 0.45;
        c.color.copy(pick(PAL.grazerSkin));
        c.glow.copy(pick(PAL.grazerGlow));
        break;
      case 'strider':
        c.scale = 0.85 + Math.random() * 0.35;
        c.color.copy(pick(PAL.striderSkin));
        c.glow.copy(pick(PAL.striderGlow));
        c.timer = 0;
        break;
      case 'jelly':
        c.scale = 0.6 + Math.random() * 1.3;
        c.alt = 5 + Math.random() * 12;
        c.y = c.groundY + c.alt;
        c.color.copy(pick(PAL.jellySkin));
        c.glow.copy(pick(PAL.jellyGlow));
        break;
      case 'manta': {
        c.scale = 0.7 + Math.random() * 0.55;
        c.a = (k / Math.max(1, count)) * 0.9 + (Math.random() - 0.5) * 0.25;
        c.b = (Math.random() - 0.5) * 14;
        c.alt = (Math.random() - 0.5) * 8;
        const rad = Math.max(12, g.radius + c.b);
        c.x = g.tx + Math.cos(g.angle + c.a) * rad;
        c.z = g.tz + Math.sin(g.angle + c.a) * rad;
        c.y = g.groundAlt + g.alt + c.alt;
        c.color.copy(pick(PAL.mantaSkin));
        c.glow.copy(pick(PAL.mantaGlow));
        break;
      }
      case 'blob':
        c.scale = 0.8 + Math.random() * 0.5;
        c.color.copy(pick(PAL.blobSkin));
        c.glow.copy(pick(PAL.blobGlow));
        break;
      case 'wyrm': {
        c.scale = 0.85 + Math.random() * 0.4;
        c.color.copy(pick(PAL.wyrmSkin));
        c.glow.copy(pick(PAL.wyrmGlow));
        if (!c.trail) c.trail = new Float32Array(TRAIL_LEN * 3);
        for (let i = 0; i < TRAIL_LEN; i++) {
          c.trail[i * 3] = c.x;
          c.trail[i * 3 + 1] = c.groundY - 3;
          c.trail[i * 3 + 2] = c.z;
        }
        c.trailHead = 0;
        c.trailAcc = 0;
        c.phase = Math.random() * Math.PI * 2;
        break;
      }
      case 'titan':
        c.scale = 0.9 + Math.random() * 0.25;
        c.color.copy(pick(PAL.titanSkin));
        c.glow.copy(pick(PAL.titanGlow));
        c.timer = 0;
        break;
      case 'crab':
        c.scale = 0.6 + Math.random() * 0.5;
        c.color.copy(pick(PAL.crabSkin));
        c.glow.copy(pick(PAL.crabGlow));
        break;
      case 'fish':
        c.scale = 0.8 + Math.random() * 0.5;
        c.tx = x;
        c.tz = z;
        c.b = 2.5 + Math.random() * 4.5;
        c.a = Math.random() * Math.PI * 2;
        c.timer = 2 + Math.random() * 8;
        c.y = -0.75;
        c.color.copy(pick(PAL.fishSkin));
        c.glow.copy(pick(PAL.fishGlow));
        break;
      case 'thorn':
        c.scale = 0.9 + Math.random() * 0.3;
        c.color.copy(pick(PAL.thornSkin));
        c.glow.copy(pick(PAL.thornGlow));
        c.timer = 4;
        break;
    }
    const preyInfo = SPECIES_PREY_INFO[spec.id];
    c.maxHp = Math.round(preyInfo.maxHp * (0.85 + c.scale * 0.25) * this.hpMult);
    c.hp = c.maxHp;
    c.hurtTimer = 0;
    c.retaliateTimer = 0;
    c.menaceTimer = 0;
    c.attackMode = 0;
    c.attackTimer = 0;
    c.attackCooldown = 0;
    c.attackDidHit = false;
  }

  /** Find closest huntable creature within range for HUD lock-on & auto-aim */
  public getNearestTargetInfo(
    px: number,
    py: number,
    pz: number,
    maxRange = 32
  ): TargetCreatureInfo | null {
    let bestC: Creature | null = null;
    let bestSp: SpeciesId = 'blob';
    let bestScore = Infinity;
    let bestDist = Infinity;

    for (const spec of this.specs) {
      const info = SPECIES_PREY_INFO[spec.id];
      const pool = this.pools[spec.id];
      for (const c of pool) {
        if (!c.active) continue;
        const cy = c.y + info.heightOffset * c.scale;
        const dx = c.x - px;
        const dy = cy - py;
        const dz = c.z - pz;
        const dist = Math.hypot(dx, dy, dz);
        if (dist > maxRange) continue;
        // Favor creatures that are close or already damaged
        const damagedBonus = c.hp < c.maxHp ? 0.55 : 1.0;
        const score = dist * damagedBonus;
        if (score < bestScore) {
          bestScore = score;
          bestDist = dist;
          bestC = c;
          bestSp = spec.id;
        }
      }
    }

    if (!bestC) return null;
    const info = SPECIES_PREY_INFO[bestSp];
    const essDef = ESSENCES[info.primaryEssence];
    return {
      speciesId: bestSp,
      name: info.name,
      tier: info.tier,
      hp: Math.max(0, Math.ceil(bestC.hp)),
      maxHp: bestC.maxHp,
      dnaReward: info.dnaReward,
      essence: info.primaryEssence,
      essenceName: essDef.shortName,
      essenceColor: essDef.color,
      distance: Math.round(bestDist),
      x: bestC.x,
      y: bestC.y + info.heightOffset * bestC.scale,
      z: bestC.z,
    };
  }

  /**
   * Alien attack-back AI: telegraph (glowing red), charge/strike, then recover.
   * Returns true while the creature is actively attacking so normal grazing/flocking AI can pause.
   */
  private advanceAttackAI(
    c: Creature,
    sp: SpeciesId,
    preyInfo: (typeof SPECIES_PREY_INFO)[SpeciesId],
    dt: number,
    px: number,
    pz: number,
    playerPos: THREE.Vector3
  ): boolean {
    const data = ATTACK_DATA[sp];
    const dx = px - c.x;
    const dz = pz - c.z;
    const dist = Math.max(0.001, Math.hypot(dx, dz));
    const ux = dx / dist;
    const uz = dz / dist;
    const targetY = playerPos.y + (sp === 'jelly' || sp === 'manta' ? 1.5 : 0.4);

    if (c.attackMode === 0) {
      const provoked = c.menaceTimer > 0;
      if (
        c.attackCooldown <= 0 &&
        !this.playerCloaked &&
        (preyInfo.aggressive || provoked) &&
        dist < (provoked ? data.detect * 1.25 : data.detect) &&
        Math.abs(c.y - targetY) < (data.pulse ? 7.0 : 3.6)
      ) {
        c.attackMode = 1;
        c.attackTimer = 0.55;
        c.attackDidHit = false;
        c.yaw = Math.atan2(-ux, -uz);
        c.state = 2;
        this.call(sp, c, dist, this.specMap[sp].hear);
      }
      return false;
    }

    if (c.attackMode === 1) {
      // Telegraph: crouch/glow and close the last few metres toward the player
      c.yaw = Math.atan2(-ux, -uz);
      c.attackTimer -= dt;
      c.speed = data.charge * 0.55;
      if (data.charge > 0 && dist > data.reach * 0.72) {
        c.x += ux * c.speed * dt;
        c.z += uz * c.speed * dt;
        c.phase += dt * c.speed * 1.6;
      }
      if (data.pulse && dt > 0) {
        c.y = lerp(c.y, targetY, Math.min(1, dt * 0.7));
      }
      if (c.attackTimer <= 0) {
        c.attackMode = 2;
        c.attackTimer = 0.22;
      }
      return true;
    }

    if (c.attackMode === 2) {
      // Strike: brief lunge / pulse burst
      c.attackTimer -= dt;
      c.speed = data.charge * 1.9;
      if (data.charge > 0 && dist > data.reach * 0.6) {
        c.x += ux * c.speed * dt;
        c.z += uz * c.speed * dt;
        c.phase += dt * c.speed * 2.2;
      }
      const finalDist = Math.hypot(px - c.x, pz - c.z);
      if (
        !c.attackDidHit &&
        this.playerHitCooldown <= 0 &&
        finalDist <= data.reach + preyInfo.hitRadius * c.scale &&
        Math.abs(c.y - targetY) < 4.2
      ) {
        c.attackDidHit = true;
        this.playerHitCooldown = 0.85;
        const dmg = Math.max(
          2,
          Math.round(preyInfo.attackDamage * (0.85 + c.scale * 0.2) * this.dmgMult)
        );
        this.onPlayerDamaged?.(dmg, preyInfo.name, c.x, c.z);
        this.call(sp, c, finalDist, this.specMap[sp].hear);
        if (sp === 'fish' || sp === 'jelly' || sp === 'manta') {
          this.onSplash(c.x, c.z, 3.2);
        }
      }
      if (c.attackTimer <= 0) {
        c.attackMode = 3;
        c.attackTimer = data.cooldown;
        c.attackCooldown = data.cooldown + 0.6;
        c.menaceTimer = 0;
      }
      return true;
    }

    // Recover: back off slightly and cool down
    c.attackTimer -= dt;
    c.speed = Math.max(0, c.speed - dt * 6.0);
    if (dt > 0 && dist < data.reach * 1.3 && data.charge > 0) {
      c.x -= ux * 1.6 * dt;
      c.z -= uz * 1.6 * dt;
    }
    if (c.attackTimer <= 0) {
      c.attackMode = 0;
      c.attackDidHit = false;
    }
    return true;
  }

  private damageCreature(c: Creature, sp: SpeciesId, damage: number, px: number, pz: number): boolean {
    c.hp -= damage;
    c.hurtTimer = 0.28;
    // Being bitten makes even shy herbivores panic-defend themselves
    c.menaceTimer = 9.0;
    c.attackCooldown = Math.min(c.attackCooldown, 0.3);
    if (c.attackMode === 0 && !this.playerCloaked) {
      c.attackMode = 1;
      c.attackTimer = 0.4;
      c.attackDidHit = false;
    }
    const d = Math.hypot(c.x - px, c.z - pz);
    this.call(sp, c, d, this.specMap[sp].hear);

    // Alert herd or trigger flee/retaliation
    const g = this.groups.get(c.group);
    if (g) {
      const inv = 1 / Math.max(0.1, d);
      g.fx = (c.x - px) * inv;
      g.fz = (c.z - pz) * inv;
      g.alarm = 7;
    }

    if (c.hp <= 0) {
      const info = SPECIES_PREY_INFO[sp];
      const cy = c.y + info.heightOffset * c.scale;
      this.spawnDnaOrbs(c.x, cy, c.z, sp);
      this.deactivate(c);
      // Award immediate prey devour so evolution bar updates right away + orb magnetic visual!
      this.onPreyDevoured?.(sp);
      return true;
    }
    return false;
  }

  private spawnDnaOrbs(x: number, y: number, z: number, sp: SpeciesId): void {
    const info = SPECIES_PREY_INFO[sp];
    const essCol = new THREE.Color(ESSENCES[info.primaryEssence].color);
    let spawned = 0;
    for (let i = 0; i < this.dnaOrbs.length && spawned < 5; i++) {
      const orb = this.dnaOrbs[i];
      if (orb.active) continue;
      orb.active = true;
      orb.age = 0;
      orb.speciesId = sp;
      orb.x = x + (Math.random() - 0.5) * 0.8;
      orb.y = Math.max(getRenderedTerrainHeight(x, z) + 0.4, y);
      orb.z = z + (Math.random() - 0.5) * 0.8;
      const a = (spawned / 5) * Math.PI * 2 + Math.random() * 0.5;
      orb.vx = Math.cos(a) * (2.5 + Math.random() * 2.5);
      orb.vy = 4.2 + Math.random() * 3.0;
      orb.vz = Math.sin(a) * (2.5 + Math.random() * 2.5);
      (orb.mesh.material as THREE.MeshBasicMaterial).color.copy(essCol);
      orb.mesh.position.set(orb.x, orb.y, orb.z);
      orb.mesh.scale.setScalar(1.0);
      orb.mesh.visible = true;
      spawned++;
    }
  }

  /**
   * Perform a Spore-style melee Bite / Lunge attack!
   * Hits creatures within reach and returns the nearest prey position for lunge-assist.
   */
  public performMeleeStrike(
    px: number,
    py: number,
    pz: number,
    fwdX: number,
    fwdZ: number,
    damage: number,
    reach: number
  ): { hitCount: number; killedCount: number; lungeTarget: { x: number; z: number } | null } {
    let hitCount = 0;
    let killedCount = 0;
    let lungeTarget: { x: number; z: number } | null = null;
    let bestLungeDist = reach * 1.85;

    for (const spec of this.specs) {
      const info = SPECIES_PREY_INFO[spec.id];
      const pool = this.pools[spec.id];
      for (const c of pool) {
        if (!c.active) continue;
        const cy = c.y + info.heightOffset * c.scale;
        const dx = c.x - px;
        const dy = cy - (py + 0.8);
        const dz = c.z - pz;
        const horizDist = Math.hypot(dx, dz);
        const hitRad = reach + info.hitRadius * c.scale;

        if (horizDist < bestLungeDist && Math.abs(dy) < 5.5) {
          const dot = (dx * fwdX + dz * fwdZ) / Math.max(0.01, horizDist);
          if (dot > -0.25) {
            bestLungeDist = horizDist;
            lungeTarget = { x: c.x, z: c.z };
          }
        }

        if (horizDist <= hitRad && Math.abs(dy) <= 4.8) {
          hitCount++;
          if (this.damageCreature(c, spec.id, damage, px, pz)) {
            killedCount++;
          }
        }
      }
    }

    this.audio.playBiteSound(hitCount > 0);
    return { hitCount, killedCount, lungeTarget };
  }

  /**
   * Fire a ranged Bio-Plasma / Acid Globule!
   * Automatically homes toward the nearest targeted creature (including flying Skyjellies & Glidewings).
   */
  public fireBioProjectile(
    px: number,
    py: number,
    pz: number,
    fwdX: number,
    fwdZ: number,
    damage: number,
    colorHex = '#2dd4bf'
  ): void {
    const p = this.projectiles.find((pr) => !pr.active) ?? this.projectiles[0];
    p.active = true;
    p.age = 0;
    p.damage = damage;
    p.x = px + fwdX * 0.8;
    p.y = py + 0.9;
    p.z = pz + fwdZ * 0.8;

    const speed = 26.0;
    const target = this.getNearestTargetInfo(px, py, pz, 34);
    if (target) {
      const dx = target.x - p.x;
      const dy = target.y - p.y;
      const dz = target.z - p.z;
      const len = Math.max(0.01, Math.hypot(dx, dy, dz));
      p.vx = (dx / len) * speed;
      p.vy = (dy / len) * speed;
      p.vz = (dz / len) * speed;
    } else {
      p.vx = fwdX * speed;
      p.vy = 1.2;
      p.vz = fwdZ * speed;
    }

    (p.mesh.material as THREE.MeshBasicMaterial).color.set(colorHex);
    p.mesh.position.set(p.x, p.y, p.z);
    p.mesh.visible = true;
    this.audio.playSpitSound();
  }

  private steerLand(
    c: Creature,
    tx: number,
    tz: number,
    targetSpeed: number,
    dt: number,
    turnRate: number,
    minNormalY: number,
    minH: number
  ): void {
    const dx = tx - c.x;
    const dz = tz - c.z;
    const dist = Math.hypot(dx, dz);
    if (dist > 0.25 && targetSpeed > 0.01) {
      c.yaw += angleDiff(c.yaw, Math.atan2(-dx, -dz)) * Math.min(1, dt * turnRate);
    }
    c.speed = lerp(c.speed, dist < 0.6 ? 0 : targetSpeed, Math.min(1, dt * 2.4));
    if (c.speed > 0.02) {
      const nx = c.x - Math.sin(c.yaw) * c.speed * dt;
      const nz = c.z - Math.cos(c.yaw) * c.speed * dt;
      const h = sampleRenderedTerrain(nx, nz, _n);
      if (h > minH && _n[1] > minNormalY) {
        c.x = nx;
        c.z = nz;
        c.groundY = h;
        const fx = -Math.sin(c.yaw);
        const fz = -Math.cos(c.yaw);
        const slope = -(_n[0] * fx + _n[2] * fz) / Math.max(0.2, _n[1]);
        c.pitch = lerp(c.pitch, Math.atan(slope) * 0.85, Math.min(1, dt * 6));
      } else {
        c.yaw += dt * 3.2 * (c.seed > 0.5 ? 1 : -1);
        c.speed *= 0.6;
        c.tx = c.x - Math.sin(c.yaw) * 20;
        c.tz = c.z - Math.cos(c.yaw) * 20;
      }
    }
  }

  private call(kind: SpeciesId, c: Creature, d: number, hear: number): void {
    if (this.callCooldown > 0) return;
    const vol = Math.pow(clamp(1 - d / hear, 0, 1), 1.4);
    if (vol < 0.03) return;
    const dx = c.x - this.lastPX;
    const dz = c.z - this.lastPZ;
    const len = Math.hypot(dx, dz) || 1;
    const pan = clamp((dx * -_camFwd.z + dz * _camFwd.x) / len, -1, 1) * 0.85;
    this.audio.playCreatureCall(kind, vol, pan);
    this.callCooldown = 0.2;
  }

  private updateGroups(dt: number): void {
    for (const g of this.groups.values()) {
      if (g.members <= 0) {
        this.groups.delete(g.id);
        continue;
      }
      if (g.cnt > 0) {
        g.cx = g.sumX / g.cnt;
        g.cz = g.sumZ / g.cnt;
      }
      g.sumX = 0;
      g.sumZ = 0;
      g.cnt = 0;
      g.alarm = Math.max(0, g.alarm - dt);
      g.timer -= dt;

      if (g.sp === 'manta') {
        g.angle += g.angSpeed * dt;
        if (g.timer <= 0) {
          const a = Math.random() * Math.PI * 2;
          g.fx = Math.cos(a);
          g.fz = Math.sin(a);
          g.timer = 18 + Math.random() * 20;
        }
        g.tx += g.fx * 2.2 * dt;
        g.tz += g.fz * 2.2 * dt;
        g.altTimer -= dt;
        if (g.altTimer <= 0) {
          g.groundAlt = Math.max(WATER_LEVEL, sampleRenderedTerrain(g.tx, g.tz, null));
          g.altTimer = 2.0;
        }
        g.swoopTimer -= dt;
        if (g.swoopTimer <= 0) {
          g.swoop = 1;
          g.swoopTimer = 35 + Math.random() * 40;
        }
        g.swoop = Math.max(0, g.swoop - dt * 0.07);
      } else if (g.sp === 'grazer') {
        if (g.alarm <= 0 && (g.timer <= 0 || Math.hypot(g.tx - g.cx, g.tz - g.cz) < 4)) {
          const a = Math.random() * Math.PI * 2;
          const dist = 18 + Math.random() * 30;
          const tx = g.cx + Math.cos(a) * dist;
          const tz = g.cz + Math.sin(a) * dist;
          if (this.specMap.grazer.habitat(sampleBiomeWeights(tx, tz)) > 0.3) {
            g.tx = tx;
            g.tz = tz;
            g.timer = 14 + Math.random() * 20;
          } else {
            g.timer = 1.5;
          }
        }
      }
    }
  }

  public update(
    dt: number,
    elapsed: number,
    playerPos: THREE.Vector3,
    camera: THREE.Camera,
    playerSpeed: number,
    nightFactor: number
  ): void {
    this.mats.night.value = nightFactor;
    const gb = 0.9 + nightFactor * 1.8;
    const px = playerPos.x;
    const pz = playerPos.z;

    camera.getWorldDirection(_camFwd);
    _camFwd.y = 0;
    if (_camFwd.lengthSq() < 1e-6) _camFwd.set(0, 0, -1);
    _camFwd.normalize();

    if (!this.primed || Math.hypot(px - this.lastPX, pz - this.lastPZ) > 120) {
      this.despawnAll();
      this.lastPX = px;
      this.lastPZ = pz;
      this.prime(px, pz);
      this.primed = true;
    }
    this.lastPX = px;
    this.lastPZ = pz;
    this.callCooldown = Math.max(0, this.callCooldown - dt);
    this.playerHitCooldown = Math.max(0, this.playerHitCooldown - dt);

    for (let k = 0; k < 2; k++) {
      const spec = this.specs[this.spawnCursor];
      this.spawnCursor = (this.spawnCursor + 1) % this.specs.length;
      if (this.countActive(spec.id) < spec.max) this.trySpawnGroup(spec, px, pz, false);
    }

    this.updateGroups(dt);

    for (const spec of this.specs) {
      const pool = this.pools[spec.id];
      let slot = 0;
      for (const c of pool) {
        if (!c.active) continue;
        const d = Math.hypot(c.x - px, c.z - pz);
        if (d > spec.despawn) {
          this.deactivate(c);
          continue;
        }
        if (c.hurtTimer > 0) c.hurtTimer = Math.max(0, c.hurtTimer - dt);
        if (c.retaliateTimer > 0) c.retaliateTimer = Math.max(0, c.retaliateTimer - dt);
        if (c.menaceTimer > 0) c.menaceTimer = Math.max(0, c.menaceTimer - dt);
        if (c.attackCooldown > 0) c.attackCooldown = Math.max(0, c.attackCooldown - dt);

        const preyInfo = SPECIES_PREY_INFO[spec.id];
        // Aggressive / wounded wildlife now actively telegraphs and attacks back
        const attacking = this.advanceAttackAI(
          c,
          spec.id,
          preyInfo,
          dt,
          px,
          pz,
          playerPos
        );
        // Render-only tick (dt = 0) prevents normal grazing AI from fighting the attack movement
        const aiDt = attacking ? 0 : dt;

        const g = this.groups.get(c.group);
        if (g) {
          g.sumX += c.x;
          g.sumZ += c.z;
          g.cnt++;
        }
        const savedR = c.color.r;
        const savedG = c.color.g;
        const savedB = c.color.b;
        if (c.attackMode === 1) {
          // Red danger glow telegraph before the strike
          c.color.setRGB(1.4, 0.35 + 0.25 * Math.abs(Math.sin(elapsed * 12)), 0.28);
        } else if (c.hurtTimer > 0 || c.attackMode === 2) {
          c.color.setRGB(1.8, 0.35, 0.45);
        }
        switch (spec.id) {
          case 'grazer':
            this.grazer(c, slot, aiDt, elapsed, px, pz, playerSpeed, d, gb, g);
            break;
          case 'strider':
            this.strider(c, slot, aiDt, elapsed, px, pz, d, gb);
            break;
          case 'jelly':
            this.jelly(c, slot, aiDt, elapsed, d, gb, nightFactor);
            break;
          case 'manta':
            this.manta(c, slot, aiDt, elapsed, gb, g);
            break;
          case 'blob':
            this.blob(c, slot, aiDt, elapsed, px, pz, playerSpeed, d, gb);
            break;
          case 'wyrm':
            this.wyrm(c, slot, aiDt, px, pz, d, gb);
            break;
          case 'titan':
            this.titan(c, slot, aiDt, elapsed, px, pz, d, gb);
            break;
          case 'crab':
            this.crab(c, slot, aiDt, elapsed, px, pz, d, gb);
            break;
          case 'fish':
            this.fish(c, slot, aiDt, elapsed, d, gb);
            break;
          case 'thorn':
            this.thorn(c, slot, aiDt, elapsed, px, pz, d, gb);
            break;
        }
        c.color.setRGB(savedR, savedG, savedB);
        slot++;
        c.callTimer -= dt;
        if (c.callTimer <= 0) {
          c.callTimer = spec.call[0] + Math.random() * (spec.call[1] - spec.call[0]);
          if (d < spec.hear) this.call(spec.id, c, d, spec.hear);
        }
      }
      for (const b of Object.values(this.batches[spec.id])) b.commit(slot);
    }

    // Update ranged Bio-Plasma Spit Projectiles
    for (let i = 0; i < this.projectiles.length; i++) {
      const p = this.projectiles[i];
      if (!p.active) continue;
      p.age += dt;
      if (p.age > 2.2) {
        p.active = false;
        p.mesh.visible = false;
        continue;
      }
      p.x += p.vx * dt;
      p.y += p.vy * dt;
      p.z += p.vz * dt;
      p.mesh.position.set(p.x, p.y, p.z);
      p.mesh.rotation.x += dt * 8;
      p.mesh.rotation.y += dt * 11;

      // Check collision with any active creature
      let hit = false;
      for (const spec of this.specs) {
        const info = SPECIES_PREY_INFO[spec.id];
        const pool = this.pools[spec.id];
        for (const c of pool) {
          if (!c.active) continue;
          const cy = c.y + info.heightOffset * c.scale;
          const dist = Math.hypot(c.x - p.x, cy - p.y, c.z - p.z);
          if (dist <= info.hitRadius * c.scale + 0.9) {
            this.damageCreature(c, spec.id, p.damage, px, pz);
            this.audio.playBiteSound(true);
            hit = true;
            break;
          }
        }
        if (hit) break;
      }

      if (hit || p.y < getRenderedTerrainHeight(p.x, p.z) - 0.1) {
        p.active = false;
        p.mesh.visible = false;
      }
    }

    // Update glowing DNA / Biomass Orbs (arc up, then magnetize into player Slime!)
    for (let i = 0; i < this.dnaOrbs.length; i++) {
      const orb = this.dnaOrbs[i];
      if (!orb.active) continue;
      orb.age += dt;
      const toPx = px - orb.x;
      const toPy = playerPos.y + 0.75 - orb.y;
      const toPz = pz - orb.z;
      const dist = Math.hypot(toPx, toPy, toPz);

      if (orb.age < 0.32) {
        orb.x += orb.vx * dt;
        orb.y += orb.vy * dt;
        orb.z += orb.vz * dt;
        orb.vy -= 12.0 * dt;
      } else {
        const pullSpeed = 14.0 + orb.age * 18.0;
        const inv = 1 / Math.max(0.01, dist);
        orb.x += toPx * inv * pullSpeed * dt;
        orb.y += toPy * inv * pullSpeed * dt;
        orb.z += toPz * inv * pullSpeed * dt;
      }

      orb.mesh.position.set(orb.x, orb.y, orb.z);
      orb.mesh.rotation.y += dt * 6;
      orb.mesh.rotation.z += dt * 4;

      if (dist < 1.35 || orb.age > 3.5) {
        orb.active = false;
        orb.mesh.visible = false;
        this.audio.playDnaAbsorbSound();
      }
    }

    // Update 3D Target Lock Reticle Ring around nearest huntable creature
    const nearest = this.getNearestTargetInfo(px, playerPos.y, pz, 28);
    if (nearest) {
      const info = SPECIES_PREY_INFO[nearest.speciesId];
      const groundAtTarget = Math.max(WATER_LEVEL, getRenderedTerrainHeight(nearest.x, nearest.z));
      const ringY =
        nearest.speciesId === 'jelly' || nearest.speciesId === 'manta'
          ? nearest.y - 0.5
          : groundAtTarget + 0.08;
      this.targetRingMesh.position.set(nearest.x, ringY, nearest.z);
      const pulse = 1.0 + Math.sin(elapsed * 5.5) * 0.08;
      this.targetRingMesh.scale.setScalar(Math.max(0.9, info.hitRadius * 0.72) * pulse);
      this.targetRingMat.color.set(nearest.essenceColor);
      this.targetRingMesh.visible = true;
    } else {
      this.targetRingMesh.visible = false;
    }

    for (let i = 0; i < this.campfires.length; i++) {
      const cf = this.campfires[i];
      for (let f = 0; f < cf.flames.length; f++) {
        const fl = cf.flames[f];
        const t = elapsed * (8.5 + f * 2.3) + cf.phase + f;
        const base = f === 0 ? 1.0 : f === 1 ? 0.72 : 0.58;
        fl.scale.set(base * (0.9 + Math.sin(t) * 0.14), base * (0.85 + Math.cos(t * 1.3) * 0.24), base * (0.9 + Math.cos(t) * 0.14));
        fl.rotation.z = Math.sin(t * 0.8) * 0.14;
      }
    }
  }

  // ───────────────────────── Vexari Grazer (herds, stampedes) ─────────────────────────
  private grazer(c: Creature, slot: number, dt: number, t: number, px: number, pz: number, pSpeed: number, d: number, gb: number, g: Group | undefined): void {
    if (g && ((d < 16 && pSpeed > 2.6) || d < 8)) {
      if (g.alarm <= 0) {
        const inv = 1 / Math.max(0.001, d);
        g.fx = (c.x - px) * inv;
        g.fz = (c.z - pz) * inv;
        this.call('grazer', c, d, 120);
      }
      g.alarm = 6;
    }
    let tx: number;
    let tz: number;
    let spd: number;
    if (g && g.alarm > 0) {
      c.state = 2;
      tx = c.x + g.fx * 25 + c.ox * 0.2;
      tz = c.z + g.fz * 25 + c.oz * 0.2;
      spd = 8.5;
    } else {
      const gx = (g ? g.tx : c.tx) + c.ox;
      const gz = (g ? g.tz : c.tz) + c.oz;
      const dist = Math.hypot(gx - c.x, gz - c.z);
      if (dist > 3.5) {
        c.state = 1;
        spd = dist > 14 ? 2.4 : 1.4;
      } else {
        c.state = 0;
        spd = 0;
      }
      tx = gx;
      tz = gz;
    }
    this.steerLand(c, tx, tz, spd, dt, 2.2, 0.8, WATER_LEVEL + 0.6);
    if (c.speed > 0.08) c.phase += (dt * (1.0 + c.speed * 2.4)) / c.scale;
    const headDown = c.state === 0 ? 0.95 + Math.sin(t * 3 + c.seed * 10) * 0.07 : c.state === 2 ? -0.12 : 0.12;
    c.a = lerp(c.a, headDown, Math.min(1, dt * 3));

    const b = this.batches.grazer;
    const glow = _glow.copy(c.glow).multiplyScalar(gb);
    rootM(c.x, c.groundY, c.z, c.yaw, c.pitch, 0, c.scale);
    const run = clamp(c.speed / 8.5, 0, 1);
    const moving = clamp(c.speed / 1.4, 0, 1);
    const bob = Math.abs(Math.sin(c.phase)) * (0.03 + run * 0.12) * moving;
    toWorld(trs(_local, 0, 1.35 + bob, 0, 0, 0, Math.sin(c.phase) * 0.03 * moving));
    b.body.set(slot, 0, _world, c.color);
    b.plates.set(slot, 0, _world, glow);
    toWorld(trs(_local, 0, 1.5 + bob, -1.18, -c.a, Math.sin(t * 0.7 + c.seed * 7) * 0.15, 0));
    b.head.set(slot, 0, _world, c.color);
    b.eyes.set(slot, 0, _world, glow);
    const stride = (0.26 + run * 0.4) * moving;
    for (let i = 0; i < 6; i++) {
      const side = i % 2 === 0 ? -1 : 1;
      const row = (i / 2) | 0;
      const hz = -0.78 + row * 0.78;
      const off = i === 0 || i === 3 || i === 4 ? 0 : Math.PI;
      const ph = c.phase + off;
      const swing = Math.sin(ph) * stride;
      const lift = Math.max(0, Math.cos(ph)) * (0.16 + run * 0.2) * moving;
      _A.set(side * 0.4, 1.18 + bob, hz);
      _B.set(side * 0.82, lift, hz - swing);
      _K.set((_A.x + _B.x) * 0.5 + side * 0.22, (_A.y + _B.y) * 0.5 + 0.18, (_A.z + _B.z) * 0.5);
      toWorld(seg(_local, _A, _K, 0.085));
      b.upper.set(slot, i, _world, c.color);
      toWorld(seg(_local, _K, _B, 0.06));
      b.lower.set(slot, i, _world, c.color);
    }
  }

  // ───────────────────────── Longstrider (towering tripod) ─────────────────────────
  private strider(c: Creature, slot: number, dt: number, t: number, px: number, pz: number, d: number, gb: number): void {
    c.timer -= dt;
    if (d < 16) {
      const inv = 1 / Math.max(0.001, d);
      c.tx = c.x + (c.x - px) * inv * 40;
      c.tz = c.z + (c.z - pz) * inv * 40;
      c.timer = 10;
    } else if (c.timer <= 0 || Math.hypot(c.tx - c.x, c.tz - c.z) < 6) {
      const a = Math.random() * Math.PI * 2;
      const dist = 60 + Math.random() * 60;
      const tx = c.x + Math.cos(a) * dist;
      const tz = c.z + Math.sin(a) * dist;
      if (this.specMap.strider.habitat(sampleBiomeWeights(tx, tz)) > 0.3) {
        c.tx = tx;
        c.tz = tz;
        c.timer = 40;
      } else {
        c.timer = 2;
      }
    }
    this.steerLand(c, c.tx, c.tz, 1.7, dt, 0.5, 0.62, WATER_LEVEL + 0.4);
    c.phase += dt * c.speed * 0.42;

    const b = this.batches.strider;
    const glow = _glow.copy(c.glow).multiplyScalar(gb);
    rootM(c.x, c.groundY, c.z, c.yaw, c.pitch * 0.3, 0, c.scale);
    const bodyY = 8.6 + Math.sin(c.phase * 2) * 0.15;
    toWorld(trs(_local, 0, bodyY, 0, Math.sin(t * 0.6) * 0.04, 0, Math.cos(t * 0.5) * 0.04));
    b.body.set(slot, 0, _world, c.color);
    b.ring.set(slot, 0, _world, glow);
    toWorld(trs(_local, Math.sin(t * 0.9 + c.seed) * 0.3, bodyY - 1.15, Math.cos(t * 0.7) * 0.3, 0, 0, 0));
    b.sac.set(slot, 0, _world, glow);
    const moving = clamp(c.speed / 1.2, 0, 1);
    for (let i = 0; i < 3; i++) {
      const a = i * 2.094 + 0.52;
      const dx = Math.sin(a);
      const dz = Math.cos(a);
      const ph = c.phase + i * 2.094;
      const swing = Math.sin(ph) * 1.5 * moving;
      const lift = Math.max(0, Math.cos(ph)) * 1.3 * moving;
      _A.set(dx * 0.55, bodyY - 0.15, dz * 0.55);
      _B.set(dx * 6.4, lift, dz * 6.4 - swing);
      _K.set(dx * 3.6, bodyY + 3.0 + lift * 0.4, dz * 3.6 - swing * 0.5);
      toWorld(seg(_local, _A, _K, 0.16));
      b.upper.set(slot, i, _world, c.color);
      toWorld(seg(_local, _K, _B, 0.11));
      b.lower.set(slot, i, _world, c.color);
    }
  }

  // ───────────────────────── Skyjelly (drifting, pulsing) ─────────────────────────
  private jelly(c: Creature, slot: number, dt: number, t: number, d: number, gb: number, night: number): void {
    c.tx += this.windX * 0.45 * dt;
    c.tz += this.windZ * 0.45 * dt;
    c.x = c.tx + Math.sin(t * 0.13 + c.seed * 20) * 5;
    c.z = c.tz + Math.cos(t * 0.11 + c.seed * 13) * 5;
    c.groundTimer -= dt;
    if (c.groundTimer <= 0) {
      c.groundY = Math.max(WATER_LEVEL, sampleRenderedTerrain(c.x, c.z, null));
      c.groundTimer = 0.8 + Math.random() * 0.6;
    }
    const pulse = Math.sin(t * 1.5 + c.seed * 30);
    const lift = d < 9 ? 6 : 0;
    c.y = lerp(c.y, c.groundY + c.alt + lift + pulse * 0.3, Math.min(1, dt * 0.9));
    c.yaw += dt * 0.15 * (c.seed > 0.5 ? 1 : -1);

    const b = this.batches.jelly;
    const glow = _glow.copy(c.glow).multiplyScalar(gb);
    const bellTint = _tint.copy(c.color).multiplyScalar(0.55 + night * 0.9);
    rootM(c.x, c.y, c.z, c.yaw, 0, 0, c.scale);
    const sy = 1 - 0.16 * pulse;
    const sxz = 1 + 0.1 * pulse;
    toWorld(trs(_local, 0, 0, 0, 0, 0, 0, sxz, sy, sxz));
    b.bell.set(slot, 0, _world, bellTint);
    b.core.set(slot, 0, _world, glow);
    for (let k = 0; k < 6; k++) {
      const ang = k * 1.047 + c.seed * 6;
      _A.set(Math.cos(ang) * 0.82 * sxz, -0.12 * sy, Math.sin(ang) * 0.82 * sxz);
      for (let s = 0; s < 3; s++) {
        const len = (1.15 - s * 0.22) * (1 + 0.08 * pulse);
        const sway = Math.sin(t * 1.3 + s * 0.8 + k * 1.7 + c.seed * 9) * 0.32;
        const sway2 = Math.cos(t * 1.1 + s * 0.7 + k) * 0.28;
        _B.set(
          _A.x + Math.sin(sway) * len * 0.45 - Math.cos(ang) * 0.08 * s,
          _A.y - len,
          _A.z + Math.sin(sway2) * len * 0.45 - Math.sin(ang) * 0.08 * s
        );
        toWorld(seg(_local, _A, _B, 0.055 * (1 - s * 0.25)));
        b.tent.set(slot, k * 3 + s, _world, bellTint);
        _A.copy(_B);
      }
    }
  }

  // ───────────────────────── Glidewing (sky ray flocks) ─────────────────────────
  private manta(c: Creature, slot: number, dt: number, t: number, gb: number, g: Group | undefined): void {
    if (g) {
      const ang = g.angle + c.a;
      const rad = Math.max(12, g.radius + c.b);
      const swoopK = Math.sin(Math.PI * clamp(g.swoop, 0, 1));
      const alt = g.groundAlt + g.alt * (1 - swoopK * 0.78) + c.alt + Math.sin(t * 0.5 + c.seed * 10) * 2;
      const nx = g.tx + Math.cos(ang) * rad;
      const nz = g.tz + Math.sin(ang) * rad;
      const vx = nx - c.x;
      const vz = nz - c.z;
      if (vx * vx + vz * vz > 1e-6) c.yaw = Math.atan2(-vx, -vz);
      const climb = alt - c.y;
      c.x = nx;
      c.z = nz;
      c.y = lerp(c.y, alt, Math.min(1, dt * 0.7));
      c.roll = lerp(c.roll, g.angSpeed > 0 ? -0.32 : 0.32, Math.min(1, dt));
      c.pitch = clamp(climb * 0.02, -0.35, 0.35);
      c.phase += dt * (1.6 + Math.max(0, climb) * 0.05 + swoopK * 1.5);
    } else {
      c.x -= Math.sin(c.yaw) * 8 * dt;
      c.z -= Math.cos(c.yaw) * 8 * dt;
      c.phase += dt * 1.6;
    }

    const b = this.batches.manta;
    const glow = _glow.copy(c.glow).multiplyScalar(gb);
    rootM(c.x, c.y, c.z, c.yaw, c.pitch, c.roll, c.scale);
    toWorld(trs(_local, 0, Math.sin(c.phase) * -0.08, 0, 0, 0, 0));
    b.body.set(slot, 0, _world, c.color);
    b.tail.set(slot, 0, _world, c.color);
    b.eyes.set(slot, 0, _world, glow);
    const a1 = Math.sin(c.phase) * 0.32;
    const a2 = Math.sin(c.phase - 0.9) * 0.55 + a1 * 0.2;
    trs(_local, 0.55, 0, 0, 0, 0, a1);
    toWorld(_local);
    b.wingIn.set(slot, 0, _world, c.color);
    trs(_local2, 2.0, 0, 0, 0, 0, a2).premultiply(_local);
    toWorld(_local2);
    b.wingOut.set(slot, 0, _world, c.color);
    trs(_local, -0.55, 0, 0, 0, 0, Math.PI - a1);
    toWorld(_local);
    b.wingIn.set(slot, 1, _world, c.color);
    trs(_local2, 2.0, 0, 0, 0, 0, -a2).premultiply(_local);
    toWorld(_local2);
    b.wingOut.set(slot, 1, _world, c.color);
  }

  // ───────────────────────── Blobling (curious hoppers) ─────────────────────────
  private blob(c: Creature, slot: number, dt: number, t: number, px: number, pz: number, pSpeed: number, d: number, gb: number): void {
    const dx = px - c.x;
    const dz = pz - c.z;
    if (c.state !== 2 && ((pSpeed > 7 && d < 9) || d < 1.6)) {
      c.state = 2;
      c.timer = 2.5 + Math.random();
      this.call('blob', c, d, 30);
    } else if (c.state === 0 && d < 18 && pSpeed < 6 && c.seed > 0.3) {
      c.state = 1;
      c.timer = 8 + Math.random() * 8;
      this.call('blob', c, d, 30);
    }
    c.timer -= dt;
    if (c.timer <= 0) {
      c.state = 0;
      c.timer = 3 + Math.random() * 4;
      c.tx = c.x + (Math.random() - 0.5) * 16;
      c.tz = c.z + (Math.random() - 0.5) * 16;
    }
    let tx = c.tx;
    let tz = c.tz;
    let spd = 1.8;
    if (c.state === 2) {
      const inv = 1 / Math.max(0.001, d);
      tx = c.x - dx * inv * 10;
      tz = c.z - dz * inv * 10;
      spd = 7;
    } else if (c.state === 1) {
      const desired = 3.6 + c.seed * 1.5;
      const ang = Math.atan2(c.z - pz, c.x - px) + 0.25;
      tx = px + Math.cos(ang) * desired;
      tz = pz + Math.sin(ang) * desired;
      spd = d > desired + 1 ? 3.2 : 0.5;
    }
    this.steerLand(c, tx, tz, spd, dt, 5, 0.7, WATER_LEVEL + 0.3);
    if (c.state === 1 && c.speed < 1) c.yaw += angleDiff(c.yaw, Math.atan2(-dx, -dz)) * Math.min(1, dt * 4);
    c.phase += dt * (c.speed > 0.3 ? 2.6 + c.speed * 0.25 : 1.2);

    const b = this.batches.blob;
    const glow = _glow.copy(c.glow).multiplyScalar(gb);
    rootM(c.x, c.groundY, c.z, c.yaw, 0, 0, c.scale);
    const hopT = c.phase - Math.floor(c.phase);
    const air = c.speed > 0.25 ? 0.5 : 0.1;
    const arc = Math.sin(Math.PI * hopT);
    const hy = arc * air;
    const squash = Math.max(0, 1 - hopT / 0.12) + Math.max(0, (hopT - 0.9) / 0.1);
    const sy = 1 - squash * 0.22 + arc * 0.12;
    const sxz = 1 + squash * 0.16 - arc * 0.05;
    toWorld(trs(_local, 0, hy, 0, 0, 0, 0, sxz, sy, sxz));
    b.body.set(slot, 0, _world, c.color);
    for (let k = 0; k < 2; k++) {
      const side = k === 0 ? -1 : 1;
      const wob = Math.sin(t * 6 + side + c.seed * 5) * 0.04;
      _A.set(side * 0.12, hy + 0.58 * sy, -0.06);
      _B.set(side * 0.2 + wob, hy + 0.92 * sy, -0.12 + wob);
      toWorld(seg(_local, _A, _B, 0.025));
      b.stalk.set(slot, k, _world, c.color);
      toWorld(trs(_local, _B.x, _B.y, _B.z, 0, 0, 0));
      b.eye.set(slot, k, _world, glow);
    }
  }

  // ───────────────────────── Rift Wyrm (burrowing serpent) ─────────────────────────
  private wyrm(c: Creature, slot: number, dt: number, px: number, pz: number, d: number, gb: number): void {
    c.timer -= dt;
    if (c.timer <= 0) {
      c.b = (Math.random() - 0.5) * 0.9;
      c.timer = 2 + Math.random() * 3;
    }
    if (d < 14) c.yaw += angleDiff(c.yaw, Math.atan2(-(c.x - px), -(c.z - pz))) * Math.min(1, dt * 1.5);
    c.yaw += c.b * dt;
    const speed = 4.2 * c.scale;
    const nx = c.x - Math.sin(c.yaw) * speed * dt;
    const nz = c.z - Math.cos(c.yaw) * speed * dt;
    const h = sampleRenderedTerrain(nx, nz, null);
    if (h < WATER_LEVEL + 0.6) {
      c.yaw += dt * 2.5;
    } else {
      c.x = nx;
      c.z = nz;
      c.groundY = h;
    }
    const prevBreach = Math.sin(c.phase);
    c.phase += dt * 0.55;
    const breach = Math.sin(c.phase);
    if (prevBreach < 0 && breach >= 0 && d < 90) this.call('wyrm', c, d, 90);
    c.y = c.groundY + breach * 2.4 * c.scale - 0.9 * c.scale;

    const tr = c.trail as Float32Array;
    c.trailAcc += speed * dt;
    while (c.trailAcc >= TRAIL_STEP) {
      c.trailAcc -= TRAIL_STEP;
      c.trailHead = (c.trailHead + 1) % TRAIL_LEN;
      tr[c.trailHead * 3] = c.x;
      tr[c.trailHead * 3 + 1] = c.y;
      tr[c.trailHead * 3 + 2] = c.z;
    }

    const b = this.batches.wyrm;
    const glow = _glow.copy(c.glow).multiplyScalar(gb);
    const prevIdx = ((c.trailHead - 4) % TRAIL_LEN + TRAIL_LEN) % TRAIL_LEN;
    const headPitch = clamp(Math.atan2(c.y - tr[prevIdx * 3 + 1], 1.0), -0.8, 0.8);
    rootM(c.x, c.y, c.z, c.yaw, headPitch, 0, c.scale);
    toWorld(trs(_local, 0, 0, 0, 0, 0, 0));
    b.head.set(slot, 0, _world, c.color);
    b.eyes.set(slot, 0, _world, glow);

    const spacing = 0.68 * c.scale;
    let prevX = c.x;
    let prevZ = c.z;
    for (let i = 1; i <= WYRM_SEGMENTS; i++) {
      const back = Math.round((i * spacing) / TRAIL_STEP);
      const idx = ((c.trailHead - back) % TRAIL_LEN + TRAIL_LEN) % TRAIL_LEN;
      const sx = tr[idx * 3];
      const sy = tr[idx * 3 + 1];
      const sz = tr[idx * 3 + 2];
      const r = (0.56 - i * 0.026) * c.scale;
      _q.identity();
      _world.compose(_p.set(sx, sy, sz), _q, _s.set(r, r, r));
      b.seg.set(slot, i - 1, _world, c.color);
      const yawS = Math.atan2(-(prevX - sx), -(prevZ - sz));
      _e.set(0.55, yawS, 0, 'YXZ');
      _q.setFromEuler(_e);
      _world.compose(_p.set(sx, sy + r * 0.8, sz), _q, _s.set(r * 0.55, r * 0.75, r * 0.55));
      b.spike.set(slot, i - 1, _world, glow);
      prevX = sx;
      prevZ = sz;
    }
  }

  // ───────────────────────── Titan Colossus (walking hill) ─────────────────────────
  private titan(c: Creature, slot: number, dt: number, t: number, px: number, pz: number, d: number, gb: number): void {
    c.timer -= dt;
    if (d < 85) {
      const inv = 1 / Math.max(0.001, d);
      c.tx = c.x + (c.x - px) * inv * 80;
      c.tz = c.z + (c.z - pz) * inv * 80;
      c.timer = 20;
    } else if (c.timer <= 0 || Math.hypot(c.tx - c.x, c.tz - c.z) < 12) {
      const a = Math.random() * Math.PI * 2;
      const dist = 140 + Math.random() * 80;
      const tx = c.x + Math.cos(a) * dist;
      const tz = c.z + Math.sin(a) * dist;
      if (this.specMap.titan.habitat(sampleBiomeWeights(tx, tz)) > 0.3) {
        c.tx = tx;
        c.tz = tz;
        c.timer = 90;
      } else {
        c.timer = 2;
      }
    }
    this.steerLand(c, c.tx, c.tz, 1.05, dt, 0.18, 0.5, WATER_LEVEL + 0.8);
    c.phase += dt * c.speed * 0.22;

    const b = this.batches.titan;
    const glow = _glow.copy(c.glow).multiplyScalar(gb);
    rootM(c.x, c.groundY, c.z, c.yaw, c.pitch * 0.25, 0, c.scale);
    const moving = clamp(c.speed / 0.8, 0, 1);
    const bob = Math.sin(c.phase * 2) * 0.35 * moving;
    toWorld(trs(_local, 0, 19.5 + bob, 0, 0, 0, Math.sin(c.phase) * 0.02));
    b.body.set(slot, 0, _world, c.color);
    b.spots.set(slot, 0, _world, glow);
    toWorld(trs(_local, 0, 19.6 + bob, -11.4, Math.sin(t * 0.3) * 0.06 - 0.05, Math.sin(t * 0.17 + c.seed) * 0.12, 0));
    b.head.set(slot, 0, _world, c.color);
    b.eyes.set(slot, 0, _world, glow);
    const offs = [0, Math.PI, Math.PI * 1.5, Math.PI * 0.5];
    for (let i = 0; i < 4; i++) {
      const side = i % 2 === 0 ? -1 : 1;
      const front = i < 2 ? -1 : 1;
      const ph = c.phase + offs[i];
      const swing = Math.sin(ph) * 2.8 * moving;
      const lift = Math.max(0, Math.cos(ph)) * 1.8 * moving;
      _A.set(side * 5.4, 18.2 + bob, front * 7.2);
      _B.set(side * 8.4, lift, front * 8.6 - swing);
      _K.set((_A.x + _B.x) * 0.5 + side * 2.4, (_A.y + _B.y) * 0.5 + 1.6, (_A.z + _B.z) * 0.5);
      toWorld(seg(_local, _A, _K, 1.35));
      b.upper.set(slot, i, _world, c.color);
      toWorld(seg(_local, _K, _B, 1.05));
      b.lower.set(slot, i, _world, c.color);
    }
    for (let k = 0; k < 6; k++) {
      const ax = k % 2 === 0 ? -2.6 : 2.6;
      const az = -4 + Math.floor(k / 2) * 4;
      _A.set(ax, 16.4 + bob, az);
      for (let s = 0; s < 3; s++) {
        const sway = Math.sin(t * 0.8 + k * 1.3 + s * 0.6) * 0.35;
        _B.set(_A.x + Math.sin(sway) * 1.2, _A.y - 2.8, _A.z + Math.cos(sway * 1.3) * 0.6);
        toWorld(seg(_local, _A, _B, 0.24 - s * 0.05));
        b.tendril.set(slot, k * 3 + s, _world, glow);
        _A.copy(_B);
      }
    }
  }

  // ───────────────────────── Prism Crab (sideways scuttler) ─────────────────────────
  private crab(c: Creature, slot: number, dt: number, t: number, px: number, pz: number, d: number, gb: number): void {
    const rightX = Math.cos(c.yaw);
    const rightZ = -Math.sin(c.yaw);
    if (d < 6.5 && c.state !== 2) {
      c.state = 2;
      c.timer = 1.6;
      c.a = (c.x - px) * rightX + (c.z - pz) * rightZ >= 0 ? 1 : -1;
      this.call('crab', c, d, 25);
    }
    c.timer -= dt;
    if (c.timer <= 0) {
      if (c.state === 0) {
        c.state = 1;
        c.timer = 0.5 + Math.random();
        c.a = Math.random() < 0.5 ? 1 : -1;
        c.yaw += (Math.random() - 0.5) * 1.2;
      } else {
        c.state = 0;
        c.timer = 1 + Math.random() * 2.5;
      }
    }
    const spd = c.state === 1 ? 2.6 : c.state === 2 ? 5.2 : 0;
    c.speed = lerp(c.speed, spd, Math.min(1, dt * 8));
    if (c.speed > 0.05) {
      const nx = c.x + rightX * c.a * c.speed * dt;
      const nz = c.z + rightZ * c.a * c.speed * dt;
      const h = sampleRenderedTerrain(nx, nz, _n);
      if (h > WATER_LEVEL + 0.1 && _n[1] > 0.6) {
        c.x = nx;
        c.z = nz;
        c.groundY = h;
      } else {
        c.a *= -1;
      }
    }
    c.phase += dt * (c.speed > 0.1 ? 16 : 1.5);

    const b = this.batches.crab;
    const glow = _glow.copy(c.glow).multiplyScalar(gb);
    rootM(c.x, c.groundY, c.z, c.yaw, 0, 0, c.scale);
    const bob = Math.abs(Math.sin(c.phase)) * 0.025;
    toWorld(trs(_local, 0, 0.3 + bob, 0, 0, 0, 0));
    b.body.set(slot, 0, _world, c.color);
    b.crystals.set(slot, 0, _world, glow);
    const active = c.speed > 0.1 ? 1 : 0.2;
    for (let i = 0; i < 6; i++) {
      const side = i < 3 ? -1 : 1;
      const row = i % 3;
      const hz = -0.18 + row * 0.18;
      const ph = c.phase + row * 2.1 + (side > 0 ? Math.PI : 0);
      const lift = Math.max(0, Math.sin(ph)) * 0.08 * active;
      _A.set(side * 0.36, 0.3 + bob, hz);
      _K.set(side * 0.62, 0.48 + lift, hz * 1.4);
      _B.set(side * 0.84, lift * 0.5, hz * 1.7 + Math.cos(ph) * 0.05 * active);
      toWorld(seg(_local, _A, _K, 0.035));
      b.upper.set(slot, i, _world, c.color);
      toWorld(seg(_local, _K, _B, 0.025));
      b.lower.set(slot, i, _world, c.color);
    }
    const snip = c.state === 0 ? Math.sin(t * 4 + c.seed * 6) * 0.25 : 0.1;
    for (let k = 0; k < 2; k++) {
      const side = k === 0 ? -1 : 1;
      toWorld(trs(_local, side * 0.3, 0.33 + bob, -0.42, 0, side * (0.3 + snip), 0));
      b.claw.set(slot, k, _world, c.color);
    }
  }

  // ───────────────────────── Glowfin (leaping fish) ─────────────────────────
  private fish(c: Creature, slot: number, dt: number, t: number, d: number, gb: number): void {
    const dirSign = c.seed > 0.5 ? 1 : -1;
    const angSpeed = 0.55 + c.seed * 0.5;
    c.a += dt * angSpeed * dirSign;
    const nx = c.tx + Math.cos(c.a) * c.b;
    const nz = c.tz + Math.sin(c.a) * c.b;
    const vx = nx - c.x;
    const vz = nz - c.z;
    if (vx * vx + vz * vz > 1e-8) c.yaw = Math.atan2(-vx, -vz);
    c.x = nx;
    c.z = nz;
    c.timer -= dt;
    if (c.state === 0 && c.timer <= 0) {
      c.state = 1;
      c.phase = 0;
      this.onSplash(c.x, c.z, 1.8);
      if (d < 40) this.call('fish', c, d, 40);
    }
    let pitch = 0;
    if (c.state === 1) {
      c.phase += dt / 1.1;
      const p = Math.min(1, c.phase);
      c.y = -0.55 + 4 * 1.75 * p * (1 - p);
      const horiz = Math.max(0.5, angSpeed * c.b * 1.1);
      pitch = Math.atan((4 * 1.75 * (1 - 2 * p)) / horiz);
      if (c.phase >= 1) {
        c.state = 0;
        c.timer = 3.5 + Math.random() * 8;
        this.onSplash(c.x, c.z, 2.2);
      }
    } else {
      c.y = -0.75 + Math.sin(t * 2 + c.seed * 9) * 0.06;
    }

    const b = this.batches.fish;
    const glow = _glow.copy(c.glow).multiplyScalar(gb);
    rootM(c.x, c.y, c.z, c.yaw, pitch, 0, c.scale);
    toWorld(trs(_local, 0, 0, 0, 0, 0, 0));
    b.body.set(slot, 0, _world, c.color);
    b.stripe.set(slot, 0, _world, glow);
    toWorld(trs(_local, 0, 0, 0.42, 0, Math.sin(t * 9 + c.seed * 20) * 0.45, 0));
    b.tail.set(slot, 0, _world, c.color);
  }

  // ───────────────────────── Thornback (stalking prowler) ─────────────────────────
  private thorn(c: Creature, slot: number, dt: number, t: number, px: number, pz: number, d: number, gb: number): void {
    c.timer -= dt;
    if (d < 11 && c.state !== 2) {
      c.state = 2;
      c.timer = 4;
      this.call('thorn', c, d, 70);
    } else if (c.state === 0 && d < 50 && Math.random() < dt * 0.3) {
      c.state = 1;
      c.timer = 14 + Math.random() * 12;
      c.b = Math.atan2(c.z - pz, c.x - px);
    } else if (c.state === 1 && Math.random() < dt * 0.12) {
      c.state = 3;
      c.timer = 2 + Math.random() * 2.5;
    }
    if (c.timer <= 0) {
      if (c.state === 3) {
        c.state = 1;
        c.timer = 6 + Math.random() * 6;
      } else {
        c.state = 0;
        c.timer = 6 + Math.random() * 6;
        c.tx = c.x + (Math.random() - 0.5) * 40;
        c.tz = c.z + (Math.random() - 0.5) * 40;
      }
    }
    let tx = c.tx;
    let tz = c.tz;
    let spd = 2.2;
    if (c.state === 1) {
      c.b += dt * 0.11 * (c.seed > 0.5 ? 1 : -1);
      tx = px + Math.cos(c.b) * 24;
      tz = pz + Math.sin(c.b) * 24;
      spd = 3.4;
    } else if (c.state === 2) {
      const inv = 1 / Math.max(0.001, d);
      tx = c.x + (c.x - px) * inv * 30;
      tz = c.z + (c.z - pz) * inv * 30;
      spd = 9.5;
    } else if (c.state === 3) {
      spd = 0;
      tx = c.x;
      tz = c.z;
    }
    this.steerLand(c, tx, tz, spd, dt, 3.0, 0.75, WATER_LEVEL + 0.5);
    const look = Math.atan2(-(px - c.x), -(pz - c.z));
    if (c.state === 1 || c.state === 3) {
      c.a = lerp(c.a, clamp(angleDiff(c.yaw, look), -0.9, 0.9), Math.min(1, dt * 3));
      if (c.state === 3) c.yaw += angleDiff(c.yaw, look) * Math.min(1, dt * 2);
    } else {
      c.a = lerp(c.a, 0, Math.min(1, dt * 3));
    }
    c.phase += dt * (0.6 + c.speed * 1.9);

    const b = this.batches.thorn;
    const glow = _glow.copy(c.glow).multiplyScalar(gb * (c.state === 1 || c.state === 3 ? 1.5 : 1));
    rootM(c.x, c.groundY, c.z, c.yaw, c.pitch, 0, c.scale);
    const run = clamp(c.speed / 9.5, 0, 1);
    const moving = clamp(c.speed / 1.2, 0, 1);
    const bob = Math.abs(Math.sin(c.phase)) * (0.03 + run * 0.1) * moving;
    toWorld(trs(_local, 0, 1.0 + bob, 0, 0, 0, 0));
    b.body.set(slot, 0, _world, c.color);
    b.spines.set(slot, 0, _world, glow);
    toWorld(trs(_local, 0, 1.12 + bob, -1.05, -0.05 + Math.sin(t * 1.3) * 0.03, c.a, 0));
    b.head.set(slot, 0, _world, c.color);
    b.eyes.set(slot, 0, _world, glow);
    const stride = (0.3 + run * 0.5) * moving;
    for (let i = 0; i < 4; i++) {
      const side = i % 2 === 0 ? -1 : 1;
      const front = i < 2 ? -1 : 1;
      const off = i === 0 || i === 3 ? 0 : Math.PI;
      const ph = c.phase + off;
      const swing = Math.sin(ph) * stride;
      const lift = Math.max(0, Math.cos(ph)) * (0.15 + run * 0.2) * moving;
      _A.set(side * 0.3, 0.92 + bob, front * 0.62);
      _B.set(side * 0.38, lift, front * 0.62 - swing);
      _K.set(side * 0.4, (_A.y + _B.y) * 0.5 + 0.05, front * 0.62 + (front < 0 ? 0.12 : -0.12) - swing * 0.5);
      toWorld(seg(_local, _A, _K, 0.085));
      b.upper.set(slot, i, _world, c.color);
      toWorld(seg(_local, _K, _B, 0.06));
      b.lower.set(slot, i, _world, c.color);
    }
    _A.set(0, 1.08 + bob, 1.0);
    for (let s = 0; s < 4; s++) {
      const sway = Math.sin(t * 2.2 + s * 0.7 + c.seed * 7) * 0.25 * (1 + s * 0.4);
      _B.set(_A.x + Math.sin(sway) * 0.42, _A.y - 0.05, _A.z + Math.cos(sway) * 0.4);
      toWorld(seg(_local, _A, _B, 0.09 * (1 - s * 0.2)));
      b.tail.set(slot, s, _world, c.color);
      _A.copy(_B);
    }
  }
}
